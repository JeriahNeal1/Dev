# RK03 bounded physical release

Separate native derivation of the sealed bounded offline model and proven identity host. The host permits exactly one fixed read at address0, length512, after the validated identity;25 requests maximum, then cleanup. No physical authorization is provided by this source tree.

Original identity source remains unchanged in ../kernel_identity_physical as historical reference. New native source is src/. Build only with tools/build_probe.py build_a or build_b. Offline fixtures do not load the provider. Physical mode requires a new sealed certificate, fresh simplified states and the exact bounded authorization token. No final full-ROM run is allowed in this session.
