#pragma once
#include "common.hpp"
// Only the fixed pass0/address0/512-byte response is representable here.
// Data comparison occurs after complete framing validation so all mismatches survive.
struct BoundedReply {
 Bytes bytes;unsigned pieces=0,indicators=0;
 static Bytes request(){return decode("beef00080300000000000200ba");}
 static Bytes expected(){return decode("beef020683000000000000000aacffffbfa000000aacffffbfa000000aa800000aa800000aa800000aa800000aa800000aa800000aa800000aa800000aa800000aa8ffffffffffffffffdf01442b00090000ffffbfa0df01000b00090000ffffbfa0e5f74518750a8451e3ff4318620c737f2239324ce13c622c4118321c25210009000900090009000b0009ffff8441600c937f20388b04d643947c917c412be506000b00098441600c937320388b04d63e94729170412be506000b0009d33b7402d23b2342d13b412b6422634392614f227ff81f418431600c202988048b0c6433b0287402d3326503b03764322f0066f394539350430be5017f084f26000b00098441600c934520388b04d62b94469142412be506000b00098441600c933920388b060002913b2019cbf0400eaffe0009000b00098441600c624040286303622c84424228600c4018330c42188443332c600c6433340c000b60432fe62fd66d432fc66c532fb63dc24f229b198d0aee0062d4622c3e2c64ed441934ec4b0b6e4c3dc28bf54f2660e36bf66cf66df6000b6ef6ff07008804e0009000b000c0ff0f04c4ffff00000fec00000ff8ffffbfa4ffffbfa00000004000000fe42fe62fd62fc62fb62fa62f962f864f2295ab6453d361430b74fed26193a62321de6092a422e1d15e90a22011730623e1721222e1919d21e1731223e1720622e1711a21e1730e23e172c022e1e7");}
 bool consume(const PASSTHRU_MSG& m,const Bytes& tx){
  require(++pieces<=527,"Bounded RX message count bound");
  require(m.ProtocolID==3&&m.TxFlags==0&&m.DataSize<=523&&(m.ExtraDataIndex==0||m.ExtraDataIndex==m.DataSize),"Bounded RX metadata bounds");
  Bytes data(m.Data,m.Data+m.DataSize);
  if(m.RxStatus){
   require(bytes.empty()&&++indicators<=4,"Bounded RX indication position/count");
   if(m.RxStatus==START_OF_MESSAGE||m.RxStatus==TX_DONE)require(data.empty(),"Nonempty bounded indication");
   else if(m.RxStatus==TX_MSG_TYPE||m.RxStatus==(TX_MSG_TYPE|TX_DONE))require(data==tx,"Unexpected bounded TX echo");
   else require(false,"Unknown bounded RX status");
   return false;
  }
  require(!data.empty()&&bytes.size()+data.size()<=523,"Bounded reply exact maximum");
  bytes.insert(bytes.end(),data.begin(),data.end());
  const Bytes header=decode("beef0206830000000000");
  require(std::equal(bytes.begin(),bytes.begin()+std::min(bytes.size(),header.size()),header.begin()),"Fixed framing length command pass address");
  if(bytes.size()<523)return false;
  require(bytes.back()==checksum(Bytes(bytes.begin(),bytes.end()-1)),"Bounded response checksum");
  return true;
 }
};
