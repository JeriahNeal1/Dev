#pragma once
static constexpr const char* CONTRACT_SHA="be14e560229f5a7eb1904cc18c47dc9c36fe6df3b79c86be12f844640fe15e02";
static constexpr const char* PROVIDER_SHA="f432084801762d919a3c31974616e097562424470003edc4f4fb843df34103cf";
static constexpr const char* SESSION_ID="RK03_BOUNDED_ROM_READ_01";
static constexpr const char* AUTH_TOKEN="PROCEED RK03 BOUNDED ROM READ";
static constexpr const wchar_t* CONTRACT_PATH=L"C:\\Dev\\A2WC511R_Final\\analysis\\rk03_bounded_read_physical_20260930_01\\PHYSICAL_BOUNDED_REVIEW_CONTRACT.json";
static constexpr const wchar_t* PROVIDER_PATH=L"C:\\Windows\\SysWOW64\\op20pt32.dll";
static constexpr const wchar_t* SESSION_PATH=L"C:\\Dev\\A2WC511R_RK03_BoundedReadPhysical\\physical_session\\RK03_BOUNDED_ROM_READ_01";
