"""Independent root review of reviewer-authored fake data/tests and native derivation."""
from pathlib import Path
import hashlib,json,re,difflib
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent/'kernel_identity_physical'
OUT=Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_bounded_read_physical_20260930_01')
def pin(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def read(p):return json.loads(Path(p).read_text())
checks=[]
def check(ok,label):
 assert ok,label
 checks.append(label)
def part(s,start,end):return s[s.index(start):s.index(end,s.index(start))]
core=(ROOT/'src/probe_core.hpp').read_text();old=(BASE/'src/probe_core.hpp').read_text();parser=(ROOT/'src/bounded_response.hpp').read_text();main=(ROOT/'src/main.cpp').read_text();fake=(ROOT/'src/fake_backend.hpp').read_text()
for name in ['common.hpp','protocol.hpp','bootstrap.hpp','bootstrap_tests.hpp','owned_artifact.h','j2534_tactrix.h','identity_response.hpp','real_clock.hpp','fixtures.hpp','physical_replay.hpp','first_physical_replay.hpp','full_physical_replay.hpp']:
 check((ROOT/'src'/name).read_bytes()==(BASE/'src'/name).read_bytes(),'unchanged_proven_'+name)
for start,end in [(' void setup()', ' Bytes exchange('),(' void identity_transport()', ' int run()'),(' template<class F> long cleanup_call',' void identity_transport()')]:
 check(part(core,start,end)==part(old,start,end),'unchanged_'+start.strip())
check(part(core,'try{setup();','identity_validated=true;')==part(old,'try{setup();','identity_validated=true;'),'entire_prefix_sequence_unchanged')
check(core.count('exchange(24)')==1 and 'stage<25' in core and 'next_tx<25' in core,'one_fixed_new_exchange_and25_boundary')
check('if(stage==24){require(identity_validated&&kernel_filter&&filtered&&requested_baud==62500' in core,'fixed_read_requires_validated_identity')
check('return BoundedReply::request();' in core and 'beef00080300000000000200ba' in parser,'fixed_read_wire_no_address_arguments')
check('m.DataSize<=523' in parser and '++pieces<=527' in parser and '++indicators<=4' in parser,'bounded_stream_metadata_fragment_limits')
check('beef0206830000000000' in parser and 'Bounded response checksum' in parser,'fixed_reply_header_length_pass_address_checksum')
check('require(reply==expected' in core and 'for(unsigned i=0;i<512;i++)' in core,'exact_current_bytes_comparison_full_mismatch_evidence')
check(core.index('require(reply==expected')<core.index('bounded_validated=true;protocol_complete=true'),'validation_precedes_success_flags')
check('GetTickCount64()+2000' in core and 'Whole frame deadline after API return' in core,'retained_whole_frame_deadline_pre_and_post_read')
check(main.count('LoadLibraryExW(')==1 and main.index('gate.lock_provider(b)')<main.index('LoadLibraryExW('),'fixed_provider_only_after_native_gates')
check('argc==6' in main and '--physical-bounded-rom-read' in main,'physical_cli_no_address_length_payload_selection')
for unsupported in ['ReadProcessMemory','WriteProcessMemory','VirtualAllocEx','CreateRemoteThread']:
 check(unsupported not in core+main,'no_unrelated_operation_'+unsupported)
check('s.writes>=25' in fake and 's.queue.empty()' in fake,'fake_independent_count_and_pending_reply_guards')
check('identity_physical_replay_message(stage*2)' in fake and 'stage<24&&is("physical_identity_replay")' in fake,'exact_physical_prefix_fixture')
check('BoundedReply::expected()' in fake,'fixed_fake_reply_seeded_from_pinned_contract')
check('s.writes==25' in fake and 'Sleep(2100)' in fake,'late_and_transport_failure_injection_at_new_read_only')
check('for(unsigned offset=0;offset<512;offset++)' in fake and 'b[10+offset]^=1' in fake,'every_data_position_corruption_fixture')
c=read(OUT/'PHYSICAL_BOUNDED_REVIEW_CONTRACT.json');expected=bytes.fromhex(c['bounded_read']['response']);raw=Path(r'C:\Dev\SubaruRoms\current.bin').read_bytes()
check(expected[10:-1]==raw[:512] and len(expected)==523 and sum(expected[:-1])&255==expected[-1],'independent_current_file_response_match')
check(hashlib.sha256(raw).hexdigest()=='bf10be6d7c75b4f2ae663b0d57a912e6e9ef7654ccfc985195954596e50427b2','current_ROM_pin_retained')
check(hashlib.sha256(expected).hexdigest()=='796f64cefcd2b81c5c7662b2bdacad828c0a948c55bfdc5d002ac5c8da7f898e','sealed_offline_response_pin')
builds=[read(ROOT/n/'BUILD.json') for n in ('build_a','build_b')]
check(Path(builds[0]['exe_path']).read_bytes()==Path(builds[1]['exe_path']).read_bytes(),'two_clean_outputs_identical')
check(builds[0]['source_inputs']==builds[1]['source_inputs'],'two_clean_input_manifests_identical')
for p in builds[0]['source_inputs']:check(pin(p['path'])['sha256']==p['sha256'],'unchanged_build_input_'+Path(p['path']).name)
report=read(read(ROOT/'reports/LATEST_QUALIFICATION.json')['report']['path'])
check(report['status']=='PASS' and report['passed_cases']==report['test_cases'],'new_native_cases_all_pass')
check(report['physical_operations']==report['real_provider_loads']==0,'qualification_fake_only')
# Independently read every journal and verify actual TX/failure boundaries.
for case in report['cases']:
 if 'journal' not in case:continue
 p=case['journal'];check(pin(p['path'])['sha256']==p['sha256'],'journal_pin_'+case['case'])
 rows=[json.loads(line) for line in Path(p['path']).read_text().splitlines()]
 writes=[r for r in rows if r.get('type')=='api_intent' and r.get('function')=='PassThruWriteMsgs']
 check(len(writes)<=25,'max25_'+case['case'])
 if len(writes)==25:check(writes[-1]['input']['message']['data_hex']==c['bounded_read']['request'],'fixed_final_request_'+case['case'])
 check(all(r.get('physical',False) is False for r in rows),'fake_only_'+case['case'])
 terminal=rows[-1]
 if terminal.get('status')=='PASS_OFFLINE_BOUNDED_ROM_READ_ONLY':
  events=[r for r in rows if r.get('type')=='bounded_read_result'];check(len(events)==1 and events[0]['response_hex']==expected.hex(),'exact_positive_reply_'+case['case'])
  check(terminal['state']['bounded_validated'] and terminal['cleanup_confirmed'] and len(writes)==25,'validated_terminal_'+case['case'])
out=OUT/'root_review';out.mkdir(exist_ok=False)
(out/'SOURCE_DIFF.txt').write_text(''.join(difflib.unified_diff(old.splitlines(True),core.splitlines(True),fromfile='sealed_identity/probe_core.hpp',tofile='bounded/probe_core.hpp')))
result=dict(status='PASS',checks_passed=len(checks),checks=checks,reviewer='root independent review of passive_review fixtures/runner, native scope, actual journals and preserved prefix',files=[pin(ROOT/'src'/n) for n in ['fake_backend.hpp','identity_physical_replay.hpp','probe_core.hpp','bounded_response.hpp','main.cpp']]+[pin(ROOT/'tools/test_bounded_physical.py'),pin(Path(__file__)),pin(out/'SOURCE_DIFF.txt')],qualification=pin(read(ROOT/'reports/LATEST_QUALIFICATION.json')['report']['path']),physical_operations=0)
with (out/'REVIEW.json').open('x',encoding='utf8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(dict(status='PASS',checks=len(checks),review=pin(out/'REVIEW.json'))))
