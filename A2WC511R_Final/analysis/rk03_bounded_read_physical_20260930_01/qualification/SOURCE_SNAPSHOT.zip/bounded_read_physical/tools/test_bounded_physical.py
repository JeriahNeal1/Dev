"""Focused new-PE qualification. Invokes ONLY explicit offline fake modes.
Prior386-case qualification is hash-reused, never rerun. Fixtures/runner authored
by passive_review; root independently reviews this source and resulting journals.
"""
from pathlib import Path
import datetime as dt, hashlib, json, re, subprocess, sys, traceback
ROOT=Path(__file__).resolve().parents[1]
A=Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_bounded_read_physical_20260930_01')
OLD=Path(r'C:\Dev\A2WC511R_RK03_KernelIdentityPhysical\kernel_identity_physical')
PHYSICAL=OLD.parent/'physical_session/RK03_KERNEL_START_IDENTITY_01/native_api.jsonl'
ORACLE=Path(r'C:\Dev\A2WC511R_RK03_BoundedRomReadOffline\bounded_rom_read\contract\CONTRACT.json')
CONTRACT=A/'PHYSICAL_BOUNDED_REVIEW_CONTRACT.json'
PRIOR=OLD/'reports/qualification_20260930T061208911770Z/TEST_REPORT.json'
POSITIVE=['physical_identity_replay','bounded_success','bounded_fragmented','bounded_indicators_fragmented','bounded_echo','bounded_multirecord','bounded_extra_index_size','bounded_som']
NEGATIVE=['bounded_data_all','bounded_short','bounded_long','bounded_double_frame','bounded_wrong_pass','bounded_wrong_address','bounded_wrong_length','bounded_zero_length','bounded_oversized_length','bounded_wrong_header','bounded_wrong_command','bounded_checksum','bounded_rx_oversize','bounded_empty','bounded_protocol','bounded_flags','bounded_extra_index','bounded_indicator_flood','bounded_indicator_after_data','bounded_echo_after_data','bounded_wrong_echo','bounded_partial_echo','bounded_combined_echo','bounded_nonempty_indicator','bounded_combined_status','bounded_unknown_status','bounded_no_reply','bounded_late_reply','bounded_read_error','bounded_status16','bounded_timeout_status','bounded_count_zero','bounded_count_large','bounded_truncated_header','bounded_write_fail','bounded_write_count_zero','bounded_write_count_large','bounded_write_mutation','bounded_cleanup_stop_fail','bounded_cleanup_disconnect_fail','bounded_cleanup_close_fail','bounded_cleanup_all_fail']
LEGACY_POSITIVE=['success','fragmented','indicators_fragmented','seed_vector_0','seed_vector_15']
LEGACY_NEGATIVE={**{f'status16_{n}':n+1 for n in range(7,24)},'wrong_bf':1,'get_wrong_0':0,'identity_wrong_identity':24,'transition_stop_fail':23,'kernel_baud_fail':23,'kernel_filter_fail':23,'filter_fail':0}
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def require(ok,detail):
    if not ok:raise AssertionError(detail)
def save(p,obj):
    with Path(p).open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,indent=2);f.write('\n')
def key(seed):
    table=[5,6,7,1,9,12,13,8,10,13,2,11,15,4,0,3,11,4,6,0,15,2,13,9,5,12,1,10,3,13,14,8]
    keys=[0x88F0,0x6E74,0x6B70,0x3563,0x9D34,0xDBA3,0x503D,0xAFB8,0x3608,0x834F,0x3382,0x7CA3,0x437D,0x72EB,0x33BC,0x53DA]
    l,r=int.from_bytes(seed[:2],'big'),int.from_bytes(seed[2:],'big')
    for k in keys:
        e=(r^k)*0x10001;v=sum(table[(e>>s)&31]<<s for s in (0,4,8,12));v=((v>>3)|(v<<13))&65535;l,r=r,l^v
    return r.to_bytes(2,'big')+l.to_bytes(2,'big')
def bounded_message(m):
    raw=bytes.fromhex(m['data_hex']);require(m['logged_bytes']==len(raw)<=4128,'bounded logged record')
    require(m['data_truncated']==(m['data_size']>4128),'explicit log truncation')
    if not m['data_truncated']:require(m['data_size']==len(raw),'logged data size')
    return raw
def inspect(case,mode,path,exit_code,oracle,contract_hash,physical_rows):
    rows=[json.loads(s) for s in path.read_text().splitlines()];start,terminal=rows[0],rows[-1]
    require(start['type']=='bounded_read_start' and start['physical'] is False and start['provider_loaded'] is False and start['backend']=='STATIC_IN_PROCESS_FAKE','offline startup')
    require(start['fixture']==case and start['contract_sha256']==contract_hash and start['kernel_sha256']=='3a65d6f0700bae394a24ba9f552d03500b7f66e6344ec57613f10bfd360d8581','startup pins')
    require(start['time_model']==('QPC_MONOTONIC_MINIMUM' if mode=='real_clock' else 'VIRTUAL_ONLY_NOT_PHYSICAL_TIME'),'clock mode')
    require(all(r.get('physical',False) is False for r in rows),'all records offline')
    events=[r for r in rows if r['type']=='bounded_read_result'];require(len(events)<=1,'one bounded result maximum')
    apirows=[r for r in rows[1:-1] if r['type']!='bounded_read_result'];require(len(apirows)%2==0,'paired calls')
    its,ret=apirows[::2],apirows[1::2]
    for n,(i,r) in enumerate(zip(its,ret)):
        require(i['type']=='api_intent' and r['type']=='api_return' and i['sequence']==r['sequence']==n and i['function']==r['function'] and i['input']==r['input'],'complete ordered call pair')
        require(r['qpc_before']<=r['qpc_after'] and r['api_elapsed_ticks']==r['qpc_after']-r['qpc_before'] and r['qpc_frequency']>0,'API timing')
        if n:require(ret[n-1]['qpc_after']<=r['qpc_before'],'ordered QPC')
        if not r.get('cleanup'):require(r['esp_before']==r['esp_after'],'ABI stack balance')
        if 'canaries_intact' in r['output']:require(r['output']['canaries_intact'],'native guard bytes')
        if r['status'] and not r.get('cleanup'):require(all(x.get('cleanup') for x in its[n+1:]),'no operation after error except cleanup')
        for m in [r['input'].get('message'),r['output'].get('message')]:
            if m:bounded_message(m)
    tx=[r for r in ret if r['function']=='PassThruWriteMsgs'];cleanup=[r for r in ret if r.get('cleanup')]
    require(len(tx)<=25 and terminal['type']=='probe_terminal' and terminal['state']['tx_attempts']==len(tx),'exact TX bound/counter')
    require(not cleanup or ret[-len(cleanup):]==cleanup,'cleanup last')
    require(len({r['function'] for r in cleanup})==len(cleanup),'one cleanup attempt each')
    require(not cleanup or [r['function'] for r in cleanup]==['PassThruStopMsgFilter','PassThruDisconnect','PassThruClose'][-len(cleanup):],'cleanup order')
    st=terminal['state'];require(terminal['cleanup_confirmed']==(not st['opened'] and not st['connected'] and not st['filter']['active']),'cleanup state honesty')
    mask=sum({'PassThruStopMsgFilter':1,'PassThruDisconnect':2,'PassThruClose':4}[r['function']] for r in cleanup if r['status'])
    if any(r['function']=='PassThruStopMsgFilter' and r['status'] and not r.get('cleanup') for r in ret):mask|=1
    require(terminal['cleanup_error_mask']==mask,'cleanup error mask')
    positive=case in POSITIVE+LEGACY_POSITIVE or case.startswith('bounded_split_')
    require(exit_code==(0 if positive else 1),'expected process status')
    require(terminal['status']==('PASS_OFFLINE_BOUNDED_ROM_READ_ONLY' if positive else 'FAIL_TERMINAL'),'expected terminal')
    want_tx=LEGACY_NEGATIVE.get(case,25);require(len(tx)==want_tx,'no skipped/extra/retried transmission')
    replies=[];rx_by_stage=[]
    for stage,w in enumerate(tx):
        seq=w['sequence'];stop=next((r['sequence'] for r in ret if r['sequence']>seq and r['function']!='PassThruReadMsgs'),len(ret))
        rx=[r for r in ret if seq<r['sequence']<stop and r['function']=='PassThruReadMsgs'];rx_by_stage.append(rx)
        wire=bytes.fromhex(w['input']['message']['data_hex']);require(w['input']['input_count']==w['input']['message_capacity']==1 and w['input']['timeout_ms']==1000,'write arguments')
        expected=oracle['frames'][stage]['tx']
        if stage==4:
            seed=bytes.fromhex(replies[3])[6:10];body=bytes.fromhex('8010f0062702')+key(seed);expected=(body+bytes([sum(body)%256])).hex()
        require(wire.hex()==expected and wire[-1]==sum(wire[:-1])%256,'exact allowlisted request')
        reply=b''.join(bytes.fromhex(r['output']['message']['data_hex']) for r in rx if r['status']==0 and r['output']['count']==1 and r['output']['message']['rx_status']==0)
        replies.append(reply.hex())
        if positive or stage<len(tx)-1:
            require(rx and all(r['status']==0 and r['output']['count']==1 for r in rx),'successful prerequisite receives')
            require(reply[-1]==sum(reply[:-1])%256,'prerequisite checksum')
            if stage==3:require(reply[:6]==bytes.fromhex('80f010066701') and len(reply)==11,'valid seed')
            else:require(reply.hex()==oracle['frames'][stage]['rx'],'exact prerequisite reply')
    if want_tx==25:
        require(st['identity_validated'] and st['start_acknowledged'] and st['acknowledged_chunks']==15,'read only after exact preceding validation')
        sets=[r for r in ret if r['function']=='PassThruIoctl' and r['input']['ioctl']==2];get=[r for r in ret if r['function']=='PassThruIoctl' and r['input']['ioctl']==1]
        values=[{'parameter':22,'value':0},{'parameter':7,'value':1},{'parameter':10,'value':0},{'parameter':12,'value':0},{'parameter':3,'value':0}]
        require([r['output']['config']['owned_buffer_entries'] for r in sets[:5]]==[[x] for x in values],'five serial SET values')
        require(len(get)==1 and get[0]['sequence']==sets[4]['sequence']+1 and get[0]['output']['config']['owned_buffer_entries']==values,'immediate GET returned values')
        for r in sets+get:
            c=r['output']['config'];require(c['pointer_matches_owned'] and c['config_pointer']==c['owned_buffer_pointer'] and c['returned_num_params']==c['owned_capacity'],'config ownership/count')
        filters=[r for r in ret if r['function']=='PassThruStartMsgFilter'];require(len(filters)==2 and filters[0]['sequence']==get[0]['sequence']+1,'two ordered filters')
        for r,mask_hex,pattern_hex,flow in [(filters[0],'00000000','00000000',True),(filters[1],'ffff','beef',False)]:
            i=r['input'];require(i['filter_type']==1 and i['mask']['data_hex']==mask_hex and i['pattern']['data_hex']==pattern_hex and i['flow_present']==flow,'filter contract')
            require(i['flow']['data_hex']=='00000000' if flow else i['flow'] is None,'nonnull broad/null BEEF flow')
        require([r['output']['config']['owned_buffer_entries'] for r in sets[5:]]==[[{'parameter':1,'value':15625}],[{'parameter':1,'value':62500}]],'exact baud transitions')
        clears=[r['input']['ioctl'] for r in ret if r['function']=='PassThruIoctl' and r['input']['ioctl'] in (7,8)];require(clears==[7,8],'single ordered queue clears')
        waits=[r for r in ret if r['function'] in ['OfflineClockAdvance','MonotonicMinimumWait']];require([r['input']['milliseconds'] for r in waits]==[200,100,200],'exact wait requests')
        if mode=='real_clock':require(all(r['api_elapsed_ticks']*1000>=r['input']['milliseconds']*r['qpc_frequency'] for r in waits),'actual minimum waits')
        require(len(rx_by_stage[24])<=527,'bounded receive record cap')
    if positive:
        require(terminal['protocol_complete'] and terminal['cleanup_confirmed'] and len(events)==1 and st['bounded_validated'],'fully accepted bounded result')
        e=events[0];require(e['mismatch_count']==0 and e['mismatches']==[] and e['response_hex']==oracle['frames'][24]['rx'] and e['payload_hex']==oracle['fixed_read']['expected_bytes_hex'],'exact full data and response')
        require(all(r['status']==0 for r in ret),'all positive calls successful')
    elif case.startswith('bounded_data_'):
        positions=list(range(512)) if case=='bounded_data_all' else [int(case.rsplit('_',1)[1])]
        require(len(events)==1 and not st['bounded_validated'] and not terminal['protocol_complete'],'mismatch result retained without success')
        e=events[0];expected=bytes.fromhex(oracle['fixed_read']['expected_bytes_hex']);raw=bytes.fromhex(e['response_hex'])
        require(raw[-1]==sum(raw[:-1])%256 and e['checksum_pass'] and e['mismatch_count']==len(positions),'checksum-correct data fault')
        require(e['mismatches']==[{'address':n,'expected':expected[n],'actual':expected[n]^1} for n in positions],'all exact mismatch records retained')
    elif case.startswith('bounded_cleanup_'):
        require(len(events)==1 and st['bounded_validated'] and terminal['protocol_complete'] and mask and not terminal['cleanup_confirmed'],'validated data does not hide cleanup failure')
    else:
        require(not events and not terminal['protocol_complete'] and not st['bounded_validated'],'failure before bounded acceptance')
    if case=='bounded_late_reply':
        last=rx_by_stage[24][-1];require(last['api_elapsed_ticks']*1000>=2000*last['qpc_frequency'] and 'deadline after API return' in terminal['failure'],'late complete reply rejected')
    if case.startswith('bounded_') and want_tx==25:
        rr=rx_by_stage[24];messages=[r['output']['message'] for r in rr];raws=[bytes.fromhex(m['data_hex']) for m in messages]
        reference=bytes.fromhex(oracle['frames'][24]['rx']);request=bytes.fromhex(oracle['frames'][24]['tx'])
        header_mutations={'bounded_wrong_pass':5,'bounded_wrong_address':9,'bounded_wrong_length':3,'bounded_wrong_header':0,'bounded_wrong_command':4}
        if case in header_mutations:
            expected=bytearray(reference);expected[header_mutations[case]]^=1;expected[-1]=sum(expected[:-1])%256
            require(raws==[bytes(expected)],'intended checksum-correct header mutation exercised')
        if case in ['bounded_zero_length','bounded_oversized_length']:
            expected=bytearray(reference);expected[2:4]=bytes([0 if case=='bounded_zero_length' else 255])*2;expected[-1]=sum(expected[:-1])%256
            require(raws==[bytes(expected)],'intended advertised-length fault exercised')
        exact_raw={'bounded_short':reference[:-1],'bounded_long':reference+b'\0','bounded_double_frame':reference*2,'bounded_checksum':reference[:-1]+bytes([reference[-1]^1]),'bounded_truncated_header':reference[:3],'bounded_empty':b'', 'bounded_wrong_echo':bytes([request[0]^1])+request[1:],'bounded_partial_echo':request[:-1],'bounded_combined_echo':request+reference}
        if case in exact_raw:require(raws and raws[0]==exact_raw[case],'intended malformed bytes exercised')
        meta={'bounded_rx_oversize':('data_size',5000),'bounded_protocol':('protocol',4),'bounded_flags':('tx_flags',1),'bounded_extra_index':('extra_data_index',1),'bounded_nonempty_indicator':('rx_status',2),'bounded_combined_status':('rx_status',3),'bounded_unknown_status':('rx_status',256)}
        if case in meta:
            field,value=meta[case];require(len(messages)==1 and messages[0][field]==value,'intended metadata fault exercised')
        status={'bounded_read_error':7,'bounded_status16':16,'bounded_timeout_status':9,'bounded_no_reply':16}
        if case in status:require(rr[-1]['status']==status[case],'intended returned transport status exercised')
        if case in ['bounded_count_zero','bounded_count_large']:require(rr[-1]['output']['count']==(0 if case.endswith('zero') else 2),'returned count mutation exercised')
        if case=='bounded_indicator_flood':require(len(messages)==5 and all(m['rx_status']==2 and m['data_size']==0 for m in messages),'fifth indication rejected')
        if case in ['bounded_indicator_after_data','bounded_echo_after_data']:require(len(messages)==2 and raws[0]==reference[:1] and messages[1]['rx_status']!=0,'after-data indication exercised')
        if case=='bounded_write_fail':require(tx[-1]['status']==7 and not rr,'write error prevents reads')
        if case in ['bounded_write_count_zero','bounded_write_count_large']:require(tx[-1]['output']['count']==(0 if case.endswith('zero') else 2) and not rr,'bad write count prevents reads')
        if case=='bounded_write_mutation':require(tx[-1]['output']['message']['data_hex']!=tx[-1]['input']['message']['data_hex'] and not rr,'write mutation prevents reads')
        expected_masks={'bounded_cleanup_stop_fail':1,'bounded_cleanup_disconnect_fail':2,'bounded_cleanup_close_fail':4,'bounded_cleanup_all_fail':7}
        if case in expected_masks:require(mask==expected_masks[case],'specific cleanup failures exercised')
    if case=='bounded_indicators_fragmented':require(len(rx_by_stage[24])==527,'exact four indications plus523 byte fragments')
    if case=='bounded_fragmented':require(len(rx_by_stage[24])==523,'all byte fragments exercised')
    if case.startswith('bounded_split_'):
        split=int(case.rsplit('_',1)[1]);require([r['output']['message']['data_size'] for r in rx_by_stage[24]]==[split,523-split],'requested split exercised')
    if case=='physical_identity_replay':
        oldret=[r for r in physical_rows if r.get('type')=='api_return'];oldrx=[r['output']['message'] for r in oldret if r['function']=='PassThruReadMsgs']
        require([r['output']['message'] for stage in rx_by_stage[:24] for r in stage]==oldrx,'exact48 physical RX records including metadata')
        oldtx=[r['input']['message'] for r in oldret if r['function']=='PassThruWriteMsgs'];require([r['input']['message'] for r in tx[:24]]==oldtx,'exact24 physical write records')
        require(next(r['output'] for r in ret if r['function']=='PassThruReadVersion')==next(r['output'] for r in oldret if r['function']=='PassThruReadVersion'),'exact physical version buffers')
    return {'tx_attempts':len(tx),'api_calls':len(ret),'bounded_rx_records':len(rx_by_stage[24]) if len(rx_by_stage)==25 else 0,'bounded_results':len(events),'terminal':terminal['status'],'cleanup_error_mask':mask}
def main():
    run=ROOT/'reports'/('qualification_'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'));run.mkdir(parents=True,exist_ok=False)
    report={'schema':1,'status':'FAIL','physical_operations':0,'real_provider_loads':0,'runner_author_and_fixture_author':'passive_review','independent_runner_reviewer':'root','prior386_reused_not_rerun':True,'cases':[]}
    try:
        require(not (ROOT.parent/'physical_session').exists(),'no physical session before offline qualification')
        require(pin(PRIOR)['sha256']=='0be7a4c5d0291af17f9d02b144580457cb5d4ab1ddc9601bb8bc6c68270a7a49','retained386 report unchanged')
        require(pin(PHYSICAL)['sha256']=='e6ac67a41cc98433fc56f2d5d0d9a8144ce836678a31094a108aff4187662e09','physical prefix unchanged')
        require(pin(ORACLE)['sha256']=='9dccc5043477150c479255803ea25f48fe815d5b254f9c045e30b5923327edcf','sealed offline oracle unchanged')
        oracle=read(ORACLE);physical=[json.loads(s) for s in PHYSICAL.read_text().splitlines()];contract_hash=pin(CONTRACT)['sha256']
        require(contract_hash=='be14e560229f5a7eb1904cc18c47dc9c36fe6df3b79c86be12f844640fe15e02','new fixed review contract')
        builds=[read(ROOT/x/'BUILD.json') for x in ('build_a','build_b')]
        require(all(b['status']=='PASS_BUILD_ONLY' for b in builds),'both clean builds')
        sourcepins={}
        for b in builds:
            require(pin(b['exe_path'])['sha256']==b['exe_sha256'],'recorded executable hash')
            for p in b['source_inputs']:
                require(pin(p['path'])['sha256']==p['sha256'],'compiled source unchanged '+p['path']);sourcepins[p['path']]=pin(p['path'])
        require(builds[0]['exe_sha256']==builds[1]['exe_sha256'] and builds[0]['source_inputs']==builds[1]['source_inputs'],'reproducible executable/source closure')
        exe=Path(builds[0]['exe_path']);require(exe.name=='rk03_bounded_rom_read_physical32.exe' and exe.parent==ROOT/'build_a','fixed same-PE target')
        for name in ['common.hpp','protocol.hpp','identity_response.hpp','bootstrap.hpp','bootstrap_tests.hpp','owned_artifact.h','real_clock.hpp']:
            require((ROOT/'src'/name).read_bytes()==(OLD/'src'/name).read_bytes(),'unchanged retained component '+name)
        report['inputs']={'binary':pin(exe),'second_clean_binary':pin(builds[1]['exe_path']),'build_a':pin(ROOT/'build_a/BUILD.json'),'build_b':pin(ROOT/'build_b/BUILD.json'),'runner':pin(__file__),'contract':pin(CONTRACT),'oracle':pin(ORACLE),'prior386_report':pin(PRIOR),'physical_identity_reference':pin(PHYSICAL),'source_inputs':list(sourcepins.values())}
        cases=[(n,'virtual') for n in POSITIVE+NEGATIVE+[f'bounded_split_{i}' for i in range(1,523)]+[f'bounded_data_{i}' for i in range(512)]+LEGACY_POSITIVE+list(LEGACY_NEGATIVE)]
        cases += [('success','real_clock'),('physical_identity_replay','real_clock'),('bounded_indicators_fragmented','real_clock')]
        require(len(cases)==len(set(cases))==1116,'focused new test matrix1116')
        for n,(case,mode) in enumerate(cases):
            target=run/(f'{n:04d}_'+case+'_'+mode);target.mkdir()
            journal=target/'native_api.jsonl';flag='--offline-real-clock-fixture' if mode=='real_clock' else '--offline-fixture'
            command=[str(exe),flag,case,'--journal',str(journal)]
            result=subprocess.run(command,capture_output=True,timeout=15)
            (target/'stdout.txt').write_bytes(result.stdout);(target/'stderr.txt').write_bytes(result.stderr)
            row={'case':case,'mode':mode,'command':command,'exit_code':result.returncode,'journal':pin(journal),'stdout':pin(target/'stdout.txt'),'stderr':pin(target/'stderr.txt')}
            report['cases'].append(row)
            row.update(inspect(case,mode,journal,result.returncode,oracle,contract_hash,physical));row['status']='PASS'
            if (n+1)%100==0:print(json.dumps({'completed':n+1,'total':len(cases)}),flush=True)
        for p in sourcepins.values():require(pin(p['path'])==p,'compiled source intact after tests')
        for k in ['binary','second_clean_binary','runner','contract','oracle','prior386_report','physical_identity_reference']:require(pin(report['inputs'][k]['path'])==report['inputs'][k],'input intact after tests '+k)
        require(not (ROOT.parent/'physical_session').exists(),'no physical artifacts created')
        report.update(status='PASS',test_cases=len(cases),passed_cases=len(cases),all522_splits_passed=True,all512_data_positions_rejected=True,all512_simultaneous_mismatches_preserved=True)
    except Exception:report['failure']=traceback.format_exc()
    save(run/'TEST_REPORT.json',report)
    if report['status']=='PASS':
        latest=ROOT/'reports/LATEST_QUALIFICATION.json';save(latest,{'status':'PASS','report':pin(run/'TEST_REPORT.json')})
    print(json.dumps({'status':report['status'],'passed':sum(c.get('status')=='PASS' for c in report['cases']),'report':pin(run/'TEST_REPORT.json'),'failure':report.get('failure')}),flush=True)
    return 0 if report['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
