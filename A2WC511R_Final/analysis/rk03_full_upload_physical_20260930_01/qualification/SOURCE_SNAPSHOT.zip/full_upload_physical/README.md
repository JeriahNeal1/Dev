# Fixed full upload with no kernel start

This separate release adds a gated physical entrypoint to the sealed offline full-upload model. The native protocol remains bounded to 22 transmissions: BF, 81, 83, seed, derived key, session, one declaration, and fifteen fixed transfers. Fourteen transfers carry 128 bytes and the last carries 16 bytes. Every transfer requires the full exact acknowledgement `80f0100176f7`. The host then closes its allocated resources and exits.

The payload covers FFFF3000 through FFFF370F, exactly 1,808 bytes. Its plaintext SHA256 is `3a65d6f0700bae394a24ba9f552d03500b7f66e6344ec57613f10bfd360d8581`. The declaration, addresses, ciphertext and expected replies are embedded and pinned. Only the seed-derived key varies. The request table excludes historical `31 01 01`; there is no sixteenth transfer, kernel start, kernel execution, kernel-version request, ROM read, flash operation, arbitrary payload/address option, automatic retry or reconnect loop.

The physical release requires a new qualification certificate, the new session's human gates and the exact authorization token. Offline test success does not grant that authorization or establish a physical upload result.

## Shared implementation and qualification

The whole core matches the sealed offline source after exactly three reviewed changes: the constructor permits physical mode only with the real monotonic clock, and the two terminal result labels distinguish a physical success. The request builder, parser, five SET_CONFIG calls and immediate GET_CONFIG, broad four-zero PASS_FILTER, seed algorithm, cleanup, payload, fake provider and clock helper remain unchanged. The bootstrap implementation and its 24 fixtures match the previously reviewed first-chunk release.

Transport remains protocol 3, connect flags 512, initial baud 4800, ordered configuration values 22=0, 7=1, 10=0, 12=0 and 3=0. The requested post-key, post-session and pre-declaration waits remain 200, 100 and 200 ms. Baud SET 15625 is followed by CLEAR_TX_BUFFER 7 then CLEAR_RX_BUFFER 8. Baud status and output integrity are checked; physical effective baud is not independently read back.

Two clean builds produced the same `rk03_full_upload_no_start_physical32.exe`: 360,448 bytes, SHA256 `6c7571ece71bb6c29feae9fbfa873cca9635e41cabe269ebc7fa21b1e2fc0d51`. The executable intentionally contains a gated provider loader and generic runtime loader imports. The independent runner selects only its offline modes:

```text
rk03_full_upload_no_start_physical32.exe --offline-fixture CASE --journal NEW_PATH
rk03_full_upload_no_start_physical32.exe --offline-real-clock-fixture CASE --journal NEW_PATH
rk03_full_upload_no_start_physical32.exe --offline-bootstrap CASE --journal NEW_PATH
```

All **311 cases passed on the first run**: the sealed 283 virtual and four real-clock fixtures, plus 24 disposable bootstrap fixtures. These qualify the new executable; earlier stage test results remain preserved and were not rerun against the old executables. The fourteen later transfer stages each retain eleven negative cases. Every failure must stop at its exact boundary without another transmission or retry and attempt the required cleanup. All sixteen seed vectors and the complete observed physical first-chunk prefix remain covered. The remaining transfer replies are synthetic fixtures supported separately by retained OEM instruction execution.

All twelve measured waits in the real-clock cases met their minima. All bootstrap tests used disposable dummy files and export pointers, invoked no provider API, and stopped before any library load. The runner verified source closure and input/binary hashes before and after execution, with no physical session directory created.

- [Final test report](reports/qualification_20260930T045456687736Z/TEST_REPORT.json): SHA256 `20273a8be9d018758eab00818b4a186cabb8cfc48083281800175c0d5dab53c1`.
- [Runner author artifact audit](reports/RUNNER_AUTHOR_AUDIT.json): 1,432 hash references, 1,115 distinct paths, and all 1,065 test artifacts verified.
- [Independent runner](tools/test_full_physical_independent.py): SHA256 `ccc470742171ff164c93341eed9d3647e4b34f6d768ef378c4ba3cf763c8411a`.

Root authored and built the native implementation and control scripts. `passive_review` authored and executed this runner, audited its artifacts, and independently reviewed root's native and control code. Root independently reviews the runner and journals. The control scripts separately passed 36 mocked launcher checks and 14 mocked OEM-return checks, without real subprocess launches.

## Fixed physical boundary

The only physical session is:

```text
C:\Dev\A2WC511R_RK03_FullUploadPhysical\physical_session\RK03_FULL_UPLOAD_NO_START_01
```

The compiled provider is `C:\Windows\SysWOW64\op20pt32.dll`, SHA256 `f432084801762d919a3c31974616e097562424470003edc4f4fb843df34103cf`. The compiled review contract is `C:\Dev\A2WC511R_Final\analysis\rk03_full_upload_physical_20260930_01\PHYSICAL_FULL_UPLOAD_REVIEW_CONTRACT.json`, SHA256 `0b56e15ae2dcf749666679effd559c54b7a7c2e202fc2ad2902e24c2a54b1e51`.

The root-controlled launcher first verifies the certificate and all pinned files, fresh ordered user replies `IGNITION OFF` then `TEST MODE ON`, engine OFF, absence of competing diagnostic clients, no abort, and zero invocations. It requires the exact new user token `PROCEED RK03 FULL UPLOAD NO START`. Historical authorization cannot be reused. The launcher rechecks state after client inspection, reserves this session once, launches one child and waits for its exit even if bookkeeping fails or the console wait is interrupted.

The launcher's exact native command is shown for review only; the independent test runner never executes it:

```text
rk03_full_upload_no_start_physical32.exe --physical-full-upload-no-start --session C:\Dev\A2WC511R_RK03_FullUploadPhysical\physical_session\RK03_FULL_UPLOAD_NO_START_01 --authorization-file C:\Dev\A2WC511R_RK03_FullUploadPhysical\physical_session\RK03_FULL_UPLOAD_NO_START_01\AUTHORIZATION.txt
```

The launcher alone creates `AUTHORIZATION.txt` after the new human authorization. Its exact format is four ASCII lines with LF endings, no BOM and a final LF. This deliberately invalid template conveys the format without authorizing a session:

```text
NOT_AUTHORIZED
SESSION_ID=RK03_FULL_UPLOAD_NO_START_01
EXE_SHA256=<qualified executable SHA256>
CONTRACT_SHA256=0b56e15ae2dcf749666679effd559c54b7a7c2e202fc2ad2902e24c2a54b1e51
```

Only after the gates and exact user token may the launcher put that token on the first line. It also exclusively creates `launch.reserved` with three LF-terminated lines: session ID, executable SHA256, contract SHA256. Native code compares both files exactly, then exclusively creates and flushes `invocation.once` with those same three lines before opening and hashing the provider. Existing markers prevent retry. The provider is held read-locked through loading from the fixed path, and every required export must resolve before the first provider API call.

## Result and recovery

A successful physical result is scoped as `PASS_FULL_UPLOAD_NO_START_ONLY`. The application stops after the fifteenth acknowledgement and attempts StopMsgFilter, Disconnect and Close for every allocated resource. Nonzero provider status, malformed replies, mutated outputs, journal errors or cleanup errors prevent success. Status 16 is terminal without retry.

After confirmed child exit, the only recovery state replies are `IGNITION OFF` then `NORMAL MODE ON`. The operator manages the associated physical preparation. The separate OEM-return wrapper verifies those fresh replies and the unchanged passive qualification, rechecks abort state after client inspection, and permits one fixed BF/A8 capture. OEM identity, capture success and complete observer/broker/provider cleanup must be checked separately before concluding recovery.

Transfer acknowledgements are not physical RAM readback. Retained current-ROM CPU execution proves the final plaintext only under its explicit programming-admission and peripheral fixtures. Complete physical transfer and recovery remain unproven until a separately authorized session completes. Kernel execution and ROM acquisition remain outside this release.
