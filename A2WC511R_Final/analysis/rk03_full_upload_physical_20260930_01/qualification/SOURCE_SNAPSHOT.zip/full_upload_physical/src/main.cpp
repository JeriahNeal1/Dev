#include "probe_core.hpp"
#include "fake_backend.hpp"
#include "real_clock.hpp"
#include "bootstrap_tests.hpp"
inline long real_fake_wait(U ms){long status=fake::wait_ms(ms);return status?status:real_clock::minimum_wait(ms);}
int wmain(int argc,wchar_t** argv){
 try{
  require(argc>=2,"Exact offline or gated physical invocation required");
  if(!wcscmp(argv[1],L"--offline-bootstrap")){
   require(argc==5&&!wcscmp(argv[3],L"--journal"),"Exact offline bootstrap/journal arguments required");return bootstrap_test::run(ascii(argv[2]),argv[4]);
  }
  const bool real_fake=!wcscmp(argv[1],L"--offline-real-clock-fixture");
  if(real_fake||!wcscmp(argv[1],L"--offline-fixture")){
   require(argc==5&&!wcscmp(argv[3],L"--journal"),"Exact offline fixture/journal arguments required");const std::string fixture=ascii(argv[2]);
   if(real_fake)require(fixture=="success"||fixture=="fragmented"||fixture=="indicators_fragmented"||fixture=="physical_first_chunk_replay","Real-clock fake fixture allowlist");
   fake::select(fixture);Api api=fake::api();if(real_fake){api.wait_ms=real_fake_wait;api.virtual_ms=real_clock::milliseconds;}
   Journal journal;journal.create(argv[4]);Probe probe(api,journal.value,false,real_fake);probe.inject_log_failure=fake::is("journal_failure_after_filter");
   probe.event("{\"type\":\"full_upload_start\",\"physical\":false,\"backend\":\"STATIC_IN_PROCESS_FAKE\",\"fixture\":"+quote(fixture)+",\"time_model\":"+quote(real_fake?"QPC_MONOTONIC_MINIMUM":"VIRTUAL_ONLY_NOT_PHYSICAL_TIME")+",\"contract_sha256\":"+quote(CONTRACT_SHA)+",\"kernel_sha256\":"+quote(KERNEL_SHA)+",\"declaration_size\":"+number(KERNEL_SIZE)+",\"embedded_cipher_bytes\":1808,\"provider_loaded\":false}");return probe.run();
  }
  require(argc==6&&!wcscmp(argv[1],L"--physical-full-upload-no-start")&&!wcscmp(argv[2],L"--session")&&!wcscmp(argv[4],L"--authorization-file"),"Exact physical arguments required");
  const Bindings b=physical_bindings();Gate gate;gate.prepare(b,argv[3],argv[5]);Journal journal;journal.create((b.session+L"\\native_api.jsonl").c_str());bool loaded=false;
  try{
   gate.lock_provider(b);gate.phase="PROVIDER_LOAD";Module module;module.value=LoadLibraryExW(PROVIDER_PATH,nullptr,LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_SYSTEM32);require(module.value!=nullptr,"Fixed provider load failed");loaded=true;gate.phase="EXPORTS";
   auto resolver=[&](const char* name){return GetProcAddress(module.value,name);};Api api=resolve_api(resolver,real_clock::minimum_wait,real_clock::milliseconds);
   Probe probe(api,journal.value,true,true);probe.event("{\"type\":\"full_upload_start\",\"physical\":true,\"session_id\":"+quote(SESSION_ID)+",\"exe_sha256\":"+quote(gate.exe_sha)+",\"contract_sha256\":"+quote(CONTRACT_SHA)+",\"provider_path\":\"C:\\\\Windows\\\\SysWOW64\\\\op20pt32.dll\",\"provider_sha256\":"+quote(PROVIDER_SHA)+",\"time_model\":\"QPC_MONOTONIC_MINIMUM\",\"embedded_cipher_bytes\":1808,\"declaration_size\":1808,\"authorization_verified\":true,\"root_reservation_verified\":true,\"native_invocation_reserved\":true}");return probe.run();
  }catch(const std::exception& e){fprintf(journal.value,"{\"type\":\"bootstrap_failure\",\"physical\":true,\"phase\":\"%s\",\"provider_was_loaded\":%s,\"native_invocation_reserved\":true}\n",gate.phase.c_str(),loaded?"true":"false");fflush(journal.value);throw std::runtime_error(e.what());}
 }catch(const std::exception& e){fprintf(stderr,"FAIL_CLOSED_BEFORE_OR_OUTSIDE_FULL_UPLOAD_NO_START: %s\n",e.what());return 2;}
}
