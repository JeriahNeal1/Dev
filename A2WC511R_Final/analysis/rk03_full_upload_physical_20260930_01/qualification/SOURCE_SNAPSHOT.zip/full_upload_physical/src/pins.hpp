#pragma once
static constexpr const char* CONTRACT_SHA="0b56e15ae2dcf749666679effd559c54b7a7c2e202fc2ad2902e24c2a54b1e51";
static constexpr const char* PROVIDER_SHA="f432084801762d919a3c31974616e097562424470003edc4f4fb843df34103cf";
static constexpr const char* SESSION_ID="RK03_FULL_UPLOAD_NO_START_01";
static constexpr const char* AUTH_TOKEN="PROCEED RK03 FULL UPLOAD NO START";
static constexpr const wchar_t* CONTRACT_PATH=L"C:\\Dev\\A2WC511R_Final\\analysis\\rk03_full_upload_physical_20260930_01\\PHYSICAL_FULL_UPLOAD_REVIEW_CONTRACT.json";
static constexpr const wchar_t* PROVIDER_PATH=L"C:\\Windows\\SysWOW64\\op20pt32.dll";
static constexpr const wchar_t* SESSION_PATH=L"C:\\Dev\\A2WC511R_RK03_FullUploadPhysical\\physical_session\\RK03_FULL_UPLOAD_NO_START_01";
