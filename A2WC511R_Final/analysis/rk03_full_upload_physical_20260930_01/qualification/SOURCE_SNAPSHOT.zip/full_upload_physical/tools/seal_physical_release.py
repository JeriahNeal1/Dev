"""Seal separately reviewed release and initialize unfulfilled human gates. Never launch hardware."""
from pathlib import Path
import datetime as dt,hashlib,json,stat,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent
OUT=Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_full_upload_physical_20260930_01')
OLD=OUT.parent/'rk03_full_upload_no_start_20260930_01'
STATE=Path(r'C:\Dev\A2WC511R_Final\state\CURRENT.json')
CONTROLS=['launch_full_upload_once.py','launch_oem_return_once.py','check_clients.ps1',
    'test_launcher_offline.py','test_oem_return_controls.py','seal_full_upload_result.py','test_result_validator.py','seal_oem_return_full_upload.py']
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(p,obj):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,indent=2);f.write('\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO,text=True).strip()
def verify(obj):
    if isinstance(obj,dict):
        if isinstance(obj.get('path'),str) and isinstance(obj.get('sha256'),str):
            actual=pin(obj['path']);assert actual['sha256']==obj['sha256'],obj['path']
            if 'bytes' in obj:assert actual['bytes']==obj['bytes'],obj['path']
        for value in obj.values():verify(value)
    elif isinstance(obj,list):
        for value in obj:verify(value)
def main():
    assert not git('status','--porcelain'),'Commit frozen release source first'
    assert git('branch','--show-current')=='rk03/full-upload-no-start-physical'
    assert not (REPO/'physical_session').exists(),'No real session controls before qualification'
    contract_path=OUT/'PHYSICAL_FULL_UPLOAD_REVIEW_CONTRACT.json';contract=read(contract_path)
    assert pin(contract_path)['sha256']=='0b56e15ae2dcf749666679effd559c54b7a7c2e202fc2ad2902e24c2a54b1e51'
    verify(contract['physical_provider']);verify(contract['offline_qualification']);verify(contract['offline_manifest'])
    latest=read(ROOT/'reports/LATEST_QUALIFICATION.json');verify(latest);tests=read(latest['report']['path'])
    assert latest['status']==tests['status']=='PASS' and tests['passed_cases']==tests['test_cases']==311
    verify(tests)
    reviews=[OUT/'native_review/NATIVE_SOURCE_AND_CONTROLS_REVIEW.json',OUT/'native_review/RESULT_CONTROLS_REVIEW.json',OUT/'root_review/ROOT_REVIEW.json']
    for path in reviews:
        report=read(path);assert report['status'].startswith('PASS');verify(report)
    for name,count in [('LAUNCHER_TESTS_V2.json',36),('OEM_RETURN_CONTROL_TESTS_V2.json',14),('RESULT_VALIDATOR_TESTS.json',38)]:
        report=read(OUT/name);assert report['status']=='PASS' and report['checks_passed']==count;verify(report)
    builds=[read(ROOT/n/'BUILD.json') for n in ('build_a','build_b')]
    for b in builds:assert b['status']=='PASS_BUILD_ONLY';verify(b['source_inputs'])
    assert builds[0]['source_inputs']==builds[1]['source_inputs']
    assert Path(builds[0]['exe_path']).read_bytes()==Path(builds[1]['exe_path']).read_bytes()
    canonical=[]
    for name,b in zip(('build_a','build_b'),builds):
        obj={'schema':1,'scope':'GATED_PHYSICAL_FIXED15_UPLOAD_NO_START','executable_sha256':b['exe_sha256'],
            'source_inputs':b['source_inputs'],'compiler':b['compiler'],'linker':b['linker']}
        raw=(json.dumps(obj,sort_keys=True,indent=2)+'\n').encode();canonical.append(raw)
        with (ROOT/name/'REPRODUCIBLE_MANIFEST.json').open('xb') as f:f.write(raw)
    assert canonical[0]==canonical[1]
    source=[REPO/p for p in git('ls-files','full_upload_physical').splitlines()]
    for name in CONTROLS:assert (ROOT/'release_controls'/name).read_bytes()==(OUT/name).read_bytes(),'Tracked control snapshot mismatch'
    qdir=OUT/'qualification';qdir.mkdir(exist_ok=False)
    with zipfile.ZipFile(qdir/'SOURCE_SNAPSHOT.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(source):
            info=zipfile.ZipInfo(p.relative_to(REPO).as_posix(),date_time=(2026,9,30,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o444<<16
            z.writestr(info,p.read_bytes())
    paths=set(source+[OUT/n for n in CONTROLS]+reviews)
    paths.update(Path(r['path']) for r in read(ROOT/'INPUT_PINS.json')['inputs'])
    for directory in [ROOT/'build_a',ROOT/'build_b',ROOT/'reports',OUT/'native_review',OUT/'root_review']:
        paths.update(p for p in directory.rglob('*') if p.is_file())
    for p in OUT.iterdir():
        if p.is_file():paths.add(p)
    # Pin unchanged passive recovery dependencies without opening the provider.
    reuse_path=OUT.parent/'current_rom_20260930_01/OEM_RETURN_REUSE.json';reuse=read(reuse_path)
    assert reuse['status']=='PASS_UNCHANGED_QUALIFIED_PASSIVE_REUSE';verify(reuse['files'])
    paths.add(reuse_path);paths.update(Path(r['path']) for r in reuse['files'])
    files=[pin(p) for p in sorted(paths)]
    cert={'schema':1,'status':'PASS_OFFLINE_QUALIFIED_PHYSICAL_FULL_UPLOAD_NO_START_ONLY',
        'utc':dt.datetime.now(dt.timezone.utc).isoformat(),'session_id':contract['session_id'],
        'branch':git('branch','--show-current'),'commit':git('rev-parse','HEAD'),
        'maximum_physical_invocations':1,'requires_exact_human_authorization':contract['requires_exact_human_authorization'],
        'physical_authorization_received':False,'physical_executable':pin(builds[0]['exe_path']),
        'second_clean_executable':pin(builds[1]['exe_path']),
        'canonical_manifests':[pin(ROOT/n/'REPRODUCIBLE_MANIFEST.json') for n in ('build_a','build_b')],
        'review_contract':pin(contract_path),'fixed_upload_manifest':pin(OLD/'FIXED_UPLOAD_MANIFEST.json'),
        'kernel_image_sha256':contract['kernel_sha256'],'payload_bytes':1808,'chunks':15,'maximum_requests':22,
        'test_report':latest['report'],'native_cases_passed':311,'native_cases_total':311,
        'additional_mocked_launcher_checks':36,'additional_mocked_recovery_checks':14,'result_validator_checks':38,
        'independent_reviews':[pin(p) for p in reviews],'source_snapshot':pin(qdir/'SOURCE_SNAPSHOT.zip'),
        'files':files,'physical_operations_during_qualification':0,'provider_loads_during_qualification':0,
        'kernel_start_allowed':False,'kernel_execution_allowed':False,'ROM_read_allowed':False,
        'flash_operations_allowed':False,'sixteenth_transfer_allowed':False,'arbitrary_payload_or_address_allowed':False,
        'automatic_retry_allowed':False,'next_scope_after_physical_pass_and_OEM_return':'OFFLINE_ONLY_RK03_KERNEL_START_IDENTITY_ONLY',
        'limitations':['Physical acceptance beyond first chunk remains unproven until this separately authorized run.',
            'ACKs are not physical RAM readback. Offline final image equality and no automatic handoff rely on the retained current instruction replay.',
            'This certificate permits preparation only; fresh operator ignition states and the exact new authorization token are still required.']}
    save(qdir/'QUALIFICATION.json',cert);cert_pin=pin(qdir/'QUALIFICATION.json')
    lines=['# Physical full upload/no start: separately qualified, not executed','',
        f'Branch `{cert["branch"]}`; commit `{cert["commit"]}`.','',
        '311/311 same-executable offline tests passed, plus36 mocked launcher,14 recovery and38 result-validation checks. Independent reviews passed. No hardware was accessed.','',
        f'Executable SHA256: `{cert["physical_executable"]["sha256"]}`.',
        f'Certificate SHA256: `{cert_pin["sha256"]}`.',
        f'Fixed plaintext image SHA256: `{cert["kernel_image_sha256"]}`.','',
        'The fixed protocol remains unchanged from the sealed offline artifact. Only physical entry, locked provider binding, one-shot authorization/session controls and physical result labels were added. Every15 fixed transfer requires its exact76 ACK. After the final ACK only filter/channel/provider cleanup is possible. There is no kernel-start, custom-kernel version, ROM-read, flash, arbitrary input or retry path.','',
        'Next human state: IGNITION OFF. Then TEST MODE ON. Only after displaying the required release details and checking competing clients may the new exact authorization token be requested.','',
        'Physical result, recovery and any later offline identity-stage qualification will be reported separately. Historical reports are unchanged.']
    with (OUT/'PHYSICAL_RELEASE_QUALIFICATION.md').open('x',encoding='utf-8') as f:f.write('\n'.join(lines)+'\n')
    save(qdir/'PRESERVATION_MANIFEST.json',{'status':'SEALED_PHYSICAL_RELEASE_NOT_EXECUTED','qualification':cert_pin,
        'files':files+[pin(qdir/'SOURCE_SNAPSHOT.zip'),pin(OUT/'PHYSICAL_RELEASE_QUALIFICATION.md')],'physical_operations':0})
    for row in files:verify(row)
    for directory in [ROOT/'build_a',ROOT/'build_b',ROOT/'reports',qdir,OUT/'native_review',OUT/'root_review']:
        for p in directory.rglob('*'):
            if p.is_file():p.chmod(stat.S_IREAD)
    for p in OUT.iterdir():
        if p.is_file():p.chmod(stat.S_IREAD)
    gates={'schema':1,'session_id':cert['session_id'],'qualification_sha256':cert_pin['sha256'],
        'status':'WAIT_IGNITION_OFF','next_gate':'IGNITION OFF','physical_state':'NOT_RECONFIRMED_FOR_NEW_SESSION',
        'engine':'NOT_RECONFIRMED','probe_invocation_count':0,'launch_reserved':False,'commit_authorization':None,
        'completed_pre_probe_gates':[],'completed_recovery_gates':[],'operator_managed_physical_context':True,
        'full_acquisition_allowed':False,'kernel_start_allowed':False,'retry_allowed':False,'abort_requested':False,
        'passive_oem_return_invocations':0,'updated_utc':cert['utc']}
    save(OUT/'FULL_UPLOAD_GATE_STATE.json',gates)
    state=read(STATE);state.update(phase='RK03_FULL_UPLOAD_PHYSICAL_QUALIFIED_WAIT_IGNITION_OFF',
        full_upload_physical_status='QUALIFIED_NOT_AUTHORIZED_NOT_RUN',full_upload_physical_qualification=cert_pin,
        full_upload_physical_commit=cert['commit'],full_upload_physical_executable_sha256=cert['physical_executable']['sha256'],
        full_upload_physical_gate_state=str(OUT/'FULL_UPLOAD_GATE_STATE.json'),
        human_required=['IGNITION OFF'],next_action='Await fresh IGNITION OFF, then TEST MODE ON, then exact software authorization',
        further_physical_activity_allowed=False,updated_utc=cert['utc'])
    STATE.write_text(json.dumps(state,indent=2)+'\n')
    assert not git('status','--porcelain')
    print(json.dumps({'status':cert['status'],'qualification':cert_pin,'executable':cert['physical_executable'],
        'files_pinned':len(files),'next_gate':'IGNITION OFF'}))
if __name__=='__main__':main()
