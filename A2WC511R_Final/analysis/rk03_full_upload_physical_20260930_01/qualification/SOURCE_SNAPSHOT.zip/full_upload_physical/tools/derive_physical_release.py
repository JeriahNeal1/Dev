"""Derive a separate gated physical boundary; never launch a provider or executable."""
from pathlib import Path
import datetime as dt, hashlib, json

ROOT=Path(__file__).resolve().parents[1]
OFF=Path(r'C:\Dev\A2WC511R_RK03_FullUploadNoStart\full_upload_no_start')
FIRST=Path(r'C:\Dev\A2WC511R_RK03_FirstChunkPhysical\first_chunk')
SEALED=Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_full_upload_no_start_20260930_01')
OUT=Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_full_upload_physical_20260930_01')
OLD_CONTROL=OUT.parent/'rk03_first_chunk_20260930_01'
STATE=Path(r'C:\Dev\A2WC511R_Final\state\CURRENT.json')
PROVIDER=Path(r'C:\Windows\SysWOW64\op20pt32.dll')
SESSION_ID='RK03_FULL_UPLOAD_NO_START_01'
SESSION=ROOT.parent/'physical_session'/SESSION_ID
TOKEN='PROCEED RK03 FULL UPLOAD NO START'
def pin(p):
    p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def write(p,text):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
def dump(p,obj):write(p,json.dumps(obj,indent=2)+'\n')
def one(text,before,after):
    assert text.count(before)==1,before
    return text.replace(before,after)
def main():
    qualification=SEALED/'qualification/QUALIFICATION.json'
    preservation=SEALED/'qualification/PRESERVATION_MANIFEST.json'
    assert pin(qualification)['sha256']=='cca85ff256dc86c7f88e3f3baa48c0868a51ff0617096455071086b5b54c2660'
    assert pin(preservation)['sha256']=='9eb37765bf8d83e8f2050e008d77ab63d575cfccaacca111877e72f5bb7f54c7'
    assert pin(PROVIDER)['sha256']=='f432084801762d919a3c31974616e097562424470003edc4f4fb843df34103cf'
    old=json.loads(qualification.read_text());assert old['passed_cases']==287
    preserved=json.loads(preservation.read_text())['files']
    for row in preserved:assert pin(row['path'])['sha256']==row['sha256'],row['path']
    fixed=json.loads((SEALED/'FIXED_UPLOAD_MANIFEST.json').read_text())
    assert len(fixed['chunks'])==15 and fixed['total_payload_bytes']==1808
    contract=json.loads((SEALED/'FULL_UPLOAD_NO_START_CONTRACT.json').read_text())
    contract.update({'status':'REVIEW_CONTRACT_PHYSICAL_FULL_UPLOAD_NO_START_NOT_AUTHORIZATION',
        'created_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'scope':'ONE_FRESH_PHYSICAL_SESSION_FIXED15_CHUNKS_THEN_CLEANUP',
        'physical_entry_point':True,'provider_loader':True,'physical_authorization':False,
        'session_id':SESSION_ID,'session_path':str(SESSION),'requires_exact_human_authorization':TOKEN,
        'maximum_physical_invocations':1,'base_branch':'rk03/full-upload-no-start',
        'base_commit':'4cb0bee977fcd979af2e88223c1ff14898ab72bf','build_branch':'rk03/full-upload-no-start-physical',
        'physical_provider':pin(PROVIDER),'offline_qualification':pin(qualification),
        'offline_manifest':pin(preservation),'fixed_upload_manifest':pin(SEALED/'FIXED_UPLOAD_MANIFEST.json'),
        'forbidden':['kernel start','kernel execution','kernel version','ROM read','flash operation','arbitrary address','arbitrary payload','sixteenth36','retry'],
        'limitations':['Separate physical executable requires new independent qualification and explicit user authorization.',
            'All remaining physical chunk acceptance and full-unstarted-upload recovery remain unproven until this experiment.',
            'ACK acceptance is not physical RAM readback. No causal attribution among individual transport changes.'],
        'simplified_physical_gates':['IGNITION OFF','TEST MODE ON'],
        'recovery_gates':['IGNITION OFF','NORMAL MODE ON'],'automatic_retry_allowed':False})
    OUT.mkdir(exist_ok=False)
    dump(OUT/'PHYSICAL_FULL_UPLOAD_REVIEW_CONTRACT.json',contract)
    contract_sha=pin(OUT/'PHYSICAL_FULL_UPLOAD_REVIEW_CONTRACT.json')['sha256']
    dump(OUT/'PRESERVED_OFFLINE_CHECKPOINT_VERIFICATION.json',{'status':'PASS_UNCHANGED_SEALED_OFFLINE_CHECKPOINT',
        'qualification':pin(qualification),'preservation_manifest':pin(preservation),'verified_files':len(preserved),
        'provider':pin(PROVIDER),'physical_operations':0,'old_offline_tests_repeated':False})
    for p in (OFF/'src').iterdir():
        if p.name in ['main.cpp','contract_pin.hpp','probe_core.hpp']:continue
        write(ROOT/'src'/p.name,p.read_text())
    core=(OFF/'src/probe_core.hpp').read_text()
    core=one(core,'require(!p,"Only static offline API allowed");','require(!p||real,"Physical mode requires monotonic minimum waits");')
    assert core.count('pass?"PASS_OFFLINE_FULL_KERNEL_UPLOAD_NO_START_ONLY":')==2
    core=core.replace('pass?"PASS_OFFLINE_FULL_KERNEL_UPLOAD_NO_START_ONLY":','pass?(physical?"PASS_FULL_UPLOAD_NO_START_ONLY":"PASS_OFFLINE_FULL_KERNEL_UPLOAD_NO_START_ONLY"):')
    write(ROOT/'src/probe_core.hpp',core)
    for name in ['bootstrap.hpp','bootstrap_tests.hpp']:write(ROOT/'src'/name,(FIRST/'src'/name).read_text())
    pins=(FIRST/'src/pins.hpp').read_text()
    pins=pins.replace('a7482b0eba224c9642745b830c71b3fff14f987988a58cdc1376e45dc0aa839c',contract_sha)
    pins=pins.replace('RK03_FIRST_CHUNK_01',SESSION_ID).replace('PROCEED RK03 FIRST CHUNK PROBE',TOKEN)
    pins=pins.replace('rk03_first_chunk_20260930_01','rk03_full_upload_physical_20260930_01').replace('FIRST_CHUNK_REVIEW_CONTRACT.json','PHYSICAL_FULL_UPLOAD_REVIEW_CONTRACT.json').replace('A2WC511R_RK03_FirstChunkPhysical','A2WC511R_RK03_FullUploadPhysical')
    write(ROOT/'src/pins.hpp',pins)
    main=(FIRST/'src/main.cpp').read_text()
    main=main.replace('--physical-first-chunk-probe','--physical-full-upload-no-start').replace('first_chunk_start','full_upload_start')
    main=main.replace('fixture=="physical_transition_replay"','fixture=="physical_first_chunk_replay"')
    main=main.replace('embedded_cipher_bytes\\\":128','embedded_cipher_bytes\\\":1808').replace('FIRST_CHUNK_PROBE','FULL_UPLOAD_NO_START')
    assert main.count('embedded_cipher_bytes\\\":1808')==2
    write(ROOT/'src/main.cpp',main)
    for p in (OFF/'fixtures').glob('*.json'):write(ROOT/'fixtures'/p.name,p.read_text())
    build=(OFF/'tools/build_probe.py').read_text().replace('rk03_full_upload_no_start_offline32.exe','rk03_full_upload_no_start_physical32.exe').replace('BUILD_ONLY_OFFLINE_FULL_UPLOAD_NO_START_PE_NOT_EXECUTED','BUILD_ONLY_GATED_PHYSICAL_FULL_UPLOAD_NO_START_PE_NOT_EXECUTED')
    write(ROOT/'tools/build_probe.py',build)
    command=(OFF/'tools/build_probe.cmd').read_text().replace('rk03_full_upload_no_start_offline32.exe','rk03_full_upload_no_start_physical32.exe').replace('/link /Brepro','/link /Brepro bcrypt.lib')
    write(ROOT/'tools/build_probe.cmd',command)
    write(ROOT/'.gitignore','build_*/\nreports/\n__pycache__/\n')
    inputs=[pin(p) for p in sorted((OFF/'src').iterdir())]+[pin(p) for p in [qualification,preservation,
        SEALED/'FULL_UPLOAD_NO_START_CONTRACT.json',SEALED/'FIXED_UPLOAD_MANIFEST.json',
        OUT/'PHYSICAL_FULL_UPLOAD_REVIEW_CONTRACT.json',PROVIDER,Path(__file__),
        FIRST/'src/bootstrap.hpp',FIRST/'src/bootstrap_tests.hpp',FIRST/'src/main.cpp']]
    dump(ROOT/'INPUT_PINS.json',{'schema':1,'scope':'PHYSICAL_BOUNDARY_QUALIFICATION_OFFLINE_FIRST','inputs':inputs})
    # Reuse reviewed one-shot launcher, passive recovery and their purely mocked tests in this new scope.
    replacements=[('launch_first_chunk_once','launch_full_upload_once'),('RK03_FIRST_CHUNK_01',SESSION_ID),
        ('A2WC511R_RK03_FirstChunkPhysical','A2WC511R_RK03_FullUploadPhysical'),
        ('first_chunk/build_a/rk03_first_chunk_probe32.exe','full_upload_physical/build_a/rk03_full_upload_no_start_physical32.exe'),
        ('FIRST_CHUNK_REVIEW_CONTRACT.json','PHYSICAL_FULL_UPLOAD_REVIEW_CONTRACT.json'),
        ('FIRST_CHUNK_GATE_STATE.json','FULL_UPLOAD_GATE_STATE.json'),('PROCEED RK03 FIRST CHUNK PROBE',TOKEN),
        ('AUTHORIZED_FIRST_CHUNK_ONLY','AUTHORIZED_FULL_UPLOAD_NO_START_ONLY'),
        ('PASS_OFFLINE_QUALIFIED_FIRST_CHUNK_ONLY','PASS_OFFLINE_QUALIFIED_PHYSICAL_FULL_UPLOAD_NO_START_ONLY'),
        ('--physical-first-chunk-probe','--physical-full-upload-no-start'),
        ('RK03_FIRST_CHUNK_PROBE_RUNNING','RK03_FULL_UPLOAD_NO_START_RUNNING'),
        ('first_chunk_physical_invocations','full_upload_physical_invocations'),
        ('first_chunk_process_id','full_upload_physical_process_id'),('first_chunk_session','full_upload_physical_session'),
        ('oem_return_after_first_chunk_01','oem_return_after_full_upload_01')]
    for old_name,new_name in [('launch_first_chunk_once.py','launch_full_upload_once.py'),('launch_oem_return_once.py','launch_oem_return_once.py'),
        ('test_launcher_offline.py','test_launcher_offline.py'),('test_oem_return_controls.py','test_oem_return_controls.py'),('check_clients.ps1','check_clients.ps1')]:
        text=(OLD_CONTROL/old_name).read_text()
        for a,b in replacements:text=text.replace(a,b)
        text=text.replace('first-chunk','full-upload/no-start')
        if new_name=='check_clients.ps1':text=text.replace('rk03_transition_probe32','rk03_transition_probe32|rk03_first_chunk_probe32|rk03_full_upload_no_start_physical32')
        write(OUT/new_name,text)
    before=json.loads(STATE.read_text());dump(OUT/'CURRENT_BEFORE_PHYSICAL_RELEASE.json',before)
    before.update({'updated_utc':contract['created_utc'],'phase':'RK03_FULL_UPLOAD_PHYSICAL_RELEASE_QUALIFICATION',
        'active_objective':'Separately qualify physical fixed15-chunk upload/no-start; await fresh simplified gates and explicit token before one launch',
        'completion_claimed':False,'further_physical_activity_allowed':False,
        'full_upload_physical_status':'RELEASE_QUALIFICATION_PENDING','full_upload_physical_invocations':0,
        'full_upload_physical_authorization_received':False,'full_upload_physical_session':str(SESSION),
        'full_upload_physical_analysis_directory':str(OUT),'full_upload_physical_development_directory':str(ROOT.parent),
        'human_required':[],'next_action':'Complete physical-release offline qualification and independent review before requesting IGNITION OFF'})
    STATE.write_text(json.dumps(before,indent=2)+'\n')
    print(json.dumps({'status':'DERIVED_NOT_EXECUTED','contract_sha256':contract_sha,'preserved_files_verified':len(preserved),'session_id':SESSION_ID}))
if __name__=='__main__':main()
