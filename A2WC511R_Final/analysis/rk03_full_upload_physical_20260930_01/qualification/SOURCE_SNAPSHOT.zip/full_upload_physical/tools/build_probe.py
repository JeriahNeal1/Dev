"""Build the offline-only full-upload-no-start replay; never launch the PE or load a provider."""
import hashlib,json,pathlib,subprocess,sys,datetime
ROOT=pathlib.Path(__file__).resolve().parents[1]
def pin(p):
    p=pathlib.Path(p)
    return {"path":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}
def main():
    if len(sys.argv)!=2 or sys.argv[1] not in ('build_a','build_b'):
        raise SystemExit('Required clean build_a or build_b')
    out=ROOT/sys.argv[1]
    out.mkdir(exist_ok=False)
    sources=sorted((ROOT/'src').glob('*'))+sorted((ROOT/'fixtures').glob('*.json'))+[ROOT/'tools/build_probe.cmd',pathlib.Path(__file__).resolve(),ROOT/'INPUT_PINS.json']
    before=[pin(p) for p in sources]
    (out/'BUILD_INPUTS.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
    log=out/'build.log'
    with log.open('wb') as stream:
        result=subprocess.run(['cmd.exe','/d','/c',str(ROOT/'tools/build_probe.cmd'),out.name],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,timeout=180,check=False)
    if result.returncode:
        print(log.read_text(errors='replace'));raise SystemExit(result.returncode)
    if before!=[pin(p) for p in sources]:
        raise SystemExit('Build inputs changed during compilation')
    exe=out/'rk03_full_upload_no_start_physical32.exe'
    report={'schema':1,'status':'PASS_BUILD_ONLY','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exe_path':str(exe),'exe_sha256':pin(exe)['sha256'],'source_inputs':before,
        'compiler':pin(pathlib.Path((out/'resolved_compiler.txt').read_text().splitlines()[0])),
        'linker':pin(pathlib.Path((out/'resolved_linker.txt').read_text().splitlines()[0])),
        'build_log':pin(log),'imports':pin(out/'imports.txt'),'headers':pin(out/'headers.txt'),
        'command':['cmd.exe','/d','/c',str(ROOT/'tools/build_probe.cmd'),out.name],
        'scope':'BUILD_ONLY_GATED_PHYSICAL_FULL_UPLOAD_NO_START_PE_NOT_EXECUTED'}
    (out/'BUILD.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':report['status'],'report':str(out/'BUILD.json'),'exe_sha256':report['exe_sha256']}))
if __name__=='__main__':main()
