# Final fixed128 two-pass physical release

Exactly two sequential1MiB passes,8192x128-byte blocks/pass. Proven fixed128 kernel/upload/start/identity retained. One future explicit authorization; no physical execution during qualification. See FINAL_RUN_PLAN.md and separately sealed certificate. No arbitrary address/size/pass/kernel, thirdpass, retry or flash path.

38 new same-PE fake-provider cases passed, two clean identical native builds. Separate independent validator65 checks, launcher36 and recovery14 checks. Reused prior physical/kernel evidence was not rerun. Data files and legacy fixture actions are references; compiled FixedReads controls physical sequencing.
