#pragma once
static constexpr const char* CONTRACT_SHA="22944aad65f7999f064c48acb2335ab4f871826aca770119d44b4d90fdc34ac9";
static constexpr const char* PROVIDER_SHA="f432084801762d919a3c31974616e097562424470003edc4f4fb843df34103cf";
static constexpr const char* SESSION_ID="RK03_FINAL_TWO_PASS_128_01";
static constexpr const char* AUTH_TOKEN="PROCEED RK03 FINAL TWO PASS ACQUISITION";
static constexpr const wchar_t* CONTRACT_PATH=L"C:\\Dev\\A2WC511R_Final\\analysis\\rk03_final_two_pass_128_20260930_01\\FINAL_TWO_PASS_REVIEW_CONTRACT.json";
static constexpr const wchar_t* PROVIDER_PATH=L"C:\\Windows\\SysWOW64\\op20pt32.dll";
static constexpr const wchar_t* SESSION_PATH=L"C:\\Dev\\A2WC511R_RK03_FinalTwoPass128\\physical_session\\RK03_FINAL_TWO_PASS_128_01";
