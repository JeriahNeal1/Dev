#pragma once
#include "prefix_fake.hpp"
#include "current_physical_replay.hpp"
// Same-PE static backend. There is no provider loader/device access in this file.
// Admission uses the successful physical128 transcript. ROM suffixes are synthetic,
// independently generated from the supplied pinned reference, not historical wire data.
namespace fake {
static const char* SIMPLE_CASES[]={
 "success","success_changed_current","success_fragmented","success_indicators","success_echo",
 "corruption_pass0_first","corruption_pass0_middle","pass1_mismatch_first","pass1_mismatch_final",
 "output_write_first","output_write_middle","output_write_last","output_flush","output_size",
 "cleanup_stop_fail","cleanup_disconnect_fail","cleanup_close_fail","cleanup_all_fail",
 "prefix_identity_bad","prefix_upload_status16","rx_protocol_first","rx_flags_first","rx_count_first",
 "late_reply_first","wrong_pass_first","wrong_command_first","extra_byte_first"
};
static const char* FAULTS[]={"bad_checksum","wrong_address","wrong_length","short","missing","duplicate","reorder","status_failure","write_failure"};
static const char* PLACES[]={"first","middle","final"};
inline bool accepted(const std::string& n){for(auto s:SIMPLE_CASES)if(n==s)return true;for(auto f:FAULTS)for(auto p:PLACES)if(n==std::string(f)+"_"+p)return true;return false;}
struct State{std::string name;Bytes reference;unsigned requests=0;unsigned target=0;bool injected=false;};
inline State& state(){static State s;return s;}
inline bool is(const char* name){return state().name==name;}
inline bool at(const char* fault,unsigned index){const auto& n=state().name;return index==state().target&&n.rfind(std::string(fault)+"_",0)==0;}
inline void select(const std::string& name){require(accepted(name),"Unknown final offline fixture");state()=State{};state().name=name;state().target=name.size()>=7&&name.compare(name.size()-7,7,"_middle")==0?8192u:(name.size()>=6&&name.compare(name.size()-6,6,"_final")==0?16383u:0u);prefix_fake::select(is("prefix_identity_bad")?"identity_wrong_identity":(is("prefix_upload_status16")?"status16_21":"physical_identity_replay"));}
inline void set_reference(const Bytes& reference){require(reference.size()==1048576,"Fake complete reference1MiB");state().reference=reference;}
inline int output_fault(){if(is("output_write_first"))return 1;if(is("output_write_middle"))return 2;if(is("output_write_last"))return 3;if(is("output_flush"))return 4;if(is("output_size"))return 5;return 0;}
inline Bytes request(unsigned index){require(index<16384,"Fake no third pass");unsigned pass=index/8192,address=(index%8192)*128;Bytes b={0xbe,0xef,0,8,3,static_cast<unsigned char>(pass),static_cast<unsigned char>(address>>24),static_cast<unsigned char>(address>>16),static_cast<unsigned char>(address>>8),static_cast<unsigned char>(address),0,128};b.push_back(checksum(b));return b;}
inline Bytes response(unsigned index){require(index<16384&&state().reference.size()==1048576,"Fake reference/index bounds");unsigned pass=index/8192,address=(index%8192)*128;Bytes b={0xbe,0xef,0,134,0x83,static_cast<unsigned char>(pass),static_cast<unsigned char>(address>>24),static_cast<unsigned char>(address>>16),static_cast<unsigned char>(address>>8),static_cast<unsigned char>(address)};b.insert(b.end(),state().reference.begin()+address,state().reference.begin()+address+128);
 // Changed-current is a transport success with equal passes and different baseline.
 if(is("success_changed_current")&&address==0)b[10]^=1;
 if((is("corruption_pass0_first")&&index==0)||(is("corruption_pass0_middle")&&index==4096)||(is("pass1_mismatch_first")&&index==8192)||(is("pass1_mismatch_final")&&index==16383))b[10]^=1;
 b.push_back(checksum(b));return b;}
inline PASSTHRU_MSG message(const Bytes& b,U status=0){auto m=prefix_fake::message(b,status);m.ExtraDataIndex=m.DataSize;return m;}
inline long PT_CALL write(U channel,const void* input,U* count,U timeout){
 auto& p=prefix_fake::state();auto& s=state();if(p.writes<24)return prefix_fake::write(channel,input,count,timeout);
 if(channel!=701||!input||!count||*count!=1||timeout!=1000||!p.filtered||!p.kernel_filtered||!p.kernel_baud||p.active_filter!=703||!p.queue.empty()||s.requests>=16384)return 7;
 const auto m=static_cast<const PASSTHRU_MSG*>(input);unsigned index=s.requests;auto tx=request(index);PASSTHRU_MSG expected{};set_message(expected,tx);if(memcmp(m,&expected,sizeof(expected)))return 7;
 ++s.requests;++p.writes;if(at("write_failure",index)){s.injected=true;return 7;}
 if(at("missing",index)||at("status_failure",index)){s.injected=true;return 0;}
 auto b=response(index);bool recalc=false;
 if(at("wrong_address",index)){b[9]^=1;recalc=true;}
 if(at("wrong_length",index)){b[3]=133;recalc=true;}
 if(at("bad_checksum",index)){b.back()^=1;s.injected=true;}
 if(at("short",index)){b.pop_back();s.injected=true;}
 if(at("duplicate",index)){b=response(index?index-1:index);auto copy=b;b.insert(b.end(),copy.begin(),copy.end());s.injected=true;}
 if(at("reorder",index)){b=response(index==16383?index-1:index+1);s.injected=true;}
 if(is("wrong_pass_first")&&index==0){b[5]=1;recalc=true;}
 if(is("wrong_command_first")&&index==0){b[4]=0x81;recalc=true;}
 if(recalc){b.back()=checksum(Bytes(b.begin(),b.end()-1));s.injected=true;}
 if(is("extra_byte_first")&&index==0){b.push_back(0);s.injected=true;}
 // Fragmentation is concentrated at first/pass boundary/final to avoid redundant huge logs.
 const bool boundary=index==0||index==8192||index==16383;
 if(boundary&&is("success_echo"))p.queue.push_back(message(tx,TX_MSG_TYPE));
 if(boundary&&is("success_indicators")){p.queue.push_back(message({},START_OF_MESSAGE));p.queue.push_back(message({},TX_DONE));p.queue.push_back(message(tx,TX_MSG_TYPE));p.queue.push_back(message(tx,TX_MSG_TYPE|TX_DONE));}
 if(boundary&&(is("success_fragmented")||is("success_indicators"))){for(auto byte:b)p.queue.push_back(message({byte}));return 0;}
 auto rx=message(b);if(index==0){if(is("rx_protocol_first")){rx.ProtocolID=4;s.injected=true;}if(is("rx_flags_first")){rx.TxFlags=1;s.injected=true;}}
 p.queue.push_back(rx);return 0;
}
inline long PT_CALL read(U channel,void* output,U* count,U timeout){
 auto& p=prefix_fake::state();auto& s=state();if(p.writes<=24)return prefix_fake::read(channel,output,count,timeout);
 if(channel!=701||!output||!count||*count!=1||timeout==0||timeout>1000||s.requests==0)return 7;unsigned index=s.requests-1;
 if(at("status_failure",index)){*count=0;return 7;}if(p.queue.empty()){*count=0;return 16;}
 if(is("late_reply_first")&&index==0&&!s.injected){s.injected=true;Sleep(2100);}
 *static_cast<PASSTHRU_MSG*>(output)=p.queue.front();p.queue.pop_front();if(is("rx_count_first")&&index==0){*count=2;s.injected=true;}return 0;
}
inline long PT_CALL stop_filter(U channel,U id){if(id==703&&(is("cleanup_stop_fail")||is("cleanup_all_fail")))return 7;return prefix_fake::stop_filter(channel,id);}
inline long PT_CALL disconnect(U channel){if(is("cleanup_disconnect_fail")||is("cleanup_all_fail"))return 7;return prefix_fake::disconnect(channel);}
inline long PT_CALL close(U device){if(is("cleanup_close_fail")||is("cleanup_all_fail"))return 7;return prefix_fake::close(device);}
inline long wait_ms(U ms){return prefix_fake::wait_ms(ms);}
inline unsigned long long virtual_ms(){return prefix_fake::virtual_ms();}
inline Api api(){return {prefix_fake::open,close,prefix_fake::connect,disconnect,read,write,prefix_fake::filter,stop_filter,prefix_fake::version,prefix_fake::ioctl,wait_ms,virtual_ms};}
}
