#pragma once
#include "bootstrap.hpp"
#include "fixed_reads.hpp"
struct RawImages {
 static constexpr const wchar_t* REFERENCE_PATH=L"C:\\Dev\\SubaruRoms\\current.bin";
 static constexpr const char* REFERENCE_SHA="bf10be6d7c75b4f2ae663b0d57a912e6e9ef7654ccfc985195954596e50427b2";
 Handle baseline,files[2];Bytes reference,pass0;unsigned accepted=0;unsigned counts[2]={0,0};int fault=0;std::string result;
 static Bytes load(HANDLE h){LARGE_INTEGER z{},size{};require(GetFileSizeEx(h,&size)&&size.QuadPart==FixedReads::END,"Exact one MiB file length required");require(SetFilePointerEx(h,z,nullptr,FILE_BEGIN)!=0,"Raw file rewind");Bytes b(FixedReads::END);DWORD n=0;require(ReadFile(h,b.data(),FixedReads::END,&n,nullptr)&&n==FixedReads::END,"Exact one MiB file read");return b;}
 void prepare(const std::wstring& directory,bool make_directory,int offline_fault=0){
  require(offline_fault>=0&&offline_fault<=5,"Fixed output fault bound");fault=offline_fault;
  baseline.value=locked_read(REFERENCE_PATH);require(sha256(baseline.value)==REFERENCE_SHA,"Pinned comparison baseline hash changed");reference=load(baseline.value);
  if(make_directory)require(CreateDirectoryW(directory.c_str(),nullptr)!=0,"Exclusive new offline image directory");
  for(unsigned p=0;p<2;p++){const auto name=directory+(p?L"\\pass1.raw":L"\\pass0.raw");files[p].value=CreateFileW(name.c_str(),GENERIC_READ|GENERIC_WRITE,0,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr);require(files[p].value!=INVALID_HANDLE_VALUE,"Exclusive new raw image required");}
  pass0.resize(FixedReads::END);
 }
 bool matches_pass0(unsigned index,const Bytes& frame)const{require(index<FixedReads::COUNT&&frame.size()==139,"Fixed comparison dimensions");if(index<FixedReads::PER_PASS)return true;const auto a=FixedReads::address(index);return std::equal(frame.begin()+10,frame.end()-1,pass0.begin()+a);}
 std::string differences(unsigned index,const Bytes& frame)const{
  std::string s="[";unsigned n=0;if(index>=FixedReads::PER_PASS){const auto a=FixedReads::address(index);for(unsigned i=0;i<128;i++)if(frame[10+i]!=pass0[a+i]){if(n++)s+=',';s+="{\"address\":"+number(a+i)+",\"pass0\":"+number(pass0[a+i])+",\"pass1\":"+number(frame[10+i])+"}";}}return s+"]";
 }
 void accept(unsigned index,const Bytes& frame){
  require(index==accepted&&index<FixedReads::COUNT&&frame.size()==139,"Exact sequential output index");const unsigned p=FixedReads::pass(index),a=FixedReads::address(index);
  require(counts[p]==a,"No output gap duplicate or overlap");require(matches_pass0(index,frame),"Pass-to-pass block mismatch; terminal without retry");
  DWORD n=0;const bool injected=(fault==1&&index==0)||(fault==2&&index==8192)||(fault==3&&index==16383);
  require(!injected&&WriteFile(files[p].value,frame.data()+10,128,&n,nullptr)&&n==128,"Raw image write failed");
  if(p==0)std::copy(frame.begin()+10,frame.end()-1,pass0.begin()+a);counts[p]+=128;accepted++;
 }
 static std::string comparison(const Bytes& raw,const Bytes& baseline){
  require(raw.size()==FixedReads::END&&baseline.size()==FixedReads::END,"Independent full baseline comparison dimensions");unsigned count=0;std::string ranges="[";bool first=true;
  for(unsigned i=0;i<FixedReads::END;){if(raw[i]==baseline[i]){i++;continue;}unsigned start=i;while(i<FixedReads::END&&raw[i]!=baseline[i]){count++;i++;}if(!first)ranges+=',';first=false;ranges+="{\"start\":"+number(start)+",\"end_exclusive\":"+number(i)+"}";}
  return "{\"identical\":"+boolean(count==0)+",\"differing_bytes\":"+number(count)+",\"differing_ranges\":"+ranges+"]}";
 }
 std::string finish(){
  require(accepted==16384&&counts[0]==1048576&&counts[1]==1048576,"Exactly two complete one MiB outputs");
  require(fault!=4&&FlushFileBuffers(files[0].value)&&FlushFileBuffers(files[1].value),"Raw image flush failed");
  require(fault!=5,"Injected raw file length check failure");const auto a=load(files[0].value),b=load(files[1].value);
  require(a==pass0&&a==b,"Written images must exactly equal captured pass0 and each other");const auto ah=sha256(files[0].value),bh=sha256(files[1].value);require(ah==bh,"Final pass SHA256 mismatch");
  result="{\"type\":\"full_read_result\",\"passes\":2,\"blocks_per_pass\":8192,\"block_bytes\":128,\"ROM_start\":0,\"ROM_end_exclusive\":1048576,\"pass0_bytes\":1048576,\"pass1_bytes\":1048576,\"pass0_sha256\":"+quote(ah)+",\"pass1_sha256\":"+quote(bh)+",\"pass_to_pass_identical\":true,\"current_reference_sha256\":"+quote(REFERENCE_SHA)+",\"pass0_vs_current\":"+comparison(a,reference)+",\"pass1_vs_current\":"+comparison(b,reference)+",\"baseline_equality_required_for_transport\":false}";return result;
 }
 ~RawImages(){for(auto& f:files)if(f.value!=INVALID_HANDLE_VALUE)FlushFileBuffers(f.value);}
};
