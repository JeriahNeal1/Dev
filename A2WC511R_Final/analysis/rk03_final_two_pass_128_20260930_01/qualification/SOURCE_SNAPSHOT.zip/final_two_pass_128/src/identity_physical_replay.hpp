#pragma once
#include "current_physical_replay.hpp"
// Existing prefix simulator compatibility: updated to the newest successful128 transcript.
static constexpr const char* IDENTITY_PHYSICAL_VERSION_FIRMWARE=CURRENT_VERSION_FIRMWARE;
static constexpr const char* IDENTITY_PHYSICAL_VERSION_DLL=CURRENT_VERSION_DLL;
static constexpr const char* IDENTITY_PHYSICAL_VERSION_API=CURRENT_VERSION_API;
static constexpr const char* IDENTITY_PHYSICAL_KEY_TX=CURRENT_PHYSICAL_TX[4];
inline PASSTHRU_MSG identity_physical_replay_message(unsigned i){require(i<48,"Identity prefix48 records");return current_physical_replay_message(i);}
