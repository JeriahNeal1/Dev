#pragma once
#include "common.hpp"
struct FixedReads {
 static constexpr unsigned BEGIN=0,END=0x100000,BLOCK=128,PER_PASS=8192,PASSES=2,COUNT=16384,PREFIX=24,MAX_TX=16408;
 static_assert(END==BLOCK*PER_PASS&&COUNT==PER_PASS*PASSES&&MAX_TX==PREFIX+COUNT,"Complete fixed coverage");
 static unsigned pass(unsigned index){require(index<COUNT,"Exactly two fixed passes");return index/PER_PASS;}
 static unsigned address(unsigned index){require(index<COUNT,"No read outside fixed schedule");return (index%PER_PASS)*BLOCK;}
 static Bytes request(unsigned index){unsigned a=address(index);Bytes b={0xbe,0xef,0,8,3,static_cast<unsigned char>(pass(index)),static_cast<unsigned char>(a>>24),static_cast<unsigned char>(a>>16),static_cast<unsigned char>(a>>8),static_cast<unsigned char>(a),0,128};b.push_back(checksum(b));return b;}
 static Bytes header(unsigned index){auto b=request(index);b.resize(10);b[3]=134;b[4]=0x83;return b;}
};
struct ScheduledReply {
 const unsigned index;Bytes bytes;unsigned pieces=0,indicators=0;
 explicit ScheduledReply(unsigned i):index(i){require(i<FixedReads::COUNT,"Fixed read parser index");}
 bool consume(const PASSTHRU_MSG& m,const Bytes& tx){
  require(++pieces<=143,"Fixed RX message count bound");
  require(m.ProtocolID==3&&m.TxFlags==0&&m.DataSize<=139&&(m.ExtraDataIndex==0||m.ExtraDataIndex==m.DataSize),"Fixed RX metadata bounds");
  Bytes data(m.Data,m.Data+m.DataSize);
  if(m.RxStatus){require(bytes.empty()&&++indicators<=4,"Fixed RX indication position/count");
   if(m.RxStatus==START_OF_MESSAGE||m.RxStatus==TX_DONE)require(data.empty(),"Nonempty fixed indication");
   else if(m.RxStatus==TX_MSG_TYPE||m.RxStatus==(TX_MSG_TYPE|TX_DONE))require(data==tx,"Unexpected fixed TX echo");
   else require(false,"Unknown fixed RX status");return false;
  }
  require(!data.empty()&&bytes.size()+data.size()<=139,"Fixed reply exact maximum");bytes.insert(bytes.end(),data.begin(),data.end());
  const auto expected=FixedReads::header(index);
  require(std::equal(bytes.begin(),bytes.begin()+std::min(bytes.size(),expected.size()),expected.begin()),"Fixed framing length command pass address");
  if(bytes.size()<139)return false;
  require(bytes.back()==checksum(Bytes(bytes.begin(),bytes.end()-1)),"Fixed response checksum");return true;
 }
};
