#pragma once
// Preserved successful physical128 transcript, static fake use only.
// Source: C:\Dev\A2WC511R_RK03_Bounded128Physical\physical_session\RK03_BOUNDED_ROM_READ_128_01\native_api.jsonl
// SHA256: 93d2ae9af66ab17c03af42926a5126fb35a83a197bb44721d1ee3521bcdaf380
// Host timing is not replayed. Provider IDs1/3/0/1 map to fake700/701/702/703.
// Only the first24 transactions are reused for admission; later generated ROM replies are synthetic.
static constexpr const char* CURRENT_VERSION_FIRMWARE="312e31372e343837370000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
static constexpr const char* CURRENT_VERSION_DLL="312e30322e343837302046656220203320323031372032333a33363a30350000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
static constexpr const char* CURRENT_VERSION_API="30342e3034000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
static constexpr const char* CURRENT_PHYSICAL_TX[]={"8010f001bf40","8010f0018102","8010f002830005","8010f0022701aa","8010f00627021e7adce70a","8010f0031085021a","8010f00834ff30000400071006","8010f08436ff30002178b10a345b1076fd256f75f05ba033e301ed7bbae243b735e6aedbc143c40be01bf9b6caab4599eccaacb23d3eeb06dddf471ed3b0238f2bf0553861e117054bad87079a8cbb9681c01303b7825b2d199bc7e5c4dd5bcf85cf1a64050df3ab050df3ab2a45f9b476963b1f16baea94084e321a79bd4cf9c0f25912ab9d7b8df4","8010f08436ff3080a614d816e73b7a2f8010d0033c21fd82e809dcd33849889e1bb8439f58c18e12d1328f80e2d30dccf17eadf57d339c382284e4779a8cbb96094cf9da205bf8c04e6120419a8cbb9687d0d3c3ea5b98c957670833e1a0128aff648ef5c03ca6b7b876eac3f7b569d887422e4be8f5108bedc55089c03ca6b7539b8ad1a4d30a534a","8010f08436ff3100e28c3ee42446007d2de0ddaa9dce70327241c643aab2699ea62dd88c9cead164bbf16590f4e0cd28e987359e6b371cd882af16896daaa08c2bfb509b6f5a700b7016e8ad4d3d09337306eba60e9f2d6e3e5ccec225f798f1fc359ea168d7727d2e12bfa5927d740c170a930a862403ee9330f481bc7dd24e36e13bd0697c3ebcfc","8010f08436ff3180e53ad55784b629fd3cea7e81d4dc1bda5cf12a09f0b79a4aa55b665170242840fb7a57ac4529e2035494df2334c35cd56728ca429349c6346df8cb0851762c820bd86e23ff3f981ecfaa3f64bd138e591f7758aa5bc2bb0a356880ee7fe99c9e999df968b7990b479cead164b8a522b9916f7876b64b0a986df8cb08e41af6e447","8010f08436ff3200eca5fa6a8a62f844b5e1848ef17eadf568825b141d4ff58dc89ab04cfbd4a32d9abc830e01f8532ebdbc9702cee42851332c5982b6577390905dcdb16d01a44985461295b0146d10af5802982bcc68f85cf4a719a94e5346ef3981a189138327778d6eabd4a1b462624856a52b19196c33317cbf50c026109533ebf66df8cb08ea","8010f08436ff3280f40b4a6eaac8fec9999df968727f34e532725d2a308f31b7fd4a3cc0fb7a57ac2178b10aecaf7860c2a995fabf999e820e33d2922119a57cfdd3ffff83d78c2ed9d6fc2e55d8f95b582d518eecaf786053bb63cf43eb460683d78c2e08ac051618f01400e24c1787a16505d65eb63b868a551574082d051ad708c41bde2eec0c0e","8010f08436ff33006bf35d4fef1ead4e87be33e29dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf3123c8","8010f08436ff33809dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf3123ec","8010f08436ff34009dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31236d","8010f08436ff34809dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf3123ed","8010f08436ff35009dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31236e","8010f08436ff35809dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf3123ee","8010f08436ff36009dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31236f","8010f08436ff36809dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf31239dbf3123ef","8010f01436ff37009dbf31239dbf31239dbf3123506e0f1dfa","8010f003310101b6","beef000101af","beef0008030000000000008038"};
inline PASSTHRU_MSG current_physical_replay_message(unsigned i){PASSTHRU_MSG m{};switch(i){
case 0:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=840193698UL;m.ExtraDataIndex=0;break;
case 1:set_message(m,decode("80f01039ffa210112f1251530673facba62b81fea800000060ce54f9b1e4000c200000000000dc00005d1f3080f226000043fb00e1000000000000c1f0c2"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=840323243UL;m.ExtraDataIndex=62;break;
case 2:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=840341558UL;m.ExtraDataIndex=0;break;
case 3:set_message(m,decode("80f01003c1ef8fc2"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=840358756UL;m.ExtraDataIndex=8;break;
case 4:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=840378565UL;m.ExtraDataIndex=0;break;
case 5:set_message(m,decode("80f01007c30000ff00ff0048"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=840404261UL;m.ExtraDataIndex=12;break;
case 6:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=840424529UL;m.ExtraDataIndex=0;break;
case 7:set_message(m,decode("80f01006670110548d4726"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=840448268UL;m.ExtraDataIndex=11;break;
case 8:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=840476521UL;m.ExtraDataIndex=0;break;
case 9:set_message(m,decode("80f0100367023420"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=840493771UL;m.ExtraDataIndex=8;break;
case 10:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=840717546UL;m.ExtraDataIndex=0;break;
case 11:set_message(m,decode("80f01002508557"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=840732798UL;m.ExtraDataIndex=7;break;
case 12:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=841052067UL;m.ExtraDataIndex=0;break;
case 13:set_message(m,decode("80f0100274847a"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=841057332UL;m.ExtraDataIndex=7;break;
case 14:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=841149967UL;m.ExtraDataIndex=0;break;
case 15:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=841154845UL;m.ExtraDataIndex=6;break;
case 16:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=841245501UL;m.ExtraDataIndex=0;break;
case 17:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=841250355UL;m.ExtraDataIndex=6;break;
case 18:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=841343848UL;m.ExtraDataIndex=0;break;
case 19:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=841348365UL;m.ExtraDataIndex=6;break;
case 20:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=841439061UL;m.ExtraDataIndex=0;break;
case 21:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=841443874UL;m.ExtraDataIndex=6;break;
case 22:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=841537599UL;m.ExtraDataIndex=0;break;
case 23:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=841542385UL;m.ExtraDataIndex=6;break;
case 24:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=841634667UL;m.ExtraDataIndex=0;break;
case 25:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=841639397UL;m.ExtraDataIndex=6;break;
case 26:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=841730137UL;m.ExtraDataIndex=0;break;
case 27:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=841734908UL;m.ExtraDataIndex=6;break;
case 28:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=841825544UL;m.ExtraDataIndex=0;break;
case 29:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=841830419UL;m.ExtraDataIndex=6;break;
case 30:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=841925494UL;m.ExtraDataIndex=0;break;
case 31:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=841929931UL;m.ExtraDataIndex=6;break;
case 32:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=842022370UL;m.ExtraDataIndex=0;break;
case 33:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=842026943UL;m.ExtraDataIndex=6;break;
case 34:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=842119374UL;m.ExtraDataIndex=0;break;
case 35:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=842123950UL;m.ExtraDataIndex=6;break;
case 36:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=842214712UL;m.ExtraDataIndex=0;break;
case 37:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=842219461UL;m.ExtraDataIndex=6;break;
case 38:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=842310051UL;m.ExtraDataIndex=0;break;
case 39:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=842314472UL;m.ExtraDataIndex=6;break;
case 40:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=842405140UL;m.ExtraDataIndex=0;break;
case 41:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=842409982UL;m.ExtraDataIndex=6;break;
case 42:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=842428747UL;m.ExtraDataIndex=0;break;
case 43:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=842433484UL;m.ExtraDataIndex=6;break;
case 44:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=842441867UL;m.ExtraDataIndex=0;break;
case 45:set_message(m,decode("80f01003710101f6"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=842447989UL;m.ExtraDataIndex=8;break;
case 46:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=842455943UL;m.ExtraDataIndex=0;break;
case 47:set_message(m,decode("beef000f8141325743353131522d524b3032005f"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=842459992UL;m.ExtraDataIndex=20;break;
case 48:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=842463492UL;m.ExtraDataIndex=0;break;
case 49:set_message(m,decode("beef008683000000000000000aacffffbfa000000aacffffbfa000000aa800000aa800000aa800000aa800000aa800000aa800000aa800000aa800000aa800000aa8ffffffffffffffffdf01442b00090000ffffbfa0df01000b00090000ffffbfa0e5f74518750a8451e3ff4318620c737f2239324ce13c622c4118321c25210009000900090009000b98"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=842486471UL;m.ExtraDataIndex=139;break;
default:throw std::runtime_error("Physical128 replay index bound");}return m;}
