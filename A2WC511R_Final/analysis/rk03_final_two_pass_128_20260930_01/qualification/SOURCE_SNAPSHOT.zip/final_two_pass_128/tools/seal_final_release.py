"""Seal reviewed final two-pass release; never authorize or invoke vehicle software."""
from pathlib import Path
import datetime,hashlib,json,subprocess,zipfile,sys
H=Path(__file__).resolve().parents[1];R=H.parent;A=Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_final_two_pass_128_20260930_01')
CONTROLS=['launch_final_once.py','launch_oem_return_once.py','check_clients.ps1','validate_final.py','seal_final_result.py','seal_oem_return_final.py','complete_project.py','test_launcher_offline.py','test_oem_return_controls.py','test_final_validator.py']
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,o):
 with Path(p).open('x',encoding='utf8',newline='\n') as f:json.dump(o,f,indent=2);f.write('\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def verify(obj):
 if isinstance(obj,dict):
  if isinstance(obj.get('path'),str) and isinstance(obj.get('sha256'),str):assert pin(obj['path'])['sha256']==obj['sha256'],obj['path']
  for x in obj.values():verify(x)
 elif isinstance(obj,list):
  for x in obj:verify(x)
def main():
 if sys.flags.optimize:raise RuntimeError("Sealing requires assertions enabled; optimized Python is forbidden")
 assert git('branch','--show-current')=='rk03/final-two-pass-128' and not git('status','--porcelain')
 assert not (R/'physical_session').exists(),'Final release must not have any physical invocation'
 cp=A/'FINAL_TWO_PASS_REVIEW_CONTRACT.json';c=read(cp)
 assert c['maximum_requests']==16408 and c['maximum_ROM_requests']==16384 and c['fixed_reads']['block_bytes']==128 and c['fixed_reads']['passes']==2
 assert c['kernel_sha256']=='808a5523d47de11881bfc2ea06a35278aedb5122ed51e8110f817b3210adb653' and c['entry']=='FFFF3004'
 assert c['requires_exact_human_authorization']=='PROCEED RK03 FINAL TWO PASS ACQUISITION' and c['baseline_equality_required_for_transport'] is False
 for key in ['kernel_image','kernel_manifest','physical_provider','current_reference','retained_bounded_qualification','physical128_result','physical128_review','OEM_return_after128','physical128_journal','fixed_upload_manifest']:verify(c[key])
 assert read(c['physical128_result']['path'])['RK03_BOUNDED_ROM_READ_128_PHYSICAL']=='PASS'
 assert read(c['OEM_return_after128']['path'])['OEM_RETURN_AFTER_BOUNDED_ROM_READ_128']=='PASS'
 testref=read(H/'reports/LATEST_QUALIFICATION.json')['report'];verify(testref);tests=read(testref['path'])
 assert tests['status']=='PASS' and tests['passed_cases']==tests['test_cases']==38 and tests['physical_operations']==tests['real_provider_loads']==0
 verify(tests['source_and_build_pins'])
 for case in tests['cases']:
  for key in ['journal','images','stdout','stderr']:verify(case[key])
 reviews=[A/'independent_review/REVIEW.json',A/'root_review/REVIEW.json',A/'independent_review/PACKAGING_REVIEW.json']
 for path in reviews:assert read(path)['status']=='PASS';verify(read(path))
 for name,n in [('FINAL_VALIDATOR_TESTS.json',65),('LAUNCHER_TESTS.json',36),('OEM_RETURN_CONTROL_TESTS.json',14)]:
  report=read(A/name);assert report['status']=='PASS' and report.get('passed_cases',report.get('checks_passed'))==n;verify(report)
 builds=[read(H/n/'BUILD.json') for n in ['build_a','build_b']]
 for b in builds:assert b['status']=='PASS_BUILD_ONLY';verify(b['source_inputs']);assert pin(b['exe_path'])['sha256']==b['exe_sha256']
 assert builds[0]['source_inputs']==builds[1]['source_inputs'] and Path(builds[0]['exe_path']).read_bytes()==Path(builds[1]['exe_path']).read_bytes()
 for name in CONTROLS:assert (A/name).read_bytes()==(H/'release_controls'/name).read_bytes(),name
 canonical=dict(scope='FINAL_TWO_PASS_128_FUTURE_PHYSICAL_RELEASE_NOT_AUTHORIZATION',executable_sha256=builds[0]['exe_sha256'],source_inputs=builds[0]['source_inputs'],compiler=builds[0]['compiler'],linker=builds[0]['linker'])
 for name in ['build_a','build_b']:save(H/name/'REPRODUCIBLE_MANIFEST.json',canonical)
 assert pin(H/'build_a/REPRODUCIBLE_MANIFEST.json')['sha256']==pin(H/'build_b/REPRODUCIBLE_MANIFEST.json')['sha256']
 q=A/'qualification';q.mkdir(exist_ok=False);source=[R/p for p in git('ls-files','final_two_pass_128').splitlines()];assert source
 with zipfile.ZipFile(q/'SOURCE_SNAPSHOT.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
  for p in sorted(source):
   i=zipfile.ZipInfo(p.relative_to(R).as_posix(),date_time=(2026,9,30,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o444<<16;z.writestr(i,p.read_bytes())
 paths=set(source+[cp]+reviews+[A/n for n in CONTROLS]+[A/n for n in ['FINAL_VALIDATOR_TESTS.json','LAUNCHER_TESTS.json','OEM_RETURN_CONTROL_TESTS.json','FIXED_READ_MANIFEST.json','FIXED_READ_SCHEDULE.bin','FINAL_RUN_PLAN.md']])
 for d in [H/'build_a',H/'build_b',H/'reports',A/'independent_review',A/'root_review',A/'validator_cli']:
  paths.update(p for p in d.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
 for key in ['kernel_image','kernel_manifest','physical_provider','current_reference','retained_bounded_qualification','physical128_result','physical128_review','OEM_return_after128','physical128_journal','fixed_upload_manifest']:paths.add(Path(c[key]['path']))
 reuse=A.parent/'current_rom_20260930_01/OEM_RETURN_REUSE.json';verify(read(reuse)['files']);paths.add(reuse);paths.update(Path(x['path']) for x in read(reuse)['files'])
 certificate=dict(schema=1,status='PASS_OFFLINE_QUALIFIED_PHYSICAL_FINAL_TWO_PASS_128',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),branch=git('branch','--show-current'),commit=git('rev-parse','HEAD'),session_id=c['session_id'],maximum_physical_invocations=1,physical_authorization_received=False,requires_exact_human_authorization=c['requires_exact_human_authorization'],physical_executable=pin(builds[0]['exe_path']),second_clean_executable=pin(builds[1]['exe_path']),review_contract=pin(cp),kernel_sha256=c['kernel_sha256'],entry=c['entry'],identity_ascii=c['identity_ascii'],fixed_reads=c['fixed_reads'],bytes_per_output=1048576,total_output_bytes=2097152,maximum_requests=16408,maximum_ROM_requests=16384,pass_to_pass_identity_required=True,baseline_equality_required_for_transport=False,current_reference=c['current_reference'],arbitrary_read_allowed=False,third_pass_allowed=False,flash_allowed=False,retry_allowed=False,independent_reviews=[pin(p) for p in reviews],native_test_report=testref,native_cases_passed=38,native_positive_cases=4,native_negative_cases=34,validator_tests=pin(A/'FINAL_VALIDATOR_TESTS.json'),launcher_tests=pin(A/'LAUNCHER_TESTS.json'),recovery_tests=pin(A/'OEM_RETURN_CONTROL_TESTS.json'),retained_physical128_result=c['physical128_result'],retained_OEM_return=c['OEM_return_after128'],source_snapshot=pin(q/'SOURCE_SNAPSHOT.zip'),canonical_build_manifest=pin(H/'build_a/REPRODUCIBLE_MANIFEST.json'),files=[pin(p) for p in sorted(paths)],physical_operations_during_final_qualification=0,provider_loads_during_final_qualification=0,remaining_physical_milestone='RK03 FINAL TWO-PASS 128-BYTE ACQUISITION',future_recovery=['IGNITION OFF','NORMAL MODE ON','PASSIVE BF/A8 OEM return','Raw comparison and integrity audit','Final checkpoint/tag','PROJECT COMPLETE'],limitations=c['limitations'])
 save(q/'QUALIFICATION.json',certificate);cert=pin(q/'QUALIFICATION.json')
 gates=dict(session_id=c['session_id'],qualification_sha256=cert['sha256'],status='QUALIFIED_FUTURE_RUN_NOT_AUTHORIZED',probe_invocation_count=0,launch_reserved=False,physical_authorization_received=False,completed_pre_probe_gates=[],completed_recovery_gates=[],commit_authorization=None,physical_state='UNCONFIRMED_FOR_FUTURE_SESSION',engine='OFF',operator_managed_physical_context=True,full_acquisition_allowed=True,retry_allowed=False,abort_requested=False,next_gate='IGNITION OFF',physical_execution_allowed_in_current_run=False)
 save(A/'FINAL_GATE_STATE.json',gates)
 p=A/'CHECKPOINT.json';state=read(p);state.update(status='SEALED_FINAL_TWO_PASS_128_READY_FOR_SEPARATE_PHYSICAL_RUN',certificate=cert,physical_executable=certificate['physical_executable'],physical_invocations=0,remaining_physical_milestones=1);p.write_text(json.dumps(state,indent=2)+'\n',encoding='utf8')
 p=Path(r'C:\Dev\A2WC511R_Final\state\CURRENT.json');state=read(p);state.update(phase='RK03_FINAL_TWO_PASS_128_QUALIFIED_PHYSICAL_REMAINS',final_gate_state=str(A/'FINAL_GATE_STATE.json'),final_release_certificate=cert,final_physical_invocations=0,human_required=[],next_action='Future separately authorized final two-pass128 acquisition; fresh IGNITION OFF, TEST MODE ON, exact final token',final_full_physical_allowed_this_run=False,further_physical_activity_allowed=False);p.write_text(json.dumps(state,indent=2)+'\n',encoding='utf8')
 for p in paths|set(q.iterdir()):
  if p.resolve().is_relative_to(H.resolve()) or p.resolve().is_relative_to(A.resolve()):p.chmod(0o444)
 print(json.dumps(dict(status=certificate['status'],executable=certificate['physical_executable'],certificate=cert,native_cases=38,physical_operations=0)))
if __name__=='__main__':main()
