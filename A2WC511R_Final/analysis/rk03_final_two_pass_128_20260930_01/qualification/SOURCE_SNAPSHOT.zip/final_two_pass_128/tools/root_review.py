"""Root independent audit of agent-authored fixtures, runner, and retained journals."""
from pathlib import Path
import hashlib,json,gzip
H=Path(__file__).resolve().parents[1];A=Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_final_two_pass_128_20260930_01');B=H.parent/'bounded_128_physical'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
checks=[]
def check(ok,s):
 assert ok,s
 checks.append(s)
def verify(p):check(pin(p['path'])['sha256']==p['sha256'],'pin '+p['path'])
reportpath=Path(read(H/'reports/LATEST_QUALIFICATION.json')['report']['path']);r=read(reportpath)
check(r['status']=='PASS' and r['test_cases']==r['passed_cases']==38 and r['positive_cases']==4 and r['negative_cases']==34,'38 focused cases,4 positives34 negatives')
check(r['physical_operations']==r['real_provider_loads']==0,'fake-only evidence')
for p in r['source_and_build_pins']:verify(p)
fake=(H/'src/fake_backend.hpp').read_text();runner=(H/'tools/test_final_physical.py').read_text();core=(H/'src/probe_core.hpp').read_text();oldcore=(B/'src/probe_core.hpp').read_text()
for name in ['bootstrap.hpp','protocol.hpp','common.hpp','identity_response.hpp','real_clock.hpp','owned_artifact.h','fixtures.hpp']:
 check((H/'src'/name).read_bytes()==(B/'src'/name).read_bytes(),'unchanged physically proven '+name)
for start,end in [(' void setup()', ' Bytes exchange('),(' void change_baud_and_clear()', ' void identity_transport()'),(' void identity_transport()', ' int run()'),(' template<class F> long cleanup_call',' void wait(')]:
 def part(s):return s[s.index(start):s.index(end,s.index(start))]
 check(part(core)==part(oldcore),'unchanged prefix/control '+start)
check('if(p.writes<24)return prefix_fake::write' in fake and 's.requests>=16384' in fake,'fake prefix boundary and no third pass')
check('index/8192' in fake and '(index%8192)*128' in fake and '0,128' in fake,'independent fixed fake schedule')
check('b[10]^=1' in fake and 'success_changed_current' in fake and 'corruption_pass0_middle' in fake,'separate consistent-difference and mismatch cases')
check('LoadLibrary' not in fake and 'GetProcAddress' not in fake,'fake has no provider loader')
check("flag in ['--offline-fixture','--offline-real-clock-fixture']" in runner and 'subprocess.run(argv' in runner,'runner invokes only static fake modes')
check("path.parent==RUN and path.suffix=='.jsonl'" in runner and "h.hexdigest()==original['sha256']" in runner,'lossless compression and scoped removal of new test copies only')
for case in r['cases']:
 verify(case['journal'])
 for p in case['images']:verify(p)
 verify(case['stdout']);verify(case['stderr'])
 original=case['journal_original'];path=case['journal']['path'];opener=gzip.open if case['journal_encoding']=='gzip' else open;h=hashlib.sha256();size=0
 with opener(path,'rb') as f:
  while data:=f.read(1048576):h.update(data);size+=len(data)
 check(h.hexdigest()==original['sha256'] and size==original['bytes'],'all original journal bytes preserved '+case['case']+' '+case['mode'])
 check(case['TX']<=16408 and case['completed_reads']<=16384,'actual fixed bounds '+case['case'])
 if case['positive']:
  check(case['TX']==16408 and case['completed_reads']==16384,'two complete passes '+case['case'])
  check([x['read_index'] for x in case['boundary_blocks']]==[0,8191,8192,16383],'first/final addresses of both passes '+case['case'])
  check(case['images'][0]['bytes']==case['images'][1]['bytes']==1048576 and case['images'][0]['sha256']==case['images'][1]['sha256'],'raw sizes/hash equality '+case['case'])
  check(case['full_read_result']['baseline_equality_required_for_transport'] is False,'baseline reported separately '+case['case'])
check(read(A/'FINAL_VALIDATOR_TESTS.json')['passed_cases']==65,'separate streaming validator accepts4/rejects34 actual cases plus21 tamper and6 argument cases')
c=read(A/'FINAL_TWO_PASS_REVIEW_CONTRACT.json');verify(c['physical128_journal']);verify(c['physical128_result']);verify(c['OEM_return_after128']);verify(c['kernel_image'])
check(c['kernel_sha256']=='808a5523d47de11881bfc2ea06a35278aedb5122ed51e8110f817b3210adb653','retained physically proven fixed128 kernel')
schedule=Path(c['fixed_reads']['fixed_schedule']['path']).read_bytes();verify(c['fixed_reads']['fixed_schedule']);check(len(schedule)==16384*13,'complete fixed schedule bytes')
addresses=[set(),set()]
for i in range(16384):
 b=schedule[i*13:(i+1)*13];p=i//8192;a=i%8192*128
 check(b[:5]==bytes.fromhex('beef000803') and b[5]==p and int.from_bytes(b[6:10],'big')==a and b[10:12]==bytes.fromhex('0080') and sum(b[:-1])%256==b[-1],'fixed scheduled index '+str(i));addresses[p].add(a)
check(all(s==set(range(0,1048576,128)) for s in addresses),'exact no-gap no-overlap monotonic fixed address coverage')
out=A/'root_review';out.mkdir(exist_ok=False)
result=dict(status='PASS',reviewer='root independent audit of passive_review authored fake backend/replay/test runner; separately validated actual journals and gzip integrity',checks_passed=len(checks),checks=checks,qualification=pin(reportpath),validator_tests=pin(A/'FINAL_VALIDATOR_TESTS.json'),files=[pin(H/'src'/n) for n in ['fake_backend.hpp','current_physical_replay.hpp','identity_physical_replay.hpp']]+[pin(H/'tools/test_final_physical.py'),pin(Path(__file__))],physical_operations=0,prior_qualification_reruns=0,limitations=['All new final native execution is static fake only.','Representative faults and exhaustive fixed schedule coverage are distinct; not every fault was injected into every block.','Same-byte corruption in bothpasses is not detectable by two-pass equality alone; independent current comparison remains separately reported.'])
with (out/'REVIEW.json').open('x',encoding='utf8',newline='\n') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(dict(status='PASS',checks=len(checks),review=pin(out/'REVIEW.json'))))
