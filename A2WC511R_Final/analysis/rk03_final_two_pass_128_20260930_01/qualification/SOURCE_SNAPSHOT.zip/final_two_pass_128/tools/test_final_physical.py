"""Independent focused qualification of same final PE via static fake modes only.
Author: passive_review; root separately reviews this runner and its evidence.
No prior suite is rerun. New test journals may be losslessly compressed after audit.
"""
from pathlib import Path
import datetime, gzip, hashlib, json, subprocess, traceback

ROOT=Path(__file__).resolve().parents[1]
A=Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_final_two_pass_128_20260930_01')
CONTRACT=A/'FINAL_TWO_PASS_REVIEW_CONTRACT.json'
EXE=ROOT/'build_a/rk03_final_two_pass_128_physical32.exe'
VIRTUAL=['success','success_changed_current','success_indicators']
VIRTUAL += [f'{fault}_first' for fault in ['bad_checksum','wrong_address','wrong_length','short','missing','duplicate','reorder','status_failure','write_failure']]
VIRTUAL += ['bad_checksum_middle','wrong_address_middle','status_failure_middle','bad_checksum_final','wrong_length_final','missing_final','reorder_final']
VIRTUAL += ['corruption_pass0_first','corruption_pass0_middle','pass1_mismatch_final']
VIRTUAL += ['output_write_first','output_write_middle','output_write_last','output_flush','output_size','cleanup_all_fail','prefix_identity_bad','prefix_upload_status16']
VIRTUAL += ['rx_protocol_first','rx_flags_first','rx_count_first','late_reply_first','wrong_pass_first','wrong_command_first','extra_byte_first']
CASES=[(s,'virtual') for s in VIRTUAL]+[('success','real_clock')]
checks=0
def require(ok,detail):
 global checks
 if not ok:raise AssertionError(detail)
 checks+=1
def load(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p);h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(1048576):h.update(b);n+=len(b)
 return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
def verify(p):
 q=pin(p['path']);require(q['sha256']==p['sha256'],'pin '+p['path'])
 if 'bytes' in p:require(q['bytes']==p['bytes'],'size '+p['path'])
def save(p,obj):
 with Path(p).open('x',encoding='utf8',newline='\n') as f:json.dump(obj,f,indent=2);f.write('\n')
def key(seed):
 t=[5,6,7,1,9,12,13,8,10,13,2,11,15,4,0,3,11,4,6,0,15,2,13,9,5,12,1,10,3,13,14,8]
 l,r=int.from_bytes(seed[:2],'big'),int.from_bytes(seed[2:],'big')
 for k in [0x88F0,0x6E74,0x6B70,0x3563,0x9D34,0xDBA3,0x503D,0xAFB8,0x3608,0x834F,0x3382,0x7CA3,0x437D,0x72EB,0x33BC,0x53DA]:
  e=(r^k)*0x10001;v=sum(t[(e>>s)&31]<<s for s in (0,4,8,12));l,r=r,l^(((v>>3)|(v<<13))&65535)
 return r.to_bytes(2,'big')+l.to_bytes(2,'big')
def checked(body):return body+bytes([sum(body)%256])
def req(index):return checked(bytes.fromhex('beef000803')+bytes([index//8192])+((index%8192)*128).to_bytes(4,'big')+bytes.fromhex('0080'))
def payload(case,index,reference):
 a=(index%8192)*128;b=bytearray(reference[a:a+128])
 if (case=='success_changed_current' and a==0) or (case=='corruption_pass0_first' and index==0) or (case=='corruption_pass0_middle' and index==4096) or (case=='pass1_mismatch_final' and index==16383):b[0]^=1
 return bytes(b)
def reply(case,index,reference):return checked(bytes.fromhex('beef008683')+bytes([index//8192])+((index%8192)*128).to_bytes(4,'big')+payload(case,index,reference))
def plan(case):
 if case=='prefix_identity_bad':return 24,0,0,False
 if case=='prefix_upload_status16':return 22,0,0,False
 if case in ['success','success_changed_current','success_indicators']:return 16408,16384,16384,True
 if case in ['output_flush','output_size','cleanup_all_fail']:return 16408,16384,16384,False
 if case.startswith('output_write_'):i={'output_write_first':0,'output_write_middle':8192,'output_write_last':16383}[case];return 25+i,i,i+1,False
 if case in ['corruption_pass0_first','corruption_pass0_middle','pass1_mismatch_final']:i={'corruption_pass0_first':8192,'corruption_pass0_middle':12288,'pass1_mismatch_final':16383}[case];return 25+i,i,i+1,False
 i=8192 if case.endswith('_middle') else 16383 if case.endswith('_final') else 0
 return 25+i,i,i,False
def inspect(case,mode,path,code,contract,contract_sha,reference,physical):
 want_tx,accepted,want_blocks,positive=plan(case);prefix=contract['ordered_prefix_requests']
 tx_count=api_count=block_count=rx_count=0;pending_intent=None;pending_exchange=None;last_qpc=0;prefix_returns=[];cleanup=[];blocks=[];full=[];prefix_replies=[];last_row=None;terminal=None;noncleanup_failed=False
 mismatches=[];failed_reply=None;new_checks=checks
 def finish_exchange():
  nonlocal pending_exchange,failed_reply
  if pending_exchange is None:return
  e=pending_exchange;stage=e['stage'];rr=e['rx'];raw=b''.join(bytes.fromhex(r['output']['message']['data_hex']) for r in rr if r['status']==0 and r['output']['count']==1 and r['output']['message']['rx_status']==0)
  failing=(not positive and stage==want_tx-1 and accepted<16384 and not case.startswith('output_write_') and not case.startswith('corruption_') and not case.startswith('pass1_mismatch_'))
  if not failing:
   require(e['write']['status']==0 and e['write']['output']['count']==1,'successful write before receive')
   require(rr and all(r['status']==0 and r['output']['count']==1 for r in rr),'complete successful RX records')
   indicators=0;seen=False
   for r in rr:
    m=r['output']['message'];b=bytes.fromhex(m['data_hex']);require(m['protocol']==3 and m['tx_flags']==0 and m['data_size']==m['logged_bytes']==len(b) and m['extra_data_index'] in [0,len(b)] and not m['data_truncated'],'successful metadata')
    if m['rx_status']:
     indicators+=1;require(not seen and indicators<=4,'leading indication bound')
     require((m['rx_status'] in [2,8] and b==b'') or (m['rx_status'] in [1,9] and b==bytes.fromhex(e['write']['input']['message']['data_hex'])),'exact recognized indication/echo')
    else:require(bool(b),'nonempty frame fragment');seen=True
   require(raw and raw[-1]==sum(raw[:-1])%256,'complete positive checksum')
   require((rr[-1]['qpc_after']-rr[0]['qpc_before'])*1000/rr[0]['qpc_frequency']<2000,'whole response deadline')
   if stage<24:
    if stage==3:require(raw[:6]==bytes.fromhex('80f010066701') and len(raw)==11,'seed length/header')
    else:require(raw.hex()==prefix[stage]['expected_reply_hex'],'fixed prerequisite ACK')
   else:require(raw==reply(case,stage-24,reference),'independent complete scheduled reply')
  else:
   failed_reply={'stage':stage,'record_statuses':[r['status'] for r in rr],'record_counts':[r['output']['count'] for r in rr],'response_hex':raw.hex(),'records':[r['output'] for r in rr]}
   if case=='prefix_identity_bad':require(raw!=bytes.fromhex(prefix[23]['expected_reply_hex']) and raw[-1]==sum(raw[:-1])%256,'injected wrong identity')
   elif case=='prefix_upload_status16':require(len(rr)==1 and rr[0]['status']==16 and rr[0]['output']['count']==0,'injected final upload status16')
   else:
    i=stage-24;expected=reply(case,i,reference);mut=bytearray(expected)
    if case.startswith('write_failure'):require(e['write']['status']==7 and not rr,'injected write failure before receive')
    elif case.startswith('status_failure'):require(len(rr)==1 and rr[0]['status']==7 and rr[0]['output']['count']==0,'injected transport error')
    elif case.startswith('missing'):require(len(rr)==1 and rr[0]['status']==16 and rr[0]['output']['count']==0,'missing response fatal without retry')
    elif case.startswith('short'):require(raw==expected[:-1] and [r['status'] for r in rr]==[0,16],'partial response then terminal empty buffer')
    elif case.startswith('bad_checksum'):mut[-1]^=1;require(raw==bytes(mut),'bad checksum injected')
    elif case.startswith('wrong_address'):mut[9]^=1;mut[-1]=sum(mut[:-1])%256;require(raw==bytes(mut),'wrong address injected')
    elif case.startswith('wrong_length'):mut[3]=133;mut[-1]=sum(mut[:-1])%256;require(raw==bytes(mut),'wrong declared length injected')
    elif case.startswith('duplicate'):b=reply(case,max(i-1,0),reference);require(raw==b+b,'duplicate response injected')
    elif case.startswith('reorder'):require(raw==reply(case,i-1 if i==16383 else i+1,reference),'out-of-order response injected')
    elif case=='wrong_pass_first':mut[5]=1;mut[-1]=sum(mut[:-1])%256;require(raw==bytes(mut),'wrong pass injected')
    elif case=='wrong_command_first':mut[4]=0x81;mut[-1]=sum(mut[:-1])%256;require(raw==bytes(mut),'wrong command injected')
    elif case=='extra_byte_first':require(raw==expected+b'\0','trailing byte injected')
    elif case=='rx_protocol_first':require(rr[0]['output']['message']['protocol']==4,'wrong protocol injected')
    elif case=='rx_flags_first':require(rr[0]['output']['message']['tx_flags']==1,'wrong flags injected')
    elif case=='rx_count_first':require(rr[0]['output']['count']==2,'wrong count injected')
    elif case=='late_reply_first':require(raw==expected and (rr[-1]['qpc_after']-rr[0]['qpc_before'])*1000/rr[0]['qpc_frequency']>=2000,'late complete reply rejected')
    else:raise AssertionError('unhandled fault '+case)
  if stage<24:prefix_replies.append(raw)
  pending_exchange=None
 with path.open(encoding='utf8') as f:
  for line_no,line in enumerate(f,1):
   r=json.loads(line);kind=r['type'];require(not r.get('physical',False),'no physical record')
   if line_no==1:
    require(kind=='full_read_start' and r['backend']=='STATIC_IN_PROCESS_FAKE' and r['provider_loaded'] is False and r['fixture']==case,'samePE static fake startup')
    require(r['contract_sha256']==contract_sha and r['kernel_sha256']==contract['kernel_sha256'],'startup pins')
    require(r['time_model']==('QPC_MONOTONIC_MINIMUM' if mode=='real_clock' else 'VIRTUAL_ONLY_NOT_PHYSICAL_TIME'),'clock label')
   elif kind=='api_intent':require(pending_intent is None,'no orphan intent');pending_intent=r
   elif kind=='api_return':
    i=pending_intent;require(i is not None and i['sequence']==r['sequence']==api_count and i['function']==r['function'] and i['input']==r['input'],'complete exact ordered call pair');pending_intent=None;api_count+=1
    require(last_qpc<=r['qpc_before']<=r['qpc_after'] and r['api_elapsed_ticks']==r['qpc_after']-r['qpc_before'] and r['qpc_frequency']>0,'ordered QPC');last_qpc=r['qpc_after']
    if not r.get('cleanup'):require(r['esp_before']==r['esp_after'],'ABI stack balance')
    if 'canaries_intact' in r['output']:require(r['output']['canaries_intact'],'native canaries')
    if noncleanup_failed:require(r.get('cleanup'),'no API after error except cleanup')
    if r['status'] and not r.get('cleanup'):noncleanup_failed=True
    for m in [r['input'].get('message'),r['output'].get('message')]:
     if m:require(m['logged_bytes']==len(bytes.fromhex(m['data_hex'])) and m['data_size']==m['logged_bytes'] and not m['data_truncated'],'full bounded record logged')
    if r['function']!='PassThruReadMsgs':finish_exchange()
    if r.get('cleanup'):cleanup.append(r)
    elif r['function']=='PassThruWriteMsgs':
     stage=tx_count;tx_count+=1;wire=bytes.fromhex(r['input']['message']['data_hex']);require(stage<16408,'no third pass')
     if stage>=24:expected=req(stage-24)
     elif stage==4:expected=checked(bytes.fromhex('8010f0062702')+key(prefix_replies[3][6:10]))
     else:expected=bytes.fromhex(prefix[stage]['wire_hex'])
     require(wire==expected,'independent exact TX address/pass/length/checksum')
     require(r['input']['timeout_ms']==1000 and r['input']['input_count']==1 and r['output']['count']==1 and r['input']['message']==r['output']['message'],'exact write arguments/count/unmutated')
     pending_exchange={'stage':stage,'write':r,'rx':[]}
    elif r['function']=='PassThruReadMsgs':require(pending_exchange is not None,'RX belongs to one TX');pending_exchange['rx'].append(r);rx_count+=1
    if tx_count<=24:prefix_returns.append(r)
   elif kind=='rom_block':
    idx=block_count;block_count+=1;require(r['read_index']==idx and r['pass']==idx//8192 and r['block']==idx%8192 and r['address']==(idx%8192)*128 and r['length']==128,'gap-free block event')
    require(r['request_hex']==req(idx).hex() and r['response_hex']==reply(case,idx,reference).hex(),'block event exact verified bytes')
    if idx>=8192:
     prev=payload(case,idx-8192,reference);now=payload(case,idx,reference);want=[{'address':(idx%8192)*128+k,'pass0':a,'pass1':b} for k,(a,b) in enumerate(zip(prev,now)) if a!=b]
    else:want=[]
    require(r['pass0_match']==(not want) and r['mismatches']==want,'all exact pass mismatch locations')
    if want:mismatches.extend(want)
    if idx in [0,8191,8192,16383] or want:blocks.append(r)
   elif kind=='full_read_result':full.append(r)
   elif kind=='probe_terminal':finish_exchange();terminal=r
   else:raise AssertionError('unknown journal event '+kind)
   last_row=r
 require(pending_intent is None and terminal is last_row,'closed final journal')
 require(code==(0 if positive else 1) and terminal['status']==('PASS_OFFLINE_FULL_ROM_TWO_PASS_128' if positive else 'FAIL_TERMINAL'),'process/terminal outcome')
 require(tx_count==want_tx and block_count==want_blocks and terminal['state']['tx_attempts']==want_tx,'exact failure boundary/no retry')
 st=terminal['state'];require(st.get('completed_reads',0)==accepted,'output accepted count')
 require([r['function'] for r in cleanup]==['PassThruStopMsgFilter','PassThruDisconnect','PassThruClose'],'all cleanup attempted once')
 mask=sum(bit for bit,r in zip([1,2,4],cleanup) if r['status']);require(mask==(7 if case=='cleanup_all_fail' else 0) and terminal['cleanup_error_mask']==mask,'cleanup statuses and mask')
 active=st.get('filtered',st.get('filter',{}).get('active',False));require(terminal['cleanup_confirmed']==(not st['opened'] and not st['connected'] and not active),'cleanup ownership honesty')
 complete=positive or case=='cleanup_all_fail';require(terminal['protocol_complete']==complete and st['acquisition_validated']==complete and len(full)==int(complete),'no premature acquisition success')
 if want_tx>=25:require(st['identity_validated'] and st['start_acknowledged'] and st['acknowledged_chunks']==15,'admission before every ROM read')
 # Audit exact physical prefix RX and version buffers for every suffix fixture.
 if not case.startswith('prefix_'):
  actual_rx=[r['output']['message'] for r in prefix_returns if r['function']=='PassThruReadMsgs'];require(actual_rx==physical['rx'],'all48 historical prefix RX records/metadata preserved')
  version=next(r for r in prefix_returns if r['function']=='PassThruReadVersion');require(version['output']==physical['version'],'physical version buffers preserved')
  sets=[r for r in prefix_returns if r['function']=='PassThruIoctl' and r['input']['ioctl']==2];gets=[r for r in prefix_returns if r['function']=='PassThruIoctl' and r['input']['ioctl']==1]
  values=[{'parameter':p,'value':v} for p,v in [(22,0),(7,1),(10,0),(12,0),(3,0)]]
  require([r['output']['config']['owned_buffer_entries'] for r in sets[:5]]==[[v] for v in values] and gets[0]['output']['config']['owned_buffer_entries']==values and gets[0]['sequence']==sets[4]['sequence']+1,'five SET immediate GET')
  filters=[r for r in prefix_returns if r['function']=='PassThruStartMsgFilter'];require(len(filters)==2 and filters[0]['sequence']==gets[0]['sequence']+1,'broad then kernel filter')
  for r,maskhex,pattern,flow in [(filters[0],'00000000','00000000','00000000'),(filters[1],'ffff','beef',None)]:
   q=r['input'];require(q['mask']['data_hex']==maskhex and q['pattern']['data_hex']==pattern and (q['flow']['data_hex'] if q['flow'] else None)==flow,'filter mask/pattern/flow')
  require([r['output']['config']['owned_buffer_entries'] for r in sets[5:]]==[[{'parameter':1,'value':15625}],[{'parameter':1,'value':62500}]],'accepted baud transitions')
  require([r['input']['ioctl'] for r in prefix_returns if r['function']=='PassThruIoctl' and r['input']['ioctl'] in [7,8]]==[7,8],'TX/RX clear order')
  waits=[r for r in prefix_returns if r['function'] in ['OfflineClockAdvance','MonotonicMinimumWait']];require([r['input']['milliseconds'] for r in waits]==[200,100,200],'fixed wait requests')
  if mode=='real_clock':require(all(r['api_elapsed_ticks']*1000>=r['input']['milliseconds']*r['qpc_frequency'] for r in waits),'actual minimum waits')
 images=[]
 for p in range(2):
  count=min(8192,max(0,accepted-p*8192));expected=b''.join(payload(case,p*8192+i,reference) for i in range(count));image=Path(str(path)+'.images')/f'pass{p}.raw'
  require(image.read_bytes()==expected,'exact persisted partial/full image bytes');images.append(pin(image))
 if complete:
  require(images[0]['bytes']==images[1]['bytes']==1048576 and images[0]['sha256']==images[1]['sha256'],'two byte-identical complete1MiB outputs')
  f=full[0];require(f['pass0_sha256']==f['pass1_sha256']==images[0]['sha256'] and f['pass0_bytes']==f['pass1_bytes']==1048576 and f['pass_to_pass_identical'] and f['baseline_equality_required_for_transport'] is False,'result exactly matches files')
  changed=case=='success_changed_current';want={'identical':not changed,'differing_bytes':int(changed),'differing_ranges':[{'start':0,'end_exclusive':1}] if changed else []}
  require(f['pass0_vs_current']==f['pass1_vs_current']==want,'baseline comparison independently verified')
 return {'case':case,'mode':mode,'status':'PASS','exit_code':code,'positive':positive,'checks':checks-new_checks,'TX':tx_count,'RX_records':rx_count,'API_returns':api_count,'completed_reads':accepted,'block_events':block_count,'boundary_blocks':blocks,'mismatches':mismatches,'terminal':terminal,'full_read_result':full[0] if full else None,'failure_injection':failed_reply,'images':images}

def compress_verified(path):
 original=pin(path);dest=Path(str(path)+'.gz')
 with path.open('rb') as inp,dest.open('xb') as raw:
  with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0,compresslevel=6) as out:
   while b:=inp.read(1048576):out.write(b)
 h=hashlib.sha256();n=0
 with gzip.open(dest,'rb') as f:
  while b:=f.read(1048576):h.update(b);n+=len(b)
 require(h.hexdigest()==original['sha256'] and n==original['bytes'],'lossless journal compression')
 # Only a new journal under this new qualification directory is eligible for removal.
 require(path.parent==RUN and path.suffix=='.jsonl','new test journal removal scope');path.unlink()
 return pin(dest),original

RUN=ROOT/'reports'/('qualification_'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
def main():
 RUN.mkdir(parents=True,exist_ok=False);report={'schema':1,'status':'FAIL','scope':'SAME_PHYSICAL_CAPABLE_PE_FOCUSED_STATIC_FAKE_QUALIFICATION','author':'passive_review','physical_operations':0,'real_provider_loads':0,'cases':[]};preflight=[]
 try:
  contract=load(CONTRACT);contract_sha=pin(CONTRACT)['sha256'];require(contract['maximum_requests']==16408 and contract['maximum_ROM_requests']==16384,'fixed two-pass scope')
  preflight=[pin(CONTRACT),pin(Path(__file__))]
  for name in ['build_a','build_b']:
   b=load(ROOT/name/'BUILD.json');require(b['status']=='PASS_BUILD_ONLY','clean build status');require(pin(b['exe_path'])['sha256']==b['exe_sha256'],'native binary pin')
   for p in b['source_inputs']:verify(p)
   for k in ['compiler','linker','build_log','imports','headers']:verify(b[k])
   preflight += [pin(ROOT/name/'BUILD.json'),pin(b['exe_path'])]+[dict(p) for p in b['source_inputs']]
  b1=load(ROOT/'build_a/BUILD.json');b2=load(ROOT/'build_b/BUILD.json');require(b1['exe_sha256']==b2['exe_sha256'],'two byte-identical native builds')
  fixed=(ROOT/'src/fixed_reads.hpp').read_text();core=(ROOT/'src/probe_core.hpp').read_text();main_source=(ROOT/'src/main.cpp').read_text()
  require('COUNT=16384,PREFIX=24,MAX_TX=16408' in fixed and 'index<COUNT' in fixed and 'PER_PASS=8192,PASSES=2' in fixed,'compiled fixed two-pass dimensions')
  require('for(unsigned index=0;index<FixedReads::COUNT;index++)' in core and 'images.accept(index,reply)' in core and 'event(images.finish());acquisition_validated=true;protocol_complete=true' in core,'compiled bounded loop/output validation before success')
  require(main_source.index('return probe.run();')<main_source.index('const Bindings b=physical_bindings()')<main_source.index('LoadLibraryExW('),'offline returns before provider loader')
  inputs=load(ROOT/'INPUT_PINS.json')
  for p in inputs['inputs']:verify(p)
  preflight.append(pin(ROOT/'INPUT_PINS.json'));verify(contract['current_reference']);reference=Path(contract['current_reference']['path']).read_bytes();require(len(reference)==1048576,'pinned full baseline')
  verify(contract['physical128_journal']);physical_rows=[json.loads(s) for s in Path(contract['physical128_journal']['path']).read_text().splitlines()]
  pr=[r for r in physical_rows if r['type']=='api_return'];physical={'rx':[r['output']['message'] for r in pr if r['function']=='PassThruReadMsgs'][:48],'version':next(r['output'] for r in pr if r['function']=='PassThruReadVersion')}
  require(len(physical['rx'])==48,'physical prefix fixture dimensions')
  report.update(physical_executable=pin(EXE),second_clean_executable=pin(b2['exe_path']),contract=pin(CONTRACT),input_pins=pin(ROOT/'INPUT_PINS.json'),source_and_build_pins=preflight,reused_physical_prefix=contract['physical128_journal'],case_matrix={'virtual':VIRTUAL,'real_clock':['success'],'selection':'Representative faults, not a Cartesian exhaustive matrix; prior349 evidence is retained, not rerun.'})
  for n,(case,mode) in enumerate(CASES):
   path=RUN/f'{n:02}_{mode}_{case}.jsonl';stdout=path.with_suffix('.stdout.txt');stderr=path.with_suffix('.stderr.txt');flag='--offline-real-clock-fixture' if mode=='real_clock' else '--offline-fixture';argv=[str(EXE),flag,case,'--journal',str(path)]
   require(flag in ['--offline-fixture','--offline-real-clock-fixture'],'offline CLI only')
   with stdout.open('xb') as out,stderr.open('xb') as err:completed=subprocess.run(argv,stdout=out,stderr=err,timeout=180)
   item=inspect(case,mode,path,completed.returncode,contract,contract_sha,reference,physical);item.update(command=argv,stdout=pin(stdout),stderr=pin(stderr))
   if mode=='real_clock':item.update(journal=pin(path),journal_encoding='jsonl',journal_original=pin(path))
   else:compressed,original=compress_verified(path);item.update(journal=compressed,journal_original=original,journal_encoding='gzip')
   report['cases'].append(item);save(RUN/f'{n:02}_{mode}_{case}.case.json',item)
   print(json.dumps({'case':case,'mode':mode,'status':'PASS','TX':item['TX'],'completed_reads':item['completed_reads'],'progress':f'{n+1}/{len(CASES)}'}),flush=True)
  for p in preflight:verify(p)
  require(not (ROOT.parent/'physical_session').exists(),'no physical session created')
  report.update(status='PASS',passed_cases=len(CASES),test_cases=len(CASES),checks_passed=checks,positive_cases=sum(x['positive'] for x in report['cases']),negative_cases=sum(not x['positive'] for x in report['cases']),limitations=['Only static fake modes invoked; physical dispatcher remains uninvoked and unapproved.','Suffix data and host timing are simulated; only first24 transaction RX/version metadata comes from physical evidence.','Output-size fault is an explicit injected length-check rejection, not an externally truncated image.','Prior physical128 success and OEM return are reused, not repeated.'])
 except BaseException as e:
  report.update(error=str(e),traceback=traceback.format_exc(),passed_cases=len(report['cases']),test_cases=len(CASES),checks_passed=checks)
 finally:
  save(RUN/'TEST_REPORT.json',report);print(json.dumps({'status':report['status'],'report':pin(RUN/'TEST_REPORT.json')}),flush=True)
 if report['status']=='PASS':
  latest=ROOT/'reports/LATEST_QUALIFICATION.json'
  require(not latest.exists(),'new qualification pointer only');save(latest,{'status':'PASS','report':pin(RUN/'TEST_REPORT.json')})
 return 0 if report['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
