# Offline full-upload model with no kernel start

This artifact models the fixed upload of the preserved 1,808-byte RAM kernel and stops after the final acknowledgement. It has only an in-process fake backend, with virtual-clock and real-clock test modes. It has no physical CLI, provider loader, authorization/bootstrap code or vehicle-session path. Qualification of this model does not establish readiness for a future physical release.

The previous first-chunk physical probe, its successful session, its passive OEM-return evidence and its 156-case qualification remain unchanged. Their hashes and relevant behavior are reused as evidence; no historical physical operation is repeated by this project.

## Exact sequence and bounds

The complete sequence has 22 transmissions: six admission requests (BF, 81, 83,27 01,27 02,10 85 02), one fixed 34 declaration and fifteen fixed 36 frames. Fourteen frames carry 128 bytes and the last carries 16 bytes, for exactly 1,808 bytes over FFFF3000..FFFF3710 exclusive. Every 36 requires the complete exact acknowledgement `80f0100176f7`. After the fifteenth acknowledgement the host performs cleanup, with no later protocol action.

The preserved `UPLOAD_WIRE_CONTRACT_RK02.json` contains 17 entries. Only entries 0..15 are used: one declaration and fifteen chunks. Entry 16 is `80 10 F0 03 31 01 01 B6`, the kernel-start request, and is explicitly excluded from the request table. There is no kernel start, custom-kernel execution, ROM read, flash erase/program/commit, arbitrary address or external payload selection, or automatic retry. A seed-derived key is the sole variable request content.

The owned plaintext kernel remains SHA256 `3a65d6f0700bae394a24ba9f552d03500b7f66e6344ec57613f10bfd360d8581`. The runner compares every declaration/chunk request and reply against the retained actual-stock execution contract, checks each frame's checksum, verifies contiguous addresses and exact chunk sizes, and verifies the embedded ciphertext against those frames. This models transmitting the fixed bytes; it does not claim a physical RAM write occurred.

Initialization retains protocol 3, flags 512 and 4800 baud; the five ordered SET_CONFIG calls and immediate GET_CONFIG verification; and the broad PASS_FILTER with four zero bytes in mask, pattern and nonnull flow objects. The requested post-key/post-session/pre-declaration waits remain 200/100/200 ms. Baud SET 15625 precedes CLEAR_TX_BUFFER 7 and CLEAR_RX_BUFFER 8. The real-clock fake mode measures actual host QPC minima and records scheduler overshoot. Baud SET status and object integrity are checked; effective physical baud is not established.

All provider outputs are recorded before interpretation. Unexpected identities, replies, checksums, lengths, metadata, counts, mutated output structures or nonzero status stop progression. Status 16 is terminal, without a retry. Every allocated resource is cleaned up in StopMsgFilter, Disconnect, Close order; a cleanup or logging error prevents success.

## Qualification coverage

The independent runner is `tools/test_full_upload_independent.py`. All 287 cases passed: 283 virtual protocol fixtures and four real-clock positive fixtures. The previous 128 virtual cases are retained with the new full-upload endpoint. A new physical-first-chunk replay case supplies the complete observed eight-request/sixteen-RX prefix, including seed `a917a34f` and key `4015f497`. An additional 154 negative cases exercise eleven failure types at each of the fourteen later chunk stages 8..21: wrong, negative, checksum-corrupt, truncated, short, extra and status 16 acknowledgements, plus write errors, zero/excess write counts and mutated write output.

Each negative case must reach its intended fault, stop at that precise transmission count, perform no later transmission/retry and attempt complete cleanup. Successful cases require all 22 transmissions and all fifteen exact 76 acknowledgements. The inherited sixteen independent seed vectors, configuration corruption, framing/metadata bounds, virtual wait faults, queue errors, baud errors and cleanup/journal failures remain covered.

The physical-prefix comparator checks all 40 noncleanup API returns through the first 36 acknowledgement, including complete transmitted and received bytes, provider message metadata, version buffers, configuration, filter, baud and queue arguments/outputs. Synthetic handles are mapped explicitly to physical handles; owned configuration-buffer addresses are treated as runtime identities. Fresh host QPC/UTC and virtual/real wait measurements are not presented as reproduced historical timing. The requested wait schedule is still compared, and each real-clock run independently checks actual minima.

The previous 24 bootstrap cases are retained as hash-pinned historical evidence rather than rerun: this executable contains no bootstrap feature. Four real-clock positives run here: success, fragmented, indicators_fragmented and the complete new physical-first-chunk replay. The older transition-only replay remains among the virtual cases.

Two clean builds must have identical bytes, and the runner verifies compiled source closure, tool/build artifacts, input pins and the contract before invoking either fake mode:

```text
rk03_full_upload_no_start_offline32.exe --offline-fixture CASE --journal NEW_PATH
rk03_full_upload_no_start_offline32.exe --offline-real-clock-fixture CASE --journal NEW_PATH
```

Every journal must be new. The runner preserves all journals/stdout/stderr in a unique report directory, rechecks input and binary hashes after execution, and verifies that no physical-session directory was created. It never invokes a physical mode or loads a real provider.

The retained OEM instruction-execution contracts use explicit ready/TEND and programming-admission inputs. The runtime fake provider replays their replies; it does not execute the OEM CPU or reproduce physical bus timing. Passing this suite qualifies the offline model only. Physical upload, kernel execution, ROM acquisition, finalization and recovery remain outside this artifact.

Root authors the native implementation and independently reviews the runner. `passive_review` authors the runner/documentation and independently reviews root's native implementation. Test execution and artifact verification are recorded separately from these review roles.


## Completed evidence

The two clean builds are byte-identical: `rk03_full_upload_no_start_offline32.exe`, 328,704 bytes, SHA256 `602f2b0835d8e39d37af9b1eddead0223cd7ba5411970645e1ebc7e78dc1c7a5`. The executable retains generic `LoadLibraryExW`, `GetProcAddress` and `FreeLibrary` imports from the MSVC/CRT runtime. The structural exclusion concerns application source and dispatch: no real-provider loader, discovery, path or physical entrypoint is present. Import absence is not claimed.

The final 287/287 PASS report is [TEST_REPORT.json](reports/qualification_20260930T043538633340Z/TEST_REPORT.json), SHA256 `bb3a7813be188705492ff5d265a27ede1d741b2cedd4df673b429b4002d79aa5`. All twelve measured waits across the four real-clock cases met their respective 200/100/200 ms minima. [RUNNER_AUTHOR_AUDIT.json](reports/RUNNER_AUTHOR_AUDIT.json) verifies 1,199 hash references covering 906 distinct paths and all 861 test artifacts. The final runner SHA256 is `d96ca60e6a97ab6fba06e0956424eca2ac6ea8e162c8b567956b1b5308c6abea`.

The first attempt is preserved in [qualification_20260930T043451588493Z](reports/qualification_20260930T043451588493Z/TEST_REPORT.json), including its exact runner snapshot. It passed 285/287 cases. Two inherited service-named cases, `bad_checksum_81` and `bad_checksum_83`, were incorrectly matched as upload stage numbers 81 and 83 by the runner. Their native executions correctly stopped after two and three transmissions. Restricting that matcher to actual indexed stages 3..21 corrected the assertions. Native source and executable bytes did not change between attempts.

Root separately executed the retained CPU model using authoritative current-ROM bytes, consuming only the declaration and fifteen upload frames. Its `CURRENT_NO_START_REPLAY.json` records 476,281 OEM instructions and 452 contiguous four-byte stores producing exactly the pinned 1,808-byte plaintext kernel, followed by return to the OEM caller. No kernel instruction ran. The resulting current instruction/memory/MMIO prefix matched the preserved stock trace. `passive_review` reviewed the script and independently decoded the saved trace, reconstructed the RAM stores and TDR replies, and verified input/artifact hashes without rerunning the CPU. These are model results under explicit programming-admission and ready/TEND fixtures, not a physical upload result.

Native source review, current replay review, combined qualification review and root's independent runner/journal review are stored under `C:\Dev\A2WC511R_Final\analysis\rk03_full_upload_no_start_20260930_01`. Root authored and built the native code and current-ROM replay; `passive_review` authored and executed the offline qualification runner, audited its artifacts, and independently reviewed root's native code and replay. Root independently reviewed the runner and journals. All execution in this stage remained offline.
