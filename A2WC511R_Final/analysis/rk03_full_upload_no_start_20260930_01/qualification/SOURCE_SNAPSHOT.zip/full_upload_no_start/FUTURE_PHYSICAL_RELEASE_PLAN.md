# Future design only: RK03_FULL_UPLOAD_NO_START_PHYSICAL

This document does not create a physical release, authorization or runnable provider host. The present executable has a static fake backend only. No additional physical operation is authorized in this run.

## Proposed scope

A future separately reviewed release would open one fresh session, repeat the validated admission sequence, declare the fixed 1,808-byte owned image once, and transmit all fifteen fixed chunks in order. It would require the complete exact acknowledgement `80f0100176f7` for every chunk and stop immediately after chunk15. The range is FFFF3000 through FFFF370F inclusive: fourteen128-byte chunks and one16-byte chunk. It must not resume an earlier partial upload or assume earlier RAM survives recovery.

Only the seed-derived key varies. The payload image, target addresses, declaration, all remaining requests and expected replies must be embedded and hash-pinned. No payload/address options, retries, reconnection loop or second invocation within the session are permitted.

The future release must contain no request or dispatch path for kernel start, handoff/jump, kernel version, custom-kernel execution, ROM reading or flash erase/program/write/commit. A separate physical transport does not grant permission to add any of those operations.

## Work needed before a physical release

1. Create a separate development/release branch and a new session identity. Preserve this offline artifact and all earlier evidence. Do not silently add a provider mode to this executable.
2. Design a tightly scoped provider binding with the installed provider/version/hash, exact x86 ABI, fixed transport configuration and broad filter. Preserve per-call arguments, complete received status records, configuration readback, messages and before/after QPC timestamps. The generic CRT imports in the offline build do not constitute a physical provider implementation.
3. Review the physical entry point, executable/certificate/source pins, exclusive invocation reservation and exact authorization consumption. Automatically confirm competing diagnostic clients are absent. A prior transition or first-chunk authorization cannot be reused.
4. Qualify the final physical executable against this full offline model and the physical transition/first-chunk prefixes. Exercise all fifteen failure boundaries, terminal cleanup, exhausted queues, malformed replies, journal failures and provider bootstrap failures. Verify all intended transport differences; do not change timeouts or serial values speculatively.
5. Repeat deterministic clean builds and independent source, binary-closure, launcher and evidence review for that new release. Publish a new qualification manifest before proposing a vehicle test. The present offline certificate cannot qualify an unseen physical binary.
6. Retain the exact reviewed200/100/200ms waits,15625 baud SET and TX-then-RX queue clears. Confirm the physical continuation remains within the fixed final request. The prior physical first chunk supports these operations only through its first ACK; it does not validate the remaining fourteen physical transfers.
7. Prepare the existing passive BF/A8 OEM-return observer and recovery record in advance. A final ACK means accepted transfer, not independently measured RAM contents. The stock/current instruction replay establishes final bytes only under its recorded peripheral and admission assumptions.

## Proposed future gated execution

Use only these operator-managed physical states, one at a time:

1. `IGNITION OFF`.
2. `TEST MODE ON` with engine off; the operator manages power, connections, Test Mode setup and disconnected radiator fans.
3. Display the exact release/certificate/provider hashes, ECU identity, scoped15-chunk sequence, cleanup/recovery readiness, absence of competing clients and zero invocations for the new session. Require a new explicit software authorization. Proposed wording: `PROCEED RK03 FULL UPLOAD NO START`.
4. Invoke the separately qualified physical release once. No physical state changes while it is active. Do not retry any terminal failure or attempt to complete a partial upload.
5. After exit and recorded cleanup, request `IGNITION OFF`, then `NORMAL MODE ON`. The operator manages the associated physical preparation; do not expand these states into battery, charger, voltage, connector or OpenPort gates.
6. Run only passive BF/A8 OEM return. Require identity2F12515306, PASS_CAPTURE_ONLY and clean observer/broker/provider exit. On failure request only IGNITION OFF and stop physical activity.

Any success would be scoped as FULL_UPLOAD_NO_START only. Kernel execution or ROM acquisition would require another separately designed, qualified and explicitly authorized milestone.

## Remaining evidence gaps

- The present artifact has no physical-provider implementation or physical-release certificate.
- Chunks2..15 have not been accepted by the vehicle through this custom host.
- Offline fake replies and CPU replay do not reproduce electrical K-line timing, provider buffering or ECU asynchronous events. The modeled ready/TEND, admission, watchdog and interrupt assumptions remain explicit.
- No physical RAM readback is performed. Offline reconstructed RAM matches the pinned kernel exactly; a future ACK-only experiment provides narrower evidence.
- Recovery after a complete but unstarted custom-host upload has not yet been physically demonstrated.

Recommended next milestone: separately design and qualify RK03_FULL_UPLOAD_NO_START_PHYSICAL, preserving the no-start boundary. Request execution only after that distinct qualification passes and the operator gives fresh authorization.
