"""Root's independent audit of the separately authored runner and its saved journals."""
from pathlib import Path
import copy, datetime as dt, hashlib, importlib.util, json, re, sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
OUT=Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_full_upload_no_start_20260930_01\root_review')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):
    p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def main():
    OUT.mkdir(exist_ok=False)
    latest=json.loads((ROOT/'reports/LATEST_QUALIFICATION.json').read_text())
    assert latest['status']=='PASS'
    report_path=Path(latest['report']['path']);assert sha(report_path)==latest['report']['sha256']
    report=json.loads(report_path.read_text())
    assert report['status']=='PASS' and report['test_cases']==report['passed_cases']==287
    assert len({(r['mode'],r['case']) for r in report['cases']})==287
    checked={}
    def walk(obj):
        if isinstance(obj,dict):
            if isinstance(obj.get('path'),str) and isinstance(obj.get('sha256'),str):
                p=obj['path'];digest=sha(p);assert digest==obj['sha256'].lower(),p
                if 'bytes' in obj:assert Path(p).stat().st_size==obj['bytes'],p
                checked[p]=digest
            for value in obj.values():walk(value)
        elif isinstance(obj,list):
            for value in obj:walk(value)
    walk(report)
    c=json.loads((OUT.parent/'FULL_UPLOAD_NO_START_CONTRACT.json').read_text())
    frames=[r['sample_wire_hex'] for r in c['ordered_requests']]
    replies=[r['expected_reply_hex'] for r in c['ordered_requests']]
    assert len(frames)==22 and [bytes.fromhex(x)[4] for x in frames]==[0xbf,0x81,0x83,0x27,0x27,0x10,0x34]+[0x36]*15
    seeds=json.loads(Path(r'C:\Dev\A2WC511R_ReadKernel\evidence\contracts\KWP_PRODUCER_REGRESSIONS.json').read_text())['seed_cases']
    def frame(body,response=False):
        data=bytes.fromhex('80f010' if response else '8010f0')+bytes([len(body)])+body
        return (data+bytes([sum(data)&255])).hex()
    tx_total=0;positive=0;negative=0
    for case in report['cases']:
        assert case['status']=='PASS'
        rows=[json.loads(line) for line in Path(case['journal']['path']).read_text().splitlines()]
        tx=[r for r in rows if r.get('type')=='api_intent' and r.get('function')=='PassThruWriteMsgs']
        expected=frames.copy();expected_rx=replies.copy()
        if case['case'].startswith('seed_vector_'):
            vector=seeds[int(case['case'].split('_')[-1])]
            expected[4]=frame(bytes.fromhex('2702'+vector['timer_and_stored_expected_key']))
            expected_rx[3]=frame(bytes.fromhex('6701'+vector['wire_seed']),True)
        elif case['case']=='physical_first_chunk_replay':
            expected[4]='8010f00627024015f4978f';expected_rx[3]='80f010066701a917a34fa0'
        assert [r['input']['message']['data_hex'] for r in tx]==expected[:len(tx)]
        assert len(tx)<=22
        for r in tx:
            wire=bytes.fromhex(r['input']['message']['data_hex'])
            assert len(wire)==wire[3]+5 and wire[-1]==sum(wire[:-1])&255
        returns=[r for r in rows if r.get('type')=='api_return']
        # Progress to each subsequent request requires the exact preceding positive reply.
        for stage,t in enumerate(tx):
            stop=tx[stage+1]['sequence'] if stage+1<len(tx) else 10**9
            rx=[r for r in returns if t['sequence']<r['sequence']<stop and r['function']=='PassThruReadMsgs']
            assembled=''.join(r['output']['message']['data_hex'] for r in rx if r['output']['message']['rx_status']==0)
            if stage+1<len(tx) or case['exit_code']==0:
                assert all(r['status']==0 and r['output']['count']==1 for r in rx)
                assert assembled==expected_rx[stage],(case['case'],stage)
        if case['exit_code']==0:
            positive+=1;assert len(tx)==22 and rows[-1]['protocol_complete'] and rows[-1]['cleanup_confirmed']
            noncleanup=[r for r in returns if r['function'] not in ['PassThruStopMsgFilter','PassThruDisconnect','PassThruClose']]
            assert noncleanup[-1]['function']=='PassThruReadMsgs'
            assert noncleanup[-1]['output']['message']['data_hex'].endswith('f7')
        else:
            negative+=1;assert case['exit_code']==1 and rows[-1]['status']=='FAIL_TERMINAL'
        assert rows[0]['physical'] is False and rows[0]['provider_loaded'] is False
        assert all(r.get('physical') is not True for r in rows)
        assert case['command'][1] in ['--offline-fixture','--offline-real-clock-fixture']
        tx_total+=len(tx)
    # Independently challenge the runner with synthetic journal corruption, without invoking a PE.
    runner=ROOT/'tools/test_full_upload_independent.py'
    spec=importlib.util.spec_from_file_location('independent_runner_audit',runner)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    success=next(x for x in report['cases'] if x['case']=='success' and x['mode']=='virtual')
    baseline=[json.loads(line) for line in Path(success['journal']['path']).read_text().splitlines()]
    stdout=Path(success['journal']['path']).with_suffix('.stdout.txt').read_text()
    module.inspect_case('success',copy.deepcopy(baseline),0,stdout)
    mutations=[]
    def rejected(name,change):
        data=copy.deepcopy(baseline);change(data)
        try:module.inspect_case('success',data,0,stdout)
        except (AssertionError,KeyError,ValueError,IndexError) as e:
            mutations.append({'case':name,'status':'PASS_REJECTED','reason':str(e)});return
        raise AssertionError('Runner accepted corrupted journal: '+name)
    def replace_tx(data,stage,wire):
        seq=[r['sequence'] for r in data if r.get('type')=='api_intent' and r.get('function')=='PassThruWriteMsgs'][stage]
        for r in data:
            if r.get('sequence')==seq:
                for side in ['input','output']:
                    if 'message' in r.get(side,{}):
                        m=r[side]['message'];m.update(data_hex=wire,data_size=len(bytes.fromhex(wire)),logged_bytes=len(bytes.fromhex(wire)))
    rejected('kernel_start_replaces_final_chunk',lambda d:replace_tx(d,21,'8010f003310101b6'))
    rejected('duplicate_second_chunk_at_third',lambda d:replace_tx(d,9,frames[8]))
    rejected('skipped_second_chunk',lambda d:replace_tx(d,8,frames[9]))
    bad=bytearray.fromhex(frames[21]);bad[7]^=1;bad[-1]=sum(bad[:-1])&255
    rejected('arbitrary_final_target_with_valid_checksum',lambda d:replace_tx(d,21,bad.hex()))
    bad=bytearray.fromhex(frames[21]);bad[8]^=1;bad[-1]=sum(bad[:-1])&255
    rejected('changed_final_payload_with_valid_checksum',lambda d:replace_tx(d,21,bad.hex()))
    def bad_final_ack(data):
        r=[r for r in data if r.get('type')=='api_return' and r.get('function')=='PassThruReadMsgs'][-1]
        r['output']['message']['data_hex']='80f0100175f6'
    rejected('wrong_final_ack_with_valid_checksum',bad_final_ack)
    rejected('false_physical_backend',lambda d:d[0].update(physical=True))
    rejected('false_provider_loader',lambda d:d[0].update(provider_loaded=True))
    rejected('false_cleanup_claim',lambda d:d[-1].update(cleanup_confirmed=False))
    summary={'schema':1,'status':'PASS_INDEPENDENT_RUNNER_AND_JOURNAL_AUDIT','reviewer':'root',
        'runner_author':'passive_review','native_author':'root','utc':dt.datetime.now(dt.timezone.utc).isoformat(),
        'test_report':pin(report_path),'runner':pin(runner),'auditor':pin(Path(__file__)),
        'verified_unique_pins':len(checked),'verified_transmissions':tx_total,'successful_scenarios':positive,
        'negative_scenarios':negative,'reviewed_cases':287,'runner_mutation_challenges':mutations,
        'physical_operations':0,'PE_invocations_during_this_audit':0,'blocking_findings':[],
        'notes':['Reviewed runner validates exact operation schedule, every intended fault and terminal boundary, per-API arguments/results, all effective serial readbacks, filters, timers and cleanup.',
            'Generic MSVC runtime loader imports are not evidence of an application provider loader; native source/reachable mode review is recorded independently.',
            'All source and historical evidence pins checked; no historical test or physical run repeated.']}
    with (OUT/'ROOT_REVIEW.json').open('x',encoding='utf-8') as f:json.dump(summary,f,indent=2);f.write('\n')
    print(json.dumps({k:summary[k] for k in ['status','verified_unique_pins','verified_transmissions','successful_scenarios','negative_scenarios']}))
if __name__=='__main__':main()
