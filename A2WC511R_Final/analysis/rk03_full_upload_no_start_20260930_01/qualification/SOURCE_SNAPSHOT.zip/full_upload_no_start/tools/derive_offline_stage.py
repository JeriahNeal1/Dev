"""Derive a new OFFLINE-ONLY replay stage from sealed reviewed inputs; never execute it."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[1]
OLD = Path(r'C:\Dev\A2WC511R_RK03_FirstChunkPhysical\first_chunk')
ANALYSIS = Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_full_upload_no_start_20260930_01')
FIRST = ANALYSIS.parent / 'rk03_first_chunk_20260930_01'
UPLOAD = Path(r'C:\Dev\A2WC511R_ReadKernel\evidence\contracts\UPLOAD_WIRE_CONTRACT_RK02.json')
PHYSICAL = FIRST / 'physical_result/evidence/native_api.jsonl'

def pin(path):
    path = Path(path)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(value)

def dump(path, obj):
    write(path, json.dumps(obj, indent=2) + '\n')

def replace_once(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)

def main():
    upload = json.loads(UPLOAD.read_text())
    assert pin(UPLOAD)['sha256'] == 'b1c5431141f9b249b16dd15938c290f20b99593e7ab8512caebcde1906c37f50'
    assert len(upload['frames']) == 17 and upload['frames'][16]['request'] == '8010f003310101b6'
    oracle = json.loads((OLD/'fixtures/first_chunk_oracle.json').read_text())
    tx = oracle['tx'][:6] + [r['request'] for r in upload['frames'][:16]]
    rx = oracle['rx'][:6] + [r['reply_from_executed_TDR'] for r in upload['frames'][:16]]
    assert len(tx) == len(rx) == 22 and '8010f003310101b6' not in tx
    cipher = b''.join(bytes.fromhex(r)[8:-1] for r in tx[7:])
    assert len(cipher) == 1808
    old_contract = json.loads((FIRST/'FIRST_CHUNK_REVIEW_CONTRACT.json').read_text())
    reused = [pin(p) for p in [FIRST/'FIRST_CHUNK_REVIEW_CONTRACT.json', FIRST/'qualification/QUALIFICATION.json',
        FIRST/'physical_result/PHYSICAL_RESULT.json', PHYSICAL, FIRST/'physical_review/PHYSICAL_REVIEW.json',
        FIRST/'oem_return_after_first_chunk_01/OEM_RETURN_RESULT.json', UPLOAD,
        Path(upload['trace']['path']), Path(r'C:\Dev\A2WC511R_ReadKernel\build\rk02_01\kernel.bin'),
        OLD/'reports/qualification_20260930T033815962561Z/TEST_REPORT.json', OLD/'tools/test_first_chunk_independent.py',
        ANALYSIS.parent/'current_rom_20260930_01/CURRENT_ROM_STATUS.json']]
    contract = {'schema':1, 'created_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
        'status':'OFFLINE_ONLY_FULL_KERNEL_UPLOAD_NO_START_REVIEW_CONTRACT',
        'scope':'FRESH_SIMULATED_SESSION_FIXED_15_CHUNKS_ALL_ACKNOWLEDGED_THEN_CLEANUP',
        'physical_entry_point':False, 'provider_loader':False, 'physical_authorization':False,
        'maximum_physical_invocations':0, 'automatic_retry_allowed':False,
        'base_branch':'rk03/first-chunk-physical', 'base_commit':'76f8bc16495529645f10fab6dd5f5b522cbe190b',
        'build_branch':'rk03/full-upload-no-start', 'connect':old_contract['connect'],
        'set_config_order':old_contract['set_config_order'], 'get_config':old_contract['get_config'],
        'filter':old_contract['filter'], 'waits_ms':[200,100,200], 'baud_set':15625,
        'queue_clears_in_order':[7,8], 'maximum_tx':22, 'download_declarations':1,
        'transfers':15, 'upload_start_inclusive':'FFFF3000', 'upload_end_exclusive':'FFFF3710',
        'upload_bytes':1808, 'payload_lengths':[128]*14+[16], 'kernel_sha256':upload['actual_upload_sha256'],
        'cipher_sha256':hashlib.sha256(cipher).hexdigest(),
        'ordered_requests':[{'stage':i,'wire_hex':wire if i!=4 else None,
            'dynamic_rule':'2702 plus reviewed key derived from validated four-byte seed' if i==4 else None,
            'sample_wire_hex':wire,'expected_reply_hex':rx[i]} for i,wire in enumerate(tx)],
        'excluded_historical_frame_index':16, 'excluded_historical_frame_hex':'8010f003310101b6',
        'forbidden':['kernel start','kernel execution','ROM read','flash operation','arbitrary address','arbitrary payload','provider loading','physical CLI','retry'],
        'reused_evidence':reused,
        'limitations':['Replay is not physical qualification. No future physical release is authorized.',
            'The full fixed kernel is embedded for a static fake transport only.',
            'Retained OEM instruction execution uses explicit peripheral/admission assumptions.',
            'No causal attribution between individual transport changes.']}
    ANALYSIS.mkdir(exist_ok=False)
    dump(ANALYSIS/'FULL_UPLOAD_NO_START_CONTRACT.json', contract)
    contract_sha = pin(ANALYSIS/'FULL_UPLOAD_NO_START_CONTRACT.json')['sha256']
    src=ROOT/'src'
    for name in ['common.hpp','protocol.hpp','real_clock.hpp','physical_replay.hpp','j2534_tactrix.h']:
        write(src/name, (OLD/'src'/name).read_text())
    write(src/'owned_artifact.h', '// Fixed full kernel cipher for OFFLINE replay only. No physical loader exists.\n'
        f'static constexpr const char* KERNEL_SHA="{contract["kernel_sha256"]}";\n'
        'static constexpr unsigned KERNEL_SIZE=1808;\n'
        'static const unsigned char KERNEL_CIPHER[1808]={'+','.join(f'0x{b:02x}' for b in cipher)+'};\n')
    write(src/'contract_pin.hpp', '#pragma once\n'+f'static constexpr const char* CONTRACT_SHA="{contract_sha}";\n')
    fixtures=(OLD/'src/fixtures.hpp').read_text()
    for name,values in [('EXPECTED_TX',tx),('REPLY_HEX',rx)]:
        fixtures=re.sub(r'(static constexpr const char\* '+name+r'\[\]=)\{[^;]+;',lambda m:m[1]+'{'+','.join(json.dumps(v) for v in values)+'};',fixtures)
    write(src/'fixtures.hpp',fixtures.replace('continuation_oracle.json','full_upload_oracle.json'))
    records=[json.loads(line) for line in PHYSICAL.read_text().splitlines()]
    returned=[r for r in records if r.get('type')=='api_return']
    actual_rx=[r['output']['message'] for r in returned if r['function']=='PassThruReadMsgs']
    actual_tx=[r['input']['message']['data_hex'] for r in returned if r['function']=='PassThruWriteMsgs']
    assert len(actual_rx)==16 and len(actual_tx)==8 and actual_tx[:4]==tx[:4] and actual_tx[5:]==tx[5:8]
    versions=next(r['output'] for r in returned if r['function']=='PassThruReadVersion')
    header='#pragma once\n// Pinned successful first-chunk physical receive records; replay only.\n'
    for name in ['firmware','dll','api']:
        header+=f'static constexpr const char* FIRST_VERSION_{name.upper()}="{versions[name]["raw_buffer_hex"]}";\n'
    header+='static constexpr const char* FIRST_PHYSICAL_KEY_TX="'+actual_tx[4]+'";\n'
    header+='inline PASSTHRU_MSG first_physical_replay_message(unsigned i){PASSTHRU_MSG m{};switch(i){\n'
    for i,m in enumerate(actual_rx):
        assert m['data_size']==len(bytes.fromhex(m['data_hex']))
        header+=f'case {i}:set_message(m,decode("{m["data_hex"]}"));m.ProtocolID={m["protocol"]};m.RxStatus={m["rx_status"]};m.TxFlags={m["tx_flags"]};m.Timestamp={m["timestamp"]}UL;m.ExtraDataIndex={m["extra_data_index"]};break;\n'
    header+='default:require(false,"First chunk replay bound");}return m;}\n'
    write(src/'first_physical_replay.hpp',header)
    core=(OLD/'src/probe_core.hpp').read_text()
    core=replace_once(core,'require(!p||real,"Physical mode requires monotonic minimum waits");','require(!p,"Only static offline API allowed");')
    core=core.replace('stage<8','stage<22').replace('next_tx<8','next_tx<22').replace('First chunk is the final protocol action','Fifteenth chunk is the final offline protocol action')
    core=replace_once(core,'static_assert(KERNEL_SIZE==1808&&sizeof(KERNEL_CIPHER)==128,"Pinned owned kernel size");Bytes chunk={0x36,0xff,0x30,0};chunk.insert(chunk.end(),KERNEL_CIPHER,KERNEL_CIPHER+128);return frame(chunk);',
        'static_assert(KERNEL_SIZE==1808&&sizeof(KERNEL_CIPHER)==1808,"Pinned owned kernel size");\n'
        '  const unsigned offset=(stage-7)*128;const unsigned length=std::min(128u,KERNEL_SIZE-offset);\n'
        '  require(stage>=7&&stage<22&&offset<KERNEL_SIZE&&offset+length<=KERNEL_SIZE,"Fixed chunk bounds");\n'
        '  const unsigned address=0xff3000+offset;Bytes chunk={0x36,static_cast<unsigned char>(address>>16),static_cast<unsigned char>(address>>8),static_cast<unsigned char>(address)};\n'
        '  chunk.insert(chunk.end(),KERNEL_CIPHER+offset,KERNEL_CIPHER+offset+length);return frame(chunk);')
    core=replace_once(core,'require(payload(exchange(7))==Bytes({0x76}),"First chunk ACK must be exact76");protocol_complete=true;',
        'for(unsigned stage=7;stage<22;stage++)require(payload(exchange(stage))==Bytes({0x76}),"Each fixed chunk ACK must be exact76");protocol_complete=true;')
    core=core.replace('(physical?"PASS_FIRST_CHUNK_PROBE_ONLY":"PASS_OFFLINE_FIRST_CHUNK_ACK_ONLY")','"PASS_OFFLINE_FULL_KERNEL_UPLOAD_NO_START_ONLY"')
    write(src/'probe_core.hpp',core)
    fake=(OLD/'src/fake_backend.hpp').read_text().replace('#include "physical_replay.hpp"','#include "physical_replay.hpp"\n#include "first_physical_replay.hpp"')
    extra=['physical_first_chunk_replay']+[f'{prefix}_{stage}' for prefix in ('bad_ack','negative_ack','bad_checksum','status16','truncated','short_ack','extra_ack','write_fail','write_count_zero','write_count_large','write_mutation') for stage in range(8,22)]
    fake=replace_once(fake,'static const char* CASES[]={','static const char* CASES[]={\n '+','.join(json.dumps(x) for x in extra)+',')
    fake=fake.replace('s.writes>=8','s.writes>=22')
    fake=replace_once(fake,'if(is("version_unterminated"))','if(is("physical_first_chunk_replay")){auto f=decode(FIRST_VERSION_FIRMWARE),d=decode(FIRST_VERSION_DLL),a=decode(FIRST_VERSION_API);memcpy(fw,f.data(),80);memcpy(dll,d.data(),80);memcpy(api,a.data(),80);}if(is("version_unterminated"))')
    fake=replace_once(fake,'if(m->ProtocolID!=3','if(s.writes==4&&is("physical_first_chunk_replay"))tx=decode(FIRST_PHYSICAL_KEY_TX);if(m->ProtocolID!=3')
    for name in ['write_fail','write_count_zero','write_count_large','write_mutation']:
        fake=replace_once(fake,f'if(is("{name}"))',f'if(is("{name}")||index("{name}_",stage))')
    fake=replace_once(fake,'if(stage<3&&is("physical_transition_replay"))','if(stage<8&&is("physical_first_chunk_replay")){s.queue.push_back(first_physical_replay_message(stage*2));s.queue.push_back(first_physical_replay_message(stage*2+1));return 0;}\n if(stage<3&&is("physical_transition_replay"))')
    fake=replace_once(fake,'if((stage==4&&is("short_ack_4"))||(stage==5&&is("short_ack_5"))||(stage==6&&is("short_ack_6")))','if(index("short_ack_",stage))')
    fake=replace_once(fake,'if(stage==7&&is("extra_ack_7"))','if(index("extra_ack_",stage))')
    write(src/'fake_backend.hpp',fake)
    previous_main=Path(r'C:\Dev\A2WC511R_RK03_PostTransitionOffline\continuation\src\main.cpp').read_text()
    journal=previous_main.split('#include <io.h>',1)[1].split('int wmain',1)[0]
    main_source='// OFFLINE ONLY. Static in-process fake; no provider loader or physical dispatcher.\n#include "probe_core.hpp"\n#include "fake_backend.hpp"\n#include "real_clock.hpp"\n#include "contract_pin.hpp"\n#include <io.h>'+journal+r'''
inline long real_fake_wait(U ms){long status=fake::wait_ms(ms);return status?status:real_clock::minimum_wait(ms);}
int wmain(int argc,wchar_t** argv){
 try{
  require(argc==5&&!wcscmp(argv[3],L"--journal"),"Exact offline fixture and NEW journal required");
  const bool real_fake=!wcscmp(argv[1],L"--offline-real-clock-fixture");
  require(real_fake||!wcscmp(argv[1],L"--offline-fixture"),"Offline fixture mode only");
  const std::string fixture=ascii(argv[2]);
  if(real_fake)require(fixture=="success"||fixture=="fragmented"||fixture=="indicators_fragmented"||fixture=="physical_first_chunk_replay","Real-clock offline fixture allowlist");
  fake::select(fixture);Api api=fake::api();if(real_fake){api.wait_ms=real_fake_wait;api.virtual_ms=real_clock::milliseconds;}
  Journal journal;journal.create(argv[4]);Probe probe(api,journal.value,false,real_fake);probe.inject_log_failure=fake::is("journal_failure_after_filter");
  probe.event("{\"type\":\"full_upload_start\",\"physical\":false,\"backend\":\"STATIC_IN_PROCESS_FAKE\",\"fixture\":"+quote(fixture)+",\"time_model\":"+quote(real_fake?"QPC_MONOTONIC_MINIMUM":"VIRTUAL_ONLY_NOT_PHYSICAL_TIME")+",\"contract_sha256\":"+quote(CONTRACT_SHA)+",\"kernel_sha256\":"+quote(KERNEL_SHA)+",\"declaration_size\":"+number(KERNEL_SIZE)+",\"embedded_cipher_bytes\":1808,\"provider_loaded\":false}");return probe.run();
 }catch(const std::exception& e){fprintf(stderr,"FAIL_CLOSED_OFFLINE_ONLY: %s\n",e.what());return 2;}
}
'''
    write(src/'main.cpp',main_source)
    build=(OLD/'tools/build_probe.py').read_text().replace('rk03_first_chunk_probe32.exe','rk03_full_upload_no_start_offline32.exe').replace('BUILD_ONLY_FIRST_CHUNK_PHYSICAL_CAPABLE_PE_NOT_EXECUTED','BUILD_ONLY_OFFLINE_FULL_UPLOAD_NO_START_PE_NOT_EXECUTED').replace('isolated first-chunk probe','offline-only full-upload-no-start replay')
    write(ROOT/'tools/build_probe.py',build)
    build_cmd=(OLD/'tools/build_probe.cmd').read_text().replace('rk03_first_chunk_probe32.exe','rk03_full_upload_no_start_offline32.exe').replace(' bcrypt.lib','')
    write(ROOT/'tools/build_probe.cmd',build_cmd)
    oracle.update({'classification':'OFFLINE_FIXED_FULL_UPLOAD_STOP_BEFORE_START','tx':tx,'rx':rx,
        'embedded_payload_bytes':1808,'full_upload_contract_sha256':contract_sha,
        'excluded_start_frame':upload['frames'][16]['request']})
    dump(ROOT/'fixtures/full_upload_oracle.json',oracle)
    dump(ROOT/'fixtures/physical_first_chunk_replay.json',{'source':pin(PHYSICAL),'tx':actual_tx,'rx_records':actual_rx,'version':versions})
    inputs=reused+[pin(p) for p in sorted((OLD/'src').glob('*')) if p.is_file()]+[pin(Path(__file__)),pin(ANALYSIS/'FULL_UPLOAD_NO_START_CONTRACT.json')]
    dump(ROOT/'INPUT_PINS.json',{'schema':1,'scope':'OFFLINE_ONLY_NO_PROVIDER','inputs':inputs})
    print(json.dumps({'contract':str(ANALYSIS/'FULL_UPLOAD_NO_START_CONTRACT.json'),'contract_sha256':contract_sha,'tx_count':len(tx),'payload_bytes':len(cipher),'source_files':len(list(src.iterdir()))}))

if __name__=='__main__':main()
