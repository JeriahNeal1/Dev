"""Offline current-ROM CPU replay of fixed upload frames; truncate before the reference handoff.

Imports the retained CPU/Memory model only. Its main() is never called. No provider code.
"""
from pathlib import Path
import datetime as dt
import gzip, hashlib, importlib.util, json, sys
sys.dont_write_bytecode=True
HERE=Path(r'C:\Dev\A2WC511R_ReadKernel\evidence\contracts')
OUT=Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_full_upload_no_start_20260930_01\current_instruction_replay')
CURRENT=Path(r'C:\Dev\SubaruRoms\current.bin')
CURRENT_SHA='bf10be6d7c75b4f2ae663b0d57a912e6e9ef7654ccfc985195954596e50427b2'
KERNEL=Path(r'C:\Dev\A2WC511R_ReadKernel\build\rk02_01\kernel.bin')
KERNEL_SHA='3a65d6f0700bae394a24ba9f552d03500b7f66e6344ec57613f10bfd360d8581'
def pin(p):
    p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(name,obj):
    with (OUT/name).open('x',encoding='utf-8') as f:json.dump(obj,f,indent=2);f.write('\n')
def main():
    source=HERE/'verify_upload_wire_rk02.py'
    assert pin(source)['sha256']=='d2c088b23baf2d3ad33dfa0db776e9047caa9dee0bcc25328039df024ea7ad95'
    contract_path=HERE/'UPLOAD_WIRE_CONTRACT_RK02.json'
    assert pin(contract_path)['sha256']=='b1c5431141f9b249b16dd15938c290f20b99593e7ab8512caebcde1906c37f50'
    contract=json.loads(contract_path.read_text())
    for row in contract['inputs']:
        assert pin(row['path'])['sha256']==row['sha256'],row['path']
    assert pin(CURRENT)['sha256']==CURRENT_SHA and pin(KERNEL)['sha256']==KERNEL_SHA
    assert len(contract['frames'])==17 and contract['frames'][16]['request']=='8010f003310101b6'
    frames=contract['frames'][:16]
    assert len(frames)==16 and all(bytes.fromhex(r['request'])[4] in (0x34,0x36) for r in frames)
    OUT.mkdir(exist_ok=False)
    save('BEGIN.json',{'scope':'OFFLINE_CURRENT_ROM_FIXED_UPLOAD_NO_START','source':pin(source),
        'excluded_frame_index':16,'physical_operations':0,'started_utc':dt.datetime.now(dt.timezone.utc).isoformat()})
    sys.path.insert(0,str(HERE))
    spec=importlib.util.spec_from_file_location('retained_upload_model_no_main',source)
    model=importlib.util.module_from_spec(spec);spec.loader.exec_module(model)
    rom=model.sh.ROM.load(CURRENT,CURRENT_SHA);kernel=KERNEL.read_bytes()
    m=model.Memory(rom);m.initialize(0xFFFFBFA0,bytes(0x60));m.initialize(0xFFFFBFBA,b'\x01');m.initialize(0xFFFFBFC8,b'\x01');m.initialize(0xFFFFBB80,bytes(0x420))
    m.write_allowlist=[(0xFFFFBB80,0xFFFFC000),(0xFFFF3000,0xFFFF3000+len(kernel))]
    trace=[];rows=[]
    for frame_index,row in enumerate(frames):
        wire=bytes.fromhex(row['request']);start=len(m.tx);before=len(trace)
        assert len(wire)==wire[3]+5 and sum(wire[:-1])&255==wire[-1]
        for byte in wire:
            m.byte=byte;c=model.CPU(m,[(0x13F6,0x1F40)],(0xFFFFBB80,0xFFFFBFA0));c.pc=0x1440;c.pr=0xFFFFFFFC;c.r[15]=0xFFFFBFA0
            c.call_context=['00001440'];c._set_system('sr',0xF0,{'boot_loop_mask15'});c.track_control_sources=False
            for _ in range(15000):
                assert c.pc!=0xFFFF3004,'Forbidden RAM entry BEFORE instruction'
                c.step()
                assert c.pc!=0xFFFF3004,'Forbidden RAM entry AFTER instruction'
                if c.returned:
                    assert c.pc==0xFFFFFFFC and c.r[15]==0xFFFFBFA0 and not c.pending
                    break
            else:raise AssertionError('Bounded parser instruction budget')
            trace.extend(c.trace)
        reply=bytes(m.tx[start:]);assert reply.hex()==row['reply_from_executed_TDR']
        assert len(trace)-before==row['instructions'],'Current instruction count differs from retained stock'
        rows.append({'frame_index':frame_index,'request':wire.hex(),'reply_from_executed_TDR':reply.hex(),
            'instructions':len(trace)-before,'returned_to_OEM_caller':True,'kernel_entered':False})
        print(json.dumps({'frame_completed':frame_index,'kind':'declaration' if frame_index==0 else 'fixed_chunk','instructions':len(trace)}),flush=True)
    actual=bytes(m.ram[0x3000:0x3000+len(kernel)])
    assert actual==kernel and hashlib.sha256(actual).hexdigest()==KERNEL_SHA
    assert all(0x13F6<=int(r['pc'],16)<0x1F40 for r in trace),'Non-OEM execution'
    stores=[e for e in m.events if e['mode']=='w' and 0xFFFF3000<=int(e['address'],16)<0xFFFF3000+len(kernel)]
    assert len(stores)==452 and all(e['size']==4 and e['pc']=='00001646' for e in stores)
    assert [int(e['address'],16) for e in stores]==list(range(0xFFFF3000,0xFFFF3710,4))
    reconstructed=b''.join(int(e['value'],16).to_bytes(4,'big') for e in stores)
    assert reconstructed==actual
    with (OUT/'expected_uploaded_ram.bin').open('xb') as f:f.write(actual)
    packed=gzip.compress(json.dumps({'instructions':trace,'memory':m.events,'mmio':m.mmio},sort_keys=True,separators=(',',':')).encode(),mtime=0)
    with (OUT/'CURRENT_NO_START_TRACE.json.gz').open('xb') as f:f.write(packed)
    # Compare the executed current-ROM instruction prefix against already sealed stock trace.
    assert pin(contract['trace']['path'])['sha256']==contract['trace']['sha256']
    old=json.loads(gzip.decompress(Path(contract['trace']['path']).read_bytes()))
    assert old['instructions'][:len(trace)]==trace,'Current/stock executed instruction prefix mismatch'
    assert old['memory'][:len(m.events)]==m.events,'Current/stock memory prefix mismatch'
    assert old['mmio'][:len(m.mmio)]==m.mmio,'Current/stock MMIO prefix mismatch'
    report={'schema':1,'status':'PASS_CURRENT_INSTRUCTIONS_FULL_FIXED_UPLOAD_NO_START',
        'completed_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'frames':rows,
        'instruction_count':len(trace),'current_and_stock_instruction_memory_mmio_prefix_identical':True,
        'kernel_started':False,'custom_kernel_instructions_executed':0,'physical_operations':0,
        'ROM_read_requests':0,'flash_operations':0,'excluded_historical_frame_index':16,
        'upload_store_count':452,'upload_store_PC':'00001646','upload_range':['FFFF3000','FFFF3710'],
        'uploaded_ram_bytes':len(actual),'uploaded_ram_sha256':hashlib.sha256(actual).hexdigest(),
        'all_ram_bytes_equal_expected_kernel':True,'inputs':[pin(CURRENT),pin(KERNEL),pin(source),pin(contract_path),pin(Path(__file__))],
        'trace':pin(OUT/'CURRENT_NO_START_TRACE.json.gz'),'derived_ram':pin(OUT/'expected_uploaded_ram.bin'),
        'assumptions':contract['assumptions'],'limits':contract['limits']+[
            'Current ROM was used directly in this offline CPU replay; no image editing or re-ingestion.',
            'Stops at returned OEM caller after final76; no later command, timer advancement, reset or physical UART behavior modeled.']}
    save('CURRENT_NO_START_REPLAY.json',report)
    print(json.dumps({'status':report['status'],'instructions':len(trace),'uploaded_ram_sha256':report['uploaded_ram_sha256']}),flush=True)
if __name__=='__main__':main()
