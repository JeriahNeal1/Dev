"""Publish fixed byte/chunk identities and canonical reproducible-build manifests."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
OUT=Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_full_upload_no_start_20260930_01')
def digest(b):return hashlib.sha256(b).hexdigest()
def pin(p):
    p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p.read_bytes())}
def save(path,obj):
    with path.open('x',encoding='utf-8') as f:json.dump(obj,f,indent=2);f.write('\n')
def main():
    c=json.loads((OUT/'FULL_UPLOAD_NO_START_CONTRACT.json').read_text())
    replay=json.loads((OUT/'current_instruction_replay/CURRENT_NO_START_REPLAY.json').read_text())
    assert replay['status']=='PASS_CURRENT_INSTRUCTIONS_FULL_FIXED_UPLOAD_NO_START'
    ram=Path(replay['derived_ram']['path']).read_bytes()
    assert digest(ram)==c['kernel_sha256'] and len(ram)==1808
    rows=[];cipher=bytearray();offset=0
    for index,item in enumerate(c['ordered_requests'][7:],1):
        wire=bytes.fromhex(item['wire_hex']);part=wire[8:-1];length=128 if index<15 else 16
        assert len(wire)==wire[3]+5 and sum(wire[:-1])&255==wire[-1]
        assert wire[4]==0x36 and len(part)==length and int.from_bytes(wire[5:8],'big')==0xff3000+offset
        assert item['expected_reply_hex']=='80f0100176f7'
        rows.append({'chunk':index,'protocol_stage':index+6,'target_address':f'{0xffff3000+offset:08X}',
            'end_exclusive':f'{0xffff3000+offset+length:08X}','payload_bytes':length,
            'cipher_payload_sha256':digest(part),'expected_plaintext_ram_sha256':digest(ram[offset:offset+length]),
            'wire_bytes':len(wire),'wire_frame_sha256':digest(wire),'wire_hex':wire.hex(),
            'wire_checksum_hex':f'{wire[-1]:02x}','expected_ack_hex':item['expected_reply_hex']})
        offset+=length;cipher.extend(part)
    assert offset==1808 and digest(cipher)==c['cipher_sha256']
    report={'schema':1,'status':'PINNED_FIXED_15_CHUNK_MANIFEST','target_start':'FFFF3000','target_end_exclusive':'FFFF3710',
        'total_payload_bytes':1808,'chunks':rows,'cipher_sha256':digest(cipher),
        'expected_uploaded_ram_sha256':digest(ram),'expected_uploaded_ram':pin(replay['derived_ram']['path']),
        'contract':pin(OUT/'FULL_UPLOAD_NO_START_CONTRACT.json'),'current_instruction_replay':pin(OUT/'current_instruction_replay/CURRENT_NO_START_REPLAY.json'),
        'maximum_protocol_requests':22,'kernel_start_present':False,'physical_backend':False}
    save(OUT/'FIXED_UPLOAD_MANIFEST.json',report)
    table=['# Fixed upload chunks','', 'SHA256 values identify the transmitted ciphertext payload, excluding address, framing and checksum. Plaintext and full-frame hashes are also recorded in FIXED_UPLOAD_MANIFEST.json.','',
        '| Chunk | Address | Bytes | Payload SHA256 |','|---:|---|---:|---|']
    table += [f'| {r["chunk"]} | `{r["target_address"]}` | {r["payload_bytes"]} | `{r["cipher_payload_sha256"]}` |' for r in rows]
    table += ['',f'Final expected plaintext RAM: **1,808 bytes**, SHA256 `{digest(ram)}`.','','No handoff/start command follows chunk15.']
    with (OUT/'FIXED_UPLOAD_CHUNKS.md').open('x',encoding='utf-8') as f:f.write('\n'.join(table)+'\n')
    canonical=[]
    for name in ['build_a','build_b']:
        b=json.loads((ROOT/name/'BUILD.json').read_text())
        normalized={'schema':1,'scope':'STATIC_FAKE_FULL_FIXED_UPLOAD_NO_START_ONLY','executable_sha256':b['exe_sha256'],
            'executable_bytes':Path(b['exe_path']).stat().st_size,'source_inputs':b['source_inputs'],
            'compiler':b['compiler'],'linker':b['linker']}
        raw=(json.dumps(normalized,sort_keys=True,indent=2)+'\n').encode()
        with (ROOT/name/'REPRODUCIBLE_MANIFEST.json').open('xb') as f:f.write(raw)
        canonical.append(raw)
    assert canonical[0]==canonical[1]
    save(OUT/'BUILD_REPRODUCIBILITY.json',{'status':'PASS_BYTE_IDENTICAL_EXES_AND_CANONICAL_MANIFESTS',
        'build_executables':[pin(ROOT/n/'rk03_full_upload_no_start_offline32.exe') for n in ['build_a','build_b']],
        'canonical_manifests':[pin(ROOT/n/'REPRODUCIBLE_MANIFEST.json') for n in ['build_a','build_b']],
        'excluded_volatile_build_fields':['UTC build timestamp','output directory and per-directory dump headers'],
        'source_inputs_identical':True,'compiler_and_linker_identical':True,'two_completed_clean_builds_reused':True})
    print(json.dumps({'chunks':len(rows),'ram_sha256':digest(ram),'manifest_sha256':digest(canonical[0])}))
if __name__=='__main__':main()
