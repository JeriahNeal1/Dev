"""Record resumed offline work and verify existing build inputs without rebuilding."""
from pathlib import Path
import ast, datetime as dt, hashlib, json, subprocess

ROOT=Path(__file__).resolve().parents[1]
OUT=Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_full_upload_no_start_20260930_01')
STATE=Path(r'C:\Dev\A2WC511R_Final\state\CURRENT.json')

def pin(p):
    p=Path(p)
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def verify(row):
    actual=pin(row['path'])
    assert actual['sha256']==row['sha256'],row['path']
    if 'bytes' in row: assert actual['bytes']==row['bytes'],row['path']
    return actual
def git(*args):
    return subprocess.check_output(['git',*args],cwd=ROOT.parent,text=True).strip()
def save(path,obj):
    with path.open('x',encoding='utf-8') as stream: json.dump(obj,stream,indent=2);stream.write('\n')
def main():
    source=ROOT/'tools/derive_offline_stage.py'
    ast.parse(source.read_text())
    pins=json.loads((ROOT/'INPUT_PINS.json').read_text())['inputs']
    verified=[verify(p) for p in pins]
    builds=[json.loads((ROOT/d/'BUILD.json').read_text()) for d in ['build_a','build_b']]
    for b in builds:
        assert b['status']=='PASS_BUILD_ONLY'
        verified.extend(verify(p) for p in b['source_inputs'])
        assert pin(b['exe_path'])['sha256']==b['exe_sha256']
    assert builds[0]['source_inputs']==builds[1]['source_inputs']
    assert Path(builds[0]['exe_path']).read_bytes()==Path(builds[1]['exe_path']).read_bytes()
    assert not (ROOT.parent/'physical_session').exists()
    saved=json.loads(STATE.read_text())
    assert saved['RK03_FIRST_CHUNK_PHYSICAL']=='PASS' and saved['OEM_RETURN_AFTER_FIRST_CHUNK']=='PASS'
    report={'schema':1,'utc':dt.datetime.now(dt.timezone.utc).isoformat(),'status':'RECOVERED_INTACT',
        'generator':pin(source),'generator_recoverable':True,'generator_completed':True,
        'generated_source_files':len(list((ROOT/'src').iterdir())),
        'branch':git('branch','--show-current'),'parent_commit':git('rev-parse','HEAD'),
        'worktrees':git('worktree','list').splitlines(),'git_status':git('status','--short'),
        'completed':['fixed offline source generation','two byte-identical clean builds','contract and input pins'],
        'pending':['offline new-stage test report','independent review','no-start current-instruction replay','sealed qualification'],
        'verified_inputs':verified,'build_hashes':[b['exe_sha256'] for b in builds],
        'physical_operations_on_resume':0,'old_physical_evidence_reused':True,
        'hardware_connection_needed':False,'no_rebuild_needed':True}
    save(OUT/'RECOVERY_AUDIT.json',report)
    save(OUT/'CURRENT_BEFORE_OFFLINE_RESUME.json',saved)
    saved.update({'updated_utc':report['utc'],'phase':'RK03_FULL_UPLOAD_NO_START_OFFLINE_QUALIFICATION',
        'active_objective':'Qualify static fake full fixed upload and stop after chunk15 ACK; no physical operations',
        'human_required':[],'further_physical_activity_allowed':False,
        'full_upload_development_directory':str(ROOT.parent),'full_upload_branch':report['branch'],
        'full_upload_checkpoint':str(OUT/'RECOVERY_AUDIT.json'),'offline_resume_physical_operations':0,
        'next_action':'Complete offline full-upload/no-start qualification, independent review, and future design plan',
        'completion_claimed':False})
    STATE.write_text(json.dumps(saved,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ['status','generator_recoverable','generated_source_files','build_hashes','physical_operations_on_resume']}))

if __name__=='__main__':main()
