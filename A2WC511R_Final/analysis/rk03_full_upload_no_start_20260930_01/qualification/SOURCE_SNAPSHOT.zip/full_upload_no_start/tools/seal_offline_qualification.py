"""Seal completed offline qualification; update mutable checkpoint, never open hardware."""
from pathlib import Path
import datetime as dt, hashlib, json, shutil, stat, subprocess, zipfile
ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent
OUT=Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_full_upload_no_start_20260930_01')
FIRST=OUT.parent/'rk03_first_chunk_20260930_01'
STATE=Path(r'C:\Dev\A2WC511R_Final\state\CURRENT.json')
def pin(p):
    p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def read(p):return json.loads(Path(p).read_text())
def save(path,obj):
    with path.open('x',encoding='utf-8') as f:json.dump(obj,f,indent=2);f.write('\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO,text=True).strip()
def check_pin(p):
    actual=pin(p['path']);assert actual['sha256']==p['sha256'],p['path']
    if 'bytes' in p:assert actual['bytes']==p['bytes'],p['path']
    return actual
def main():
    assert not git('status','--porcelain'),'Commit reviewed source before sealing'
    branch=git('branch','--show-current');commit=git('rev-parse','HEAD')
    assert branch=='rk03/full-upload-no-start'
    assert not (REPO/'physical_session').exists()
    recovery=read(OUT/'RECOVERY_AUDIT.json');check_pin(recovery['generator'])
    latest=read(ROOT/'reports/LATEST_QUALIFICATION.json');assert latest['status']=='PASS';check_pin(latest['report'])
    tests=read(latest['report']['path']);assert tests['passed_cases']==tests['test_cases']==287
    assert tests['physical_operations']==tests['real_provider_loads']==0
    native=read(OUT/'native_review/NATIVE_SOURCE_REVIEW.json')
    extra=read(OUT/'native_review/QUALIFICATION_AND_MODEL_REVIEW.json')
    audit=read(OUT/'root_review/ROOT_REVIEW.json')
    assert all(r['status'].startswith('PASS') for r in [native,extra,audit])
    current=read(OUT/'current_instruction_replay/CURRENT_NO_START_REPLAY.json')
    assert current['status']=='PASS_CURRENT_INSTRUCTIONS_FULL_FIXED_UPLOAD_NO_START' and current['all_ram_bytes_equal_expected_kernel'] and not current['kernel_started']
    manifest=read(OUT/'FIXED_UPLOAD_MANIFEST.json')
    assert len(manifest['chunks'])==15 and manifest['total_payload_bytes']==1808
    builds=read(OUT/'BUILD_REPRODUCIBILITY.json')
    for group in ['build_executables','canonical_manifests']:
        assert len({check_pin(p)['sha256'] for p in builds[group]})==1
    sources=[REPO/p for p in git('ls-files','full_upload_no_start').splitlines()]
    assert all(p.is_file() for p in sources)
    package=OUT/'qualification';package.mkdir(exist_ok=False)
    with zipfile.ZipFile(package/'SOURCE_SNAPSHOT.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in sorted(sources):
            info=zipfile.ZipInfo(path.relative_to(REPO).as_posix(),date_time=(2026,9,30,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o444<<16
            z.writestr(info,path.read_bytes())
    executable=package/'rk03_full_upload_no_start_offline32.exe'
    with executable.open('xb') as f:f.write(Path(builds['build_executables'][0]['path']).read_bytes())
    assert pin(executable)['sha256']==builds['build_executables'][0]['sha256']
    # Preserve first-chunk physical and OEM-return evidence, without repeating their operations.
    preserved=[]
    for name in ['physical_result/MANIFEST.json','oem_return_after_first_chunk_01/MANIFEST.json']:
        old=read(FIRST/name)
        rows=old.get('files',old.get('inputs',[]));assert rows,name
        preserved.extend(check_pin(row) for row in rows)
        preserved.append(pin(FIRST/name))
    for name in ['physical_result/PHYSICAL_RESULT.json','physical_review/PHYSICAL_REVIEW.json','qualification/QUALIFICATION.json']:
        preserved.append(pin(FIRST/name))
    qualification={'schema':1,'status':'PASS_OFFLINE_FULL_KERNEL_UPLOAD_NO_START_ONLY',
        'utc':dt.datetime.now(dt.timezone.utc).isoformat(),'branch':branch,'commit':commit,
        'source_snapshot':pin(package/'SOURCE_SNAPSHOT.zip'),'source_identity':[pin(p) for p in sources],
        'executable':pin(executable),'build_reproducibility':pin(OUT/'BUILD_REPRODUCIBILITY.json'),
        'test_report':latest['report'],'test_cases':287,'passed_cases':287,
        'positive_scenarios':audit['successful_scenarios'],'negative_scenarios':audit['negative_scenarios'],
        'test_history':'Earlier285/287 report preserved; two inherited service-name fixtures were misclassified by runner regex. Runner corrected; same binaries287/287.',
        'contract':pin(OUT/'FULL_UPLOAD_NO_START_CONTRACT.json'),'fixed_upload_manifest':pin(OUT/'FIXED_UPLOAD_MANIFEST.json'),
        'chunk_table':pin(OUT/'FIXED_UPLOAD_CHUNKS.md'),'current_instruction_replay':pin(OUT/'current_instruction_replay/CURRENT_NO_START_REPLAY.json'),
        'expected_uploaded_ram':current['derived_ram'],'expected_uploaded_ram_sha256':current['uploaded_ram_sha256'],
        'independent_native_review':pin(OUT/'native_review/NATIVE_SOURCE_REVIEW.json'),
        'independent_model_and_execution_review':pin(OUT/'native_review/QUALIFICATION_AND_MODEL_REVIEW.json'),
        'independent_runner_review':pin(OUT/'root_review/ROOT_REVIEW.json'),
        'recovery_audit':pin(OUT/'RECOVERY_AUDIT.json'),'future_design_plan':pin(ROOT/'FUTURE_PHYSICAL_RELEASE_PLAN.md'),
        'preserved_previous_evidence':preserved,'physical_operations':0,'physical_provider_loader':False,
        'physical_release_created':False,'physical_execution_authorized':False,'maximum_physical_invocations':0,
        'structural_no_start_proof':[
            'Only static fake API can be bound by the two accepted offline CLI modes; Probe constructor rejects physical=true.',
            'Request stage guarded below22, monotonic next_tx guarded below22, each fixed request transmitted once.',
            'Stages0..6 are fixed admission/declaration except the validated seed-derived key; stages7..21 are the15 bounded fixed transfer frames.',
            'Exact76 required at every transfer; run() immediately leaves protocol after stage21 and invokes cleanup.',
            'Reference frame16 containing310101 is excluded by frames[:16]; generated runtime table has no handoff frame.',
            'No provider discovery, physical dispatcher, kernel protocol, ROM-read or flash command dispatch exists in the compiled source closure.',
            'Payload array1808 and fixed contiguous addresses are embedded; CLI accepts no payload or address.',
            'Current-ROM CPU replay supplies only declaration+15chunks, executes476281OEM instructions, returns after lastACK and never enters RAM.',
            'Generic MSVC CRT LoadLibraryExW/GetProcAddress imports exist; no application call uses them to load a provider.'],
        'limits':current['assumptions']+current['limits']+[
            'Offline qualification is not evidence of physical acceptance of chunks2..15.',
            'Complete future physical host, launcher, certificate and recovery qualification remain outstanding.',
            'No custom kernel is executed and no ROM acquisition or flash operation is qualified.']}
    save(package/'QUALIFICATION.json',qualification)
    qpin=pin(package/'QUALIFICATION.json')
    sequence='BF ->81 ->8300 ->2701 ->2702 ->wait200ms ->108502 ->wait100ms ->baud15625 ->clearTX7 ->clearRX8 ->wait200ms ->one34 ->15fixed36(each exact76 ACK) ->STOP ->cleanup'
    report_lines=['# FULL_KERNEL_UPLOAD_NO_START: offline qualification PASS','',
        'No physical operation occurred in this resumed scope. Previous first-chunk physical PASS and passive OEM-return PASS remain preserved. The vehicle did not need to be connected.','',
        f'Branch: `{branch}`. Commit: `{commit}`.','',
        '`derive_offline_stage.py` was recovered intact and had completed generation. Its12 source files and two completed clean builds passed integrity checks; the generator and builds were reused.','',
        '## Modeled sequence','',f'`{sequence}`','',
        'There are22 protocol requests: six admission requests, one declaration and15 transfers. The first14 blocks carry128bytes each; the last carries16. All are fixed and hash-pinned.','',
        '## Results','',
        '- Qualification:287/287 passed (28positive,259negative), including every transfer failure boundary. No automatic retry.',
        '- Independent native/model review:PASS. Independent runner/journal audit:PASS,906unique pins and3402transmissions checked;9mutated journals rejected.',
        '- An earlier285/287 attempt exposed a runner-only service-name/index matching error; its report and runner snapshot remain preserved. Native source and executables did not change.',
        f'- Both clean executables:328704bytes, SHA256 `{qualification["executable"]["sha256"]}`.',
        f'- Both canonical build manifests: SHA256 `{builds["canonical_manifests"][0]["sha256"]}`. Volatile timestamps/output-directory fields are excluded explicitly.',
        '- Current-ROM instruction replay:476281instructions,452aligned four-byte RAM stores, exact current/stock instruction-memory-MMIO prefix match.',
        f'- Final modeled plaintext RAM:1808bytes, SHA256 `{current["uploaded_ram_sha256"]}`; byte-identical to the preserved owned kernel image.',
        '- Kernel start is unreachable within the compiled entry points:bounded stage0..21 dispatcher, fifteen exactACK exchanges, then cleanup. The reference handoff frame is excluded. No physical-provider, kernel-version, ROM-read, flash or arbitrary input path exists.',
        '- Generic CRT loader imports remain in the executable; they are not an application physical-provider loader.','',
        '## Fixed upload chunks','',
        'Hashes below identify transmitted ciphertext payloads. FIXED_UPLOAD_MANIFEST.json also records each complete-frame hash/checksum and expected plaintext block hash. Equal payload hashes at different addresses reflect identical bytes in the fixed image, not repeated frames.','',
        '|Chunk|Address|Bytes|Payload SHA256|','|---:|---|---:|---|']
    report_lines += [f'|{r["chunk"]}|`{r["target_address"]}`|{r["payload_bytes"]}|`{r["cipher_payload_sha256"]}`|' for r in manifest['chunks']]
    report_lines += ['', '## Remaining gaps and next milestone','',
        'This is an offline-only release. Physical chunks2..15, provider/electrical behavior and recovery after a full unstarted upload are not yet demonstrated. Final RAM equality is a CPU-model result under explicit admission/peripheral assumptions, not a vehicle RAM readback.','',
        'Next recommended milestone: separately design and qualify `RK03_FULL_UPLOAD_NO_START_PHYSICAL`. The future design plan is prepared in FUTURE_PHYSICAL_RELEASE_PLAN.md; it does not create or authorize a physical binary. Retain IGNITION OFF ->TEST MODE ON ->new explicit software authorization ->one future test ->IGNITION OFF ->NORMAL MODE ON ->passive OEM return. No individual component gates.','',
        'Current physical ECU image analysis is reused unchanged: authoritative current.bin, edited calibration, executable code byte-identical to verified stock. It is not factory stock.','',
        f'Qualification SHA256: `{qpin["sha256"]}`.']
    with (OUT/'FULL_UPLOAD_NO_START_RESULT.md').open('x',encoding='utf-8') as f:f.write('\n'.join(report_lines)+'\n')
    # Hash-pin all new reports (including the failed run), model artifacts, builds and source.
    paths=set(sources)
    for directory in [OUT,ROOT/'build_a',ROOT/'build_b',ROOT/'reports']:
        paths.update(p for p in directory.rglob('*') if p.is_file())
    paths.update(Path(p['path']) for p in preserved)
    pins=[pin(p) for p in sorted(paths)]
    save(package/'PRESERVATION_MANIFEST.json',{'schema':1,'status':'SEALED_HASH_PINNED_OFFLINE_FULL_UPLOAD_NO_START',
        'qualification':qpin,'files':pins,'source_commit':commit,'physical_operations':0})
    preservation=pin(package/'PRESERVATION_MANIFEST.json')
    for row in pins:check_pin(row)
    # Seal new generated output only. Working source is bound through the readonly source archive.
    for directory in [OUT,ROOT/'build_a',ROOT/'build_b',ROOT/'reports']:
        for p in directory.rglob('*'):
            if p.is_file():p.chmod(stat.S_IREAD)
    saved=read(STATE)
    saved.update({'updated_utc':qualification['utc'],'phase':'RK03_FULL_UPLOAD_NO_START_OFFLINE_PASS',
        'active_objective':'Completed OFFLINE_ONLY FULL_KERNEL_UPLOAD_NO_START qualification and future design plan',
        'completion_claimed':True,'completion_scope':'Offline static-fake fixed15-chunk upload/no-start model only',
        'full_upload_offline_status':'PASS','full_upload_offline_tests':'287/287',
        'full_upload_branch':branch,'full_upload_commit':commit,'full_upload_executable_sha256':qualification['executable']['sha256'],
        'full_upload_qualification':qpin,'full_upload_preservation_manifest':preservation,
        'full_upload_result_report':str(OUT/'FULL_UPLOAD_NO_START_RESULT.md'),
        'full_upload_physical_status':'NOT_BUILT_NOT_AUTHORIZED_NOT_RUN',
        'further_physical_activity_allowed':False,'human_required':[],
        'offline_resume_physical_operations':0,'next_action':'Future separate design/qualification of RK03_FULL_UPLOAD_NO_START_PHYSICAL; no execution authorization',
        'future_physical_release_plan':str(ROOT/'FUTURE_PHYSICAL_RELEASE_PLAN.md')})
    STATE.write_text(json.dumps(saved,indent=2)+'\n')
    assert not git('status','--porcelain')
    print(json.dumps({'status':qualification['status'],'branch':branch,'commit':commit,
        'qualification':qpin,'preservation_manifest':preservation,'files_pinned':len(pins)}))
if __name__=='__main__':main()
