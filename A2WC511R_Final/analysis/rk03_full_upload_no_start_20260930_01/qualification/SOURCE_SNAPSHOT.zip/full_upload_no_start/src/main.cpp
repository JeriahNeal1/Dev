// OFFLINE ONLY. Static in-process fake; no provider loader or physical dispatcher.
#include "probe_core.hpp"
#include "fake_backend.hpp"
#include "real_clock.hpp"
#include "contract_pin.hpp"
#include <io.h>
#include <fcntl.h>
struct Journal{FILE* value=nullptr;~Journal(){if(value)fclose(value);}void create(const wchar_t* path){HANDLE h=CreateFileW(path,GENERIC_WRITE,0,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr);require(h!=INVALID_HANDLE_VALUE,"Exclusive new offline journal required");int fd=_open_osfhandle(reinterpret_cast<intptr_t>(h),_O_BINARY|_O_WRONLY);if(fd<0){CloseHandle(h);require(false,"Journal descriptor");}value=_fdopen(fd,"wb");if(!value){_close(fd);require(false,"Journal stream");}}};
std::string ascii(const wchar_t* s){std::string out;while(*s){require(*s>0&&*s<128,"ASCII fixture name required");out+=static_cast<char>(*s++);}return out;}

inline long real_fake_wait(U ms){long status=fake::wait_ms(ms);return status?status:real_clock::minimum_wait(ms);}
int wmain(int argc,wchar_t** argv){
 try{
  require(argc==5&&!wcscmp(argv[3],L"--journal"),"Exact offline fixture and NEW journal required");
  const bool real_fake=!wcscmp(argv[1],L"--offline-real-clock-fixture");
  require(real_fake||!wcscmp(argv[1],L"--offline-fixture"),"Offline fixture mode only");
  const std::string fixture=ascii(argv[2]);
  if(real_fake)require(fixture=="success"||fixture=="fragmented"||fixture=="indicators_fragmented"||fixture=="physical_first_chunk_replay","Real-clock offline fixture allowlist");
  fake::select(fixture);Api api=fake::api();if(real_fake){api.wait_ms=real_fake_wait;api.virtual_ms=real_clock::milliseconds;}
  Journal journal;journal.create(argv[4]);Probe probe(api,journal.value,false,real_fake);probe.inject_log_failure=fake::is("journal_failure_after_filter");
  probe.event("{\"type\":\"full_upload_start\",\"physical\":false,\"backend\":\"STATIC_IN_PROCESS_FAKE\",\"fixture\":"+quote(fixture)+",\"time_model\":"+quote(real_fake?"QPC_MONOTONIC_MINIMUM":"VIRTUAL_ONLY_NOT_PHYSICAL_TIME")+",\"contract_sha256\":"+quote(CONTRACT_SHA)+",\"kernel_sha256\":"+quote(KERNEL_SHA)+",\"declaration_size\":"+number(KERNEL_SIZE)+",\"embedded_cipher_bytes\":1808,\"provider_loaded\":false}");return probe.run();
 }catch(const std::exception& e){fprintf(stderr,"FAIL_CLOSED_OFFLINE_ONLY: %s\n",e.what());return 2;}
}
