#pragma once
static constexpr const char* CONTRACT_SHA="3861d397a625a252394ab2c0fdd58af9bbf03c9996a7c98ec7de239270779a5f";
