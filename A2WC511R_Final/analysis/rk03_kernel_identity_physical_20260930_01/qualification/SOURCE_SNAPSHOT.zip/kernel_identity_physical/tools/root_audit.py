"""Root's independent read-only audit of the reviewer-authored qualification runner.
This file reads completed journals and cannot invoke the executable or a provider.
"""
from pathlib import Path
import collections, datetime as dt, hashlib, json, re

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_kernel_identity_physical_20260930_01')
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p=Path(p)
    return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
verified={}
def verify(obj):
    if isinstance(obj,dict):
        if isinstance(obj.get('path'),str) and isinstance(obj.get('sha256'),str):
            p=obj['path'];actual=verified.setdefault(p,pin(p))
            assert actual['sha256']==obj['sha256'],p
            if 'bytes' in obj: assert actual['bytes']==obj['bytes'],p
        for v in obj.values(): verify(v)
    elif isinstance(obj,list):
        for v in obj: verify(v)
def rows(p): return [json.loads(s) for s in Path(p).read_text().splitlines()]
def main():
    latest=read(ROOT/'reports/LATEST_QUALIFICATION.json');verify(latest)
    report=read(latest['report']['path']);verify(report)
    assert report['status']=='PASS' and report['passed_cases']==report['test_cases']==386
    assert report['physical_operations']==report['real_provider_loads']==0
    contract=read(OUT/'PHYSICAL_IDENTITY_REVIEW_CONTRACT.json')
    fixed=[r['wire_hex'] for r in contract['ordered_requests']]
    assert len(fixed)==24 and fixed[-2:]==['8010f003310101b6','beef000101af']
    prior=read(report['inputs']['prior311_report']['path'])
    old={(c['mode'],c['case']) for c in prior['cases']}
    new={(c['mode'],c['case']) for c in report['cases']}
    assert len(old)==311 and old<=new and len(new-old)==75
    vectors=read(report['inputs']['seed_vectors']['path'])['seed_cases']
    known_keys={v['wire_seed'].lower():v['timer_and_stored_expected_key'].lower() for v in vectors}
    known_keys.update({'12345678':'e78f1f21','b99d2bfd':'51f7b537','a917a34f':'4015f497'})
    counts=collections.Counter();case_rows=[];journals={}
    for c in report['cases']:
        name=c['case'];mode=c['mode'];rs=rows(c['journal']['path']);journals[(mode,name)]=rs
        assert c['status']=='PASS'
        assert c['command'][1]=={'virtual':'--offline-fixture','real_clock':'--offline-real-clock-fixture','bootstrap':'--offline-bootstrap'}[mode]
        assert c['command'][2]==name and c['command'][0]==report['inputs']['binary']['path']
        assert all(r.get('physical',False) is False for r in rs)
        if mode=='bootstrap':
            assert len(rs)==1 and rs[0]['type']=='offline_bootstrap_result'
            assert rs[0]['provider_load_attempts']==rs[0]['api_calls']==0
            assert c['exit_code']==0
            counts['bootstrap']+=1
            continue
        assert rs[0]['type']=='kernel_identity_start' and rs[0]['provider_loaded'] is False
        assert rs[0]['backend']=='STATIC_IN_PROCESS_FAKE'
        assert rs[-1]['type']=='probe_terminal'
        its=[r for r in rs if r['type']=='api_intent'];rets=[r for r in rs if r['type']=='api_return']
        assert [r['sequence'] for r in its]==list(range(len(its)))
        tx=[r for r in its if r['function']=='PassThruWriteMsgs'];terminal=rs[-1]
        assert len(tx)==c['tx_attempts']==c['expected_tx_attempts']<=24
        rx_stage=-1;assembled=[]
        for r in rets:
            if r['function']=='PassThruWriteMsgs': rx_stage+=1;assembled.append('')
            if r['function']=='PassThruReadMsgs' and r['status']==0 and r['output']['count']==1:
                m=r['output']['message']
                if m['rx_status']==0: assembled[rx_stage]+=m['data_hex']
        for n,r in enumerate(tx):
            wire=r['input']['message']['data_hex'];b=bytes.fromhex(wire)
            if n!=4: assert wire==fixed[n],(name,n)
            else:
                assert b[:6]==bytes.fromhex('8010f0062702') and len(b)==11
                seed=assembled[3][12:20];assert b[6:10].hex()==known_keys[seed],(name,seed)
            assert b[-1]==sum(b[:-1])%256
            assert r['input']['input_count']==1 and r['input']['message_capacity']==1
        cleanup=[r for r in its if r.get('cleanup')]
        if cleanup: assert its[-len(cleanup):]==cleanup
        for r in rets:
            assert r['qpc_before']<=r['qpc_after'] and r['api_elapsed_ticks']==r['qpc_after']-r['qpc_before']
            if r['status'] and not r.get('cleanup'):
                assert not any(x['sequence']>r['sequence'] and not x.get('cleanup') for x in its)
        if c['exit_code']==0:
            counts['protocol_success']+=1
            assert terminal['status']=='PASS_OFFLINE_KERNEL_START_IDENTITY_ONLY'
            assert terminal['cleanup_confirmed'] and terminal['protocol_complete']
            assert len(tx)==24 and assembled[7:22]==['80f0100176f7']*15
            assert assembled[22:]==['80f01003710101f6','beef000f8141325743353131522d524b3032005f']
            assert [r['function'] for r in cleanup]==['PassThruStopMsgFilter','PassThruDisconnect','PassThruClose']
            assert all(r['status']==0 for r in rets)
            transitions=[r for r in its if r['function']=='PassThruStopMsgFilter' and not r.get('cleanup')]
            assert len(transitions)==1 and tx[22]['sequence']<transitions[0]['sequence']<tx[23]['sequence']
            start_rx=[r for r in rets if r['function']=='PassThruReadMsgs' and tx[22]['sequence']<r['sequence']<transitions[0]['sequence']]
            assert ''.join(r['output']['message']['data_hex'] for r in start_rx if r['output']['message']['rx_status']==0)==assembled[22]
            waits=[r for r in rets if r['function'] in ('OfflineClockAdvance','MonotonicMinimumWait')]
            assert [r['input']['milliseconds'] for r in waits]==[200,100,200]
            if mode=='real_clock':
                for r in waits: assert 1000*r['api_elapsed_ticks']>=r['input']['milliseconds']*r['qpc_frequency']
        else:
            counts['terminal_negative']+=1
            assert c['exit_code']==1 and terminal['status']=='FAIL_TERMINAL'
            indexed=re.fullmatch(r'(?:bad_ack|negative_ack|bad_checksum|status16|truncated|short_ack|extra_ack|write_fail|write_count_zero|write_count_large|write_mutation)_(\d+)',name)
            if indexed and int(indexed[1])<=23: assert len(tx)==int(indexed[1])+1
            if name in ('transition_stop_fail','kernel_baud_fail','kernel_baud_mutation','kernel_filter_fail','kernel_filter_mutation','start_late_reply'): assert len(tx)==23
            if name.startswith('identity_'): assert len(tx)==24
        case_rows.append(dict(case=name,mode=mode,tx=len(tx),exit_code=c['exit_code'],journal=c['journal']))
    assert counts==dict(protocol_success=50,terminal_negative=312,bootstrap=24),counts
    physical=rows(report['inputs']['full_physical_upload_reference']['path'])
    replay=journals[('virtual','physical_full_upload_replay')]
    def wires(rs,kind):
        return [r['input']['message'] if kind=='PassThruWriteMsgs' else r['output']['message'] for r in rs if r.get('type')==('api_intent' if kind=='PassThruWriteMsgs' else 'api_return') and r.get('function')==kind]
    assert wires(physical,'PassThruWriteMsgs')==wires(replay,'PassThruWriteMsgs')[:22]
    assert wires(physical,'PassThruReadMsgs')==wires(replay,'PassThruReadMsgs')[:44]
    late={}
    for name in ['start_late_reply','identity_late_reply']:
        rs=journals[('virtual',name)]
        reads=[r for r in rs if r.get('type')=='api_return' and r.get('function')=='PassThruReadMsgs']
        last=reads[-1];ms=last['api_elapsed_ticks']*1000/last['qpc_frequency']
        assert ms>=2000 and rs[-1]['status']=='FAIL_TERMINAL';late[name]=ms
    controls=[]
    for name,count in [('LAUNCHER_TESTS_V2.json',36),('OEM_RETURN_CONTROL_TESTS_V2.json',14),('RESULT_VALIDATOR_TESTS.json',46)]:
        d=read(OUT/name);verify(d);assert d['status']=='PASS' and d['checks_passed']==count
        controls.append(pin(OUT/name))
    assert not (ROOT.parent/'physical_session').exists()
    output=dict(schema=1,status='PASS_ROOT_INDEPENDENT_RUNNER_AND_RAW_EVIDENCE_REVIEW',reviewer='root',runner_author='passive_review',
        native_author='root',native_review_author='passive_review',utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        report=latest['report'],runner=report['inputs']['runner'],audit_source=pin(__file__),
        counts=dict(counts),retained_cases=311,new_suffix_cases=75,physical_replay_tx_records=22,physical_replay_rx_records=44,
        late_valid_reply_ms=late,controls=controls,distinct_pins_verified=len(verified),
        independent_findings=['All transmitted wires form only the fixed24-request prefix; seed keys match retained known vectors.',
        'All15 chunkACKs, startACK and exact identity bytes recovered from every successful raw journal.',
        'Every indexed negative stops at its named stage; nonzero API returns permit only cleanup.',
        'Full physical transcript prefix matches bytes and provider message metadata, including timestamps.',
        'Runner subprocess arguments select only static-fake/bootstrap modes; bootstrap hard-stop records have no provider calls.',
        'No new native executions or provider access were performed by this read-only audit.'],
        limitations=['Independent review of source and recorded fake results does not establish physical kernel execution or silicon timing.'],
        physical_operations=0,provider_loads=0,executable_invocations=0,cases=case_rows)
    dest=OUT/'root_review';dest.mkdir(exist_ok=True)
    with (dest/'ROOT_REVIEW.json').open('x',encoding='utf-8') as f: json.dump(output,f,indent=2);f.write('\n')
    print(json.dumps({'status':output['status'],'counts':dict(counts),'report':pin(dest/'ROOT_REVIEW.json')}))
if __name__=='__main__': main()
