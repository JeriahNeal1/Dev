"""Derive the reviewed, fixed identity suffix; no executable/provider invocation."""
from pathlib import Path
import datetime,hashlib,json
ROOT=Path(__file__).resolve().parents[1]
OLD=Path(r'C:\Dev\A2WC511R_RK03_FullUploadPhysical\full_upload_physical')
OUT=Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_kernel_identity_physical_20260930_01')
OFF=OUT.parent/'rk03_kernel_identity_offline_20260930_01'
PREV=OUT.parent/'rk03_full_upload_physical_20260930_01'
SESSION='RK03_KERNEL_START_IDENTITY_01'
TOKEN='PROCEED RK03 KERNEL START IDENTITY'
def pin(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(p,o):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(o,f,indent=2);f.write('\n')
def one(t,a,b):
 assert t.count(a)==1,a
 return t.replace(a,b)
def main():
 cert=OFF/'sealed/QUALIFICATION.json'
 assert pin(cert)['sha256']=='1ea49f1c26570305e15801e27408a0b0c0f153e35e32df8d09e73dd121d34c27'
 o=json.loads(cert.read_text());assert o['tests_passed']==526 and o['maximum_transmits']==24
 for key in ['qualification_tests','instruction_replay','independent_review']:
  p=o[key];assert pin(p['path'])['sha256']==p['sha256']
 provider=Path(r'C:\Windows\SysWOW64\op20pt32.dll');assert pin(provider)['sha256']=='f432084801762d919a3c31974616e097562424470003edc4f4fb843df34103cf'
 receipt={'source':'user','reply':'Yes','meaning':'Include exactly one fixed beef000101af identity query after the start ACK and62500baud, as sealed offline model','physical_execution_authorized':False,'received_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 save(OUT/'IDENTITY_QUERY_SCOPE_AUTHORIZATION.json',receipt)
 contract=json.loads((PREV/'PHYSICAL_FULL_UPLOAD_REVIEW_CONTRACT.json').read_text())
 contract.update(status='REVIEW_CONTRACT_PHYSICAL_KERNEL_START_IDENTITY_NOT_AUTHORIZATION',scope='FIXED15_CHUNKS_ONE_START_ONE_IDENTITY_THEN_CLEANUP',
  created_utc=receipt['received_utc'],session_id=SESSION,session_path=str(ROOT.parent/'physical_session'/SESSION),requires_exact_human_authorization=TOKEN,
  base_branch='rk03/full-upload-no-start-physical',base_commit='41b01141ab2aaa8f001f993b245e09cb1756f5b5',build_branch='rk03/kernel-start-identity-physical',
  offline_identity_qualification=pin(cert),identity_query_scope=pin(OUT/'IDENTITY_QUERY_SCOPE_AUTHORIZATION.json'),
  start_frame='8010f003310101b6',start_ack='80f01003710101f6',entry='FFFF3004',identity_request='beef000101af',identity_reply='beef000f8141325743353131522d524b3032005f',identity_ascii='A2WC511R-RK02\u0000',maximum_requests=24,
  post_start_transition=['exact start ACK','stop old filter once','SET_CONFIG DATA_RATE62500','BEEF PASS_FILTER maskffff patternbeef nullflow','fixed identity request','exact20byte identity reply','cleanup'],
  additions=['fixed start and identity suffix','strict bounded BEEF receive parser','post-ReadMsgs whole-frame deadline enforcement','dynamic filter-state logging and one-attempt filter release'],
  forbidden=['second start','ROM read','arbitrary memory read','flash operation','arbitrary address','arbitrary payload','sixteenth36','retry'],
  limitations=['Physical start and identity remain unproven until separately authorized single run.','Unchanged kernel contains its prior ROM-read implementation; this host has no request path to it.','Simulation does not establish silicon timing.','Fixed cipher/image unchanged; no physical RAM readback.'])
 contract['maximum_tx']=24
 contract.pop('excluded_historical_frame_index');contract.pop('excluded_historical_frame_hex')
 contract['included_historical_start_frame_index']=16
 for stage,tx,rx in [(22,contract['start_frame'],contract['start_ack']),(23,contract['identity_request'],contract['identity_reply'])]:
  contract['ordered_requests'].append({'stage':stage,'wire_hex':tx,'dynamic_rule':None,'sample_wire_hex':tx,'expected_reply_hex':rx})
 contract['kernel_filter']={'type':1,'protocol':3,'tx_flags':0,'mask_hex':'ffff','pattern_hex':'beef','flow_control_hex':None,'flow_pointer_nonnull':False}
 save(OUT/'PHYSICAL_IDENTITY_REVIEW_CONTRACT.json',contract)
 sha=pin(OUT/'PHYSICAL_IDENTITY_REVIEW_CONTRACT.json')['sha256']
 pins=(OLD/'src/pins.hpp').read_text().replace('0b56e15ae2dcf749666679effd559c54b7a7c2e202fc2ad2902e24c2a54b1e51',sha).replace('RK03_FULL_UPLOAD_NO_START_01',SESSION).replace('PROCEED RK03 FULL UPLOAD NO START',TOKEN).replace('rk03_full_upload_physical_20260930_01','rk03_kernel_identity_physical_20260930_01').replace('PHYSICAL_FULL_UPLOAD_REVIEW_CONTRACT.json','PHYSICAL_IDENTITY_REVIEW_CONTRACT.json').replace('A2WC511R_RK03_FullUploadPhysical','A2WC511R_RK03_KernelIdentityPhysical')
 (ROOT/'src/pins.hpp').write_text(pins,newline='\n')
 maincpp=(OLD/'src/main.cpp').read_text().replace('--physical-full-upload-no-start','--physical-kernel-start-identity').replace('full_upload_start','kernel_identity_start').replace('FULL_UPLOAD_NO_START','KERNEL_START_IDENTITY_ONLY')
 (ROOT/'src/main.cpp').write_text(maincpp,newline='\n')
 core=(OLD/'src/probe_core.hpp').read_text()
 core=one(core,'#include "protocol.hpp"','#include "protocol.hpp"\n#include "identity_response.hpp"')
 core=one(core,'Bytes key_request;U requested_baud','bool kernel_filter=false,filter_stop_attempted=false,start_acknowledged=false,identity_validated=false;unsigned acknowledged_chunks=0;\n Bytes key_request;U requested_baud')
 core=one(core,'require(stage<22,"Fifteenth chunk is the final offline protocol action");','require(stage<24,"Fixed identity is the final protocol action");\n  if(stage==22){require(acknowledged_chunks==15,"All fifteen ACKs before fixed start");return decode("8010f003310101b6");}\n  if(stage==23){require(start_acknowledged&&kernel_filter&&filtered&&requested_baud==62500,"Identity follows reviewed start transition");return decode("beef000101af");}')
 core=core.replace('stage==next_tx&&stage<22','stage==next_tx&&stage<24').replace('stage==next_tx&&next_tx<22','stage==next_tx&&next_tx<24')
 core=one(core,'Stream stream;ULONGLONG deadline','Stream stream;IdentityReply identity;ULONGLONG deadline')
 core=one(core,'require(rx.intact()&&count==1,"RX count/ABI bounds");if(stream.consume(rx.value,request(stage)))return stream.bytes;',
  'require(GetTickCount64()<deadline,"Whole frame deadline after API return");require(rx.intact()&&count==1,"RX count/ABI bounds");if(stage==23){if(identity.consume(rx.value,request(stage)))return identity.bytes;}else if(stream.consume(rx.value,request(stage)))return stream.bytes;')
 core=one(core,'if(filtered){if(cleanup_call','if(filtered&&!filter_stop_attempted){filter_stop_attempted=true;if(cleanup_call')
 core=one(core,'const Bytes','const Bytes') if False else core
 core=one(core,'+",\\\"tx_attempts\\\":"+number(next_tx)', '+",\\\"kernel_filter\\\":"+boolean(kernel_filter)+",\\\"filter_stop_attempted\\\":"+boolean(filter_stop_attempted)+",\\\"acknowledged_chunks\\\":"+number(acknowledged_chunks)+",\\\"start_acknowledged\\\":"+boolean(start_acknowledged)+",\\\"identity_validated\\\":"+boolean(identity_validated)+",\\\"tx_attempts\\\":"+number(next_tx)')
 core=one(core,',\\\"requested_mask_hex\\\":\\\"00000000\\\",\\\"requested_pattern_hex\\\":\\\"00000000\\\",\\\"requested_flow_hex\\\":\\\"00000000\\\",\\\"protocol\\\":3', ',\\\"requested_mask_hex\\\":"+quote(kernel_filter?"ffff":"00000000")+",\\\"requested_pattern_hex\\\":"+quote(kernel_filter?"beef":"00000000")+",\\\"requested_flow_hex\\\":"+(kernel_filter?std::string("null"):quote("00000000"))+",\\\"protocol\\\":3')
 core=one(core,'(filter_requested?message_json(observed_flow):"null")','(filter_requested&&!kernel_filter?message_json(observed_flow):"null")')
 old='for(unsigned stage=7;stage<22;stage++)require(payload(exchange(stage))==Bytes({0x76}),"Each fixed chunk ACK must be exact76");protocol_complete=true;'
 new='for(unsigned stage=7;stage<22;stage++){require(payload(exchange(stage))==Bytes({0x76}),"Each fixed chunk ACK must be exact76");acknowledged_chunks++;}\n   require(payload(exchange(22))==Bytes({0x71,1,1}),"Exact fixed start ACK");start_acknowledged=true;identity_transport();\n   require(exchange(23)==IdentityReply::expected(),"Exact pinned kernel identity including NUL");identity_validated=true;protocol_complete=true;'
 core=one(core,old,new)
 core=core.replace('PASS_FULL_UPLOAD_NO_START_ONLY','PASS_KERNEL_START_IDENTITY_ONLY').replace('PASS_OFFLINE_FULL_KERNEL_UPLOAD_NO_START_ONLY','PASS_OFFLINE_KERNEL_START_IDENTITY_ONLY')
 method=r'''
 void identity_transport(){
  require(next_tx==23&&start_acknowledged&&filtered&&!filter_stop_attempted,"Start ACK precedes transition");
  long stopped=call("PassThruStopMsgFilter","{\"channel\":"+number(channel)+",\"filter_id\":"+number(filter)+"}",[&](){filter_stop_attempted=true;return api.stop_filter(channel,filter);},[&](long s){if(!s)filtered=false;else cleanup_errors|=1;return "{}";});ok(stopped);
  requested_baud=62500;baud_accepted=false;ConfigBuffer b;b.list.NumOfParams=1;b.items[0]={1,62500};
  ok(call("PassThruIoctl","{\"channel\":"+number(channel)+",\"ioctl\":2,\"input_present\":true,\"output_present\":false,\"config\":"+config_json(b.list,b.items,1)+"}",[&](){return api.ioctl(channel,2,&b.list,nullptr);},[&](long s){baud_accepted=!s;return "{\"config\":"+config_json(b.list,b.items,1)+",\"canaries_intact\":"+boolean(b.intact())+"}";}));
  require(b.intact()&&b.list.NumOfParams==1&&b.list.ConfigPtr==b.items&&b.items[0].Parameter==1&&b.items[0].Value==62500,"Identity baud SET_CONFIG mutation");
  Message mask,pattern;set_message(mask.value,{0xff,0xff});set_message(pattern.value,{0xbe,0xef});const auto expected_mask=mask.value,expected_pattern=pattern.value;
  kernel_filter=true;filter_requested=true;filter_objects_valid=false;filter_stop_attempted=false;
  std::string input="{\"channel\":"+number(channel)+",\"filter_type\":1,\"mask_present\":true,\"pattern_present\":true,\"flow_present\":false,\"filter_output_present\":true,\"mask\":"+message_json(mask.value)+",\"pattern\":"+message_json(pattern.value)+",\"flow\":null}";
  ok(call("PassThruStartMsgFilter",input,[&](){return api.filter(channel,1,&mask.value,&pattern.value,nullptr,&filter);},[&](long s){if(!s)filtered=true;observed_mask=mask.value;observed_pattern=pattern.value;observed_flow={};filter_objects_valid=mask.intact()&&pattern.intact()&&!memcmp(&mask.value,&expected_mask,sizeof(expected_mask))&&!memcmp(&pattern.value,&expected_pattern,sizeof(expected_pattern));return "{\"filter_id\":"+number(filter)+",\"mask\":"+message_json(mask.value)+",\"pattern\":"+message_json(pattern.value)+",\"flow\":null,\"canaries_intact\":"+boolean(mask.intact()&&pattern.intact())+"}";}));
  require(filter_objects_valid,"Identity filter output mutation/ABI bounds");
 }
'''
 core=one(core,' int run(){',method+'\n int run(){')
 (ROOT/'src/probe_core.hpp').write_text(core,newline='\n')
 save(ROOT/'INPUT_PINS.json',{'schema':1,'scope':'OFFLINE_QUALIFICATION_OF_NEW_PHYSICAL_IDENTITY_RELEASE','inputs':[pin(p) for p in sorted((OLD/'src').iterdir()) if p.is_file()]+[pin(cert),pin(OUT/'PHYSICAL_IDENTITY_REVIEW_CONTRACT.json'),pin(provider),pin(Path(__file__))]})
 cp=json.loads((OUT/'CHECKPOINT.json').read_text());cp.update(status='NATIVE_INTEGRATION_AND_QUALIFICATION_IN_PROGRESS',identity_query_scope='EXPLICITLY_AUTHORIZED_BY_USER_YES',physical_invocations=0,review_contract=pin(OUT/'PHYSICAL_IDENTITY_REVIEW_CONTRACT.json'))
 (OUT/'CHECKPOINT.json').write_text(json.dumps(cp,indent=2)+'\n')
 print(json.dumps({'contract_sha256':sha,'status':'DERIVED_NOT_EXECUTED','maximum_requests':24}))
if __name__=='__main__':main()
