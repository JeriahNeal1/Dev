"""Seal the reviewed identity release and initialize unfulfilled human gates.
Never invokes a physical executable, enumerates devices or loads a provider.
"""
from pathlib import Path
import datetime as dt, hashlib, json, stat, subprocess, zipfile

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parent
OUT=Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_kernel_identity_physical_20260930_01')
STATE=Path(r'C:\Dev\A2WC511R_Final\state\CURRENT.json')
CONTROLS=['launch_identity_once.py','launch_oem_return_once.py','check_clients.ps1',
    'test_launcher_offline.py','test_oem_return_controls.py','seal_identity_result.py',
    'test_result_validator.py','seal_oem_return_identity.py']
REVIEWS=[OUT/'independent_review/NATIVE_AND_QUALIFICATION_REVIEW.json',
    OUT/'independent_review/RELEASE_CONTROLS_REVIEW.json',OUT/'root_review/ROOT_REVIEW.json',
    OUT/'independent_review/SEALING_REVIEW.json']
TESTS=[('LAUNCHER_TESTS_V2.json',36),('OEM_RETURN_CONTROL_TESTS_V2.json',14),('RESULT_VALIDATOR_TESTS.json',46)]
EXPECTED_EXE='623dc766ca69a97b16f7beabc9acb909a1225eabb8a21c40fe8379b4f72b593f'
EXPECTED_CONTRACT='5f2b1e263d98bc1a4a957770ea8e3c214a6ffb5a6798caf7aba79bcc5ecfe167'
EXPECTED_IMAGE='3a65d6f0700bae394a24ba9f552d03500b7f66e6344ec57613f10bfd360d8581'

def require(condition,detail):
    if not condition: raise RuntimeError(detail)
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p=Path(p)
    return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,obj):
    with Path(p).open('x',encoding='utf-8',newline='\n') as f: json.dump(obj,f,indent=2);f.write('\n')
def git(*args): return subprocess.check_output(['git',*args],cwd=REPO,text=True).strip()
def verify(obj):
    if isinstance(obj,dict):
        if isinstance(obj.get('path'),str) and isinstance(obj.get('sha256'),str):
            actual=pin(obj['path']);require(actual['sha256']==obj['sha256'],'Changed pin: '+obj['path'])
            if 'bytes' in obj: require(actual['bytes']==obj['bytes'],'Changed size: '+obj['path'])
        for value in obj.values(): verify(value)
    elif isinstance(obj,list):
        for value in obj: verify(value)
def all_files(directory): return [p for p in directory.rglob('*') if p.is_file() and '__pycache__' not in p.parts]

def main():
    require(not git('status','--porcelain'),'Commit frozen release source first')
    require(git('branch','--show-current')=='rk03/kernel-start-identity-physical','Wrong branch')
    require(not (REPO/'physical_session').exists(),'Physical session already exists')
    require(not (OUT/'qualification').exists(),'Never overwrite a sealed release')
    require(not (OUT/'IDENTITY_GATE_STATE.json').exists(),'Never replace a human gate state')
    contract_path=OUT/'PHYSICAL_IDENTITY_REVIEW_CONTRACT.json';contract=read(contract_path)
    require(pin(contract_path)['sha256']==EXPECTED_CONTRACT,'Contract hash changed')
    require(contract['session_id']=='RK03_KERNEL_START_IDENTITY_01','Wrong session')
    require(contract['kernel_sha256']==EXPECTED_IMAGE and contract['entry']=='FFFF3004','Kernel/entry changed')
    require(contract['maximum_tx']==contract['maximum_requests']==24,'Wrong TX boundary')
    require(len(contract['ordered_requests'])==24,'Wrong request list')
    require(contract['start_frame']=='8010f003310101b6' and contract['identity_request']=='beef000101af','Wrong suffix')
    require(contract['identity_reply']=='beef000f8141325743353131522d524b3032005f','Wrong reply')
    for key in ['physical_provider','offline_qualification','offline_manifest','offline_identity_qualification','identity_query_scope']:
        verify(contract[key])
    latest=read(ROOT/'reports/LATEST_QUALIFICATION.json');verify(latest)
    tests=read(latest['report']['path']);verify(tests)
    require(latest['status']==tests['status']=='PASS' and tests['passed_cases']==tests['test_cases']==386,'Native qualification failed')
    require(tests['physical_operations']==tests['real_provider_loads']==0,'Offline boundary violation')
    for path in REVIEWS:
        report=read(path);require(report['status'].startswith('PASS'),'Review not passed: '+str(path));verify(report)
    for name,count in TESTS:
        report=read(OUT/name);verify(report)
        require(report['status']=='PASS' and report['checks_passed']==count,'Control checks not passed')
    builds=[read(ROOT/name/'BUILD.json') for name in ('build_a','build_b')]
    for b in builds:
        require(b['status']=='PASS_BUILD_ONLY','Build failed');verify(b['source_inputs'])
        require(pin(b['exe_path'])['sha256']==b['exe_sha256']==EXPECTED_EXE,'Executable hash mismatch')
    require(builds[0]['source_inputs']==builds[1]['source_inputs'],'Independent builds used different inputs')
    require(Path(builds[0]['exe_path']).read_bytes()==Path(builds[1]['exe_path']).read_bytes(),'Build bytes differ')
    for name in CONTROLS:
        require((ROOT/'release_controls'/name).read_bytes()==(OUT/name).read_bytes(),'Control snapshot mismatch: '+name)
    source=[REPO/p for p in git('ls-files','kernel_identity_physical').splitlines()]
    require(source and all(p.is_file() for p in source),'Empty/incomplete source snapshot')
    require(not any('draft_build_' in str(p) or p.name in ['launch_full_upload_once.py','seal_full_upload_result.py','seal_oem_return_full_upload.py'] for p in source),'Historical copies in active source closure')
    # All checks above are read-only. Only the new qualification outputs follow.
    canonical=[]
    for name,b in zip(('build_a','build_b'),builds):
        obj={'schema':1,'scope':'GATED_PHYSICAL_FIXED_KERNEL_START_IDENTITY_ONLY',
             'executable_sha256':b['exe_sha256'],'source_inputs':b['source_inputs'],
             'compiler':b['compiler'],'linker':b['linker']}
        raw=(json.dumps(obj,sort_keys=True,indent=2)+'\n').encode();canonical.append(raw)
        with (ROOT/name/'REPRODUCIBLE_MANIFEST.json').open('xb') as f: f.write(raw)
    require(canonical[0]==canonical[1],'Canonical manifests differ')
    qdir=OUT/'qualification';qdir.mkdir(exist_ok=False)
    with zipfile.ZipFile(qdir/'SOURCE_SNAPSHOT.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(source):
            info=zipfile.ZipInfo(p.relative_to(REPO).as_posix(),date_time=(2026,9,30,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o444<<16
            z.writestr(info,p.read_bytes())
    paths=set(source+[OUT/n for n in CONTROLS]+REVIEWS+[OUT/n for n,_ in TESTS])
    paths.update([contract_path,OUT/'IDENTITY_QUERY_SCOPE_AUTHORIZATION.json',OUT/'independent_review/REVIEW.md'])
    paths.update(Path(r['path']) for r in read(ROOT/'INPUT_PINS.json')['inputs'])
    for key in ['physical_provider','offline_qualification','offline_manifest','offline_identity_qualification','fixed_upload_manifest']:
        paths.add(Path(contract[key]['path']))
    for directory in [ROOT/'build_a',ROOT/'build_b',ROOT/'reports',OUT/'root_review']:
        paths.update(all_files(directory))
    # Only completed immutable dependencies are certificate inputs. Mutable
    # CHECKPOINT, CURRENT and human gates must not invalidate their own certificate.
    reuse_path=OUT.parent/'current_rom_20260930_01/OEM_RETURN_REUSE.json';reuse=read(reuse_path)
    require(reuse['status']=='PASS_UNCHANGED_QUALIFIED_PASSIVE_REUSE','Passive reuse not qualified')
    verify(reuse['files']);paths.add(reuse_path);paths.update(Path(r['path']) for r in reuse['files'])
    files=[pin(p) for p in sorted(paths)]
    cert={'schema':1,'status':'PASS_OFFLINE_QUALIFIED_PHYSICAL_KERNEL_START_IDENTITY_ONLY',
        'utc':dt.datetime.now(dt.timezone.utc).isoformat(),'session_id':contract['session_id'],
        'branch':git('branch','--show-current'),'commit':git('rev-parse','HEAD'),
        'maximum_physical_invocations':1,'requires_exact_human_authorization':contract['requires_exact_human_authorization'],
        'physical_authorization_received':False,'physical_executable':pin(builds[0]['exe_path']),
        'second_clean_executable':pin(builds[1]['exe_path']),
        'canonical_manifests':[pin(ROOT/n/'REPRODUCIBLE_MANIFEST.json') for n in ('build_a','build_b')],
        'review_contract':pin(contract_path),'fixed_upload_manifest':contract['fixed_upload_manifest'],
        'retained_offline_identity_qualification':contract['offline_identity_qualification'],
        'kernel_image_sha256':EXPECTED_IMAGE,'payload_bytes':1808,'chunks':15,'maximum_requests':24,
        'start_requests':1,'entry':'FFFF3004','start_frame':contract['start_frame'],'start_ack':contract['start_ack'],
        'identity_requests':1,'identity_request':contract['identity_request'],'identity_reply':contract['identity_reply'],
        'identity_ascii':contract['identity_ascii'],'identity_query_scope_authorization':contract['identity_query_scope'],
        'test_report':latest['report'],'native_cases_passed':386,'native_cases_total':386,
        'additional_mocked_launcher_checks':36,'additional_mocked_recovery_checks':14,'result_validator_checks':46,
        'independent_reviews':[pin(p) for p in REVIEWS],'source_snapshot':pin(qdir/'SOURCE_SNAPSHOT.zip'),
        'files':files,'physical_operations_during_qualification':0,'provider_loads_during_qualification':0,
        'kernel_start_allowed':True,'kernel_execution_allowed':'FIXED_ENTRY_IDENTITY_ONLY_AFTER_EXACT_AUTHORIZATION',
        'second_start_allowed':False,'ROM_read_allowed':False,'flash_operations_allowed':False,
        'sixteenth_transfer_allowed':False,'arbitrary_payload_or_address_allowed':False,'automatic_retry_allowed':False,
        'next_scope_after_physical_pass_and_OEM_return':'OFFLINE_ONLY_RK03_BOUNDED_ROM_READ',
        'limitations':['Offline fake and reused instruction replay do not establish physical kernel execution or silicon timing.',
          'Baud SET status and returned argument integrity are verified; effective electrical baud is not measured.',
          'The preserved kernel has a read implementation, but this host cannot transmit a read request.',
          'Exact complete identity ends reception; separately queued trailing records are not inspected.',
          'Fresh IGNITION OFF, TEST MODE ON and the exact physical token remain required.']}
    save(qdir/'QUALIFICATION.json',cert);cert_pin=pin(qdir/'QUALIFICATION.json')
    text=['# RK03 physical kernel start and identity: qualified, not executed','',
        f'Branch `{cert["branch"]}`; commit `{cert["commit"]}`.','',
        '386/386 native offline cases passed, with36 launcher,14 recovery and46 result-validator checks. Independent reviews passed. No hardware was opened.','',
        f'Executable SHA256: `{EXPECTED_EXE}`.',f'Certificate SHA256: `{cert_pin["sha256"]}`.',
        f'Both canonical build manifests SHA256: `{cert["canonical_manifests"][0]["sha256"]}`.',
        f'Unchanged1808-byte kernel SHA256: `{EXPECTED_IMAGE}`.','',
        'Maximum sequence: retained transport/session setup and15 fixed upload chunks, one start atFFFF3004, exact startACK, stop OEM filter,62500-baud SET, fixedBEEF filter, one approved identity query, exactA2WC511R-RK02 withNUL, cleanup.24 transmissions maximum.','',
        'No ROM-read, flash, arbitrary memory access/input, second start or retry path is present in this host. The fixed identity query is expressly authorized but physical execution is not yet authorized.','',
        'Next human state: IGNITION OFF. Then TEST MODE ON. Before the exact new software authorization token, display release pins and check competing clients.','',
        'After one physical invocation, require IGNITION OFF then NORMAL MODE ON and passive BF/A8 OEM return. Only after identityPASS and OEM-returnPASS may RK03_BOUNDED_ROM_READ be prepared offline.']
    with (OUT/'PHYSICAL_RELEASE_QUALIFICATION.md').open('x',encoding='utf-8') as f: f.write('\n'.join(text)+'\n')
    historical=[]
    for directory in [OUT/'control_review_revision1',OUT/'inherited_control_reference',ROOT/'draft_build_a_contract_v1']:
        historical.extend(pin(p) for p in all_files(directory))
    historical.extend(pin(OUT/n) for n in ['DRAFT_CONTRACT_V1.json','RESULT_VALIDATOR_TESTS_V1_43_CASES.json','STATE_BEFORE_PHYSICAL_IDENTITY_WORK.json'])
    save(qdir/'PRESERVATION_MANIFEST.json',{'status':'SEALED_PHYSICAL_IDENTITY_RELEASE_NOT_EXECUTED','qualification':cert_pin,
        'files':files+[pin(qdir/'SOURCE_SNAPSHOT.zip'),pin(OUT/'PHYSICAL_RELEASE_QUALIFICATION.md')],
        'historical_superseded_drafts_preserved_not_current_qualification':historical,'physical_operations':0})
    verify(files);verify(cert)
    for directory in [ROOT/'build_a',ROOT/'build_b',ROOT/'reports',qdir,OUT/'independent_review',OUT/'root_review']:
        for p in all_files(directory): p.chmod(stat.S_IREAD)
    for p in [OUT/n for n in CONTROLS]+[OUT/n for n,_ in TESTS]+[contract_path,OUT/'IDENTITY_QUERY_SCOPE_AUTHORIZATION.json',OUT/'PHYSICAL_RELEASE_QUALIFICATION.md']:
        p.chmod(stat.S_IREAD)
    gates={'schema':1,'session_id':cert['session_id'],'qualification_sha256':cert_pin['sha256'],
        'status':'WAIT_IGNITION_OFF','next_gate':'IGNITION OFF','physical_state':'NOT_RECONFIRMED_FOR_NEW_SESSION',
        'engine':'NOT_RECONFIRMED','probe_invocation_count':0,'launch_reserved':False,'commit_authorization':None,
        'completed_pre_probe_gates':[],'completed_recovery_gates':[],'operator_managed_physical_context':True,
        'full_acquisition_allowed':False,'kernel_start_allowed':True,'retry_allowed':False,'abort_requested':False,
        'passive_oem_return_invocations':0,'updated_utc':cert['utc']}
    save(OUT/'IDENTITY_GATE_STATE.json',gates)
    state=read(STATE)
    save(OUT/'STATE_BEFORE_RELEASE_SEAL.json',state)
    state.update(phase='RK03_IDENTITY_PHYSICAL_QUALIFIED_WAIT_IGNITION_OFF',
        active_objective='One separately qualified physical fixed kernel start and identity exchange, then passive OEM return',
        new_user_scope='RK03_KERNEL_START_IDENTITY_ONLY_PHYSICAL; one fixed start and approved fixed identity query; no ROM read or flash; fresh human gates required',
        identity_query_scope='EXPLICITLY_AUTHORIZED_BY_USER_YES',
        identity_physical_status='QUALIFIED_NOT_AUTHORIZED_NOT_RUN',kernel_identity_physical_status='QUALIFIED_NOT_AUTHORIZED_NOT_RUN',
        identity_physical_qualification=cert_pin,identity_physical_commit=cert['commit'],
        identity_physical_executable_sha256=EXPECTED_EXE,identity_physical_gate_state=str(OUT/'IDENTITY_GATE_STATE.json'),
        identity_physical_invocations=0,identity_physical_authorization_received=False,
        human_required=['IGNITION OFF'],human_action_required=True,
        next_action='Await fresh IGNITION OFF, then TEST MODE ON, then exact PROCEED RK03 KERNEL START IDENTITY',
        further_physical_activity_allowed=False,updated_utc=cert['utc'])
    STATE.write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8')
    checkpoint=read(OUT/'CHECKPOINT.json');save(OUT/'CHECKPOINT_BEFORE_RELEASE_SEAL.json',checkpoint)
    checkpoint.update(status='SEALED_PHYSICAL_IDENTITY_RELEASE_WAIT_IGNITION_OFF',physical_invocations=0,provider_loaded=False,
        blocking_conflict=None,completed=['Fixed identity query explicitly approved','Native release integrated',
        'Two identical clean builds','386 native qualification cases passed','36/14/46 control checks passed',
        'Independent source/control/seal review and independent root runner audit passed','Source committed and release sealed'],
        not_completed=['Fresh human ignition gates','Exact physical execution token','One physical identity run','Passive OEM return'],
        qualification=cert_pin,source_commit=cert['commit'],updated_utc=cert['utc'])
    (OUT/'CHECKPOINT.json').write_text(json.dumps(checkpoint,indent=2)+'\n',encoding='utf-8')
    require(not git('status','--porcelain'),'Sealing changed tracked source')
    print(json.dumps({'status':cert['status'],'qualification':cert_pin,'executable':cert['physical_executable'],
        'canonical_manifest':cert['canonical_manifests'][0],'files_pinned':len(files),'next_gate':'IGNITION OFF'}))
if __name__=='__main__': main()
