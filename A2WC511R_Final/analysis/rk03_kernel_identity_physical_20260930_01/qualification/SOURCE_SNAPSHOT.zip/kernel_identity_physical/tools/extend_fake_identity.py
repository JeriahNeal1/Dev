"""Extend only the statically linked offline fixture backend. No PE invocation."""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
BASE=Path(r'C:\Dev\A2WC511R_RK03_FullUploadPhysical\full_upload_physical\src\fake_backend.hpp')
LOG=Path(r'C:\Dev\A2WC511R_RK03_FullUploadPhysical\physical_session\RK03_FULL_UPLOAD_NO_START_01\native_api.jsonl')
def one(t,a,b):
 assert t.count(a)==1,a
 return t.replace(a,b)
def main():
 r=[json.loads(x) for x in LOG.read_text().splitlines()];r=[x for x in r if x['type']=='api_return']
 rx=[x['output']['message'] for x in r if x['function']=='PassThruReadMsgs'];assert len(rx)==44
 tx=[x['input']['message']['data_hex'] for x in r if x['function']=='PassThruWriteMsgs'];assert len(tx)==22
 version=next(x['output'] for x in r if x['function']=='PassThruReadVersion')
 lines=['#pragma once','// Immutable successful physical full-upload receive transcript; fake use only.']
 for key in ['firmware','dll','api']:lines.append('static constexpr const char* FULL_VERSION_'+key.upper()+'="'+version[key]['raw_buffer_hex']+'";')
 lines += ['static constexpr const char* FULL_PHYSICAL_KEY_TX="'+tx[4]+'";', 'inline PASSTHRU_MSG full_physical_replay_message(unsigned i){PASSTHRU_MSG m{};switch(i){']
 for i,m in enumerate(rx):lines.append(f'case {i}:set_message(m,decode("{m["data_hex"]}"));m.ProtocolID={m["protocol"]};m.RxStatus={m["rx_status"]};m.TxFlags={m["tx_flags"]};m.Timestamp={m["timestamp"]}UL;m.ExtraDataIndex={m["extra_data_index"]};break;')
 lines += ['default:require(false,"Fixed full physical replay index");}return m;}']
 (ROOT/'src/full_physical_replay.hpp').write_text('\n'.join(lines)+'\n')
 positive=['physical_full_upload_replay','identity_fragmented','identity_indicators_fragmented']+[f'identity_split_{n}' for n in range(1,20)]
 negative=[f'{prefix}_{n}' for prefix in ['bad_ack','negative_ack','bad_checksum','status16','truncated','short_ack','extra_ack','write_fail','write_count_zero','write_count_large','write_mutation'] for n in [22,23]]
 negative+=['transition_stop_fail','kernel_baud_fail','kernel_baud_mutation','kernel_filter_fail','kernel_filter_mutation','start_late_reply']
 negative+=['identity_'+s for s in ['wrong_identity','wrong_version','missing_nul','bad_length','zero_length','oversized_length','trailing','double_frame','wrong_header','negative_reply','empty','protocol','flags','extra_index','indicator_flood','indicator_after_data','wrong_echo','nonempty_indicator','combined_status','unknown_status','count_zero','count_large','read_error','no_reply','late_reply']]
 t=BASE.read_text().replace('#include "first_physical_replay.hpp"','#include "first_physical_replay.hpp"\n#include "full_physical_replay.hpp"')
 t=one(t,'static const char* CASES[]={','static const char* CASES[]={\n '+','.join('"'+x+'"' for x in positive+negative)+',')
 t=one(t,'bool baud=false;bool got=false,filtered=false;','bool baud=false,kernel_baud=false,kernel_filtered=false,old_filter_stopped=false;U active_filter=0;bool got=false,filtered=false;')
 t=one(t,'if(is("version_unterminated"))','if(is("physical_full_upload_replay")){auto f=decode(FULL_VERSION_FIRMWARE),d=decode(FULL_VERSION_DLL),a=decode(FULL_VERSION_API);memcpy(fw,f.data(),80);memcpy(dll,d.data(),80);memcpy(api,a.data(),80);}if(is("version_unterminated"))')
 old='if(s.writes!=6||s.waits!=2||s.virtual_now!=300||list->ConfigPtr[0].Value!=15625)return 7;'
 new='if(list->ConfigPtr[0].Value==62500){if(s.writes!=23||!s.old_filter_stopped||s.filtered||s.waits!=3||s.virtual_now!=500)return 7;if(is("kernel_baud_fail"))return 7;s.kernel_baud=true;if(is("kernel_baud_mutation"))list->ConfigPtr[0].Value=62501;return 0;}'+old
 t=one(t,old,new)
 t=one(t,'if(channel!=701||type!=1||!state().got||!zero_filter(mask)',
  'if(state().writes==23){auto& s=state();if(channel!=701||type!=1||!s.kernel_baud||!s.old_filter_stopped||s.filtered||!mask||!pattern||flow||!id)return 7;PASSTHRU_MSG em{},ep{};set_message(em,{0xff,0xff});set_message(ep,{0xbe,0xef});if(memcmp(mask,&em,sizeof(em))||memcmp(pattern,&ep,sizeof(ep)))return 7;if(is("kernel_filter_fail"))return 7;*id=703;s.active_filter=703;s.filtered=true;s.kernel_filtered=true;if(is("kernel_filter_mutation"))const_cast<PASSTHRU_MSG*>(static_cast<const PASSTHRU_MSG*>(pattern))->Data[0]^=1;return 0;}\n if(channel!=701||type!=1||!state().got||!zero_filter(mask)')
 t=one(t,'*id=702;state().filtered=true;','*id=702;state().active_filter=702;state().filtered=true;')
 start=t.index('inline long PT_CALL stop_filter(');end=t.index('\ninline PASSTHRU_MSG message',start)
 t=t[:start]+'''inline long PT_CALL stop_filter(U channel,U id){auto& s=state();if(channel!=701||!s.filtered||id!=s.active_filter)return 7;
 if(id==702&&s.writes==23&&is("transition_stop_fail"))return 7;
 if(is("physical_83_cleanup_all_fail")||(id==703&&(is("cleanup_stop_fail")||is("cleanup_all_fail"))))return 7;
 s.filtered=false;if(id==702&&s.writes==23)s.old_filter_stopped=true;return 0;}
'''+t[end:]
 t=t.replace('s.writes>=22','s.writes>=24')
 t=one(t,'auto tx=decode(EXPECTED_TX[s.writes]);','auto tx=s.writes<22?decode(EXPECTED_TX[s.writes]):decode(s.writes==22?"8010f003310101b6":"beef000101af");')
 t=one(t,'if(m->ProtocolID!=3||m->RxStatus','if(s.writes==4&&is("physical_full_upload_replay"))tx=decode(FULL_PHYSICAL_KEY_TX);if(m->ProtocolID!=3||m->RxStatus')
 t=one(t,'unsigned stage=s.writes++;','if(s.writes==23&&(!s.kernel_baud||!s.kernel_filtered||s.active_filter!=703))return 7;\n unsigned stage=s.writes++;')
 t=one(t,'if(stage<8&&is("physical_first_chunk_replay"))','if(stage<22&&is("physical_full_upload_replay")){s.queue.push_back(full_physical_replay_message(stage*2));s.queue.push_back(full_physical_replay_message(stage*2+1));return 0;}\n if(stage<8&&is("physical_first_chunk_replay"))')
 t=one(t,'Bytes b=decode(REPLY_HEX[stage]);','Bytes b=stage<22?decode(REPLY_HEX[stage]):decode(stage==22?"80f01003710101f6":"beef000f8141325743353131522d524b3032005f");')
 extra=r'''
 if(stage==23){
  if(is("identity_no_reply"))return 0;
  if(is("identity_wrong_identity")){b[5]^=1;b.back()=checksum(Bytes(b.begin(),b.end()-1));}
  if(is("identity_wrong_version")){b[17]^=1;b.back()=checksum(Bytes(b.begin(),b.end()-1));}
  if(is("identity_missing_nul")){b[18]=1;b.back()=checksum(Bytes(b.begin(),b.end()-1));}
  if(is("identity_bad_length"))b[3]=14;if(is("identity_zero_length"))b[3]=0;if(is("identity_oversized_length"))b[2]=1;
  if(is("identity_trailing"))b.push_back(0);if(is("identity_double_frame")){auto copy=b;b.insert(b.end(),copy.begin(),copy.end());}
  if(is("identity_wrong_header"))b[0]=0xbf;if(is("identity_negative_reply")){b[4]=0x7f;b.back()=checksum(Bytes(b.begin(),b.end()-1));}
  if(is("identity_indicator_flood")){for(unsigned i=0;i<5;i++)s.queue.push_back(message({},START_OF_MESSAGE));return 0;}
  if(is("identity_indicator_after_data")){s.queue.push_back(message({b[0]}));s.queue.push_back(message({},START_OF_MESSAGE));return 0;}
  if(is("identity_indicators_fragmented")){s.queue.push_back(message({},START_OF_MESSAGE));s.queue.push_back(message({},TX_DONE));s.queue.push_back(message(tx,TX_MSG_TYPE));s.queue.push_back(message(tx,TX_MSG_TYPE|TX_DONE));}
  if(is("identity_fragmented")||is("identity_indicators_fragmented")){for(auto byte:b)s.queue.push_back(message({byte}));return 0;}
  for(unsigned split=1;split<20;split++)if(index("identity_split_",split)){s.queue.push_back(message(Bytes(b.begin(),b.begin()+split)));s.queue.push_back(message(Bytes(b.begin()+split,b.end())));return 0;}
  if(state().name.rfind("identity_",0)==0){auto rx=message(b);
   if(is("identity_empty"))rx.DataSize=0;if(is("identity_protocol"))rx.ProtocolID=4;if(is("identity_flags"))rx.TxFlags=1;if(is("identity_extra_index"))rx.ExtraDataIndex=1;
   if(is("identity_wrong_echo")){rx=message(tx,TX_MSG_TYPE);rx.Data[0]^=1;}
   if(is("identity_nonempty_indicator"))rx.RxStatus=START_OF_MESSAGE;if(is("identity_combined_status"))rx.RxStatus=3;if(is("identity_unknown_status"))rx.RxStatus=0x100;
   s.queue.push_back(rx);return 0;
  }
 }
'''
 t=one(t,'if(stage==7&&is("upload_unknown_status"))',extra+'\n if(stage==7&&is("upload_unknown_status"))')
 t=one(t,'if(s.queue.empty()){*count=0;return 16;}','if(s.queue.empty()){*count=0;return 16;}if((s.writes==23&&is("start_late_reply"))||(s.writes==24&&is("identity_late_reply")))Sleep(2100);')
 t=one(t,'if(is("read_count_zero"))*count=0;','if(is("read_count_zero")||(s.writes==24&&is("identity_count_zero")))*count=0;')
 t=one(t,'if(is("read_count_large"))*count=2;','if(is("read_count_large")||(s.writes==24&&is("identity_count_large")))*count=2;')
 t=one(t,'return is("read_error_output")?16:0;','return is("read_error_output")||(s.writes==24&&is("identity_read_error"))?16:0;')
 (ROOT/'src/fake_backend.hpp').write_text(t,newline='\n')
 out={'new_positive_fixtures':positive,'new_negative_fixtures':negative,'physical_full_upload_log':{'path':str(LOG),'sha256':hashlib.sha256(LOG.read_bytes()).hexdigest()},'status':'FIXTURES_ONLY_NOT_EXECUTED'}
 (ROOT/'fixtures/identity_fixture_contract.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps({'new_positive':len(positive),'new_negative':len(negative),'total_new':len(positive+negative)}))
if __name__=='__main__':main()
