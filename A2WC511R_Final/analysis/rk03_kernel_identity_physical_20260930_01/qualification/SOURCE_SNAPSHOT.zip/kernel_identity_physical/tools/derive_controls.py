"""Create new release/recovery controls without executing any of them."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OLD=Path(r'C:\Dev\A2WC511R_RK03_FullUploadPhysical\full_upload_physical\release_controls')
OUT=Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_kernel_identity_physical_20260930_01')
NAMES={'launch_full_upload_once.py':'launch_identity_once.py','seal_full_upload_result.py':'seal_identity_result.py','seal_oem_return_full_upload.py':'seal_oem_return_identity.py'}
REPLACE=[('launch_full_upload_once','launch_identity_once'),('seal_full_upload_result','seal_identity_result'),('seal_oem_return_full_upload','seal_oem_return_identity'),
 ('A2WC511R_RK03_FullUploadPhysical','A2WC511R_RK03_KernelIdentityPhysical'),('rk03_full_upload_physical_20260930_01','rk03_kernel_identity_physical_20260930_01'),
 ('full_upload_physical/build_a/rk03_full_upload_no_start_physical32.exe','kernel_identity_physical/build_a/rk03_kernel_start_identity_physical32.exe'),
 ('PHYSICAL_FULL_UPLOAD_REVIEW_CONTRACT.json','PHYSICAL_IDENTITY_REVIEW_CONTRACT.json'),('FULL_UPLOAD_GATE_STATE.json','IDENTITY_GATE_STATE.json'),
 ('PROCEED RK03 FULL UPLOAD NO START','PROCEED RK03 KERNEL START IDENTITY'),('RK03_FULL_UPLOAD_NO_START_01','RK03_KERNEL_START_IDENTITY_01'),
 ('PASS_OFFLINE_QUALIFIED_PHYSICAL_FULL_UPLOAD_NO_START_ONLY','PASS_OFFLINE_QUALIFIED_PHYSICAL_KERNEL_START_IDENTITY_ONLY'),
 ('AUTHORIZED_FULL_UPLOAD_NO_START_ONLY','AUTHORIZED_KERNEL_START_IDENTITY_ONLY'),('--physical-full-upload-no-start','--physical-kernel-start-identity'),
 ('RK03_FULL_UPLOAD_NO_START','RK03_KERNEL_START_IDENTITY'),('OEM_RETURN_AFTER_FULL_UPLOAD_NO_START','OEM_RETURN_AFTER_KERNEL_START_IDENTITY'),
 ('PASS_OFFLINE_FULL_KERNEL_UPLOAD_NO_START_ONLY','PASS_OFFLINE_KERNEL_START_IDENTITY_ONLY'),('PASS_FULL_UPLOAD_NO_START_ONLY','PASS_KERNEL_START_IDENTITY_ONLY'),
 ('full_upload_start','kernel_identity_start'),('full_upload_physical','identity_physical'),('full_upload_kernel_started','identity_kernel_started'),
 ('full_upload_ROM_read','identity_ROM_read'),('full_upload_flash_operation','identity_flash_operation'),('oem_return_after_full_upload_01','oem_return_after_identity_01'),
 ('full-upload/no-start','kernel-start/identity'),('full_upload_no_start','kernel_start_identity')]
def one(t,a,b):
 assert t.count(a)==1,a
 return t.replace(a,b)
def main():
 for src in OLD.iterdir():
  if not src.is_file():continue
  name=NAMES.get(src.name,src.name);t=src.read_text()
  for a,b in REPLACE:t=t.replace(a,b)
  t=t.replace("/identity_physical')","/kernel_identity_physical')").replace("/identity_physical'","/kernel_identity_physical'")
  if name=='check_clients.ps1':t=t.replace('rk03_kernel_start_identity_physical32','rk03_full_upload_no_start_physical32|rk03_kernel_start_identity_physical32')
  if name=='seal_identity_result.py':
   t=t.replace('len(tx)==22','len(tx)==24').replace('exactly22','exactly24').replace('stage<21','stage<23')
   old="require(len(data)>=6 and data[:3]==bytes.fromhex('80f010') and len(data)==data[3]+5 and sum(data[:-1])&255==data[-1],'Reply framing/checksum stage'+str(stage))"
   new="require(len(data)>=6 and sum(data[:-1])&255==data[-1],'Reply checksum stage'+str(stage))\n        if stage==23:require(len(data)==20 and data[:4]==bytes.fromhex('beef000f'),'Exact identity frame length/marker')\n        else:require(data[:3]==bytes.fromhex('80f010') and len(data)==data[3]+5,'SSM reply framing stage'+str(stage))"
   t=one(t,old,new)
   t=one(t,"wanted += [('PassThruWriteMsgs',t['input']['message']['data_hex']) for t in tx[6:]]","wanted += [('PassThruWriteMsgs',t['input']['message']['data_hex']) for t in tx[6:23]]\n    wanted += [('PassThruStopMsgFilter',),('PassThruIoctl',2,((1,62500),)),('PassThruStartMsgFilter',),('PassThruWriteMsgs',tx[23]['input']['message']['data_hex'])]")
   t=t.replace("require(len(filters)==1 and filters[0]['state']['filter']['returned_objects_valid'],'Broad filter validated')","require(len(filters)==2 and all(f['state']['filter']['returned_objects_valid'] for f in filters),'Both filters validated')")
   old="require(returns[-3]['input']['filter_id']==filt['output']['filter_id'] and returns[-3]['input']['filter_id_present'] is True,'Cleanup filter identifier')"
   new="""kernel_filter=filters[1];require(kernel_filter['input']['filter_type']==1 and kernel_filter['input']['flow_present'] is False and kernel_filter['input']['flow'] is None and kernel_filter['output']['flow'] is None,'Identity null flow filter')
    for key,value in [('mask','ffff'),('pattern','beef')]:
        msg=kernel_filter['input'][key];require(msg==kernel_filter['output'][key] and msg['protocol']==3 and msg['rx_status']==msg['tx_flags']==msg['timestamp']==msg['extra_data_index']==0 and msg['data_size']==2 and msg['data_hex']==value,'Fixed BEEF filter object')
    stops=[r for r in returns if r['function']=='PassThruStopMsgFilter'];require(len(stops)==2 and stops[0]['input']['filter_id']==filt['output']['filter_id'] and stops[1]['input']['filter_id']==kernel_filter['output']['filter_id'],'Owned filter identifiers')
    require(returns[-3]['input']['filter_id_present'] is True,'Cleanup filter argument')
    require(tx[22]['state']['acknowledged_chunks']==15 and tx[23]['state']['start_acknowledged'] and tx[23]['state']['kernel_filter'] and tx[23]['state']['requested_baud']==62500,'Start/identity state boundary')"""
   t=one(t,old,new)
   t=t.replace("terminal['state']['tx_attempts']==22","terminal['state']['tx_attempts']==24 and terminal['state']['identity_validated'] and terminal['state']['acknowledged_chunks']==15")
   t=t.replace("'tx_count':22","'tx_count':24").replace("'kernel_start_requests':0","'kernel_start_requests':1,'identity_requests':1,'entry':'FFFF3004','identity_ascii':'A2WC511R-RK02\\0'")
   t=t.replace("'kernel_start_allowed':False","'additional_kernel_start_allowed':False")
   t=t.replace('identity_kernel_started=False','identity_kernel_started=True if validation else "UNCONFIRMED"')
   t=t.replace("'filter':filters[0]['input']","'filter':filters[0]['input'],'identity_filter':filters[1]['input']")
   t=t.replace('SEALED_PHYSICAL_FULL_UPLOAD_','SEALED_PHYSICAL_KERNEL_START_IDENTITY_')
   t=one(t,"end=tx[stage+1]['sequence'] if stage<23 else 10**9","end=min(r['sequence'] for r in returns if r['sequence']>t['sequence'] and r['function']!='PassThruReadMsgs')")
   t=one(t,"data=bytearray();indicators=0","require(received,'Reply must precede any following control action')\n        require(received[-1]['qpc_after']-received[0]['qpc_before']<2*received[0]['qpc_frequency'],'Complete reply exceeds2000ms observation window')\n        data=bytearray();indicators=0")
   t=one(t,"require(len(intents)==len(returns),'Incomplete API journal')","require(len(intents)==len(returns),'Incomplete API journal')\n    require(len(rows)==2*len(returns)+2 and [r['type'] for r in rows[1:-1]]==['api_intent','api_return']*len(returns),'Exact API intent/return ordering; no unaccounted events')")
  if name=='seal_oem_return_identity.py':
   for a,b in [('RK03_FULL_UPLOAD_EXITED_OEM_RETURN_PASS_OFFLINE_ONLY','RK03_IDENTITY_EXITED_OEM_RETURN_PASS_OFFLINE_ONLY'),('full_upload_oem_return_result','identity_oem_return_result'),('oem_return_after_full_upload','oem_return_after_identity'),('RK03_KERNEL_START_IDENTITY_ONLY','RK03_BOUNDED_ROM_READ'),('Recorded physical upload outcome','Recorded physical identity outcome'),('upload_physical_result','identity_physical_result'),('If the upload passed','If identity passed'),('after a failed upload','after a failed identity stage')]:t=t.replace(a,b)
  if name=='test_result_validator.py':
   t=t.replace("\\identity_physical'","\\kernel_identity_physical'")
   # Additional mutations exercise the newly allowed suffix and disallowed second start/read.
   t=one(t,"reject('reject_cleanup_failure'", "reject('reject_second_start_at_identity',lambda r:replace_tx(r,23,'8010f003310101b6'))\nreject('reject_ROM_command_at_identity',lambda r:replace_tx(r,23,'beef000103b1'))\nreject('reject_wrong_fixed_start',lambda r:replace_tx(r,22,'8010f003310102b7'))\nreject('reject_wrong_identity_response',lambda r:bad_ack(r,23))\nreject('reject_wrong_start_ACK',lambda r:bad_ack(r,22))\nreject('reject_cleanup_failure'")
   tests=r'''
def delayed_reply(rows,stage):
    tx=[r for r in rows if r.get('type')=='api_return' and r.get('function')=='PassThruWriteMsgs'][stage]
    rx=next(r for r in rows if r.get('type')=='api_return' and r.get('function')=='PassThruReadMsgs' and r['sequence']>tx['sequence'])
    rx['qpc_after']=rx['qpc_before']+3*rx['qpc_frequency'];rx['api_elapsed_ticks']=rx['qpc_after']-rx['qpc_before']
reject('reject_late_start_ACK',lambda r:delayed_reply(r,22))
reject('reject_late_identity',lambda r:delayed_reply(r,23))
def reordered_start_ACK(rows):
    tx=[r for r in rows if r.get('type')=='api_return' and r.get('function')=='PassThruWriteMsgs'][22]
    ackseq=next(r['sequence'] for r in rows if r.get('type')=='api_return' and r.get('function')=='PassThruReadMsgs' and r['sequence']>tx['sequence'])
    stopseq=next(r['sequence'] for r in rows if r.get('type')=='api_return' and r.get('function')=='PassThruStopMsgFilter')
    ack=[r for r in rows if r.get('sequence')==ackseq];stop=[r for r in rows if r.get('sequence')==stopseq]
    for r in ack:r['sequence']=stopseq
    for r in stop:r['sequence']=ackseq
    middle=sorted(rows[1:-1],key=lambda r:(r['sequence'],0 if r['type']=='api_intent' else 1));rows[1:-1]=middle
reject('reject_start_ACK_after_filter_stop',reordered_start_ACK)
'''
   t=one(t,"bindings={'session_id'",tests+"\nbindings={'session_id'")
  for dest in (ROOT/'release_controls'/name,OUT/name):dest.write_text(t,encoding='utf-8',newline='\n')
 print('New controls written, not executed.')
if __name__=='__main__':main()
