# RK03 kernel start and identity: separate physical release

This release extends the physically successful full-upload/no-start host with
one fixed start and the fixed identity query authorized by the operator. Its
maximum is 24 transmissions. The unchanged 1,808-byte kernel is SHA256
`3a65d6f0700bae394a24ba9f552d03500b7f66e6344ec57613f10bfd360d8581`.

The retained setup, five serial SET values/readback, broad filter, BF/81/83,
seed/key, 200/100/200 ms waits, 15625-baud transition, TX/RX clears, one34 and
15 fixed36 transfers are followed by:

1. Start `8010f003310101b6`, whose reviewed OEM implementation enters `FFFF3004`.
2. Exact start ACK `80f01003710101f6`.
3. Stop the OEM filter once; checked SET_CONFIG to62500; BEEF pass filter
   (mask `ffff`, pattern `beef`, null flow-control pointer).
4. One identity request `beef000101af`.
5. Exact reply `beef000f8141325743353131522d524b3032005f`, containing
   `A2WC511R-RK02\0`, then filter/channel/provider cleanup.

There is no sixteenth chunk, second start, arbitrary address/payload interface,
ROM-read request, flash operation or automatic retry in this host. The preserved
kernel itself retains its earlier read implementation; the host cannot select it.
The identity is not unsolicited: the fixed query is required by the reviewed
instruction model and was expressly approved by the operator.

The two clean executable builds match SHA256
`623dc766ca69a97b16f7beabc9acb909a1225eabb8a21c40fe8379b4f72b593f`.
The same executable passed386/386 offline cases:311 retained cases on the new
executable and75 new suffix cases. Controls passed36 launcher,14 recovery and46
result-validation checks. Source and controls were independently reviewed;
root independently audited the reviewer-authored runner and raw journals.

The new response validator rejects late valid replies after API return, in
addition to checking the deadline before entry. The result verifier also rejects
ACKs recorded after intervening control calls. Failed old-filter removal is
recorded as unconfirmed cleanup and is not retried; disconnect/close are attempted.

Qualification uses static fake/bootstrap modes. It makes no physical entry,
effective electrical baud or silicon-timing claim. Reused instruction replay
provides the start-to-entry and entry-to-identity evidence without changing or
rebuilding the kernel. Coalesced trailing reply data is rejected; no extra receive
is sent to attest absence of separately queued records after a complete reply.

Canonical operational controls and the sealed certificate are under
`C:\Dev\A2WC511R_Final\analysis\rk03_kernel_identity_physical_20260930_01`.
The copies in `release_controls` are source snapshots, not invocation locations.

Fresh gates must be `IGNITION OFF`, then `TEST MODE ON`, followed by exactly
`PROCEED RK03 KERNEL START IDENTITY`. The earlier approval of the fixed identity
query is not the physical execution token. Run once, then `IGNITION OFF`,
`NORMAL MODE ON`, passive BF/A8 recovery, and offline work only.

Only after physical identity PASS and OEM-return PASS may the next offline
milestone, RK03_BOUNDED_ROM_READ, be prepared. It is not included in this release.
