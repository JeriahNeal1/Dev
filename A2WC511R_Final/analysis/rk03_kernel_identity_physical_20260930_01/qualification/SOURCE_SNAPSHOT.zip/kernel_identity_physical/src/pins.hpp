#pragma once
static constexpr const char* CONTRACT_SHA="5f2b1e263d98bc1a4a957770ea8e3c214a6ffb5a6798caf7aba79bcc5ecfe167";
static constexpr const char* PROVIDER_SHA="f432084801762d919a3c31974616e097562424470003edc4f4fb843df34103cf";
static constexpr const char* SESSION_ID="RK03_KERNEL_START_IDENTITY_01";
static constexpr const char* AUTH_TOKEN="PROCEED RK03 KERNEL START IDENTITY";
static constexpr const wchar_t* CONTRACT_PATH=L"C:\\Dev\\A2WC511R_Final\\analysis\\rk03_kernel_identity_physical_20260930_01\\PHYSICAL_IDENTITY_REVIEW_CONTRACT.json";
static constexpr const wchar_t* PROVIDER_PATH=L"C:\\Windows\\SysWOW64\\op20pt32.dll";
static constexpr const wchar_t* SESSION_PATH=L"C:\\Dev\\A2WC511R_RK03_KernelIdentityPhysical\\physical_session\\RK03_KERNEL_START_IDENTITY_01";
