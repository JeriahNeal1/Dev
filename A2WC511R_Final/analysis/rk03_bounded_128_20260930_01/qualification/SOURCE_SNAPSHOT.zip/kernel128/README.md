# Fixed128 temporary RAM kernel

This separately built variant accepts only128-byte, strictly sequential ROM requests after identity. It retains the prior1808-byte image extent, entry `FFFF3004`, memory layout, identity string, two-pass limit, and peripheral setup. It does not write ROM or flash.

The kernel changes are two request-length instruction words, the block-size literal128, the response-body literal134, and the regenerated loader checksum word `00006B15`. The manifest generator reports the new sizes. The original512-byte kernel remains unchanged.

Clean builds `build/a` and `build/b` have identical binary and ELF bytes. Kernel SHA256 is `808a5523d47de11881bfc2ea06a35278aedb5122ed51e8110f817b3210adb653`; ELF SHA256 is `2198d4fea8c0b6054712c32a2c553c87be8b9fdcbf2cfb5f2c330b3c21f7358f`.

The unchanged SH-2E instruction model passed17 new cases: first128-byte reply from poisoned and retained OEM entry registers, contiguous reads, invalid length/address/pass/checksum and missing-identity rejection, plus explicitly injected final-block states for pass wrap and completion. Those boundary fixtures do not represent full acquisition. Full traces and coverage are retained under `C:\Dev\A2WC511R_Final\analysis\rk03_bounded_128_20260930_01\kernel_review`.

This source and its instruction tests were authored by `passive_review`; root independently reviews them. The separately qualified native host owns physical controls. These builds and tests grant no physical authorization and do not prove a fix for the earlier incomplete512-byte response. The unchanged identity text alone does not distinguish kernel variants; use the pinned kernel and executable hashes.
