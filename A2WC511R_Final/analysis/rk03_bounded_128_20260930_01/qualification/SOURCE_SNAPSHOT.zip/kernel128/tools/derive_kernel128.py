"""Create only the new fixed128 kernel sources from immutable known parent inputs."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
OLD=Path(r'C:\Dev\A2WC511R_ReadKernel')
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def one(t,a,b):
 if t.count(a)!=1:raise ValueError('Expected exactly one source segment: '+a)
 return t.replace(a,b)
source=OLD/'src/kernel.S';linker=OLD/'linker/kernel.ld';builder=OLD/'tools/build.py'
assert pin(source)['sha256']=='3d20c9227c209b6712a451ce867c032e8e8d21fd4d2776816d720e2a3fa72355'
assert pin(linker)['sha256']=='269d8b6de2edfa84afabad1080b6c7f4baefedd60bdd7ec2d75b5d7240e7dbef'
assert pin(builder)['sha256']=='f6e7219c8d7ec7d169e3b8acdddcd609da109f0d7ca83fcf6e10d13b137cd249'
text=source.read_text()
text=one(text,'mov.b @(6,r1),r0\n    cmp/eq #2,r0','mov.b @(6,r1),r0\n    cmp/eq #0,r0')
text=one(text,'mov.b @(7,r1),r0\n    tst r0,r0','mov.b @(7,r1),r0\n    cmp/eq #0x80,r0')
text=one(text,'.Lblock:       .long 512','.Lblock:       .long 128')
text=one(text,'.Lraw_length:  .long 518','.Lraw_length:  .long 134')
build=one(builder.read_text(),"'read_response_body_bytes':518,'block_bytes':512","'read_response_body_bytes':134,'block_bytes':128")
for rel,value in [('src/kernel.S',text),('tools/build.py',build)]:
 target=ROOT/rel;target.parent.mkdir(parents=True,exist_ok=True)
 with target.open('x',encoding='utf-8',newline='\n') as f:f.write(value)
(ROOT/'linker').mkdir(exist_ok=True)
with (ROOT/'linker/kernel.ld').open('xb') as f:f.write(linker.read_bytes())
pins=dict(scope='NEW_FIXED128_KERNEL_SOURCE_DERIVATION_NO_PHYSICAL_AUTHORIZATION',inputs=[pin(p) for p in [source,linker,builder,OLD/'build/rk02_01/kernel.bin',OLD/'build/rk02_01/manifest.json']],outputs=[pin(ROOT/p) for p in ['src/kernel.S','linker/kernel.ld','tools/build.py']],deriver=pin(Path(__file__)),physical_operations=0,changes=['Only raw_read length high/low comparisons and block/raw-body constants changed in kernel source.','Build manifest protocol reports134 response-body bytes and128 data bytes.','Source text line endings normalized in new copied source; prior source bytes unchanged.'])
with (ROOT/'DERIVATION.json').open('x',encoding='utf8',newline='\n') as f:json.dump(pins,f,indent=2);f.write('\n')
print(json.dumps(dict(status='DERIVED_NEW128_SOURCES_ONLY',root=str(ROOT))))
