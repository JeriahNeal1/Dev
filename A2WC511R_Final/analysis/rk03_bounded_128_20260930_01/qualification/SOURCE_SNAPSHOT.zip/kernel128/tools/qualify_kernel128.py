"""Execute only the new kernel in the unchanged SH-2E instruction model."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import datetime,hashlib,json,gzip,struct,traceback,difflib
ROOT=Path(__file__).resolve().parents[1]
OLD=Path(r'C:\Dev\A2WC511R_ReadKernel')
A=Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_bounded_128_20260930_01\kernel_review')
PRIOR=Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_kernel_identity_offline_20260930_01\instruction_review\replay_20260930T054149444398Z\INSTRUCTION_REPLAY.json')
ROM=Path(r'C:\Dev\SubaruRoms\current.bin');ROMSHA='bf10be6d7c75b4f2ae663b0d57a912e6e9ef7654ccfc985195954596e50427b2'
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def read(p):return json.loads(Path(p).read_text())
def save(p,o):
 with p.open('x',encoding='utf8',newline='\n') as f:json.dump(o,f,indent=2);f.write('\n')
def frame(body):
 b=bytes.fromhex('beef')+len(body).to_bytes(2,'big')+body;return b+bytes([sum(b)%256])
def request(address=0,length=128,passno=0):return frame(bytes([3,passno])+address.to_bytes(4,'big')+length.to_bytes(2,'big'))
def response(rom,address=0,passno=0):return frame(bytes([0x83,passno])+address.to_bytes(4,'big')+rom[address:address+128])
CHECKS=[]
def check(ok,label):
 if not ok:raise AssertionError(label)
 CHECKS.append(label)
def main():
 A.mkdir(parents=True,exist_ok=True);run=A/('run_'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'));run.mkdir()
 report=dict(status='FAIL',scope='NEW_FIXED128_KERNEL_INSTRUCTION_MODEL_ONLY',physical_operations=0,provider_loads=0,old_qualification_reruns=0,old_upload_or_start_instruction_replay=False,cases=[],full_ROM_acquisition=False,independent_reviewer='root pending',kernel_author_and_test_author='passive_review')
 try:
  ma,mb=[read(ROOT/'build'/n/'manifest.json') for n in ['a','b']];old=read(OLD/'build/rk02_01/manifest.json')
  binary=(ROOT/'build/a/kernel.bin').read_bytes();original=(OLD/'build/rk02_01/kernel.bin').read_bytes();rom=ROM.read_bytes()
  check(hashlib.sha256(rom).hexdigest()==ROMSHA,'current ROM unchanged')
  check(binary==(ROOT/'build/b/kernel.bin').read_bytes(),'two clean kernel binaries identical')
  check((ROOT/'build/a/kernel.elf').read_bytes()==(ROOT/'build/b/kernel.elf').read_bytes(),'two clean kernel ELF outputs identical')
  check(len(binary)==1808 and ma['entry']==mb['entry']==0xffff3004,'fixed size and entry')
  check(ma['kernel_sha256']==mb['kernel_sha256']==hashlib.sha256(binary).hexdigest()=='808a5523d47de11881bfc2ea06a35278aedb5122ed51e8110f817b3210adb653','new variant pin')
  check(sum(struct.unpack('>452I',binary))&65535==0x5aa5,'loader BE32 low16 sum5AA5')
  check(ma['loader_checksum']['word_value']==0x6b15,'regenerated checksum exact prediction')
  check({k:v for k,v in ma['symbols'].items() if k!='loader_checksum'}=={k:v for k,v in old['symbols'].items() if k!='loader_checksum'},'all symbol locations unchanged')
  check(ma['instruction_addresses']==old['instruction_addresses'],'same executable address whitelist')
  opcode_diff=[dict(address=f'{n["address"]:08X}',old=f'{o["opcode"]:04X}',new=f'{n["opcode"]:04X}',old_assembly=o['assembly'],new_assembly=n['assembly']) for o,n in zip(old['instructions'],ma['instructions']) if o['opcode']!=n['opcode']]
  check([(d['address'],d['old'],d['new']) for d in opcode_diff]==[('FFFF3162','8802','8800'),('FFFF3168','2008','8880')],'only two exact instruction words changed')
  expected=bytearray(original)
  for offset,value in [(0x162,'8800'),(0x168,'8880'),(0x2f4,'00000080'),(0x2f8,'00000086'),(0x70c,'00006b15')]:expected[offset:offset+len(bytes.fromhex(value))]=bytes.fromhex(value)
  check(binary==expected,'only two instructions two literals and checksum differ')
  check(ma['protocol']==dict(old['protocol'],read_response_body_bytes=134,block_bytes=128),'manifest128 contract only')
  check((ROOT/'linker/kernel.ld').read_bytes()==(OLD/'linker/kernel.ld').read_bytes(),'linker preserved')
  prior=read(PRIOR);variant=prior['kernel_identity_variants']['actual_OEM_registers'];simfiles=[OLD/'sim'/n for n in variant['model_identity']['model_sources']]
  for p in simfiles:check(pin(p)['sha256']==variant['model_identity']['model_sources'][p.name],'unchanged simulator '+p.name)
  corepath=Path(variant['model_identity']['core_path']);check(pin(corepath)['sha256']==variant['model_identity']['core_sha256'],'unchanged SH2 core')
  sys.path.insert(0,str(OLD));from sim.harness import KernelSession
  from sim.core import SimulationStop
  initial=variant['model_identity']['peripheral_initial'];initial=dict(initial,sci2={int(k,16):v for k,v in initial['sci2'].items()})
  inputs=[ROOT/'DERIVATION.json',ROOT/'src/kernel.S',ROOT/'linker/kernel.ld',ROOT/'tools/build.py',Path(__file__),PRIOR,ROM,corepath]+simfiles+[ROOT/'build'/n/p for n in ['a','b'] for p in ['kernel.bin','kernel.elf','manifest.json','kernel.disassembly.txt','kernel.sections.txt','kernel.symbols.txt']]+[OLD/'src/kernel.S',OLD/'build/rk02_01/kernel.bin',OLD/'build/rk02_01/manifest.json']
  before=[pin(p) for p in inputs];report['inputs']=before;report['binary_changes']=[dict(offset=i,old_hex=f'{a:02x}',new_hex=f'{b:02x}') for i,(a,b) in enumerate(zip(original,binary)) if a!=b];report['instruction_changes']=opcode_diff
  def new_session(name,actual=False,identity=True):
   folder=run/name;folder.mkdir();s=KernelSession(ROOT/'build/a/manifest.json',ROM,ROMSHA,trace_dir=folder/'exchanges',peripheral_initial=initial,detailed=True,optimized=False)
   if actual:
    regs=variant['entry_registers']
    for i,v in enumerate(regs['r']):s.cpu._reg(i,v,())
    s.cpu._set_system('sr',regs['SR'],());s.cpu.pr=regs['PR'];s.cpu.vbr=regs['VBR'];s.cpu.mach=regs['MACH'];s.cpu.macl=regs['MACL']
   start=s.start();check(start.status=='PASS' and start.stop_reason=='RX_WAIT' and not start.tx_bytes,name+' startup reaches empty RX')
   if identity:
    answer=s.exchange(frame(bytes([1])));check(answer.status=='PASS' and answer.tx_bytes==frame(b'\x81A2WC511R-RK02\0'),name+' identity exact')
   return s,folder
  def exchange(s,name,req,expected_reply,expected_reason='RX_WAIT'):
   begin=len(s.memory.events);result=s.exchange(req)
   check(result.tx_bytes==expected_reply,name+' exact executed SCI response')
   check(result.stop_reason==expected_reason,name+' terminal reason')
   check(result.status==('FAIL' if expected_reason=='KERNEL_REJECT' else 'PASS'),name+' status')
   events=s.memory.events[begin:];reads=[e for e in events if e['mode']=='r' and int(e['address'],16)<0x100000]
   if expected_reason=='KERNEL_REJECT':check(not reads,name+' rejects before ROM load')
   else:
    addr=int.from_bytes(req[6:10],'big');check([int(e['address'],16) for e in reads]==list(range(addr,addr+128)),name+' exactly128 contiguous ROM byte loads')
    check(all(e['size']==1 and e['pc']=='FFFF3260' for e in reads),name+' actual tx_data instruction ROM load')
   return dict(request_hex=req.hex(),result=result.as_dict(),ROM_data_reads=len(reads),ROM_addresses=[e['address'] for e in reads])
  def finish(name,s,folder,exchanges,extra=None):
   coverage=s.coverage();writes=[e for e in s.memory.events if e['mode']=='w'];check(all(int(e['address'],16)>=0x100000 for e in writes),name+' no ROM store')
   check(all(not(0xffff3000<=int(e['address'],16)<0xffff3710) for e in writes),name+' no uploaded kernel mutation')
   allowed=[(int(e['address'],16),e['size']) for e in writes]
   check(all(any(lo<=a<a+n<=hi for lo,hi in s.ram_spans) or a in [0xffffecb0,0xffffec10,0xfffff73c] or 0xfffff010<=a<=0xfffff016 for a,n in allowed),name+' writes remain declared private RAM or modeled peripherals')
   save(folder/'COVERAGE.json',coverage)
   trace=dict(cpu=s.cpu.trace.rows,memory=s.memory.events,peripherals=s.peripheral.events,sci=s.peripheral.sci.events)
   with (folder/'TRACE.json.gz').open('xb') as raw:
    with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as f:f.write(json.dumps(trace,separators=(',',':')).encode())
   case=dict(name=name,status='PASS',exchanges=exchanges,coverage=pin(folder/'COVERAGE.json'),trace=pin(folder/'TRACE.json.gz'),cursor=s.cpu.r[8],pass_number=s.cpu.r[9],identity_seen=s.cpu.r[10],instruction_count=s.cpu.trace.count,SCI_control=s.peripheral.sci.reg[0xfffff012],injections=extra)
   report['cases'].append(case)
  for name,actual in [('poisoned_first128',False),('actual_OEM_registers_first128',True)]:
   s,f=new_session(name,actual);ex=[exchange(s,name,request(),response(rom))];check(s.cpu.r[8]==128 and s.cpu.r[9]==0,name+' cursor128 pass0');finish(name,s,f,ex)
  s,f=new_session('contiguous128');ex=[exchange(s,'contiguous_first',request(),response(rom)),exchange(s,'contiguous_second',request(128),response(rom,128))];check(s.cpu.r[8]==256 and s.cpu.r[9]==0,'contiguous cursor256');finish('contiguous128',s,f,ex)
  bad=[('length512',request(length=512)),('length0',request(length=0)),('length127',request(length=127)),('length129',request(length=129)),('length256',request(length=256)),('length65535',request(length=65535)),('wrong_address128',request(address=128)),('wrong_address1',request(address=1)),('wrong_pass1',request(passno=1)),('wrong_pass2',request(passno=2)),('bad_checksum',request()[:-1]+bytes([request()[-1]^1]))]
  for name,req in bad:
   s,f=new_session(name);ex=[exchange(s,name,req,b'','KERNEL_REJECT')];check(s.cpu.r[8]==0 and s.cpu.r[9]==0 and s.peripheral.sci.reg[0xfffff012]==0,name+' no cursor progress and SCI disabled');finish(name,s,f,ex)
  s,f=new_session('missing_identity',identity=False);ex=[exchange(s,'missing_identity',request(),b'','KERNEL_REJECT')];finish('missing_identity',s,f,ex)
  for passno in [0,1]:
   name='synthetic_final128_pass'+str(passno);s,f=new_session(name);before_state=dict(cursor=s.cpu.r[8],pass_number=s.cpu.r[9],pc=f'{s.cpu.pc:08X}')
   s.cpu._reg(8,0xfff80,());s.cpu._reg(9,passno,());injection=dict(classification='EXPLICIT_MODEL_STATE_BOUNDARY_FIXTURE_NOT_FULL_PASS_ACQUISITION',before=before_state,injected_cursor='000FFF80',injected_pass=passno)
   ex=[exchange(s,name,request(0xfff80,passno=passno),response(rom,0xfff80,passno),expected_reason='COMPLETE' if passno==1 else 'RX_WAIT')]
   check(s.cpu.r[8]==0 and s.cpu.r[9]==passno+1,name+' exact pass wrap')
   if passno==0:ex.append(exchange(s,name+'_next_pass_start',request(passno=1),response(rom,passno=1)));check(s.cpu.r[8]==128 and s.cpu.r[9]==1,name+' second pass begins at0')
   else:
    check(s.cpu.pc==s.symbols['halt_complete'] and s.peripheral.sci.reg[0xfffff012]==0,name+' actual completion halt and SCI off')
    try:s.exchange(request(passno=2))
    except SimulationStop:injection['third_pass_rejected_by_terminal_session']=True
    else:raise AssertionError('Third pass entered')
   finish(name,s,f,ex,injection)
  check([pin(p['path']) for p in before]==before,'all old and new inputs unchanged after model execution')
  report.update(status='PASS',checks_passed=len(CHECKS),checks=CHECKS,test_cases=len(report['cases']),passed_cases=len(report['cases']),kernel=pin(ROOT/'build/a/kernel.bin'),second_kernel=pin(ROOT/'build/b/kernel.bin'),fixed_read=dict(request=request().hex(),response=response(rom).hex(),response_bytes=139,data_bytes=128,data_sha256=hashlib.sha256(rom[:128]).hexdigest(),response_sha256=hashlib.sha256(response(rom)).hexdigest()),limits=['All responses come from executed new-kernel SCI instructions in the unchanged model. No provider or physical code is invoked.','Old kernel/upload/start/identity qualification is not rerun; actual-OEM entry registers and peripheral assumptions are reused from retained evidence. New kernel startup and identity necessarily run.','Synthetic end-of-pass cases explicitly inject cursor/pass registers at idle RX; they do not represent a full pass or full acquisition.','SCI instruction ticks and completion/self-echo assumptions do not establish physical timing or resolve the prior228-byte cutoff.','The kernel identity string remains unchanged; variant identity is established by new build/hash/upload pins, not identity text alone.','One128 physical request remains separately gated and unexecuted; final two-pass physical release is not qualified by these tests.'])
 except Exception:report['failure']=traceback.format_exc()
 save(run/'KERNEL_TEST_REPORT.json',report)
 if report['status']=='PASS':save(A/'LATEST_KERNEL_TESTS.json',dict(status='PASS',report=pin(run/'KERNEL_TEST_REPORT.json')))
 print(json.dumps(dict(status=report['status'],cases=len(report['cases']),report=pin(run/'KERNEL_TEST_REPORT.json'),failure=report.get('failure'))),flush=True)
 return 0 if report['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
