"""Derive a separate fixed-read native release. Never invoke any executable/provider."""
from pathlib import Path
import hashlib,json,datetime
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT.parent/'kernel_identity_physical'
OUT=Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_bounded_read_physical_20260930_01')
OLD=OUT.parent/'rk03_kernel_identity_physical_20260930_01'
OFF=OUT.parent/'rk03_bounded_rom_read_offline_20260930_01'
def pin(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,o):
 with p.open('x',encoding='utf8',newline='\n') as f:json.dump(o,f,indent=2);f.write('\n')
def one(t,a,b):
 assert t.count(a)==1,a
 return t.replace(a,b)
def main():
 cert=OFF/'sealed/QUALIFICATION.json'
 assert pin(cert)['sha256']=='0ec65a7934e51c1d3afc4dfaeab9b53c6bf7355bd7f5b30a5f6384e3ffc6d44b'
 data=Path(r'C:\Dev\SubaruRoms\current.bin').read_bytes()
 assert len(data)==1048576 and hashlib.sha256(data).hexdigest()=='bf10be6d7c75b4f2ae663b0d57a912e6e9ef7654ccfc985195954596e50427b2'
 block=data[:512]; response=bytes.fromhex('beef0206830000000000')+block
 response+=bytes([sum(response)&255])
 assert hashlib.sha256(response).hexdigest()=='796f64cefcd2b81c5c7662b2bdacad828c0a948c55bfdc5d002ac5c8da7f898e'
 offline=Path(r'C:\Dev\A2WC511R_RK03_BoundedRomReadOffline\bounded_rom_read\contract\CONTRACT.json')
 assert pin(offline)['sha256']=='9dccc5043477150c479255803ea25f48fe815d5b254f9c045e30b5923327edcf'
 c=json.loads((OLD/'PHYSICAL_IDENTITY_REVIEW_CONTRACT.json').read_text())
 c.update(status='REVIEW_CONTRACT_PHYSICAL_BOUNDED_READ_NOT_AUTHORIZATION',scope='FIXED15_UPLOAD_START_IDENTITY_ONE512_READ_CLEANUP',session_id='RK03_BOUNDED_ROM_READ_01',session_path=str(ROOT.parent/'physical_session/RK03_BOUNDED_ROM_READ_01'),requires_exact_human_authorization='PROCEED RK03 BOUNDED ROM READ',base_branch='rk03/kernel-start-identity-physical',base_commit='a8cb760b09e6219ae640419ddb030af2037a432e',build_branch='rk03/bounded-rom-read-physical',offline_bounded_qualification=pin(cert),offline_bounded_contract=pin(offline),maximum_requests=25,maximum_tx=25,bounded_read=dict(address=0,length=512,request='beef00080300000000000200ba',response=response.hex(),payload_sha256=hashlib.sha256(block).hexdigest(),response_sha256=hashlib.sha256(response).hexdigest(),current_rom=pin(r'C:\Dev\SubaruRoms\current.bin')),forbidden=['second read','arbitrary address or length','flash operations','second start','arbitrary payload','retry'],limitations=['First512 bytes only; identical to both current and stock; no whole-ROM provenance claim.','Physical bounded read not yet executed.'],additions=['one fixed read after validated identity','bounded523-byte streaming receiver','exact returned-data comparison and mismatch evidence'])
 c['ordered_requests'].append(dict(stage=24,wire_hex=c['bounded_read']['request'],dynamic_rule=None,sample_wire_hex=c['bounded_read']['request'],expected_reply_hex=response.hex()))
 cp=OUT/'PHYSICAL_BOUNDED_REVIEW_CONTRACT.json';save(cp,c)
 pins=(BASE/'src/pins.hpp').read_text().replace('5f2b1e263d98bc1a4a957770ea8e3c214a6ffb5a6798caf7aba79bcc5ecfe167',pin(cp)['sha256']).replace('RK03_KERNEL_START_IDENTITY_01','RK03_BOUNDED_ROM_READ_01').replace('PROCEED RK03 KERNEL START IDENTITY','PROCEED RK03 BOUNDED ROM READ').replace('rk03_kernel_identity_physical_20260930_01','rk03_bounded_read_physical_20260930_01').replace('PHYSICAL_IDENTITY_REVIEW_CONTRACT.json','PHYSICAL_BOUNDED_REVIEW_CONTRACT.json').replace('A2WC511R_RK03_KernelIdentityPhysical','A2WC511R_RK03_BoundedReadPhysical')
 (ROOT/'src/pins.hpp').write_text(pins,newline='\n')
 src=(ROOT/'src/bounded_response.hpp').read_text().replace('@EXPECTED_RESPONSE@',response.hex())
 (ROOT/'src/bounded_response.hpp').write_text(src,newline='\n')
 core=(BASE/'src/probe_core.hpp').read_text()
 core=one(core,'#include "identity_response.hpp"','#include "identity_response.hpp"\n#include "bounded_response.hpp"')
 core=one(core,'Bytes key_request;','bool bounded_validated=false;\n Bytes key_request;')
 core=one(core,'require(stage<24,"Fixed identity is the final protocol action");','require(stage<25,"One fixed512 read is the final protocol action");\n  if(stage==24){require(identity_validated&&kernel_filter&&filtered&&requested_baud==62500,"Read only after exact identity");return BoundedReply::request();}')
 core=core.replace('stage==next_tx&&stage<24','stage==next_tx&&stage<25').replace('stage==next_tx&&next_tx<24','stage==next_tx&&next_tx<25')
 core=one(core,'Stream stream;IdentityReply identity;','Stream stream;IdentityReply identity;BoundedReply bounded;')
 core=one(core,'if(stage==23){if(identity.consume','if(stage==24){if(bounded.consume(rx.value,request(stage)))return bounded.bytes;}else if(stage==23){if(identity.consume')
 core=one(core,'identity_validated=true;protocol_complete=true;',r'''identity_validated=true;
   const Bytes reply=exchange(24),expected=BoundedReply::expected();std::string differences="[";unsigned mismatches=0;
   for(unsigned i=0;i<512;i++)if(reply[10+i]!=expected[10+i]){if(mismatches++)differences+=',';differences+="{\"address\":"+number(i)+",\"expected\":"+number(expected[10+i])+",\"actual\":"+number(reply[10+i])+"}";}differences+=']';
   event("{\"type\":\"bounded_read_result\",\"address\":0,\"length\":512,\"request_hex\":"+quote(hex(BoundedReply::request().data(),13))+",\"response_hex\":"+quote(hex(reply.data(),reply.size()))+",\"payload_hex\":"+quote(hex(reply.data()+10,512))+",\"checksum_pass\":true,\"mismatch_count\":"+number(mismatches)+",\"mismatches\":"+differences+"}");
   require(reply==expected,"Returned512 bytes differ from pinned current.bin");bounded_validated=true;protocol_complete=true;''')
 core=core.replace('PASS_KERNEL_START_IDENTITY_ONLY','PASS_BOUNDED_ROM_READ_ONLY').replace('PASS_OFFLINE_KERNEL_START_IDENTITY_ONLY','PASS_OFFLINE_BOUNDED_ROM_READ_ONLY')
 (ROOT/'src/probe_core.hpp').write_text(core,newline='\n')
 main=(BASE/'src/main.cpp').read_text().replace('--physical-kernel-start-identity','--physical-bounded-rom-read').replace('kernel_identity_start','bounded_read_start').replace('KERNEL_START_IDENTITY_ONLY','BOUNDED_ROM_READ_ONLY')
 (ROOT/'src/main.cpp').write_text(main,newline='\n')
 for name in ['build_probe.py','build_probe.cmd']:
  t=(BASE/'tools'/name).read_text().replace('rk03_kernel_start_identity_physical32','rk03_bounded_rom_read_physical32').replace('KERNEL_START_IDENTITY_ONLY','BOUNDED_ROM_READ_ONLY')
  (ROOT/'tools'/name).write_text(t,newline='\n')
 save(OUT/'CHECKPOINT.json',dict(status='BOUNDED_NATIVE_QUALIFICATION_IN_PROGRESS',physical_invocations=0,physical_authorization_received=False,next_after_bounded_pass='OFFLINE_FINAL_TWO_PASS_RELEASE_QUALIFICATION',final_full_physical_allowed=False,contract=pin(cp)))
 (ROOT/'INPUT_PINS.json').write_text(json.dumps(dict(inputs=[pin(p) for p in (BASE/'src').iterdir() if p.is_file()]+[pin(cert),pin(offline),pin(cp)]),indent=2)+'\n')
 print(json.dumps(dict(status='DERIVED_NOT_EXECUTED',contract_sha256=pin(cp)['sha256'])))
if __name__=='__main__':main()
