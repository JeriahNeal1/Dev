@echo off
setlocal
if "%~1"=="build_a" goto allowed
if "%~1"=="build_b" goto allowed
exit /b 2
:allowed
cd /d "%~dp0.."
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars32.bat"
if errorlevel 1 exit /b 1
where.exe cl.exe > "%~1\resolved_compiler.txt"
where.exe link.exe > "%~1\resolved_linker.txt"
cl.exe /nologo /W4 /WX /EHsc /std:c++17 /MT /O2 /Brepro /Isrc src\main.cpp /Fo"%~1\probe.obj" /Fe"%~1\rk03_bounded_rom_read_128_physical32.exe" /link /Brepro bcrypt.lib
if errorlevel 1 exit /b 1
dumpbin.exe /headers "%~1\rk03_bounded_rom_read_128_physical32.exe" > "%~1\headers.txt"
if errorlevel 1 exit /b 1
dumpbin.exe /imports "%~1\rk03_bounded_rom_read_128_physical32.exe" > "%~1\imports.txt"
if errorlevel 1 exit /b 1
exit /b 0
