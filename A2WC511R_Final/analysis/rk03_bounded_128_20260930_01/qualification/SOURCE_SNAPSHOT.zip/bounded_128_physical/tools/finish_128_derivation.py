"""Complete fixed128 fixtures, controls and focused offline qualification runner."""
from pathlib import Path
import hashlib,json,re
from derive_128 import ROOT,BASE,A,OLD,rename,pin
c=json.loads((A/'PHYSICAL_BOUNDED_128_REVIEW_CONTRACT.json').read_text());old=json.loads((OLD/'PHYSICAL_BOUNDED_REVIEW_CONTRACT.json').read_text())
p=ROOT/'src/bounded_response.hpp';s=p.read_text();s=re.sub(r'static Bytes expected\(\)\{return decode\("[0-9a-f]+"\);\}',lambda _:f'static Bytes expected(){{return decode("{c["bounded_read"]["response"]}");}}',s).replace('512-byte','128-byte');p.write_text(s,newline='\n')
p=ROOT/'src/fake_backend.hpp';s=p.read_text();s=s.replace('if(is("failed512_reference")){s.queue.push_back(message({},START_OF_MESSAGE));s.queue.push_back(message(decode(', 'if(is("failed512_reference")){auto som=message({},START_OF_MESSAGE);som.Timestamp=2603231369;s.queue.push_back(som);auto data=message(decode(')
fragment=c['prior_physical_failure'];f=json.loads(Path(fragment['path']).read_text())['RK03_event']['received_status_records'][1]['output']['message']['data_hex']
s=s.replace(fragment if False else 'decode("'+f+'")));return 0;}', 'decode("'+f+'"));data.Timestamp=2603268720;data.ExtraDataIndex=data.DataSize;s.queue.push_back(data);return 0;}');p.write_text(s,newline='\n')
# Reuse the independently reviewed runner, changing only fixed new image/size oracles.
s=rename((BASE/'tools/test_bounded_physical.py').read_text())
s=s.replace("ORACLE=Path(r'C:\\Dev\\A2WC511R_RK03_BoundedRomReadOffline\\bounded_rom_read\\contract\\CONTRACT.json')","ORACLE=ROOT/'fixtures/128_oracle.json'")
s=s.replace('9dccc5043477150c479255803ea25f48fe815d5b254f9c045e30b5923327edcf',pin(ROOT/'fixtures/128_oracle.json')['sha256']).replace('be14e560229f5a7eb1904cc18c47dc9c36fe6df3b79c86be12f844640fe15e02',pin(A/'PHYSICAL_BOUNDED_128_REVIEW_CONTRACT.json')['sha256']).replace(old['kernel_sha256'],c['kernel_sha256'])
s=s.replace("NEGATIVE=['bounded_data_all'","NEGATIVE=['failed512_reference','bounded_data_all'")
for a,b in [('range(512)','range(128)'),('range(1,523)','range(1,139)'),('==527','==143'),('<=527','<=143'),('==523','==139'),('523-split','139-split'),('all522','all138'),('all512','all128'),("'owned_artifact.h',",''),('==1116','==349'),('matrix1116','matrix349')]:s=s.replace(a,b)
s=s.replace("require([r['input']['message'] for r in tx[:24]]==oldtx,'exact24 physical write records')", "require(all(r['input']['message']==oldtx[i] for i,r in enumerate(tx[:24]) if not 7<=i<22),'physical transport TX preserved except separately pinned newkernel chunks')\n        require([r['input']['message']['data_hex'] for r in tx[7:22]]==[row['tx'] for row in oracle['frames'][7:22]],'exact reviewed newkernel chunks')")
s=s.replace("    if case=='bounded_late_reply':", "    if case=='failed512_reference':\n        source=json.loads((A/'BOUNDED_512_FAILURE_CLASSIFICATION.json').read_text());messages=[r['output']['message'] for r in rx_by_stage[24]]\n        require(len(messages)==2 and messages[0]['rx_status']==2 and messages[1]['data_hex']==source['received_frame_hex'] and messages[1]['data_size']==228,'exact prior failed512 data supplied and rejected before another read')\n    if case=='bounded_late_reply':")
(ROOT/'tools/test_bounded_physical.py').write_text(s,newline='\n')
# Controls retain reviewed reservations, user gates, cleanup and passive observer.
names=['launch_bounded_once.py','launch_oem_return_once.py','check_clients.ps1','seal_bounded_result.py','seal_oem_return_bounded.py','test_launcher_offline.py','test_oem_return_controls.py','test_result_validator.py']
for name in names:
 s=rename((OLD/name).read_text())
 for a,b in [('beef00080300000000000200ba','beef0008030000000000008038'),('beef0206830000000000','beef0086830000000000'),('len(data)==523','len(data)==139'),('address=0,length=512','address=0,length=128'),("'bounded_length':512","'bounded_length':128"),('Exact current.bin bounded data','Exact128 current.bin bounded data'),('RK03_FINAL_TWO_PASS_128','RK03_FINAL_TWO_PASS_128'),('RK03_FULL_ROM_TWO_PASS_PHYSICAL','RK03_FINAL_TWO_PASS_128'),('OEM_RETURN_AFTER_BOUNDED_ROM_READ','OEM_RETURN_AFTER_BOUNDED_ROM_READ_128'),('RK03_BOUNDED_ROM_READ_PHYSICAL','RK03_BOUNDED_ROM_READ_128_PHYSICAL')]:s=s.replace(a,b)
 if name=='check_clients.ps1':s=s.replace('|rk03_bounded_rom_read_128_physical32)', '|rk03_bounded_rom_read_physical32|rk03_bounded_rom_read_128_physical32)')
 with (A/name).open('x',encoding='utf8') as f:f.write(s)
 (ROOT/'release_controls'/name).write_text(s,newline='\n')
print('Fixed128 native fixture/runner/controls complete; no execution')
