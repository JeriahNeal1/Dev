"""Seal already reviewed native bounded qualification; never operate hardware."""
from pathlib import Path
import datetime,hashlib,json,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[1];REPO=ROOT.parent
OUT=Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_bounded_128_20260930_01')
CONTROLS=['launch_bounded_once.py','launch_oem_return_once.py','check_clients.ps1','seal_bounded_result.py','seal_oem_return_bounded.py','test_launcher_offline.py','test_oem_return_controls.py','test_result_validator.py']
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,o):
 with Path(p).open('x',encoding='utf8',newline='\n') as f:json.dump(o,f,indent=2);f.write('\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO,text=True).strip()
def verify(obj):
 if isinstance(obj,dict):
  if isinstance(obj.get('path'),str) and isinstance(obj.get('sha256'),str):assert pin(obj['path'])['sha256']==obj['sha256'],obj['path']
  for value in obj.values():verify(value)
 elif isinstance(obj,list):
  for value in obj:verify(value)
def main():
 assert git('branch','--show-current')=='rk03/bounded-128-physical' and not git('status','--porcelain')
 assert not (REPO/'physical_session').exists()
 cpath=OUT/'PHYSICAL_BOUNDED_128_REVIEW_CONTRACT.json';c=read(cpath)
 assert c['maximum_tx']==c['maximum_requests']==len(c['ordered_requests'])==25
 assert c['bounded_read']['request']=='beef0008030000000000008038' and c['bounded_read']['length']==128 and c['bounded_read']['address']==0
 assert c['bounded_read']['payload_sha256']=='e3e408102d41a7b927df188b025a89688d8e831d21a36666b01c2cc7807bc012'
 assert c['kernel_sha256']=='808a5523d47de11881bfc2ea06a35278aedb5122ed51e8110f817b3210adb653'
 verify(c['kernel_image']);verify(c['kernel_manifest']);verify(c['classification']);verify(c['prior_physical_failure']);verify(c['offline_bounded_qualification']);verify(c['offline_bounded_contract']);verify(c['bounded_read']['current_rom']);verify(c['physical_provider'])
 testref=read(ROOT/'reports/LATEST_QUALIFICATION.json');verify(testref);tests=read(testref['report']['path'])
 assert tests['status']=='PASS' and tests['passed_cases']==tests['test_cases'] and tests['physical_operations']==tests['real_provider_loads']==0
 reviews=[OUT/'independent_review/REVIEW.json',OUT/'root_review/REVIEW.json',OUT/'independent_review/PACKAGING_REVIEW.json']
 for path in reviews:
  r=read(path);assert r['status']=='PASS';verify(r)
 for name in ['LAUNCHER_TESTS_V2.json','OEM_RETURN_CONTROL_TESTS_V2.json','RESULT_VALIDATOR_TESTS.json']:
  r=read(OUT/name);assert r['status']=='PASS';verify(r)
 ktref=read(OUT/'kernel_review/LATEST_KERNEL_TESTS.json');verify(ktref);kt=read(ktref['report']['path']);assert kt['status']=='PASS' and kt['passed_cases']==kt['test_cases']==17;verify(kt['inputs'])
 builds=[read(ROOT/n/'BUILD.json') for n in ('build_a','build_b')]
 for b in builds:
  assert b['status']=='PASS_BUILD_ONLY';verify(b['source_inputs']);assert pin(b['exe_path'])['sha256']==b['exe_sha256']
 assert builds[0]['exe_sha256']==builds[1]['exe_sha256'] and builds[0]['source_inputs']==builds[1]['source_inputs']
 assert Path(builds[0]['exe_path']).read_bytes()==Path(builds[1]['exe_path']).read_bytes()
 for name in CONTROLS:assert (ROOT/'release_controls'/name).read_bytes()==(OUT/name).read_bytes(),name
 canonical=dict(scope='FIXED_ONE128_READ_PHYSICAL_RELEASE_NOT_AUTHORIZATION',executable_sha256=builds[0]['exe_sha256'],source_inputs=builds[0]['source_inputs'],compiler=builds[0]['compiler'],linker=builds[0]['linker'])
 for name in ('build_a','build_b'):save(ROOT/name/'REPRODUCIBLE_MANIFEST.json',canonical)
 assert pin(ROOT/'build_a/REPRODUCIBLE_MANIFEST.json')['sha256']==pin(ROOT/'build_b/REPRODUCIBLE_MANIFEST.json')['sha256']
 q=OUT/'qualification';q.mkdir(exist_ok=False)
 source=[REPO/p for p in git('ls-files','bounded_128_physical','kernel128').splitlines()]
 assert source
 with zipfile.ZipFile(q/'SOURCE_SNAPSHOT.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
  for p in sorted(source):
   info=zipfile.ZipInfo(p.relative_to(REPO).as_posix(),date_time=(2026,9,30,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o444<<16;archive.writestr(info,p.read_bytes())
 paths=set(source+[cpath]+reviews+[OUT/n for n in CONTROLS]+[OUT/n for n in ['LAUNCHER_TESTS_V2.json','OEM_RETURN_CONTROL_TESTS_V2.json','RESULT_VALIDATOR_TESTS.json']])
 for d in [ROOT/'build_a',ROOT/'build_b',ROOT/'reports',OUT/'independent_review',OUT/'root_review']:
  paths.update(p for p in d.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
 for key in ['offline_bounded_qualification','offline_bounded_contract','physical_provider']:paths.add(Path(c[key]['path']))
 paths.add(Path(c['bounded_read']['current_rom']['path']))
 for d in [REPO/'kernel128/build',OUT/'kernel_review',OUT/'forensics']:
  paths.update(p for p in d.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
 paths.update([OUT/'FIXED_UPLOAD_128_MANIFEST.json',OUT/'BOUNDED_512_FAILURE_CLASSIFICATION.json',OUT/'CONTRACT_INTERPRETATION.json'])
 reuse=OUT.parent/'current_rom_20260930_01/OEM_RETURN_REUSE.json';r=read(reuse);verify(r['files']);paths.add(reuse);paths.update(Path(p['path']) for p in r['files'])
 certificate=dict(schema=1,status='PASS_OFFLINE_QUALIFIED_PHYSICAL_BOUNDED_ROM_READ_128_ONLY',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),session_id=c['session_id'],branch=git('branch','--show-current'),commit=git('rev-parse','HEAD'),maximum_physical_invocations=1,requires_exact_human_authorization=c['requires_exact_human_authorization'],physical_authorization_received=False,physical_executable=pin(builds[0]['exe_path']),second_clean_executable=pin(builds[1]['exe_path']),review_contract=pin(cpath),kernel_sha256=c['kernel_sha256'],bounded_read=c['bounded_read'],maximum_requests=25,maximum_ROM_requests=1,arbitrary_read_allowed=False,repeated_read_allowed=False,flash_allowed=False,retry_allowed=False,independent_reviews=[pin(p) for p in reviews],test_report=testref['report'],tests_passed=tests['passed_cases'],tests_total=tests['test_cases'],retained_512_reference_qualification=c['offline_bounded_qualification'],kernel_instruction_tests=ktref['report'],kernel_instruction_cases=17,fixed_upload_manifest=pin(OUT/'FIXED_UPLOAD_128_MANIFEST.json'),contract_interpretation=pin(OUT/'CONTRACT_INTERPRETATION.json'),source_snapshot=pin(q/'SOURCE_SNAPSHOT.zip'),files=[pin(p) for p in sorted(paths)],physical_operations_during_qualification=0,provider_loads_during_qualification=0,next_after_bounded_and_OEM_pass='OFFLINE_QUALIFY_RK03_FINAL_TWO_PASS_128_DO_NOT_EXECUTE',limitations=['First128 bytes equal current.bin and stock; no whole-ROM provenance claim.','New fixed128 kernel is independently qualified offline; its first physical use remains gated. Identity text is unchanged, image pin distinguishes this variant.','Two-second whole-frame deadline retained; simulation is not silicon timing and does not explain prior228-byte cutoff.','After exact complete reply the host stops receiving; separately queued trailing frames are not consumed.'])
 save(q/'QUALIFICATION.json',certificate);certpin=pin(q/'QUALIFICATION.json')
 gates=dict(session_id=c['session_id'],qualification_sha256=certpin['sha256'],status='WAITING_IGNITION_OFF',probe_invocation_count=0,launch_reserved=False,physical_authorization_received=False,completed_pre_probe_gates=[],completed_recovery_gates=[],commit_authorization=None,physical_state='UNCONFIRMED_FOR_NEW_SESSION',engine='OFF',operator_managed_physical_context=True,full_acquisition_allowed=False,retry_allowed=False,abort_requested=False,next_gate='IGNITION OFF')
 save(OUT/'BOUNDED_128_GATE_STATE.json',gates)
 checkpoint=read(OUT/'CHECKPOINT.json');checkpoint.update(status='QUALIFIED_WAITING_FRESH_HUMAN_GATES',certificate=certpin,physical_executable=certificate['physical_executable']);(OUT/'CHECKPOINT.json').write_text(json.dumps(checkpoint,indent=2)+'\n')
 statepath=Path(r'C:\Dev\A2WC511R_Final\state\CURRENT.json');state=read(statepath)
 state.update(phase='RK03_BOUNDED_128_PHYSICAL_QUALIFIED_WAITING_IGNITION_OFF',bounded_128_gate_state=str(OUT/'BOUNDED_128_GATE_STATE.json'),bounded_128_physical_invocations=0,human_required=['IGNITION OFF'],next_action='Fresh IGNITION OFF then TEST MODE ON and exact bounded authorization',final_full_physical_allowed_this_run=False)
 statepath.write_text(json.dumps(state,indent=2)+'\n')
 # Only new release-owned outputs are frozen; historical evidence, current.bin
 # and the installed provider are verified without changing their attributes.
 for p in paths|set(q.iterdir()):
  if p.resolve().is_relative_to(ROOT.resolve()) or p.resolve().is_relative_to((REPO/'kernel128').resolve()) or p.resolve().is_relative_to(OUT.resolve()):p.chmod(0o444)
 print(json.dumps(dict(status=certificate['status'],exe=certificate['physical_executable'],certificate=certpin,tests=tests['passed_cases'])))
if __name__=='__main__':main()
