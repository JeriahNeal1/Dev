"""Derive one fixed128-byte release from preserved bounded512 host + reviewed newkernel."""
from pathlib import Path
import hashlib,json,re,sys
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent/'bounded_read_physical'
A=Path(r'C:\Dev\A2WC511R_Final\analysis\rk03_bounded_128_20260930_01')
OLD=A.parent/'rk03_bounded_read_physical_20260930_01'
K=ROOT.parent/'kernel128/build/a/kernel.bin';KM=K.with_name('manifest.json')
def pin(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,o):
 with p.open('x',encoding='utf8') as f:json.dump(o,f,indent=2);f.write('\n')
def rename(t):
 for a,b in [('A2WC511R_RK03_BoundedReadPhysical','A2WC511R_RK03_Bounded128Physical'),('rk03_bounded_read_physical_20260930_01','rk03_bounded_128_20260930_01'),('bounded_read_physical','bounded_128_physical'),('rk03_bounded_rom_read_physical32','rk03_bounded_rom_read_128_physical32'),('RK03_BOUNDED_ROM_READ_01','RK03_BOUNDED_ROM_READ_128_01'),('PROCEED RK03 BOUNDED ROM READ','PROCEED RK03 128 BYTE ROM READ'),('--physical-bounded-rom-read','--physical-bounded-rom-read-128'),('PASS_BOUNDED_ROM_READ_ONLY','PASS_BOUNDED_ROM_READ_128_ONLY'),('PASS_OFFLINE_BOUNDED_ROM_READ_ONLY','PASS_OFFLINE_BOUNDED_ROM_READ_128_ONLY'),('PHYSICAL_BOUNDED_REVIEW_CONTRACT.json','PHYSICAL_BOUNDED_128_REVIEW_CONTRACT.json'),('BOUNDED_GATE_STATE.json','BOUNDED_128_GATE_STATE.json'),('QUALIFIED_PHYSICAL_BOUNDED_ROM_READ_ONLY','QUALIFIED_PHYSICAL_BOUNDED_ROM_READ_128_ONLY'),('AUTHORIZED_BOUNDED_ROM_READ_ONLY','AUTHORIZED_BOUNDED_ROM_READ_128_ONLY')]:t=t.replace(a,b)
 return t
def main():
 kernel=K.read_bytes();m=json.loads(KM.read_text());assert len(kernel)==1808 and m['entry']==0xffff3004 and m['protocol']['block_bytes']==128
 assert kernel==(ROOT.parent/'kernel128/build/b/kernel.bin').read_bytes()
 sys.path.insert(0,r'C:\Dev\A2WC511R_ReadKernel')
 from host.protocol import encrypt_upload,upload_frames,decrypt_upload
 cipher=encrypt_upload(kernel);assert decrypt_upload(cipher)==kernel
 oldc=json.loads((OLD/'PHYSICAL_BOUNDED_REVIEW_CONTRACT.json').read_text());c=json.loads(json.dumps(oldc))
 block=Path(r'C:\Dev\SubaruRoms\current.bin').read_bytes()[:128];reply=bytes.fromhex('beef0086830000000000')+block;reply+=bytes([sum(reply)&255]);request='beef0008030000000000008038'
 assert hashlib.sha256(block).hexdigest()=='e3e408102d41a7b927df188b025a89688d8e831d21a36666b01c2cc7807bc012'
 chunks=list(upload_frames(kernel));assert len(chunks)==15
 c.update(session_id='RK03_BOUNDED_ROM_READ_128_01',session_path=str(ROOT.parent/'physical_session/RK03_BOUNDED_ROM_READ_128_01'),requires_exact_human_authorization='PROCEED RK03 128 BYTE ROM READ',scope='FIXED128_KERNEL_UPLOAD_START_IDENTITY_ONE128_READ_CLEANUP',build_branch='rk03/bounded-128-physical',base_branch='rk03/bounded-rom-read-physical',base_commit='96f6c49030b2d1c694e388ba6a1925d62d83b56a',kernel_sha256=pin(K)['sha256'],kernel_manifest=pin(KM),kernel_image=pin(K),prior_kernel_sha256=oldc['kernel_sha256'],kernel_change='Only fixed read admission128,response body134,cursor128 and loaderchecksum; identity/entry/layout unchanged.',prior_physical_failure=pin(OLD/'failure_analysis/EVENT_DIFF.json'),classification=pin(A/'BOUNDED_512_FAILURE_CLASSIFICATION.json'),status='REVIEW_CONTRACT_FIXED128_NOT_PHYSICAL_AUTHORIZATION')
 c['bounded_read'].update(length=128,request=request,response=reply.hex(),payload_sha256=hashlib.sha256(block).hexdigest(),response_sha256=hashlib.sha256(reply).hexdigest())
 for i,frame in enumerate(chunks,7):c['ordered_requests'][i].update(wire_hex=frame.hex(),sample_wire_hex=frame.hex())
 c['ordered_requests'][24].update(wire_hex=request,sample_wire_hex=request,expected_reply_hex=reply.hex())
 c['post_start_transition']=['exactstartACK','stopOEMfilter','62500baud','BEEFfilter','oneidentity','exactidentityreply','onefixed128read','exact139byteframe','cleanup']
 c['limitations']=['Physical128read unproven until fresh authorization/run.','Newfixed128kernel requires newhash/upload qualification; prior512image preserved.','Old512failure cause remains unresolved; shorterframe is a bounded physical test, not a proven fix.']
 cpath=A/'PHYSICAL_BOUNDED_128_REVIEW_CONTRACT.json';save(cpath,c);ch=pin(cpath)['sha256']
 fixed=[]
 for i,frame in enumerate(chunks):
  off=i*128;data=kernel[off:off+128];fixed.append(dict(index=i+1,address=f'{0xffff3000+off:08X}',length=len(data),payload_sha256=hashlib.sha256(data).hexdigest(),cipher_sha256=hashlib.sha256(cipher[off:off+128]).hexdigest(),request_hex=frame.hex(),reply_hex='80f0100176f7'))
 save(A/'FIXED_UPLOAD_128_MANIFEST.json',dict(kernel=pin(K),kernel_bytes=1808,chunks=fixed))
 oracle=json.loads(Path(r'C:\Dev\A2WC511R_RK03_BoundedRomReadOffline\bounded_rom_read\contract\CONTRACT.json').read_text())
 for i,frame in enumerate(chunks,7):oracle['frames'][i]['tx']=frame.hex()
 oracle['frames'][24].update(tx=request,rx=reply.hex());oracle['fixed_read'].update(expected_bytes_hex=block.hex(),request=request,response=reply.hex())
 save(ROOT/'fixtures/128_oracle.json',oracle)
 for name in ['main.cpp','pins.hpp','probe_core.hpp','bounded_response.hpp','fake_backend.hpp']:
  s=rename((BASE/'src'/name).read_text())
  s=s.replace(oldc['kernel_sha256'],pin(K)['sha256']).replace(pin(OLD/'PHYSICAL_BOUNDED_REVIEW_CONTRACT.json')['sha256'],ch)
  if name in ['probe_core.hpp','bounded_response.hpp','fake_backend.hpp']:
   for a,b in [('beef00080300000000000200ba',request),('beef0206830000000000','beef0086830000000000'),('i<512','i<128'),('offset<512','offset<128'),('i<523','i<139'),('split<523','split<139'),('<=523','<=139'),('<=527','<=143'),('<523','<139'),('523-split','139-split'),('511','127'),('for(unsigned i=0;i<512','for(unsigned i=0;i<128'),('reply.data()+10,512','reply.data()+10,128'),('\\"length\\":512','\\"length\\":128'),('fixed512','fixed128'),('Returned512','Returned128')]:s=s.replace(a,b)
  if name=='bounded_response.hpp':s=s.replace(oldc['bounded_read']['response'],reply.hex()).replace('bytes.size()<523','bytes.size()<139')
  if name=='fake_backend.hpp':
   s=s.replace('const unsigned cuts[]={1,2,5,13,64,128,310};','const unsigned cuts[]={1,2,5,13,32,64,22};')
   s=s.replace('"bounded_data_all",','"failed512_reference","bounded_data_all",',1)
   raw=[json.loads(x) for x in Path(r'C:\Dev\A2WC511R_RK03_BoundedReadPhysical\physical_session\RK03_BOUNDED_ROM_READ_01\native_api.jsonl').read_text().splitlines()]
   actual=next(x['output']['message']['data_hex'] for x in raw if x.get('type')=='api_return' and x.get('sequence')==93)
   s=s.replace('if(stage==24){\n  if(is("bounded_no_reply"))',f'if(stage==24){{\n  if(is("failed512_reference")){{s.queue.push_back(message({{}},START_OF_MESSAGE));s.queue.push_back(message(decode("{actual}")));return 0;}}\n  if(is("bounded_no_reply"))')
  (ROOT/'src'/name).write_text(s,newline='\n')
 owned='// Fixed reviewed128-read kernel; no dynamic payload selection.\nstatic constexpr const char* KERNEL_SHA="'+pin(K)['sha256']+'";\nstatic constexpr unsigned KERNEL_SIZE=1808;\nstatic const unsigned char KERNEL_CIPHER[]={'+','.join('0x%02x'%x for x in cipher)+'};\n'
 (ROOT/'src/owned_artifact.h').write_text(owned)
 s=(BASE/'src/fixtures.hpp').read_text();s=re.sub(r'(EXPECTED_TX\[\]\s*=\s*\{).*?(\};)',lambda mm:mm[1]+','.join('"'+row['wire_hex']+'"' if i!=4 else '"8010f0062702e78f1f2165"' for i,row in enumerate(c['ordered_requests'][:22]))+mm[2],s,flags=re.S)
 assert chunks[0].hex() in s and chunks[-1].hex() in s
 (ROOT/'src/fixtures.hpp').write_text(s,newline='\n')
 for name in ['build_probe.py','build_probe.cmd']:(ROOT/'tools'/name).write_text(rename((BASE/'tools'/name).read_text()),newline='\n')
 (ROOT/'INPUT_PINS.json').write_text(json.dumps(dict(inputs=[pin(cpath),pin(K),pin(KM),pin(OLD/'qualification/QUALIFICATION.json'),pin(A/'BOUNDED_512_FAILURE_CLASSIFICATION.json')]),indent=2)+'\n')
 print(json.dumps(dict(kernel_sha=pin(K)['sha256'],contract_sha=ch,oracle_sha=pin(ROOT/'fixtures/128_oracle.json')['sha256'],expected_data_sha=c['bounded_read']['payload_sha256'])))
if __name__=='__main__':main()
