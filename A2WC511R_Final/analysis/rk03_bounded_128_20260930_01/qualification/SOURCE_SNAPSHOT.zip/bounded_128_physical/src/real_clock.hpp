#pragma once
#include "common.hpp"
namespace real_clock {
inline unsigned long long milliseconds(){LARGE_INTEGER ticks,hz;if(!QueryPerformanceCounter(&ticks)||!QueryPerformanceFrequency(&hz)||ticks.QuadPart<0||hz.QuadPart<=0)return 0;const auto t=static_cast<unsigned long long>(ticks.QuadPart),f=static_cast<unsigned long long>(hz.QuadPart);return (t/f)*1000+((t%f)*1000)/f;}
inline long minimum_wait(U ms){
 if(ms!=100&&ms!=200)return 7;LARGE_INTEGER begin,hz,now;
 if(!QueryPerformanceFrequency(&hz)||hz.QuadPart<=0||!QueryPerformanceCounter(&begin)||begin.QuadPart<0)return 7;
 const auto minimum=(static_cast<unsigned long long>(hz.QuadPart)*ms+999)/1000;
 for(;;){if(!QueryPerformanceCounter(&now)||now.QuadPart<begin.QuadPart)return 7;auto elapsed=static_cast<unsigned long long>(now.QuadPart-begin.QuadPart);if(elapsed>=minimum)return 0;
  auto remaining=minimum-elapsed;auto sleep_ms=(remaining*1000)/static_cast<unsigned long long>(hz.QuadPart);Sleep(static_cast<DWORD>(std::max<unsigned long long>(1,std::min<unsigned long long>(50,sleep_ms))));
 }
}
}
