#pragma once
static constexpr const char* CONTRACT_SHA="767885ac7ec8dae204902dd0bc7dda54c8a7a3890ee9703f20a169fae05ba16a";
static constexpr const char* PROVIDER_SHA="f432084801762d919a3c31974616e097562424470003edc4f4fb843df34103cf";
static constexpr const char* SESSION_ID="RK03_BOUNDED_ROM_READ_128_01";
static constexpr const char* AUTH_TOKEN="PROCEED RK03 128 BYTE ROM READ";
static constexpr const wchar_t* CONTRACT_PATH=L"C:\\Dev\\A2WC511R_Final\\analysis\\rk03_bounded_128_20260930_01\\PHYSICAL_BOUNDED_128_REVIEW_CONTRACT.json";
static constexpr const wchar_t* PROVIDER_PATH=L"C:\\Windows\\SysWOW64\\op20pt32.dll";
static constexpr const wchar_t* SESSION_PATH=L"C:\\Dev\\A2WC511R_RK03_Bounded128Physical\\physical_session\\RK03_BOUNDED_ROM_READ_128_01";
