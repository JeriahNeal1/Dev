#pragma once
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
#include <array>
#include <algorithm>
#include <stdexcept>
#include <cstddef>
#include "j2534_tactrix.h"
static_assert(sizeof(void*)==4&&sizeof(PASSTHRU_MSG)==4152,"Pinned x86 J2534 ABI");
static_assert(sizeof(long)==4&&sizeof(unsigned long)==4&&offsetof(PASSTHRU_MSG,Data)==24,"Pinned message ABI");
static_assert(sizeof(SCONFIG)==8&&sizeof(SCONFIG_LIST)==8&&offsetof(SCONFIG_LIST,ConfigPtr)==4,"Pinned configuration ABI");
using Bytes=std::vector<unsigned char>;
using U=unsigned long;
inline void require(bool b,const char* text){if(!b)throw std::runtime_error(text);}
inline std::string quote(const std::string& s){std::string r="\"";for(unsigned char c:s){if(c=='"'||c=='\\'){r+='\\';r+=c;}else if(c<32||c>=127){char b[7];sprintf_s(b,"\\u%04x",c);r+=b;}else r+=c;}return r+'"';}
inline std::string hex(const unsigned char* p,size_t n){static const char* d="0123456789abcdef";std::string r;for(size_t i=0;i<n;i++){r+=d[p[i]>>4];r+=d[p[i]&15];}return r;}
inline Bytes decode(const char* s){Bytes r;size_t n=strlen(s);require(n%2==0,"Fixture hex size");for(size_t i=0;i<n;i+=2){unsigned v=0;require(sscanf_s(s+i,"%2x",&v)==1,"Fixture hex");r.push_back(static_cast<unsigned char>(v));}return r;}
inline std::string number(unsigned long long v){return std::to_string(v);}
inline std::string boolean(bool v){return v?"true":"false";}
inline std::string pointer(const void* p){return number(reinterpret_cast<uintptr_t>(p));}
inline unsigned long long utc(){FILETIME t;GetSystemTimePreciseAsFileTime(&t);return (static_cast<unsigned long long>(t.dwHighDateTime)<<32)|t.dwLowDateTime;}
inline long long qpc(){LARGE_INTEGER t;QueryPerformanceCounter(&t);return t.QuadPart;}
inline long long frequency(){LARGE_INTEGER t;QueryPerformanceFrequency(&t);return t.QuadPart;}
inline unsigned char checksum(const Bytes& b){unsigned s=0;for(auto v:b)s+=v;return static_cast<unsigned char>(s);}
static const std::array<SCONFIG,5> SERIAL={{{22,0},{7,1},{10,0},{12,0},{3,0}}};
static constexpr U SENTINEL=0xD15EA5ED;
struct Message{U before[4];PASSTHRU_MSG value;U after[4];Message(){memset(this,0,sizeof(*this));for(unsigned i=0;i<4;i++)before[i]=after[i]=0x51A7C0DE;}bool intact()const{for(unsigned i=0;i<4;i++)if(before[i]!=0x51A7C0DE||after[i]!=0x51A7C0DE)return false;return true;}};
inline void set_message(PASSTHRU_MSG& m,const Bytes& b){m={};m.ProtocolID=3;m.DataSize=static_cast<U>(b.size());memcpy(m.Data,b.data(),b.size());}
inline std::string message_json(const PASSTHRU_MSG& m){size_t n=std::min<size_t>(m.DataSize,sizeof(m.Data));return "{\"protocol\":"+number(m.ProtocolID)+",\"rx_status\":"+number(m.RxStatus)+",\"tx_flags\":"+number(m.TxFlags)+",\"timestamp\":"+number(m.Timestamp)+",\"data_size\":"+number(m.DataSize)+",\"extra_data_index\":"+number(m.ExtraDataIndex)+",\"buffer_capacity\":4128,\"logged_bytes\":"+number(n)+",\"data_truncated\":"+boolean(n!=m.DataSize)+",\"data_hex\":"+quote(hex(m.Data,n))+"}";}
struct ConfigBuffer{U before[4];SCONFIG_LIST list;SCONFIG items[5];U after[4];ConfigBuffer(){for(unsigned i=0;i<4;i++)before[i]=after[i]=0xC011CAFE;for(unsigned i=0;i<5;i++)items[i]={SERIAL[i].Parameter,SENTINEL};list={5,items};}bool intact()const{for(unsigned i=0;i<4;i++)if(before[i]!=0xC011CAFE||after[i]!=0xC011CAFE)return false;return true;}};
inline std::string config_json(const SCONFIG_LIST& list,const SCONFIG* owned,size_t capacity){std::string r="{\"list_present\":true,\"returned_num_params\":"+number(list.NumOfParams)+",\"config_pointer\":"+pointer(list.ConfigPtr)+",\"owned_buffer_pointer\":"+pointer(owned)+",\"pointer_matches_owned\":"+boolean(list.ConfigPtr==owned)+",\"owned_capacity\":"+number(capacity)+",\"owned_buffer_entries\":[";for(size_t i=0;i<capacity;i++){if(i)r+=',';r+="{\"parameter\":"+number(owned[i].Parameter)+",\"value\":"+number(owned[i].Value)+"}";}return r+"]}";}
struct VersionBuffer{U before[4];char firmware[80],dll[80],api[80];U after[4];VersionBuffer(){memset(this,0,sizeof(*this));for(unsigned i=0;i<4;i++)before[i]=after[i]=0xA11C0DE5;}bool intact()const{for(unsigned i=0;i<4;i++)if(before[i]!=0xA11C0DE5||after[i]!=0xA11C0DE5)return false;return true;}};
inline std::string version_part(const char* p){size_t n=0;while(n<80&&p[n])n++;return "{\"capacity\":80,\"nul_terminated\":"+boolean(n<80)+",\"value\":"+quote(std::string(p,n))+",\"raw_buffer_hex\":"+quote(hex(reinterpret_cast<const unsigned char*>(p),80))+"}";}
struct Api{PF_PassThruOpen* open;PF_PassThruClose* close;PF_PassThruConnect* connect;PF_PassThruDisconnect* disconnect;PF_PassThruReadMsgs* read;PF_PassThruWriteMsgs* write;PF_PassThruStartMsgFilter* filter;PF_PassThruStopMsgFilter* stop_filter;PF_PassThruReadVersion* version;PF_PassThruIoctl* ioctl;long (*wait_ms)(U);unsigned long long (*virtual_ms)();};
struct Stream{
 Bytes bytes;unsigned pieces=0,indicators=0;
 bool consume(const PASSTHRU_MSG& m,const Bytes& tx){
  require(++pieces<=527,"RX message count bound");require(m.ProtocolID==3&&m.TxFlags==0&&m.DataSize<=523&&(m.ExtraDataIndex==0||m.ExtraDataIndex==m.DataSize),"RX metadata bounds");Bytes data(m.Data,m.Data+m.DataSize);
  if(m.RxStatus){require(bytes.empty()&&++indicators<=4,"RX indication position/count");if(m.RxStatus==START_OF_MESSAGE||m.RxStatus==TX_DONE)require(data.empty(),"Nonempty RX indication");else if(m.RxStatus==TX_MSG_TYPE||m.RxStatus==(TX_MSG_TYPE|TX_DONE))require(data==tx,"Unexpected TX echo");else require(false,"Unknown RX status");return false;}
  require(!data.empty()&&bytes.size()+data.size()<=523,"Empty/oversized RX data");bytes.insert(bytes.end(),data.begin(),data.end());require(bytes[0]==0x80,"RX prefix");if(bytes.size()>=2)require(bytes[1]==0xf0,"RX direction");if(bytes.size()>=3)require(bytes[2]==0x10,"RX source");if(bytes.size()<4)return false;
  require(bytes[3]>0,"RX declared payload length");require(bytes.size()<=bytes[3]+5u,"RX trailing/duplicate data");return bytes.size()==bytes[3]+5u;
 }
};
inline Bytes payload(const Bytes& b){require(b.size()>=6&&b[0]==0x80&&b[1]==0xf0&&b[2]==0x10&&b.size()==b[3]+5u&&b.back()==checksum(Bytes(b.begin(),b.end()-1)),"RX framing/checksum");return Bytes(b.begin()+4,b.end()-1);}
