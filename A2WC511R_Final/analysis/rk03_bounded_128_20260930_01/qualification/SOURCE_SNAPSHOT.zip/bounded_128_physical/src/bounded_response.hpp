#pragma once
#include "common.hpp"
// Only the fixed pass0/address0/128-byte response is representable here.
// Data comparison occurs after complete framing validation so all mismatches survive.
struct BoundedReply {
 Bytes bytes;unsigned pieces=0,indicators=0;
 static Bytes request(){return decode("beef0008030000000000008038");}
 static Bytes expected(){return decode("beef008683000000000000000aacffffbfa000000aacffffbfa000000aa800000aa800000aa800000aa800000aa800000aa800000aa800000aa800000aa800000aa8ffffffffffffffffdf01442b00090000ffffbfa0df01000b00090000ffffbfa0e5f74518750a8451e3ff4318620c737f2239324ce13c622c4118321c25210009000900090009000b98");}
 bool consume(const PASSTHRU_MSG& m,const Bytes& tx){
  require(++pieces<=143,"Bounded RX message count bound");
  require(m.ProtocolID==3&&m.TxFlags==0&&m.DataSize<=139&&(m.ExtraDataIndex==0||m.ExtraDataIndex==m.DataSize),"Bounded RX metadata bounds");
  Bytes data(m.Data,m.Data+m.DataSize);
  if(m.RxStatus){
   require(bytes.empty()&&++indicators<=4,"Bounded RX indication position/count");
   if(m.RxStatus==START_OF_MESSAGE||m.RxStatus==TX_DONE)require(data.empty(),"Nonempty bounded indication");
   else if(m.RxStatus==TX_MSG_TYPE||m.RxStatus==(TX_MSG_TYPE|TX_DONE))require(data==tx,"Unexpected bounded TX echo");
   else require(false,"Unknown bounded RX status");
   return false;
  }
  require(!data.empty()&&bytes.size()+data.size()<=139,"Bounded reply exact maximum");
  bytes.insert(bytes.end(),data.begin(),data.end());
  const Bytes header=decode("beef0086830000000000");
  require(std::equal(bytes.begin(),bytes.begin()+std::min(bytes.size(),header.size()),header.begin()),"Fixed framing length command pass address");
  if(bytes.size()<139)return false;
  require(bytes.back()==checksum(Bytes(bytes.begin(),bytes.end()-1)),"Bounded response checksum");
  return true;
 }
};
