#pragma once
// Exact successful physical identity transcript used ONLY by the static fake.
// Source native_api.jsonl SHA256 e6ac67a41cc98433fc56f2d5d0d9a8144ce836678a31094a108aff4187662e09.
// Provider resource IDs map from original1/3/0/1 to fake700/701/702/703; recorded RX metadata is unchanged.
static constexpr const char* IDENTITY_PHYSICAL_VERSION_FIRMWARE="312e31372e343837370000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
static constexpr const char* IDENTITY_PHYSICAL_VERSION_DLL="312e30322e343837302046656220203320323031372032333a33363a30350000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
static constexpr const char* IDENTITY_PHYSICAL_VERSION_API="30342e3034000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
static constexpr const char* IDENTITY_PHYSICAL_KEY_TX="8010f0062702349c6319fb";
inline PASSTHRU_MSG identity_physical_replay_message(unsigned i){PASSTHRU_MSG m{};switch(i){
case 0:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3422908663UL;m.ExtraDataIndex=0;break;
case 1:set_message(m,decode("80f01039ffa210112f1251530673facba62b81fea800000060ce54f9b1e4000c200000000000dc00005d1f3080f226000043fb00e1000000000000c1f0c2"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3423038437UL;m.ExtraDataIndex=62;break;
case 2:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3423056517UL;m.ExtraDataIndex=0;break;
case 3:set_message(m,decode("80f01003c1ef8fc2"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3423073953UL;m.ExtraDataIndex=8;break;
case 4:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3423093535UL;m.ExtraDataIndex=0;break;
case 5:set_message(m,decode("80f01007c30000ff00ff0048"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3423119456UL;m.ExtraDataIndex=12;break;
case 6:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3423139495UL;m.ExtraDataIndex=0;break;
case 7:set_message(m,decode("80f010066701b8808513be"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3423162965UL;m.ExtraDataIndex=11;break;
case 8:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3423191683UL;m.ExtraDataIndex=0;break;
case 9:set_message(m,decode("80f0100367023420"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3423208968UL;m.ExtraDataIndex=8;break;
case 10:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3423431462UL;m.ExtraDataIndex=0;break;
case 11:set_message(m,decode("80f01002508557"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3423446993UL;m.ExtraDataIndex=7;break;
case 12:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3423765412UL;m.ExtraDataIndex=0;break;
case 13:set_message(m,decode("80f0100274847a"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3423770533UL;m.ExtraDataIndex=7;break;
case 14:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3423862927UL;m.ExtraDataIndex=0;break;
case 15:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3423867540UL;m.ExtraDataIndex=6;break;
case 16:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3423958077UL;m.ExtraDataIndex=0;break;
case 17:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3423962552UL;m.ExtraDataIndex=6;break;
case 18:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3424053162UL;m.ExtraDataIndex=0;break;
case 19:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3424057561UL;m.ExtraDataIndex=6;break;
case 20:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3424148695UL;m.ExtraDataIndex=0;break;
case 21:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3424153572UL;m.ExtraDataIndex=6;break;
case 22:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3424244292UL;m.ExtraDataIndex=0;break;
case 23:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3424249083UL;m.ExtraDataIndex=6;break;
case 24:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3424339695UL;m.ExtraDataIndex=0;break;
case 25:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3424344093UL;m.ExtraDataIndex=6;break;
case 26:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3424438619UL;m.ExtraDataIndex=0;break;
case 27:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3424443104UL;m.ExtraDataIndex=6;break;
case 28:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3424535626UL;m.ExtraDataIndex=0;break;
case 29:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3424540114UL;m.ExtraDataIndex=6;break;
case 30:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3424630707UL;m.ExtraDataIndex=0;break;
case 31:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3424635127UL;m.ExtraDataIndex=6;break;
case 32:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3424729695UL;m.ExtraDataIndex=0;break;
case 33:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3424734137UL;m.ExtraDataIndex=6;break;
case 34:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3424824911UL;m.ExtraDataIndex=0;break;
case 35:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3424829648UL;m.ExtraDataIndex=6;break;
case 36:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3424920443UL;m.ExtraDataIndex=0;break;
case 37:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3424925157UL;m.ExtraDataIndex=6;break;
case 38:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3425015975UL;m.ExtraDataIndex=0;break;
case 39:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3425020669UL;m.ExtraDataIndex=6;break;
case 40:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3425111380UL;m.ExtraDataIndex=0;break;
case 41:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3425116178UL;m.ExtraDataIndex=6;break;
case 42:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3425135441UL;m.ExtraDataIndex=0;break;
case 43:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3425140182UL;m.ExtraDataIndex=6;break;
case 44:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3425148876UL;m.ExtraDataIndex=0;break;
case 45:set_message(m,decode("80f01003710101f6"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3425154686UL;m.ExtraDataIndex=8;break;
case 46:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=3425161146UL;m.ExtraDataIndex=0;break;
case 47:set_message(m,decode("beef000f8141325743353131522d524b3032005f"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=3425165188UL;m.ExtraDataIndex=20;break;
default:require(false,"Fixed physical identity replay index");}return m;}
