#pragma once
// Pinned successful first-chunk physical receive records; replay only.
static constexpr const char* FIRST_VERSION_FIRMWARE="312e31372e343837370000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
static constexpr const char* FIRST_VERSION_DLL="312e30322e343837302046656220203320323031372032333a33363a30350000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
static constexpr const char* FIRST_VERSION_API="30342e3034000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
static constexpr const char* FIRST_PHYSICAL_KEY_TX="8010f00627024015f4978f";
inline PASSTHRU_MSG first_physical_replay_message(unsigned i){PASSTHRU_MSG m{};switch(i){
case 0:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=2140142023UL;m.ExtraDataIndex=0;break;
case 1:set_message(m,decode("80f01039ffa210112f1251530673facba62b81fea800000060ce54f9b1e4000c200000000000dc00005d1f3080f226000043fb00e1000000000000c1f0c2"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=2140271685UL;m.ExtraDataIndex=62;break;
case 2:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=2140290918UL;m.ExtraDataIndex=0;break;
case 3:set_message(m,decode("80f01003c1ef8fc2"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=2140308201UL;m.ExtraDataIndex=8;break;
case 4:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=2140330017UL;m.ExtraDataIndex=0;break;
case 5:set_message(m,decode("80f01007c30000ff00ff0048"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=2140355704UL;m.ExtraDataIndex=12;break;
case 6:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=2140375970UL;m.ExtraDataIndex=0;break;
case 7:set_message(m,decode("80f010066701a917a34fa0"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=2140399718UL;m.ExtraDataIndex=11;break;
case 8:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=2140427962UL;m.ExtraDataIndex=0;break;
case 9:set_message(m,decode("80f0100367023420"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=2140445216UL;m.ExtraDataIndex=8;break;
case 10:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=2140670852UL;m.ExtraDataIndex=0;break;
case 11:set_message(m,decode("80f01002508557"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=2140686242UL;m.ExtraDataIndex=7;break;
case 12:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=2141005702UL;m.ExtraDataIndex=0;break;
case 13:set_message(m,decode("80f0100274847a"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=2141010778UL;m.ExtraDataIndex=7;break;
case 14:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=2141103538UL;m.ExtraDataIndex=0;break;
case 15:set_message(m,decode("80f0100176f7"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=2141108289UL;m.ExtraDataIndex=6;break;
default:require(false,"First chunk replay bound");}return m;}
