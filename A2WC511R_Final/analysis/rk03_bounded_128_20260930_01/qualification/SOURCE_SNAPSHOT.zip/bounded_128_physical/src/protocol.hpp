#pragma once
#include "owned_artifact.h"
static Bytes key_for_seed(const Bytes& seed){
 require(seed.size()==4,"Four byte seed");static const unsigned t[]={5,6,7,1,9,12,13,8,10,13,2,11,15,4,0,3,11,4,6,0,15,2,13,9,5,12,1,10,3,13,14,8};
 static const unsigned keys[]={0x88F0,0x6E74,0x6B70,0x3563,0x9D34,0xDBA3,0x503D,0xAFB8,0x3608,0x834F,0x3382,0x7CA3,0x437D,0x72EB,0x33BC,0x53DA};
 unsigned left=seed[0]*256+seed[1],right=seed[2]*256+seed[3];
 for(auto key:keys){unsigned expand=(right^key)*0x10001u,value=0;for(unsigned shift:{0u,4u,8u,12u})value|=t[(expand>>shift)&31]<<shift;value=((value>>3)|(value<<13))&0xFFFF;unsigned old=right;right=left^value;left=old;}
 return {static_cast<unsigned char>(right>>8),static_cast<unsigned char>(right),static_cast<unsigned char>(left>>8),static_cast<unsigned char>(left)};
}

inline Bytes frame(Bytes body){require(!body.empty()&&body.size()<=255,"Fixed frame payload bound");Bytes wire={0x80,0x10,0xf0,static_cast<unsigned char>(body.size())};wire.insert(wire.end(),body.begin(),body.end());wire.push_back(checksum(wire));return wire;}
