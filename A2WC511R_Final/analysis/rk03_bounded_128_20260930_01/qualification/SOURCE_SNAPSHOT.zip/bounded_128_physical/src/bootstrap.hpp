#pragma once
#include "common.hpp"
#include "pins.hpp"
#include <bcrypt.h>
#include <io.h>
#include <fcntl.h>
struct Handle{HANDLE value=INVALID_HANDLE_VALUE;explicit Handle(HANDLE h=INVALID_HANDLE_VALUE):value(h){}~Handle(){if(value!=INVALID_HANDLE_VALUE&&value)CloseHandle(value);}Handle(const Handle&)=delete;Handle& operator=(const Handle&)=delete;};
struct Module{HMODULE value=nullptr;~Module(){if(value)FreeLibrary(value);}};
struct Journal{FILE* value=nullptr;~Journal(){if(value)fclose(value);}void create(const wchar_t* path){HANDLE h=CreateFileW(path,GENERIC_WRITE,0,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr);require(h!=INVALID_HANDLE_VALUE,"Exclusive new journal required");int fd=_open_osfhandle(reinterpret_cast<intptr_t>(h),_O_BINARY|_O_WRONLY);if(fd<0){CloseHandle(h);require(false,"Journal descriptor failure");}value=_fdopen(fd,"wb");if(!value){_close(fd);require(false,"Journal stream failure");}}};
inline std::string ascii(const wchar_t* s){std::string out;while(*s){require(*s>0&&*s<128,"ASCII mode/fixture argument required");out+=static_cast<char>(*s++);}return out;}
inline std::wstring running_executable(){wchar_t path[32768];DWORD chars=GetModuleFileNameW(nullptr,path,32768);require(chars>0&&chars<32768,"Running executable path failure");return std::wstring(path,chars);}
inline std::string sha256(HANDLE file){
 LARGE_INTEGER start{};require(SetFilePointerEx(file,start,nullptr,FILE_BEGIN)!=0,"Hash rewind failed");BCRYPT_ALG_HANDLE alg=nullptr;BCRYPT_HASH_HANDLE hash=nullptr;Bytes object;
 require(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,nullptr,0)==0,"SHA256 algorithm failure");
 try{DWORD bytes=0,size=0;require(BCryptGetProperty(alg,BCRYPT_OBJECT_LENGTH,reinterpret_cast<PUCHAR>(&size),sizeof(size),&bytes,0)==0,"SHA256 property failure");object.resize(size);require(BCryptCreateHash(alg,&hash,object.data(),size,nullptr,0,0)==0,"SHA256 creation failure");unsigned char buffer[65536];
  for(;;){DWORD n=0;require(ReadFile(file,buffer,sizeof(buffer),&n,nullptr)!=0,"Hash file read failure");if(!n)break;require(BCryptHashData(hash,buffer,n,0)==0,"SHA256 update failure");}
  unsigned char digest[32];require(BCryptFinishHash(hash,digest,sizeof(digest),0)==0,"SHA256 finish failure");BCryptDestroyHash(hash);hash=nullptr;BCryptCloseAlgorithmProvider(alg,0);alg=nullptr;return hex(digest,sizeof(digest));
 }catch(...){if(hash)BCryptDestroyHash(hash);if(alg)BCryptCloseAlgorithmProvider(alg,0);throw;}
}
inline HANDLE locked_read(const std::wstring& p){HANDLE h=CreateFileW(p.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);require(h!=INVALID_HANDLE_VALUE,"Required pinned file absent/unreadable");return h;}
inline std::string read_bounded(HANDLE file){LARGE_INTEGER size{};require(GetFileSizeEx(file,&size)&&size.QuadPart>=0&&size.QuadPart<=1024,"Authorization/reservation size");std::string text(static_cast<size_t>(size.QuadPart),'\0');DWORD count=0;require(ReadFile(file,text.data(),static_cast<DWORD>(text.size()),&count,nullptr)&&count==text.size(),"Authorization/reservation read");return text;}
inline void write_new(const std::wstring& path,const std::string& text){Handle h(CreateFileW(path.c_str(),GENERIC_WRITE,0,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr));require(h.value!=INVALID_HANDLE_VALUE,"Exclusive new file required");DWORD written=0;require(WriteFile(h.value,text.data(),static_cast<DWORD>(text.size()),&written,nullptr)&&written==text.size()&&FlushFileBuffers(h.value),"New file persistence failure");}
struct Bindings{std::wstring session,executable,contract,provider;std::string session_id,token,contract_sha,provider_sha;};
inline Bindings physical_bindings(){return {SESSION_PATH,running_executable(),CONTRACT_PATH,PROVIDER_PATH,SESSION_ID,AUTH_TOKEN,CONTRACT_SHA,PROVIDER_SHA};}
struct Gate{
 Handle exe,contract,authorization,reservation,marker,provider;std::string exe_sha;std::string phase="NONE";bool marker_consumed=false,provider_file_opened=false;
 void prepare(const Bindings& b,const std::wstring& supplied_session,const std::wstring& supplied_authorization){
  phase="FIXED_PATH";require(supplied_session==b.session&&supplied_authorization==b.session+L"\\AUTHORIZATION.txt","Fixed session and authorization path required");
  phase="EXE_HASH";exe.value=locked_read(b.executable);exe_sha=sha256(exe.value);
  phase="CONTRACT_HASH";contract.value=locked_read(b.contract);require(sha256(contract.value)==b.contract_sha,"Pinned contract SHA256 mismatch");
  phase="AUTHORIZATION";authorization.value=locked_read(b.session+L"\\AUTHORIZATION.txt");const std::string expected=b.token+"\nSESSION_ID="+b.session_id+"\nEXE_SHA256="+exe_sha+"\nCONTRACT_SHA256="+b.contract_sha+"\n";require(read_bounded(authorization.value)==expected,"Authorization exact content mismatch");
  phase="ROOT_RESERVATION";reservation.value=locked_read(b.session+L"\\launch.reserved");const std::string text=b.session_id+"\n"+exe_sha+"\n"+b.contract_sha+"\n";require(read_bounded(reservation.value)==text,"Root launch reservation mismatch");
  phase="NATIVE_ONCE";marker.value=CreateFileW((b.session+L"\\invocation.once").c_str(),GENERIC_WRITE,0,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr);require(marker.value!=INVALID_HANDLE_VALUE,"Native invocation already consumed; no retry");marker_consumed=true;DWORD written=0;require(WriteFile(marker.value,text.data(),static_cast<DWORD>(text.size()),&written,nullptr)&&written==text.size()&&FlushFileBuffers(marker.value),"Native reservation persistence failure");
  phase="NATIVE_RESERVED";
 }
 void lock_provider(const Bindings& b){phase="PROVIDER_HASH";provider.value=locked_read(b.provider);provider_file_opened=true;require(sha256(provider.value)==b.provider_sha,"Fixed provider SHA256 mismatch");phase="PROVIDER_HASH_ACCEPTED";}
};
template<class T,class F> T symbol(F resolver,const char* name){auto address=resolver(name);require(address!=nullptr,"Fixed provider missing required export");static_assert(sizeof(T)==sizeof(address),"Export pointer ABI");T result;memcpy(&result,&address,sizeof(result));return result;}
template<class F> Api resolve_api(F resolver,long (*wait)(U),unsigned long long (*clock)()){return {symbol<PF_PassThruOpen*>(resolver,"PassThruOpen"),symbol<PF_PassThruClose*>(resolver,"PassThruClose"),symbol<PF_PassThruConnect*>(resolver,"PassThruConnect"),symbol<PF_PassThruDisconnect*>(resolver,"PassThruDisconnect"),symbol<PF_PassThruReadMsgs*>(resolver,"PassThruReadMsgs"),symbol<PF_PassThruWriteMsgs*>(resolver,"PassThruWriteMsgs"),symbol<PF_PassThruStartMsgFilter*>(resolver,"PassThruStartMsgFilter"),symbol<PF_PassThruStopMsgFilter*>(resolver,"PassThruStopMsgFilter"),symbol<PF_PassThruReadVersion*>(resolver,"PassThruReadVersion"),symbol<PF_PassThruIoctl*>(resolver,"PassThruIoctl"),wait,clock};}
