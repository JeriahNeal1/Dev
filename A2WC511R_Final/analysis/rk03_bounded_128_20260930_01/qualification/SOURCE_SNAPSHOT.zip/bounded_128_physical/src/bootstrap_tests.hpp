#pragma once
#include "bootstrap.hpp"
namespace bootstrap_test {
static const char* CASES[]={"valid_gates_no_load","wrong_session_path","wrong_auth_path","missing_auth","malformed_auth","wrong_exe_hash","wrong_auth_contract","wrong_contract_hash","missing_contract","missing_reservation","wrong_reservation","consumed_marker","wrong_provider_hash","missing_provider","missing_export_open","missing_export_close","missing_export_connect","missing_export_disconnect","missing_export_read","missing_export_write","missing_export_filter","missing_export_stop_filter","missing_export_version","missing_export_ioctl"};
inline bool accepted(const std::string& name){for(auto s:CASES)if(name==s)return true;return false;}
inline std::string file_sha(const std::wstring& path){Handle h(locked_read(path));return sha256(h.value);}
inline int run(const std::string& name,const std::wstring& journal_path){
 require(accepted(name),"Unknown offline bootstrap fixture");Journal journal;journal.create(journal_path.c_str());
 const std::wstring folder=journal_path+L".fixture";require(folder!=SESSION_PATH,"Offline bootstrap cannot use real session");require(CreateDirectoryW(folder.c_str(),nullptr)!=0,"New isolated bootstrap fixture directory required");
 Bindings b{folder,folder+L"\\fixture_executable.bin",folder+L"\\fixture_contract.json",folder+L"\\fixture_provider.bin","OFFLINE_BOOTSTRAP_FIXTURE","OFFLINE_BOOTSTRAP_TEST_ONLY","",""};
 write_new(b.executable,"OFFLINE DUMMY EXECUTABLE BYTES; NEVER EXECUTED\n");write_new(b.contract,"OFFLINE DUMMY CONTRACT BYTES\n");write_new(b.provider,"OFFLINE DUMMY PROVIDER BYTES; NEVER LOADED\n");
 const auto expected_exe=file_sha(b.executable);b.contract_sha=file_sha(b.contract);b.provider_sha=file_sha(b.provider);
 auto auth_exe=name=="wrong_exe_hash"?std::string(64,'0'):expected_exe;auto auth_contract=name=="wrong_auth_contract"?std::string(64,'0'):b.contract_sha;
 std::string auth=b.token+"\nSESSION_ID="+b.session_id+"\nEXE_SHA256="+auth_exe+"\nCONTRACT_SHA256="+auth_contract+"\n";
 if(name=="malformed_auth")auth+="EXTRA_LINE\n";
 if(name!="missing_auth")write_new(folder+L"\\AUTHORIZATION.txt",auth);
 std::string reserved=b.session_id+"\n"+expected_exe+"\n"+b.contract_sha+"\n";
 if(name=="wrong_reservation")reserved+="EXTRA_LINE\n";
 if(name!="missing_reservation")write_new(folder+L"\\launch.reserved",reserved);
 if(name=="consumed_marker")write_new(folder+L"\\invocation.once","PREVIOUS OFFLINE FIXTURE INVOCATION\n");
 if(name=="wrong_contract_hash")b.contract_sha=std::string(64,'0');if(name=="wrong_provider_hash")b.provider_sha=std::string(64,'0');
 if(name=="missing_contract")b.contract+=L".absent";if(name=="missing_provider")b.provider+=L".absent";
 const std::wstring supplied_session=name=="wrong_session_path"?folder+L".wrong":folder;
 const std::wstring supplied_auth=name=="wrong_auth_path"?folder+L"\\WRONG_AUTHORIZATION.txt":folder+L"\\AUTHORIZATION.txt";
 Gate gate;bool reached_no_load=false;std::string error;std::vector<std::string> requested_exports;
 try{
  gate.prepare(b,supplied_session,supplied_auth);gate.lock_provider(b);gate.phase="EXPORTS";
  const char* labels[]={"open","close","connect","disconnect","read","write","filter","stop_filter","version","ioctl"};
  const char* exports[]={"PassThruOpen","PassThruClose","PassThruConnect","PassThruDisconnect","PassThruReadMsgs","PassThruWriteMsgs","PassThruStartMsgFilter","PassThruStopMsgFilter","PassThruReadVersion","PassThruIoctl"};
  auto resolver=[&](const char* symbol_name)->FARPROC{requested_exports.push_back(symbol_name);for(unsigned i=0;i<10;i++)if(!strcmp(symbol_name,exports[i])&&name==std::string("missing_export_")+labels[i])return nullptr;uintptr_t address=1;FARPROC dummy;memcpy(&dummy,&address,sizeof(dummy));return dummy;};
  // The same required-export validation is exercised, but these dummy pointers are never invoked.
  (void)resolve_api(resolver,nullptr,nullptr);gate.phase="OFFLINE_HARD_STOP_BEFORE_LOADER";reached_no_load=true;
 }catch(const std::exception& e){error=e.what();}
 std::string export_json="[";for(size_t i=0;i<requested_exports.size();i++){if(i)export_json+=',';export_json+=quote(requested_exports[i]);}export_json+=']';
 const bool pass=name=="valid_gates_no_load"?reached_no_load:!reached_no_load;
 std::string record="{\"type\":\"offline_bootstrap_result\",\"physical\":false,\"fixture\":"+quote(name)+",\"status\":"+quote(pass?"PASS_OFFLINE_BOOTSTRAP_TEST":"FAIL_OFFLINE_BOOTSTRAP_TEST")+",\"phase\":"+quote(gate.phase)+",\"reached_hard_stop\":"+boolean(reached_no_load)+",\"marker_consumed\":"+boolean(gate.marker_consumed)+",\"provider_file_opened\":"+boolean(gate.provider_file_opened)+",\"provider_load_attempts\":0,\"api_calls\":0,\"fixture_token\":\"OFFLINE_BOOTSTRAP_TEST_ONLY\",\"requested_exports\":"+export_json+",\"error\":"+quote(error)+"}\n";
 require(fwrite(record.data(),1,record.size(),journal.value)==record.size()&&fflush(journal.value)==0,"Bootstrap fixture journal failure");printf("%s\n",pass?"PASS_OFFLINE_BOOTSTRAP_TEST":"FAIL_OFFLINE_BOOTSTRAP_TEST");return pass?0:1;
}
}
