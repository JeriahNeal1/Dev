#pragma once
#include "common.hpp"
#include "protocol.hpp"
#include "identity_response.hpp"
#include "bounded_response.hpp"
struct Probe{
 bool kernel_filter=false,filter_stop_attempted=false,start_acknowledged=false,identity_validated=false;unsigned acknowledged_chunks=0;
 bool bounded_validated=false;
 Bytes key_request;U requested_baud=4800;bool baud_accepted=false;unsigned clear_mask=0;
 Api api;FILE* journal;bool physical;bool real_clock=false;long long last_elapsed_ticks=0,last_qpc_frequency=0;bool inject_log_failure=false;bool opened=false,connected=false,filtered=false,protocol_complete=false,log_failed=false;
 U device=SENTINEL,channel=SENTINEL,filter=SENTINEL;unsigned next_tx=0,sequence=0,requested_count=0,set_success_count=0,cleanup_errors=0;
 bool get_observed=false,get_valid=false,filter_requested=false,filter_objects_valid=false;SCONFIG observed[5]{};PASSTHRU_MSG observed_mask{},observed_pattern{},observed_flow{};char failure[256]{};
 Probe(Api a,FILE* j,bool p,bool real=false):api(a),journal(j),physical(p),real_clock(real){require(!p||real,"Physical mode requires monotonic minimum waits");}
 Bytes request(unsigned stage)const{
  require(stage<25,"One fixed128 read is the final protocol action");
  if(stage==24){require(identity_validated&&kernel_filter&&filtered&&requested_baud==62500,"Read only after exact identity");return BoundedReply::request();}
  if(stage==22){require(acknowledged_chunks==15,"All fifteen ACKs before fixed start");return decode("8010f003310101b6");}
  if(stage==23){require(start_acknowledged&&kernel_filter&&filtered&&requested_baud==62500,"Identity follows reviewed start transition");return decode("beef000101af");}
  if(stage==0)return frame({0xbf});if(stage==1)return frame({0x81});if(stage==2)return frame({0x83,0});if(stage==3)return frame({0x27,1});
  if(stage==4){require(key_request.size()==6,"Key must derive from validated seed");return frame(key_request);}if(stage==5)return frame({0x10,0x85,2});
  if(stage==6)return frame({0x34,0xff,0x30,0,4,static_cast<unsigned char>(KERNEL_SIZE>>16),static_cast<unsigned char>(KERNEL_SIZE>>8),static_cast<unsigned char>(KERNEL_SIZE)});
  static_assert(KERNEL_SIZE==1808&&sizeof(KERNEL_CIPHER)==1808,"Pinned owned kernel size");
  const unsigned offset=(stage-7)*128;const unsigned length=std::min(128u,KERNEL_SIZE-offset);
  require(stage>=7&&stage<22&&offset<KERNEL_SIZE&&offset+length<=KERNEL_SIZE,"Fixed chunk bounds");
  const unsigned address=0xff3000+offset;Bytes chunk={0x36,static_cast<unsigned char>(address>>16),static_cast<unsigned char>(address>>8),static_cast<unsigned char>(address)};
  chunk.insert(chunk.end(),KERNEL_CIPHER+offset,KERNEL_CIPHER+offset+length);return frame(chunk);
 }

 std::string state()const{std::string requested="[",returned=get_observed?"[":"null";for(unsigned i=0;i<requested_count;i++){if(i)requested+=',';requested+="{\"parameter\":"+number(SERIAL[i].Parameter)+",\"value\":"+number(SERIAL[i].Value)+"}";}requested+=']';if(get_observed){for(unsigned i=0;i<5;i++){if(i)returned+=',';returned+="{\"parameter\":"+number(observed[i].Parameter)+",\"value\":"+number(observed[i].Value)+"}";}returned+=']';}
 return "{"+std::string(real_clock?"\"clock_model\":\"QPC_MONOTONIC_MINIMUM\",\"monotonic_ms\":":"\"clock_model\":\"VIRTUAL_ONLY_NOT_PHYSICAL_TIME\",\"virtual_ms\":")+number(api.virtual_ms())+",\"requested_baud\":"+number(requested_baud)+",\"baud_set_accepted\":"+boolean(baud_accepted)+",\"clear_mask\":"+number(clear_mask)+",\"connection_contract\":{\"protocol\":3,\"flags\":512,\"baud\":4800},\"opened\":"+boolean(opened)+",\"device\":"+number(device)+",\"connected\":"+boolean(connected)+",\"channel\":"+number(channel)+",\"kernel_filter\":"+boolean(kernel_filter)+",\"filter_stop_attempted\":"+boolean(filter_stop_attempted)+",\"acknowledged_chunks\":"+number(acknowledged_chunks)+",\"start_acknowledged\":"+boolean(start_acknowledged)+",\"identity_validated\":"+boolean(identity_validated)+",\"bounded_validated\":"+boolean(bounded_validated)+",\"tx_attempts\":"+number(next_tx)+",\"requested_configuration\":"+requested+",\"successful_set_calls\":"+number(set_success_count)+",\"observed_configuration\":"+returned+",\"effective_configuration_valid\":"+boolean(get_valid)+",\"filter\":{\"requested\":"+boolean(filter_requested)+",\"active\":"+boolean(filtered)+",\"id\":"+number(filter)+",\"type\":1,\"requested_mask_hex\":"+quote(kernel_filter?"ffff":"00000000")+",\"requested_pattern_hex\":"+quote(kernel_filter?"beef":"00000000")+",\"requested_flow_hex\":"+(kernel_filter?std::string("null"):quote("00000000"))+",\"protocol\":3,\"flags\":0,\"returned_objects_valid\":"+boolean(filter_objects_valid)+",\"observed_mask\":"+(filter_requested?message_json(observed_mask):"null")+",\"observed_pattern\":"+(filter_requested?message_json(observed_pattern):"null")+",\"observed_flow\":"+(filter_requested&&!kernel_filter?message_json(observed_flow):"null")+"}}";}
 void event(const std::string& s){if(!physical&&inject_log_failure&&filtered){inject_log_failure=false;throw std::runtime_error("Offline injected journal failure after filter allocation");}require(fwrite(s.data(),1,s.size(),journal)==s.size()&&fwrite("\n",1,1,journal)==1&&fflush(journal)==0,"Journal persistence failure");}
 template<class F,class O> long call(const char* name,const std::string& input,F fn,O output,bool cleanup=false){
  unsigned seq=sequence++;std::string prefix="\"sequence\":"+number(seq)+",\"function\":"+quote(name)+",\"physical\":"+boolean(physical);
  try{event("{\"type\":\"api_intent\","+prefix+",\"utc_filetime\":"+number(utc())+",\"host_event_counter\":"+std::to_string(qpc())+",\"input\":"+input+",\"state\":"+state()+"}");}catch(...){log_failed=true;if(!cleanup)throw;}
  uintptr_t before=0,after=0;__asm{mov before,esp}
  LARGE_INTEGER begin,end;QueryPerformanceCounter(&begin);
  long result=fn();
  QueryPerformanceCounter(&end);
  __asm{mov after,esp}
  last_elapsed_ticks=end.QuadPart-begin.QuadPart;last_qpc_frequency=frequency();
  // Allocation ownership/output snapshot is established before journal errors can throw.
  const std::string returned_output=output(result);
  try{event("{\"type\":\"api_return\","+prefix+",\"status\":"+std::to_string(result)+",\"input\":"+input+",\"output\":"+returned_output+",\"qpc_before\":"+std::to_string(begin.QuadPart)+",\"qpc_after\":"+std::to_string(end.QuadPart)+",\"qpc_frequency\":"+std::to_string(frequency())+",\"api_elapsed_ticks\":"+std::to_string(end.QuadPart-begin.QuadPart)+",\"utc_filetime\":"+number(utc())+",\"esp_before\":"+number(before)+",\"esp_after\":"+number(after)+",\"state\":"+state()+"}");}catch(...){log_failed=true;if(!cleanup)throw;}
  if(before!=after){if(cleanup){log_failed=true;}else require(false,"J2534 stack imbalance");}
  return result;
 }
 static void ok(long status){require(status==0,"J2534 nonzero status; terminal without retry");}
 void setup(){
  ok(call("PassThruOpen","{\"name_present\":false,\"device_output_present\":true}",[&](){return api.open(nullptr,&device);},[&](long s){if(!s)opened=true;return "{\"device\":"+number(device)+"}";}));
  VersionBuffer versions;
  ok(call("PassThruReadVersion","{\"device\":"+number(device)+",\"firmware_capacity\":80,\"dll_capacity\":80,\"api_capacity\":80}",[&](){return api.version(device,versions.firmware,versions.dll,versions.api);},[&](long){return "{\"firmware\":"+version_part(versions.firmware)+",\"dll\":"+version_part(versions.dll)+",\"api\":"+version_part(versions.api)+",\"canaries_intact\":"+boolean(versions.intact())+"}";}));
  require(versions.intact()&&memchr(versions.firmware,0,80)&&memchr(versions.dll,0,80)&&memchr(versions.api,0,80),"ReadVersion bounds");
  ok(call("PassThruConnect","{\"device\":"+number(device)+",\"protocol\":3,\"flags\":512,\"baud\":4800,\"channel_output_present\":true}",[&](){return api.connect(device,3,512,4800,&channel);},[&](long s){if(!s)connected=true;return "{\"channel\":"+number(channel)+"}";}));
  for(auto item:SERIAL){ConfigBuffer b;b.items[0]=item;b.list.NumOfParams=1;requested_count++;std::string input="{\"channel\":"+number(channel)+",\"ioctl\":2,\"input_present\":true,\"output_present\":false,\"config\":"+config_json(b.list,b.items,1)+"}";
   ok(call("PassThruIoctl",input,[&](){return api.ioctl(channel,2,&b.list,nullptr);},[&](long s){if(!s)set_success_count++;return "{\"config\":"+config_json(b.list,b.items,1)+",\"canaries_intact\":"+boolean(b.intact())+"}";}));
   require(b.intact()&&b.list.NumOfParams==1&&b.list.ConfigPtr==b.items&&b.items[0].Parameter==item.Parameter&&b.items[0].Value==item.Value,"SET_CONFIG mutation");
  }
  ConfigBuffer get;
  ok(call("PassThruIoctl","{\"channel\":"+number(channel)+",\"ioctl\":1,\"input_present\":true,\"output_present\":false,\"config\":"+config_json(get.list,get.items,5)+"}",[&](){return api.ioctl(channel,1,&get.list,nullptr);},[&](long s){get_observed=true;memcpy(observed,get.items,sizeof(observed));get_valid=!s&&get.intact()&&get.list.NumOfParams==5&&get.list.ConfigPtr==get.items;for(unsigned i=0;i<5;i++)get_valid=get_valid&&get.items[i].Parameter==SERIAL[i].Parameter&&get.items[i].Value==SERIAL[i].Value;return "{\"config\":"+config_json(get.list,get.items,5)+",\"canaries_intact\":"+boolean(get.intact())+"}";}));
  require(get.intact()&&get.list.NumOfParams==5&&get.list.ConfigPtr==get.items,"GET_CONFIG list integrity");require(get_valid,"GET_CONFIG effective value/parameter mismatch");
  Message mask,pattern,flow;set_message(mask.value,{0,0,0,0});set_message(pattern.value,{0,0,0,0});set_message(flow.value,{0,0,0,0});
  std::string input="{\"channel\":"+number(channel)+",\"filter_type\":1,\"mask_present\":true,\"pattern_present\":true,\"flow_present\":true,\"filter_output_present\":true,\"mask\":"+message_json(mask.value)+",\"pattern\":"+message_json(pattern.value)+",\"flow\":"+message_json(flow.value)+"}";
  const PASSTHRU_MSG expected_filter=mask.value;filter_requested=true;
  ok(call("PassThruStartMsgFilter",input,[&](){return api.filter(channel,1,&mask.value,&pattern.value,&flow.value,&filter);},[&](long s){if(!s)filtered=true;observed_mask=mask.value;observed_pattern=pattern.value;observed_flow=flow.value;filter_objects_valid=mask.intact()&&pattern.intact()&&flow.intact()&&!memcmp(&mask.value,&expected_filter,sizeof(expected_filter))&&!memcmp(&pattern.value,&expected_filter,sizeof(expected_filter))&&!memcmp(&flow.value,&expected_filter,sizeof(expected_filter));return "{\"filter_id\":"+number(filter)+",\"mask\":"+message_json(mask.value)+",\"pattern\":"+message_json(pattern.value)+",\"flow\":"+message_json(flow.value)+",\"canaries_intact\":"+boolean(mask.intact()&&pattern.intact()&&flow.intact())+"}";}));
  require(filter_objects_valid,"Filter output mutation/ABI bounds");
 }
 Bytes exchange(unsigned stage){
  require(stage==next_tx&&stage<25,"Fixed transmit order/count guard");Message tx;set_message(tx.value,request(stage));U count=1;
  const std::string input="{\"channel\":"+number(channel)+",\"timeout_ms\":1000,\"count_pointer_present\":true,\"input_count\":1,\"message_capacity\":1,\"message\":"+message_json(tx.value)+"}";
  require(stage==next_tx&&next_tx<25&&Bytes(tx.value.Data,tx.value.Data+tx.value.DataSize)==request(stage),"Dispatch whitelist guard");const PASSTHRU_MSG expected_tx=tx.value;
  ok(call("PassThruWriteMsgs",input,[&](){return api.write(channel,&tx.value,&count,1000);},[&](long){next_tx++;return "{\"count\":"+number(count)+",\"message\":"+message_json(tx.value)+",\"canaries_intact\":"+boolean(tx.intact())+"}";}));
  require(tx.intact()&&count==1&&!memcmp(&tx.value,&expected_tx,sizeof(expected_tx)),"TX output count/mutation/ABI");Stream stream;IdentityReply identity;BoundedReply bounded;ULONGLONG deadline=GetTickCount64()+2000;
  for(;;){ULONGLONG now=GetTickCount64();require(now<deadline,"Whole frame deadline");U timeout=static_cast<U>(std::min<ULONGLONG>(1000,deadline-now));Message rx;count=1;
   ok(call("PassThruReadMsgs","{\"channel\":"+number(channel)+",\"timeout_ms\":"+number(timeout)+",\"input_count\":1,\"count_pointer_present\":true,\"message_capacity\":1,\"message\":"+message_json(rx.value)+"}",[&](){return api.read(channel,&rx.value,&count,timeout);},[&](long){return "{\"count\":"+number(count)+",\"message\":"+message_json(rx.value)+",\"canaries_intact\":"+boolean(rx.intact())+"}";}));
   require(GetTickCount64()<deadline,"Whole frame deadline after API return");require(rx.intact()&&count==1,"RX count/ABI bounds");if(stage==24){if(bounded.consume(rx.value,request(stage)))return bounded.bytes;}else if(stage==23){if(identity.consume(rx.value,request(stage)))return identity.bytes;}else if(stream.consume(rx.value,request(stage)))return stream.bytes;
  }
 }
 template<class F> long cleanup_call(const char* name,const char* resource,U id,bool has_filter,bool& owned,F fn){
  // Optional state serialization is caught independently; the C logging fallback never suppresses cleanup.
  unsigned seq=sequence++;const char* p=physical?"true":"false";
  std::string snapshot;const char* recorded="null";try{snapshot=state();recorded=snapshot.c_str();}catch(...){log_failed=true;}
  int n=fprintf(journal,"{\"type\":\"api_intent\",\"sequence\":%u,\"function\":\"%s\",\"physical\":%s,\"cleanup\":true,\"utc_filetime\":%llu,\"host_event_counter\":%lld,\"input\":{\"%s\":%lu,\"filter_id_present\":%s,\"filter_id\":%lu},\"state\":%s}\n",seq,name,p,utc(),qpc(),resource,id,has_filter?"true":"false",has_filter?filter:0,recorded);
  if(n<0||fflush(journal))log_failed=true;
  LARGE_INTEGER begin,end;QueryPerformanceCounter(&begin);long result=fn();QueryPerformanceCounter(&end);
  if(!result)owned=false;recorded="null";try{snapshot=state();recorded=snapshot.c_str();}catch(...){log_failed=true;}
  n=fprintf(journal,"{\"type\":\"api_return\",\"sequence\":%u,\"function\":\"%s\",\"physical\":%s,\"cleanup\":true,\"status\":%ld,\"input\":{\"%s\":%lu,\"filter_id_present\":%s,\"filter_id\":%lu},\"output\":{},\"qpc_before\":%lld,\"qpc_after\":%lld,\"qpc_frequency\":%lld,\"api_elapsed_ticks\":%lld,\"utc_filetime\":%llu,\"state\":%s}\n",seq,name,p,result,resource,id,has_filter?"true":"false",has_filter?filter:0,begin.QuadPart,end.QuadPart,frequency(),end.QuadPart-begin.QuadPart,utc(),recorded);
  if(n<0||fflush(journal))log_failed=true;return result;
 }
 void cleanup(){
  if(filtered&&!filter_stop_attempted){filter_stop_attempted=true;if(cleanup_call("PassThruStopMsgFilter","channel",channel,true,filtered,[&](){return api.stop_filter(channel,filter);}))cleanup_errors|=1;}
  if(connected){if(cleanup_call("PassThruDisconnect","channel",channel,false,connected,[&](){return api.disconnect(channel);}))cleanup_errors|=2;}
  if(opened){if(cleanup_call("PassThruClose","device",device,false,opened,[&](){return api.close(device);}))cleanup_errors|=4;}
 }


 void wait(unsigned ms,const char* reason){
  const auto before=api.virtual_ms();const auto hz=frequency();require(hz>0,"Monotonic frequency");const auto minimum=(static_cast<unsigned long long>(hz)*ms+999)/1000;
  std::string input="{\"model\":"+quote(real_clock?"QPC_MONOTONIC_MINIMUM":"VIRTUAL_ONLY_NOT_PHYSICAL_TIME")+",\"milliseconds\":"+number(ms)+",\"requested_ms\":"+number(ms)+",\"reason\":"+quote(reason)+(real_clock?",\"monotonic_before_ms\":":",\"virtual_before\":")+number(before)+"}";
  ok(call(real_clock?"MonotonicMinimumWait":"OfflineClockAdvance",input,[&](){return api.wait_ms(ms);},[&](long){if(!real_clock)return "{\"virtual_after\":"+number(api.virtual_ms())+"}";return "{\"monotonic_after_ms\":"+number(api.virtual_ms())+",\"requested_ms\":"+number(ms)+",\"minimum_qpc_ticks\":"+number(minimum)+",\"elapsed_qpc_ticks\":"+std::to_string(last_elapsed_ticks)+",\"qpc_frequency\":"+std::to_string(last_qpc_frequency)+",\"overshoot_qpc_ticks\":"+std::to_string(last_elapsed_ticks-static_cast<long long>(minimum))+",\"minimum_satisfied\":"+boolean(last_elapsed_ticks>=static_cast<long long>(minimum))+"}";}));
  require(api.virtual_ms()>=before+ms,"Requested minimum wait not satisfied by selected clock");
  if(real_clock)require(last_elapsed_ticks>=static_cast<long long>(minimum),"Actual QPC minimum wait not satisfied");
 }
 void change_baud_and_clear(){
  requested_baud=15625;ConfigBuffer b;b.list.NumOfParams=1;b.items[0]={1,15625};
  ok(call("PassThruIoctl","{\"channel\":"+number(channel)+",\"ioctl\":2,\"input_present\":true,\"output_present\":false,\"config\":"+config_json(b.list,b.items,1)+"}",[&](){return api.ioctl(channel,2,&b.list,nullptr);},[&](long s){baud_accepted=!s;return "{\"config\":"+config_json(b.list,b.items,1)+",\"canaries_intact\":"+boolean(b.intact())+"}";}));
  require(b.intact()&&b.list.NumOfParams==1&&b.list.ConfigPtr==b.items&&b.items[0].Parameter==1&&b.items[0].Value==15625,"Baud SET_CONFIG mutation");
  for(U code:{7UL,8UL})ok(call("PassThruIoctl","{\"channel\":"+number(channel)+",\"ioctl\":"+number(code)+",\"input_present\":false,\"output_present\":false}",[&](){return api.ioctl(channel,code,nullptr,nullptr);},[&](long s){if(!s)clear_mask|=code==7?1:2;return "{}";}));
 }

 void identity_transport(){
  require(next_tx==23&&start_acknowledged&&filtered&&!filter_stop_attempted,"Start ACK precedes transition");
  long stopped=call("PassThruStopMsgFilter","{\"channel\":"+number(channel)+",\"filter_id\":"+number(filter)+"}",[&](){filter_stop_attempted=true;return api.stop_filter(channel,filter);},[&](long s){if(!s)filtered=false;else cleanup_errors|=1;return "{}";});ok(stopped);
  requested_baud=62500;baud_accepted=false;ConfigBuffer b;b.list.NumOfParams=1;b.items[0]={1,62500};
  ok(call("PassThruIoctl","{\"channel\":"+number(channel)+",\"ioctl\":2,\"input_present\":true,\"output_present\":false,\"config\":"+config_json(b.list,b.items,1)+"}",[&](){return api.ioctl(channel,2,&b.list,nullptr);},[&](long s){baud_accepted=!s;return "{\"config\":"+config_json(b.list,b.items,1)+",\"canaries_intact\":"+boolean(b.intact())+"}";}));
  require(b.intact()&&b.list.NumOfParams==1&&b.list.ConfigPtr==b.items&&b.items[0].Parameter==1&&b.items[0].Value==62500,"Identity baud SET_CONFIG mutation");
  Message mask,pattern;set_message(mask.value,{0xff,0xff});set_message(pattern.value,{0xbe,0xef});const auto expected_mask=mask.value,expected_pattern=pattern.value;
  kernel_filter=true;filter_requested=true;filter_objects_valid=false;filter_stop_attempted=false;
  std::string input="{\"channel\":"+number(channel)+",\"filter_type\":1,\"mask_present\":true,\"pattern_present\":true,\"flow_present\":false,\"filter_output_present\":true,\"mask\":"+message_json(mask.value)+",\"pattern\":"+message_json(pattern.value)+",\"flow\":null}";
  ok(call("PassThruStartMsgFilter",input,[&](){return api.filter(channel,1,&mask.value,&pattern.value,nullptr,&filter);},[&](long s){if(!s)filtered=true;observed_mask=mask.value;observed_pattern=pattern.value;observed_flow={};filter_objects_valid=mask.intact()&&pattern.intact()&&!memcmp(&mask.value,&expected_mask,sizeof(expected_mask))&&!memcmp(&pattern.value,&expected_pattern,sizeof(expected_pattern));return "{\"filter_id\":"+number(filter)+",\"mask\":"+message_json(mask.value)+",\"pattern\":"+message_json(pattern.value)+",\"flow\":null,\"canaries_intact\":"+boolean(mask.intact()&&pattern.intact())+"}";}));
  require(filter_objects_valid,"Identity filter output mutation/ABI bounds");
 }

 int run(){
  try{setup();auto id=payload(exchange(0));require(id.size()==57&&Bytes(id.begin(),id.begin()+4)==Bytes({0xff,0xa2,0x10,0x11})&&Bytes(id.begin()+4,id.begin()+9)==Bytes({0x2f,0x12,0x51,0x53,0x06}),"Wrong BF identity");
   require(payload(exchange(1))==Bytes({0xc1,0xef,0x8f}),"Malformed/unexpected 81 response");require(payload(exchange(2))==Bytes({0xc3,0,0,0xff,0,0xff,0}),"Malformed/unexpected 83 response");
   auto seed=payload(exchange(3));require(seed.size()==6&&seed[0]==0x67&&seed[1]==1,"Seed response length/SID/subfunction");key_request={0x27,2};auto key=key_for_seed(Bytes(seed.begin()+2,seed.end()));key_request.insert(key_request.end(),key.begin(),key.end());
   require(payload(exchange(4))==Bytes({0x67,2,0x34}),"Key ACK must be exact670234");wait(200,"post_key_ack");
   require(payload(exchange(5))==Bytes({0x50,0x85}),"Session ACK must be exact5085");wait(100,"post_session_ack");change_baud_and_clear();wait(200,"pre_download_declaration");
   require(payload(exchange(6))==Bytes({0x74,0x84}),"Download ACK must be exact7484");for(unsigned stage=7;stage<22;stage++){require(payload(exchange(stage))==Bytes({0x76}),"Each fixed chunk ACK must be exact76");acknowledged_chunks++;}
   require(payload(exchange(22))==Bytes({0x71,1,1}),"Exact fixed start ACK");start_acknowledged=true;identity_transport();
   require(exchange(23)==IdentityReply::expected(),"Exact pinned kernel identity including NUL");identity_validated=true;
   const Bytes reply=exchange(24),expected=BoundedReply::expected();std::string differences="[";unsigned mismatches=0;
   for(unsigned i=0;i<128;i++)if(reply[10+i]!=expected[10+i]){if(mismatches++)differences+=',';differences+="{\"address\":"+number(i)+",\"expected\":"+number(expected[10+i])+",\"actual\":"+number(reply[10+i])+"}";}differences+=']';
   event("{\"type\":\"bounded_read_result\",\"address\":0,\"length\":128,\"request_hex\":"+quote(hex(BoundedReply::request().data(),13))+",\"response_hex\":"+quote(hex(reply.data(),reply.size()))+",\"payload_hex\":"+quote(hex(reply.data()+10,128))+",\"checksum_pass\":true,\"mismatch_count\":"+number(mismatches)+",\"mismatches\":"+differences+"}");
   require(reply==expected,"Returned128 bytes differ from pinned current.bin");bounded_validated=true;protocol_complete=true;
  }catch(const std::exception& e){strncpy_s(failure,e.what(),_TRUNCATE);}
  cleanup();bool pass=!failure[0]&&!cleanup_errors&&!log_failed&&protocol_complete;
  try{event("{\"type\":\"probe_terminal\",\"physical\":"+boolean(physical)+",\"status\":"+quote(pass?(physical?"PASS_BOUNDED_ROM_READ_128_ONLY":"PASS_OFFLINE_BOUNDED_ROM_READ_128_ONLY"):"FAIL_TERMINAL")+",\"protocol_complete\":"+boolean(protocol_complete)+",\"cleanup_confirmed\":"+boolean(!opened&&!connected&&!filtered)+",\"cleanup_error_mask\":"+number(cleanup_errors)+",\"log_failed\":"+boolean(log_failed)+",\"failure\":"+quote(failure)+",\"state\":"+state()+"}");}catch(...){pass=false;}
  printf("%s physical=%s tx_attempts=%u\n",pass?(physical?"PASS_BOUNDED_ROM_READ_128_ONLY":"PASS_OFFLINE_BOUNDED_ROM_READ_128_ONLY"):"FAIL_TERMINAL",physical?"true":"false",next_tx);return pass?0:1;
 }
};
