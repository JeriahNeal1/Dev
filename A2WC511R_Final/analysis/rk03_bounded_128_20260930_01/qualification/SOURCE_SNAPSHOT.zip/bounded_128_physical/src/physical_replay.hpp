#pragma once
// Exact retained physical version buffers and six received records; fake handles are separately mapped.
static constexpr const char* PHYSICAL_VERSION_FIRMWARE="312e31372e343837370000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
static constexpr const char* PHYSICAL_VERSION_DLL="312e30322e343837302046656220203320323031372032333a33363a30350000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
static constexpr const char* PHYSICAL_VERSION_API="30342e3034000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
inline PASSTHRU_MSG physical_replay_message(unsigned i){PASSTHRU_MSG m{};switch(i){
case 0:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=1307635543;m.ExtraDataIndex=0;break;
case 1:set_message(m,decode("80f01039ffa210112f1251530673facba62b81fea800000060ce54f9b1e4000c200000000000dc00005d1f3080f226000043fb00e1000000000000c1f0c2"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=1307765064;m.ExtraDataIndex=62;break;
case 2:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=1307783393;m.ExtraDataIndex=0;break;
case 3:set_message(m,decode("80f01003c1ef8fc2"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=1307800580;m.ExtraDataIndex=8;break;
case 4:set_message(m,decode(""));m.ProtocolID=3;m.RxStatus=2;m.TxFlags=0;m.Timestamp=1307820413;m.ExtraDataIndex=0;break;
case 5:set_message(m,decode("80f01007c30000ff00ff0048"));m.ProtocolID=3;m.RxStatus=0;m.TxFlags=0;m.Timestamp=1307846085;m.ExtraDataIndex=12;break;
default:require(false,"Physical replay message bound");}return m;}
