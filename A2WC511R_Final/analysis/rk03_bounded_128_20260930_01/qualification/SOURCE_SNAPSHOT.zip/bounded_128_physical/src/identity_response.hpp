#pragma once
#include "common.hpp"
// Receive validation only. The sole accepted body is 81 + the pinned RK02
// identity including its terminating NUL. No generic kernel command parser.
struct IdentityReply {
 Bytes bytes;unsigned pieces=0,indicators=0;
 static Bytes expected(){return decode("beef000f8141325743353131522d524b3032005f");}
 bool consume(const PASSTHRU_MSG& m,const Bytes& tx){
  require(++pieces<=24,"Identity RX message count bound");
  require(m.ProtocolID==3&&m.TxFlags==0&&m.DataSize<=20&&(m.ExtraDataIndex==0||m.ExtraDataIndex==m.DataSize),"Identity RX metadata bounds");
  Bytes data(m.Data,m.Data+m.DataSize);
  if(m.RxStatus){
   require(bytes.empty()&&++indicators<=4,"Identity RX indication position/count");
   if(m.RxStatus==START_OF_MESSAGE||m.RxStatus==TX_DONE)require(data.empty(),"Nonempty identity indication");
   else if(m.RxStatus==TX_MSG_TYPE||m.RxStatus==(TX_MSG_TYPE|TX_DONE))require(data==tx,"Unexpected identity TX echo");
   else require(false,"Unknown identity RX status");
   return false;
  }
  require(!data.empty()&&bytes.size()+data.size()<=20,"Identity exact reply maximum");
  bytes.insert(bytes.end(),data.begin(),data.end());
  const Bytes wanted=expected();
  // Prefix comparison fixes marker, length, status, identity, NUL and checksum.
  require(std::equal(bytes.begin(),bytes.end(),wanted.begin()),"Exact fixed identity prefix");
  if(bytes.size()<20)return false;
  require(bytes.back()==checksum(Bytes(bytes.begin(),bytes.end()-1)),"Identity checksum");
  return true;
 }
};
