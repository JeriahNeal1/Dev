#pragma once
#include "common.hpp"
#include "fixtures.hpp"
#include "physical_replay.hpp"
#include "first_physical_replay.hpp"
#include "full_physical_replay.hpp"
#include "identity_physical_replay.hpp"
#include "bounded_response.hpp"
#include <deque>
// This backend is linked into the same PE. No provider module, registry, device or DLL lookup occurs here.
namespace fake {
static const char* CASES[]={
 "failed512_reference","bounded_data_all","physical_identity_replay","bounded_success","bounded_fragmented","bounded_indicators_fragmented","bounded_echo","bounded_multirecord","bounded_extra_index_size","bounded_som","bounded_short","bounded_long","bounded_double_frame","bounded_wrong_pass","bounded_wrong_address","bounded_wrong_length","bounded_zero_length","bounded_oversized_length","bounded_wrong_header","bounded_wrong_command","bounded_checksum","bounded_rx_oversize","bounded_empty","bounded_protocol","bounded_flags","bounded_extra_index","bounded_indicator_flood","bounded_indicator_after_data","bounded_echo_after_data","bounded_wrong_echo","bounded_partial_echo","bounded_combined_echo","bounded_nonempty_indicator","bounded_combined_status","bounded_unknown_status","bounded_no_reply","bounded_late_reply","bounded_read_error","bounded_status16","bounded_timeout_status","bounded_count_zero","bounded_count_large","bounded_truncated_header","bounded_write_fail","bounded_write_count_zero","bounded_write_count_large","bounded_write_mutation","bounded_cleanup_stop_fail","bounded_cleanup_disconnect_fail","bounded_cleanup_close_fail","bounded_cleanup_all_fail",
 "physical_full_upload_replay","identity_fragmented","identity_indicators_fragmented","identity_split_1","identity_split_2","identity_split_3","identity_split_4","identity_split_5","identity_split_6","identity_split_7","identity_split_8","identity_split_9","identity_split_10","identity_split_11","identity_split_12","identity_split_13","identity_split_14","identity_split_15","identity_split_16","identity_split_17","identity_split_18","identity_split_19","bad_ack_22","bad_ack_23","negative_ack_22","negative_ack_23","bad_checksum_22","bad_checksum_23","status16_22","status16_23","truncated_22","truncated_23","short_ack_22","short_ack_23","extra_ack_22","extra_ack_23","write_fail_22","write_fail_23","write_count_zero_22","write_count_zero_23","write_count_large_22","write_count_large_23","write_mutation_22","write_mutation_23","transition_stop_fail","kernel_baud_fail","kernel_baud_mutation","kernel_filter_fail","kernel_filter_mutation","start_late_reply","identity_wrong_identity","identity_wrong_version","identity_missing_nul","identity_bad_length","identity_zero_length","identity_oversized_length","identity_trailing","identity_double_frame","identity_wrong_header","identity_negative_reply","identity_empty","identity_protocol","identity_flags","identity_extra_index","identity_indicator_flood","identity_indicator_after_data","identity_wrong_echo","identity_nonempty_indicator","identity_combined_status","identity_unknown_status","identity_count_zero","identity_count_large","identity_read_error","identity_no_reply","identity_late_reply",
 "physical_first_chunk_replay","bad_ack_8","bad_ack_9","bad_ack_10","bad_ack_11","bad_ack_12","bad_ack_13","bad_ack_14","bad_ack_15","bad_ack_16","bad_ack_17","bad_ack_18","bad_ack_19","bad_ack_20","bad_ack_21","negative_ack_8","negative_ack_9","negative_ack_10","negative_ack_11","negative_ack_12","negative_ack_13","negative_ack_14","negative_ack_15","negative_ack_16","negative_ack_17","negative_ack_18","negative_ack_19","negative_ack_20","negative_ack_21","bad_checksum_8","bad_checksum_9","bad_checksum_10","bad_checksum_11","bad_checksum_12","bad_checksum_13","bad_checksum_14","bad_checksum_15","bad_checksum_16","bad_checksum_17","bad_checksum_18","bad_checksum_19","bad_checksum_20","bad_checksum_21","status16_8","status16_9","status16_10","status16_11","status16_12","status16_13","status16_14","status16_15","status16_16","status16_17","status16_18","status16_19","status16_20","status16_21","truncated_8","truncated_9","truncated_10","truncated_11","truncated_12","truncated_13","truncated_14","truncated_15","truncated_16","truncated_17","truncated_18","truncated_19","truncated_20","truncated_21","short_ack_8","short_ack_9","short_ack_10","short_ack_11","short_ack_12","short_ack_13","short_ack_14","short_ack_15","short_ack_16","short_ack_17","short_ack_18","short_ack_19","short_ack_20","short_ack_21","extra_ack_8","extra_ack_9","extra_ack_10","extra_ack_11","extra_ack_12","extra_ack_13","extra_ack_14","extra_ack_15","extra_ack_16","extra_ack_17","extra_ack_18","extra_ack_19","extra_ack_20","extra_ack_21","write_fail_8","write_fail_9","write_fail_10","write_fail_11","write_fail_12","write_fail_13","write_fail_14","write_fail_15","write_fail_16","write_fail_17","write_fail_18","write_fail_19","write_fail_20","write_fail_21","write_count_zero_8","write_count_zero_9","write_count_zero_10","write_count_zero_11","write_count_zero_12","write_count_zero_13","write_count_zero_14","write_count_zero_15","write_count_zero_16","write_count_zero_17","write_count_zero_18","write_count_zero_19","write_count_zero_20","write_count_zero_21","write_count_large_8","write_count_large_9","write_count_large_10","write_count_large_11","write_count_large_12","write_count_large_13","write_count_large_14","write_count_large_15","write_count_large_16","write_count_large_17","write_count_large_18","write_count_large_19","write_count_large_20","write_count_large_21","write_mutation_8","write_mutation_9","write_mutation_10","write_mutation_11","write_mutation_12","write_mutation_13","write_mutation_14","write_mutation_15","write_mutation_16","write_mutation_17","write_mutation_18","write_mutation_19","write_mutation_20","write_mutation_21",
 "physical_transition_replay",
 "success","fragmented","indicators_fragmented","version_nonascii","extra_index_size",
 "physical_83_buffer_empty","wrong_bf","wrong_81","wrong_83","bad_checksum_bf","bad_checksum_81","bad_checksum_83","unexpected_frame",
 "open_fail","version_fail","version_unterminated","connect_fail",
 "set_fail_0","set_fail_1","set_fail_2","set_fail_3","set_fail_4","set_mutation",
 "get_fail","get_wrong_0","get_wrong_1","get_wrong_2","get_wrong_3","get_wrong_4","get_sentinel","get_count_zero","get_count_large","get_pointer_null","get_pointer_invalid","get_parameter",
 "filter_fail","filter_mutation","write_fail","write_count_zero","write_count_large","write_mutation",
 "read_count_zero","read_count_large","read_error_output","rx_oversize","rx_protocol","rx_flags","rx_extra","rx_unknown_status","rx_combined_status","rx_nonempty_indicator","rx_wrong_echo","rx_indicator_flood","rx_indicator_after_data","rx_empty","rx_trailing","rx_wrong_direction","rx_zero_length","rx_marker_only",
 "cleanup_stop_fail","cleanup_disconnect_fail","cleanup_close_fail","cleanup_all_fail","physical_83_cleanup_all_fail","journal_failure_after_filter",
 "queued_stale_rx","fail_baud","mutate_baud","clear_tx_fail","clear_rx_fail","wait_fail_0","wait_fail_1","wait_fail_2","wait_short_0","wait_short_1","wait_short_2","bad_ack_3","bad_ack_4","bad_ack_5","bad_ack_6","bad_ack_7","negative_ack_3","negative_ack_4","negative_ack_5","negative_ack_6","negative_ack_7","bad_checksum_3","bad_checksum_4","bad_checksum_5","bad_checksum_6","bad_checksum_7","status16_3","status16_4","status16_5","status16_6","status16_7","truncated_3","truncated_4","truncated_5","truncated_6","truncated_7","short_ack_4","short_ack_5","short_ack_6","extra_ack_7","upload_unknown_status","upload_wrong_echo","seed_vector_0","seed_vector_1","seed_vector_2","seed_vector_3","seed_vector_4","seed_vector_5","seed_vector_6","seed_vector_7","seed_vector_8","seed_vector_9","seed_vector_10","seed_vector_11","seed_vector_12","seed_vector_13","seed_vector_14","seed_vector_15","seed_short","seed_extra","seed_wrong_subfunction","upload_rx_extra"
};
inline bool accepted(const std::string& name){for(auto s:CASES)if(name==s)return true;for(unsigned i=1;i<139;i++)if(name=="bounded_split_"+std::to_string(i))return true;for(unsigned i=0;i<128;i++)if(name=="bounded_data_"+std::to_string(i))return true;return false;}
struct State{std::string name;unsigned sets=0,writes=0,waits=0,clears=0;unsigned long long virtual_now=0;bool baud=false,kernel_baud=false,kernel_filtered=false,old_filter_stopped=false;U active_filter=0;bool got=false,filtered=false;std::array<U,5> config={{1,20,55,5,1}};std::deque<PASSTHRU_MSG> queue;};
inline State& state(){static State s;return s;}
inline bool is(const char* name){return state().name==name;}
inline bool index(const char* prefix,unsigned i){return state().name==std::string(prefix)+std::to_string(i);}
inline void select(const std::string& name){require(accepted(name),"Unknown offline fixture");state()=State{};state().name=name;}
inline long PT_CALL open(const void* name,U* id){if(name||!id)return 7;if(is("open_fail"))return 7;*id=700;return 0;}
inline long PT_CALL close(U id){if(id!=700)return 7;return is("cleanup_close_fail")||is("cleanup_all_fail")||is("physical_83_cleanup_all_fail")||is("bounded_cleanup_close_fail")||is("bounded_cleanup_all_fail")?7:0;}
inline long PT_CALL version(U id,char* fw,char* dll,char* api){if(id!=700||!fw||!dll||!api)return 7;strcpy_s(fw,80,"OFFLINE_FAKE_FIRMWARE");strcpy_s(dll,80,"OFFLINE_FAKE_DLL");strcpy_s(api,80,"04.04");if(is("physical_transition_replay")){auto f=decode(PHYSICAL_VERSION_FIRMWARE),d=decode(PHYSICAL_VERSION_DLL),a=decode(PHYSICAL_VERSION_API);memcpy(fw,f.data(),80);memcpy(dll,d.data(),80);memcpy(api,a.data(),80);}if(is("physical_first_chunk_replay")){auto f=decode(FIRST_VERSION_FIRMWARE),d=decode(FIRST_VERSION_DLL),a=decode(FIRST_VERSION_API);memcpy(fw,f.data(),80);memcpy(dll,d.data(),80);memcpy(api,a.data(),80);}if(is("physical_full_upload_replay")){auto f=decode(FULL_VERSION_FIRMWARE),d=decode(FULL_VERSION_DLL),a=decode(FULL_VERSION_API);memcpy(fw,f.data(),80);memcpy(dll,d.data(),80);memcpy(api,a.data(),80);}if(is("physical_identity_replay")){auto f=decode(IDENTITY_PHYSICAL_VERSION_FIRMWARE),d=decode(IDENTITY_PHYSICAL_VERSION_DLL),a=decode(IDENTITY_PHYSICAL_VERSION_API);memcpy(fw,f.data(),80);memcpy(dll,d.data(),80);memcpy(api,a.data(),80);}if(is("version_unterminated"))memset(dll,'X',80);if(is("version_nonascii"))dll[0]=static_cast<char>(0xff);return is("version_fail")?7:0;}
inline long PT_CALL connect(U id,U protocol,U flags,U baud,U* channel){if(id!=700||protocol!=3||flags!=512||baud!=4800||!channel)return 7;if(is("connect_fail"))return 7;*channel=701;return 0;}
inline long PT_CALL disconnect(U channel){if(channel!=701)return 7;return is("cleanup_disconnect_fail")||is("cleanup_all_fail")||is("physical_83_cleanup_all_fail")||is("bounded_cleanup_disconnect_fail")||is("bounded_cleanup_all_fail")?7:0;}
inline long PT_CALL ioctl(U channel,U code,const void* input,void* output){
 if(channel!=701||output)return 7;
 if(code==7||code==8){auto& x=state();if(input||!x.baud||x.writes!=6||x.waits!=2||code!=7+x.clears)return 7;if((code==7&&is("clear_tx_fail"))||(code==8&&is("clear_rx_fail")))return 7;if(code==8)x.queue.clear();x.clears++;return 0;}
 if(!input)return 7;auto list=const_cast<SCONFIG_LIST*>(static_cast<const SCONFIG_LIST*>(input));if(!list->ConfigPtr)return 7;auto& s=state();
 if(code==2&&list->NumOfParams==1&&list->ConfigPtr[0].Parameter==1){if(list->ConfigPtr[0].Value==62500){if(s.writes!=23||!s.old_filter_stopped||s.filtered||s.waits!=3||s.virtual_now!=500)return 7;if(is("kernel_baud_fail"))return 7;s.kernel_baud=true;if(is("kernel_baud_mutation"))list->ConfigPtr[0].Value=62501;return 0;}if(s.writes!=6||s.waits!=2||s.virtual_now!=300||list->ConfigPtr[0].Value!=15625)return 7;if(is("fail_baud"))return 7;s.baud=true;if(is("mutate_baud"))list->ConfigPtr[0].Value=15626;if(is("queued_stale_rx")){PASSTHRU_MSG stale{};stale.ProtocolID=3;stale.DataSize=1;stale.Data[0]=0xff;s.queue.push_back(stale);}return 0;}
 if(code==2){unsigned i=s.sets;if(i>=5||list->NumOfParams!=1||list->ConfigPtr[0].Parameter!=SERIAL[i].Parameter||list->ConfigPtr[0].Value!=SERIAL[i].Value)return 7;if(index("set_fail_",i))return 7;s.config[i]=list->ConfigPtr[0].Value;s.sets++;if(is("set_mutation"))list->ConfigPtr[0].Value=99;return 0;}
 if(code!=1||s.sets!=5||list->NumOfParams!=5)return 7;
 for(unsigned i=0;i<5;i++)if(list->ConfigPtr[i].Parameter!=SERIAL[i].Parameter||list->ConfigPtr[i].Value!=SENTINEL)return 7;
 for(unsigned i=0;i<5;i++){if(!is("get_sentinel"))list->ConfigPtr[i].Value=s.config[i];if(index("get_wrong_",i))list->ConfigPtr[i].Value=99;}
 if(is("get_parameter"))list->ConfigPtr[2].Parameter=99;
 if(is("get_count_zero"))list->NumOfParams=0;if(is("get_count_large"))list->NumOfParams=6;
 if(is("get_pointer_null"))list->ConfigPtr=nullptr;if(is("get_pointer_invalid"))list->ConfigPtr=reinterpret_cast<SCONFIG*>(1);
 s.got=true;return is("get_fail")?7:0;
}
inline bool zero_filter(const void* object){if(!object)return false;auto p=static_cast<const PASSTHRU_MSG*>(object);PASSTHRU_MSG expected{};set_message(expected,{0,0,0,0});return !memcmp(p,&expected,sizeof(expected));}
inline long PT_CALL filter(U channel,U type,const void* mask,const void* pattern,const void* flow,U* id){
 if(state().writes==23){auto& s=state();if(channel!=701||type!=1||!s.kernel_baud||!s.old_filter_stopped||s.filtered||!mask||!pattern||flow||!id)return 7;PASSTHRU_MSG em{},ep{};set_message(em,{0xff,0xff});set_message(ep,{0xbe,0xef});if(memcmp(mask,&em,sizeof(em))||memcmp(pattern,&ep,sizeof(ep)))return 7;if(is("kernel_filter_fail"))return 7;*id=703;s.active_filter=703;s.filtered=true;s.kernel_filtered=true;if(is("kernel_filter_mutation"))const_cast<PASSTHRU_MSG*>(static_cast<const PASSTHRU_MSG*>(pattern))->Data[0]^=1;return 0;}
 if(channel!=701||type!=1||!state().got||!zero_filter(mask)||!zero_filter(pattern)||!zero_filter(flow)||!id)return 7;
 if(is("filter_fail"))return 7;*id=702;state().active_filter=702;state().filtered=true;if(is("filter_mutation"))const_cast<PASSTHRU_MSG*>(static_cast<const PASSTHRU_MSG*>(flow))->Data[0]=1;return 0;
}
inline long PT_CALL stop_filter(U channel,U id){auto& s=state();if(channel!=701||!s.filtered||id!=s.active_filter)return 7;
 if(id==702&&s.writes==23&&is("transition_stop_fail"))return 7;
 if(is("physical_83_cleanup_all_fail")||(id==703&&(is("cleanup_stop_fail")||is("cleanup_all_fail")||is("bounded_cleanup_stop_fail")||is("bounded_cleanup_all_fail"))))return 7;
 s.filtered=false;if(id==702&&s.writes==23)s.old_filter_stopped=true;return 0;}

inline PASSTHRU_MSG message(const Bytes& bytes,U status=0){PASSTHRU_MSG m{};set_message(m,bytes);m.RxStatus=status;m.Timestamp=1234;return m;}
inline long PT_CALL write(U channel,const void* input,U* count,U timeout){
 auto& s=state();if(channel!=701||!input||!count||*count!=1||timeout!=1000||!s.filtered||!s.got||s.writes>=25||!s.queue.empty())return 7;
 // Intentionally incompatible fixture initial values are not claims about actual provider defaults.
 for(unsigned i=0;i<5;i++)if(s.config[i]!=SERIAL[i].Value)return 7;
 auto m=static_cast<const PASSTHRU_MSG*>(input);auto tx=s.writes<22?decode(EXPECTED_TX[s.writes]):(s.writes==24?BoundedReply::request():decode(s.writes==22?"8010f003310101b6":"beef000101af"));if(s.writes==4)for(unsigned v=0;v<16;v++)if(index("seed_vector_",v))tx=decode(KEY_TX[v]);if(s.writes==4&&is("physical_first_chunk_replay"))tx=decode(FIRST_PHYSICAL_KEY_TX);if(s.writes==4&&is("physical_full_upload_replay"))tx=decode(FULL_PHYSICAL_KEY_TX);if(s.writes==4&&is("physical_identity_replay"))tx=decode(IDENTITY_PHYSICAL_KEY_TX);if(m->ProtocolID!=3||m->RxStatus||m->TxFlags||m->ExtraDataIndex||m->DataSize!=tx.size()||memcmp(m->Data,tx.data(),tx.size()))return 7;
 if(s.writes==5&&(s.waits!=1||s.virtual_now<200))return 7;
 if(s.writes>=6&&(!s.baud||s.clears!=2||s.waits!=3||s.virtual_now<500))return 7;
 if(s.writes>=23&&(!s.kernel_baud||!s.kernel_filtered||s.active_filter!=703))return 7;
 unsigned stage=s.writes++;if(stage==24){if(is("bounded_write_fail"))return 7;if(is("bounded_write_count_zero")){*count=0;return 0;}if(is("bounded_write_count_large")){*count=2;return 0;}if(is("bounded_write_mutation")){const_cast<PASSTHRU_MSG*>(m)->Data[0]^=1;return 0;}}if(is("write_fail")||index("write_fail_",stage))return 7;if(is("write_count_zero")||index("write_count_zero_",stage)){*count=0;return 0;}if(is("write_count_large")||index("write_count_large_",stage)){*count=2;return 0;}if(is("write_mutation")||index("write_mutation_",stage)){const_cast<PASSTHRU_MSG*>(m)->Data[0]^=1;return 0;}
 if(stage<24&&is("physical_identity_replay")){s.queue.push_back(identity_physical_replay_message(stage*2));s.queue.push_back(identity_physical_replay_message(stage*2+1));return 0;}
 if(stage<22&&is("physical_full_upload_replay")){s.queue.push_back(full_physical_replay_message(stage*2));s.queue.push_back(full_physical_replay_message(stage*2+1));return 0;}
 if(stage<8&&is("physical_first_chunk_replay")){s.queue.push_back(first_physical_replay_message(stage*2));s.queue.push_back(first_physical_replay_message(stage*2+1));return 0;}
 if(stage<3&&is("physical_transition_replay")){s.queue.push_back(physical_replay_message(stage*2));s.queue.push_back(physical_replay_message(stage*2+1));return 0;}
 if(stage==2&&(is("physical_83_buffer_empty")||is("physical_83_cleanup_all_fail")))return 0;
 if(index("status16_",stage))return 0;
 Bytes b=stage<22?decode(REPLY_HEX[stage]):(stage==24?BoundedReply::expected():decode(stage==22?"80f01003710101f6":"beef000f8141325743353131522d524b3032005f"));if(stage==3)for(unsigned v=0;v<16;v++)if(index("seed_vector_",v))b=decode(SEED_RX[v]);
 if(stage==3&&is("seed_short")){b.erase(b.end()-2);b[3]--;b.back()=checksum(Bytes(b.begin(),b.end()-1));}
 if(stage==3&&is("seed_extra")){b.insert(b.end()-1,0);b[3]++;b.back()=checksum(Bytes(b.begin(),b.end()-1));}
 if(stage==3&&is("seed_wrong_subfunction")){b[5]=2;b.back()=checksum(Bytes(b.begin(),b.end()-1));}
 if(index("bad_ack_",stage)){b[4]^=1;b.back()=checksum(Bytes(b.begin(),b.end()-1));}
 if(index("negative_ack_",stage)){b={0x80,0xf0,0x10,3,0x7f,tx[4],0x22};b.push_back(checksum(b));}
 if(index("bad_checksum_",stage))b.back()^=1;
 if(index("truncated_",stage)){s.queue.push_back(message(Bytes(b.begin(),b.begin()+3)));return 0;}
 if(index("short_ack_",stage)){b.erase(b.end()-2);b[3]--;b.back()=checksum(Bytes(b.begin(),b.end()-1));}
 if(index("extra_ack_",stage)){b.insert(b.end()-1,0);b[3]++;b.back()=checksum(Bytes(b.begin(),b.end()-1));}
 

 if(stage==24){
  if(is("failed512_reference")){auto som=message({},START_OF_MESSAGE);som.Timestamp=2603231369;s.queue.push_back(som);auto data=message(decode("beef020683000000000000000aacffffbfa000000aacffffbfa000000aa800000aa800000aa800000aa800000aa800000aa800000aa800000aa800000aa800000aa8ffffffffffffffffdf01442b00090000ffffbfa0df01000b00090000ffffbfa0e5f74518750a8451e3ff4318620c737f2239324ce13c622c4118321c25210009000900090009000b0009ffff8441600c937f20388b04d643947c917c412be506000b00098441600c937320388b04d63e94729170412be506000b0009d33b7402d23b2342d13b412b6422634392614f227ff81f418431600c202988048b0c6433b0f8"));data.Timestamp=2603268720;data.ExtraDataIndex=data.DataSize;s.queue.push_back(data);return 0;}
  if(is("bounded_no_reply"))return 0;
  if(is("bounded_short"))b.pop_back();
  if(is("bounded_long"))b.push_back(0);
  if(is("bounded_double_frame")){auto second=b;b.insert(b.end(),second.begin(),second.end());}
  bool recalc=false;
  if(is("bounded_wrong_pass")){b[5]^=1;recalc=true;}
  if(is("bounded_wrong_address")){b[9]^=1;recalc=true;}
  if(is("bounded_wrong_length")){b[3]^=1;recalc=true;}
  if(is("bounded_zero_length")){b[2]=b[3]=0;recalc=true;}
  if(is("bounded_oversized_length")){b[2]=b[3]=0xff;recalc=true;}
  if(is("bounded_wrong_header")){b[0]^=1;recalc=true;}
  if(is("bounded_wrong_command")){b[4]^=1;recalc=true;}
  for(unsigned offset=0;offset<128;offset++)if(index("bounded_data_",offset)||is("bounded_data_all")){b[10+offset]^=1;recalc=true;}
  if(recalc)b.back()=checksum(Bytes(b.begin(),b.end()-1));
  if(is("bounded_checksum"))b.back()^=1;
  if(is("bounded_truncated_header")){s.queue.push_back(message(Bytes(b.begin(),b.begin()+3)));return 0;}
  if(is("bounded_indicator_flood")){for(unsigned i=0;i<5;i++)s.queue.push_back(message({},START_OF_MESSAGE));return 0;}
  if(is("bounded_indicator_after_data")||is("bounded_echo_after_data")){s.queue.push_back(message({b[0]}));s.queue.push_back(is("bounded_echo_after_data")?message(tx,TX_MSG_TYPE):message({},START_OF_MESSAGE));return 0;}
  if(is("bounded_echo"))s.queue.push_back(message(tx,TX_MSG_TYPE));
  if(is("bounded_som"))s.queue.push_back(message({},START_OF_MESSAGE));
  if(is("bounded_indicators_fragmented")){s.queue.push_back(message({},START_OF_MESSAGE));s.queue.push_back(message({},TX_DONE));s.queue.push_back(message(tx,TX_MSG_TYPE));s.queue.push_back(message(tx,TX_MSG_TYPE|TX_DONE));}
  if(is("bounded_fragmented")||is("bounded_indicators_fragmented")){for(auto byte:b)s.queue.push_back(message({byte}));return 0;}
  if(is("bounded_multirecord")){const unsigned cuts[]={1,2,5,13,32,64,22};unsigned offset=0;for(auto size:cuts){s.queue.push_back(message(Bytes(b.begin()+offset,b.begin()+offset+size)));offset+=size;}require(offset==b.size(),"Bounded multirecord fixture size");return 0;}
  for(unsigned split=1;split<139;split++)if(index("bounded_split_",split)){s.queue.push_back(message(Bytes(b.begin(),b.begin()+split)));s.queue.push_back(message(Bytes(b.begin()+split,b.end())));return 0;}
  auto rx=message(b);
  if(is("bounded_extra_index_size")||is("physical_identity_replay"))rx.ExtraDataIndex=rx.DataSize;
  if(is("bounded_rx_oversize"))rx.DataSize=5000;if(is("bounded_empty"))rx.DataSize=0;
  if(is("bounded_protocol"))rx.ProtocolID=4;if(is("bounded_flags"))rx.TxFlags=1;if(is("bounded_extra_index"))rx.ExtraDataIndex=1;
  if(is("bounded_wrong_echo")){rx=message(tx,TX_MSG_TYPE);rx.Data[0]^=1;}
  if(is("bounded_partial_echo"))rx=message(Bytes(tx.begin(),tx.end()-1),TX_MSG_TYPE);
  if(is("bounded_combined_echo")){auto combined=tx;combined.insert(combined.end(),b.begin(),b.end());rx=message(combined,TX_MSG_TYPE);}
  if(is("bounded_nonempty_indicator"))rx.RxStatus=START_OF_MESSAGE;if(is("bounded_combined_status"))rx.RxStatus=3;if(is("bounded_unknown_status"))rx.RxStatus=0x100;
  s.queue.push_back(rx);return 0;
 }

 if(stage==23){
  if(is("identity_no_reply"))return 0;
  if(is("identity_wrong_identity")){b[5]^=1;b.back()=checksum(Bytes(b.begin(),b.end()-1));}
  if(is("identity_wrong_version")){b[17]^=1;b.back()=checksum(Bytes(b.begin(),b.end()-1));}
  if(is("identity_missing_nul")){b[18]=1;b.back()=checksum(Bytes(b.begin(),b.end()-1));}
  if(is("identity_bad_length"))b[3]=14;if(is("identity_zero_length"))b[3]=0;if(is("identity_oversized_length"))b[2]=1;
  if(is("identity_trailing"))b.push_back(0);if(is("identity_double_frame")){auto copy=b;b.insert(b.end(),copy.begin(),copy.end());}
  if(is("identity_wrong_header"))b[0]=0xbf;if(is("identity_negative_reply")){b[4]=0x7f;b.back()=checksum(Bytes(b.begin(),b.end()-1));}
  if(is("identity_indicator_flood")){for(unsigned i=0;i<5;i++)s.queue.push_back(message({},START_OF_MESSAGE));return 0;}
  if(is("identity_indicator_after_data")){s.queue.push_back(message({b[0]}));s.queue.push_back(message({},START_OF_MESSAGE));return 0;}
  if(is("identity_indicators_fragmented")){s.queue.push_back(message({},START_OF_MESSAGE));s.queue.push_back(message({},TX_DONE));s.queue.push_back(message(tx,TX_MSG_TYPE));s.queue.push_back(message(tx,TX_MSG_TYPE|TX_DONE));}
  if(is("identity_fragmented")||is("identity_indicators_fragmented")){for(auto byte:b)s.queue.push_back(message({byte}));return 0;}
  for(unsigned split=1;split<20;split++)if(index("identity_split_",split)){s.queue.push_back(message(Bytes(b.begin(),b.begin()+split)));s.queue.push_back(message(Bytes(b.begin()+split,b.end())));return 0;}
  if(state().name.rfind("identity_",0)==0){auto rx=message(b);
   if(is("identity_empty"))rx.DataSize=0;if(is("identity_protocol"))rx.ProtocolID=4;if(is("identity_flags"))rx.TxFlags=1;if(is("identity_extra_index"))rx.ExtraDataIndex=1;
   if(is("identity_wrong_echo")){rx=message(tx,TX_MSG_TYPE);rx.Data[0]^=1;}
   if(is("identity_nonempty_indicator"))rx.RxStatus=START_OF_MESSAGE;if(is("identity_combined_status"))rx.RxStatus=3;if(is("identity_unknown_status"))rx.RxStatus=0x100;
   s.queue.push_back(rx);return 0;
  }
 }

 if(stage==7&&is("upload_unknown_status")){s.queue.push_back(message({},0x100));return 0;}
 if(stage==7&&is("upload_wrong_echo")){auto bad=message(tx,TX_MSG_TYPE);bad.Data[0]^=1;s.queue.push_back(bad);return 0;}
 if(stage==7&&is("upload_rx_extra")){auto bad=message(b);bad.ExtraDataIndex=1;s.queue.push_back(bad);return 0;}

 if(stage==0&&is("wrong_bf")){b[8]^=1;b.back()=checksum(Bytes(b.begin(),b.end()-1));}
 if((stage==1&&is("wrong_81"))||(stage==2&&is("wrong_83"))){b[4]^=1;b.back()=checksum(Bytes(b.begin(),b.end()-1));}
 if((stage==0&&is("bad_checksum_bf"))||(stage==1&&is("bad_checksum_81"))||(stage==2&&is("bad_checksum_83")))b.back()^=1;
 if(stage==0&&is("unexpected_frame"))b=decode(REPLY_HEX[1]);
 const bool physical_record=is("physical_83_buffer_empty")||is("physical_83_cleanup_all_fail");
 if(stage<2&&physical_record){auto indication=message({},START_OF_MESSAGE);indication.Timestamp=stage==0?2062904608:2063128580;s.queue.push_back(indication);}
 if(is("indicators_fragmented")){s.queue.push_back(message({},START_OF_MESSAGE));s.queue.push_back(message({},TX_DONE));s.queue.push_back(message(tx,TX_MSG_TYPE));s.queue.push_back(message(tx,TX_MSG_TYPE|TX_DONE));}
 if(is("rx_indicator_flood")){for(unsigned i=0;i<5;i++)s.queue.push_back(message({},START_OF_MESSAGE));}
 if(is("rx_marker_only")){s.queue.push_back(message({},START_OF_MESSAGE));return 0;}
 if(is("rx_indicator_after_data")){s.queue.push_back(message(Bytes(b.begin(),b.begin()+1)));s.queue.push_back(message({},START_OF_MESSAGE));return 0;}
 if(is("fragmented")||is("indicators_fragmented")){for(auto byte:b)s.queue.push_back(message({byte}));return 0;}
 auto rx=message(b);if(physical_record){rx.ExtraDataIndex=rx.DataSize;rx.Timestamp=stage==0?2063053738:2063165760;}
 if(is("extra_index_size"))rx.ExtraDataIndex=rx.DataSize;
 if(is("rx_oversize"))rx.DataSize=5000;if(is("rx_protocol"))rx.ProtocolID=4;if(is("rx_flags"))rx.TxFlags=1;if(is("rx_extra"))rx.ExtraDataIndex=1;
 if(is("rx_unknown_status"))rx.RxStatus=0x100;if(is("rx_combined_status"))rx.RxStatus=3;
 if(is("rx_nonempty_indicator"))rx.RxStatus=START_OF_MESSAGE;
 if(is("rx_wrong_echo")){rx=message(tx,TX_MSG_TYPE);rx.Data[0]^=1;}
 if(is("rx_empty"))rx.DataSize=0;if(is("rx_trailing")){rx.Data[rx.DataSize++]=0;}
 if(is("rx_wrong_direction"))rx.Data[1]=0x10;if(is("rx_zero_length"))rx.Data[3]=0;
 s.queue.push_back(rx);return 0;
}
inline long PT_CALL read(U channel,void* output,U* count,U timeout){
 if(channel!=701||!output||!count||*count!=1||!timeout||timeout>1000)return 7;auto& s=state();
 if(s.queue.empty()){*count=0;return 16;}if((s.writes==23&&is("start_late_reply"))||(s.writes==24&&is("identity_late_reply"))||(s.writes==25&&is("bounded_late_reply")))Sleep(2100);*static_cast<PASSTHRU_MSG*>(output)=s.queue.front();s.queue.pop_front();
 if(is("read_count_zero")||(s.writes==24&&is("identity_count_zero"))||(s.writes==25&&is("bounded_count_zero")))*count=0;if(is("read_count_large")||(s.writes==24&&is("identity_count_large"))||(s.writes==25&&is("bounded_count_large")))*count=2;
 if(s.writes==25){if(is("bounded_read_error"))return 7;if(is("bounded_status16"))return 16;if(is("bounded_timeout_status"))return 9;}
 return is("read_error_output")||(s.writes==24&&is("identity_read_error"))?16:0;
}
inline unsigned long long virtual_ms(){return state().virtual_now;}
inline long wait_ms(U ms){auto& s=state();const U wanted[]={200,100,200};const unsigned at_writes[]={5,6,6};if(s.waits>=3||ms!=wanted[s.waits]||s.writes!=at_writes[s.waits]||!s.queue.empty()||(s.waits==2&&s.clears!=2))return 7;unsigned step=s.waits++;if(index("wait_fail_",step))return 7;s.virtual_now+=index("wait_short_",step)?ms-1:ms;return 0;}
inline Api api(){return {open,close,connect,disconnect,read,write,filter,stop_filter,version,ioctl,wait_ms,virtual_ms};}
}
