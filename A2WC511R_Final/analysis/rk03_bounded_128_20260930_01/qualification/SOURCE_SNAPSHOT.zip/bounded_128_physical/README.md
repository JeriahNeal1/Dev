# Fixed128 physical release

New stage derived from sealed512 failure. Exactly one address0/128-byte read after the proven transport/start/identity path. Uses fixed1808-byte kernel808a5523d47de11881bfc2ea06a35278aedb5122ed51e8110f817b3210adb653 because the historical kernel admitted only512. Same entry/layout/identity; no alternate image selector.

349 native cases and17 new-kernel instruction cases, two identical PE/kernel builds. Physical execution requires new gates and exact PROCEED RK03 128 BYTE ROM READ. Previous512 authorization is not reusable.

Inherited fixtures and contract provenance are described in CONTRACT_INTERPRETATION.json in the new analysis directory. derive_bounded_release.py and derive_bounded_controls.py are inherited historical derivation references, never used by the new launcher/build. Active derivation is derive_128.py plus finish_128_derivation.py; release is seal_bounded_release.py.
