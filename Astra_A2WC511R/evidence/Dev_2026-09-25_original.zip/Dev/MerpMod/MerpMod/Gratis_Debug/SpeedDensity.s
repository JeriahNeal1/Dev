	.file	"SpeedDensity.c"
	.text
	.text
.Ltext0:
	.cfi_sections	.debug_frame
	.section	RomHole_Code,"ax",@progbits
	.align 2
	.global	_ComputeMassAirFlow
	.type	_ComputeMassAirFlow, @function
_ComputeMassAirFlow:
.LFB0:
	.file 1 "C:\\Dev\\MerpMod\\MerpMod\\SpeedDensity.c"
	.loc 1 20 0
	.cfi_startproc
	mov.l	r8,@-r15
.LCFI0:
	.cfi_def_cfa_offset 4
	.cfi_offset 8, -4
	mov.l	r14,@-r15
.LCFI1:
	.cfi_def_cfa_offset 8
	.cfi_offset 14, -8
	sts.l	pr,@-r15
.LCFI2:
	.cfi_def_cfa_offset 12
	.cfi_offset 17, -12
	add	#-12,r15
.LCFI3:
	.cfi_def_cfa_offset 24
	mov	r15,r14
.LCFI4:
	.cfi_def_cfa_register 14
	mov	r14,r1
	add	#-52,r1
	mov.l	r4,@(56,r1)
	mov	r14,r1
	fmov.s	fr4,@r1
	.loc 1 21 0
	mov.w	.L40,r8
	mov.l	.L6,r1
	mov.l	@r1,r1
	mov	r14,r2
	add	#-52,r2
	mov.l	@(56,r2),r3
	mov	r14,r2
	mov	r3,r4
	fmov.s	@r2,fr4
	jsr	@r1
	nop
	fmov	fr0,fr1
	mov	r8,r1
	add	#24,r1
	fmov.s	fr1,@r1
	.loc 1 35 0
	mov.w	.L40,r8
	mov.l	.L30,r1
	mov.l	@r1,r1
	mov.l	.L31,r2
	fmov.s	@r2,fr2
	mov.l	.L32,r2
	fmov.s	@r2,fr1
	mov.l	.L11,r2
	mov	r2,r4
	fmov	fr2,fr4
	fmov	fr1,fr5
	jsr	@r1
	nop
	fmov	fr0,fr1
	mov	r8,r1
	add	#16,r1
	fmov.s	fr1,@r1
	.loc 1 42 0
	mov.l	.L12,r1
	fmov.s	@r1,fr2
	mov.l	.L13,r1
	fmov.s	@r1,fr1
	mov	r14,r1
	add	#8,r1
	fadd	fr2,fr1
	fmov.s	fr1,@r1
	.loc 1 44 0
	mov.w	.L40,r8
	mov.l	.L30,r1
	mov.l	@r1,r1
	mov.l	.L31,r2
	fmov.s	@r2,fr2
	mov.l	.L17,r2
	fmov.s	@r2,fr1
	mov.l	.L18,r2
	mov	r2,r4
	fmov	fr2,fr4
	fmov	fr1,fr5
	jsr	@r1
	nop
	fmov	fr0,fr1
	mov	r8,r1
	add	#28,r1
	fmov.s	fr1,@r1
	.loc 1 49 0
	mov.w	.L40,r1
	.loc 1 51 0
	mov.l	.L32,r2
	fmov.s	@r2,fr2
	.loc 1 50 0
	mov.l	.L21,r2
	fmov.s	@r2,fr1
	fmul	fr1,fr2
	.loc 1 52 0
	mov.l	.L31,r2
	fmov.s	@r2,fr1
	.loc 1 51 0
	fmul	fr1,fr2
	.loc 1 53 0
	mov.w	.L40,r2
	add	#16,r2
	fmov.s	@r2,fr1
	.loc 1 52 0
	fmul	fr1,fr2
	.loc 1 54 0
	mov.w	.L40,r2
	add	#28,r2
	fmov.s	@r2,fr1
	.loc 1 53 0
	fmul	fr1,fr2
	.loc 1 54 0
	mov.l	.L25,r2
	fmov.s	@r2,fr1
	fmul	fr1,fr2
	.loc 1 58 0
	mov	r14,r2
	add	#8,r2
	fmov.s	@r2,fr1
	fmov	fr2,fr3
	fdiv	fr1,fr3
	fmov	fr3,fr1
	.loc 1 49 0
	add	#20,r1
	fmov.s	fr1,@r1
	.loc 1 63 0
	mov.w	.L40,r1
	add	#13,r1
	mov.b	@r1,r1
	extu.b	r1,r2
	mov	#2,r1
	cmp/eq	r1,r2
	bf.s	.L2
	nop
	.loc 1 66 0
	mov.w	.L40,r1
	add	#20,r1
	fmov.s	@r1,fr1
	bra	.L3
	nop
	.align 1
.L2:
	.loc 1 68 0
	mov.w	.L40,r1
	add	#13,r1
	mov.b	@r1,r1
	extu.b	r1,r2
	mov	#3,r1
	cmp/eq	r1,r2
	bf.s	.L4
	nop
	.loc 1 70 0
	mov.w	.L40,r8
	mov.l	.L30,r1
	mov.l	@r1,r1
	mov.l	.L31,r2
	fmov.s	@r2,fr2
	mov.l	.L32,r2
	fmov.s	@r2,fr1
	mov.l	.L33,r2
	mov	r2,r4
	fmov	fr2,fr4
	fmov	fr1,fr5
	jsr	@r1
	nop
	fmov	fr0,fr1
	mov	r8,r1
	add	#36,r1
	fmov.s	fr1,@r1
	.loc 1 72 0
	mov.w	.L40,r1
	.loc 1 73 0
	mov.w	.L40,r2
	add	#20,r2
	fmov.s	@r2,fr2
	mov.w	.L40,r2
	add	#36,r2
	fmov.s	@r2,fr1
	fmul	fr1,fr2
	.loc 1 74 0
	mov.w	.L40,r2
	add	#24,r2
	fmov.s	@r2,fr3
	.loc 1 75 0
	mov.w	.L40,r2
	add	#36,r2
	fmov.s	@r2,fr1
	fldi1	fr4
	fmov	fr4,fr5
	fsub	fr1,fr5
	fmov	fr5,fr1
	.loc 1 74 0
	fmul	fr3,fr1
	.loc 1 73 0
	fadd	fr2,fr1
	.loc 1 72 0
	add	#40,r1
	fmov.s	fr1,@r1
	.loc 1 77 0
	mov.w	.L40,r1
	add	#40,r1
	fmov.s	@r1,fr1
	bra	.L3
	nop
	.align 1
.L4:
	.loc 1 81 0
	mov.w	.L40,r1
	add	#24,r1
	fmov.s	@r1,fr1
.L3:
	.loc 1 83 0
	fmov	fr1,fr0
	add	#12,r14
	mov	r14,r15
	lds.l   @r15+,pr
	mov.l   @r15+,r14
	mov.l   @r15+,r8
	rts	
	nop
	.align 1
.L40:
	.short	-26944
.L41:
	.align 2
.L6:
	.long	_Pull2DHooked
.L30:
	.long	_Pull3DHooked
.L31:
	.long	-39272
.L32:
	.long	-38376
.L11:
	.long	_VolumetricEfficiencyTable1
.L12:
	.long	-41828
.L13:
	.long	_CelsiusToKelvin
.L17:
	.long	-41772
.L18:
	.long	_AtmosphericCompensationTable
.L21:
	.long	_Displacement
.L25:
	.long	_SpeedDensityConstant
.L33:
	.long	_SDBlendingTable
	.cfi_endproc
.LFE0:
	.size	_ComputeMassAirFlow, .-_ComputeMassAirFlow
	.text
.Letext0:
	.file 2 "C:\\Dev\\MerpMod\\MerpMod\\enums.h"
	.file 3 "C:\\Dev\\MerpMod\\MerpMod\\RamVariables.h"
	.file 4 "C:\\Dev\\MerpMod\\MerpMod\\Externs.h"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.ualong	0x4e3
	.uaword	0x2
	.ualong	.Ldebug_abbrev0
	.byte	0x4
	.uleb128 0x1
	.ualong	.LASF75
	.byte	0x1
	.ualong	.LASF76
	.ualong	.Ldebug_ranges0+0
	.ualong	0
	.ualong	0
	.ualong	.Ldebug_line0
	.uleb128 0x2
	.ualong	.LASF77
	.byte	0x4
	.byte	0x2
	.byte	0x2e
	.ualong	0x4a
	.uleb128 0x3
	.ualong	.LASF0
	.sleb128 0
	.uleb128 0x3
	.ualong	.LASF1
	.sleb128 1
	.uleb128 0x3
	.ualong	.LASF2
	.sleb128 2
	.uleb128 0x3
	.ualong	.LASF3
	.sleb128 3
	.byte	0
	.uleb128 0x4
	.byte	0x1c
	.byte	0x2
	.byte	0x81
	.ualong	0xc3
	.uleb128 0x5
	.ualong	.LASF4
	.byte	0x2
	.byte	0x83
	.ualong	0xc3
	.byte	0x2
	.byte	0x23
	.uleb128 0
	.uleb128 0x5
	.ualong	.LASF5
	.byte	0x2
	.byte	0x84
	.ualong	0xc3
	.byte	0x2
	.byte	0x23
	.uleb128 0x2
	.uleb128 0x5
	.ualong	.LASF6
	.byte	0x2
	.byte	0x85
	.ualong	0xca
	.byte	0x2
	.byte	0x23
	.uleb128 0x4
	.uleb128 0x5
	.ualong	.LASF7
	.byte	0x2
	.byte	0x86
	.ualong	0xca
	.byte	0x2
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x5
	.ualong	.LASF8
	.byte	0x2
	.byte	0x87
	.ualong	0xd7
	.byte	0x2
	.byte	0x23
	.uleb128 0xc
	.uleb128 0x5
	.ualong	.LASF9
	.byte	0x2
	.byte	0x88
	.ualong	0xd9
	.byte	0x2
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x5
	.ualong	.LASF10
	.byte	0x2
	.byte	0x89
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x5
	.ualong	.LASF11
	.byte	0x2
	.byte	0x8a
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x18
	.byte	0
	.uleb128 0x6
	.byte	0x2
	.byte	0x5
	.ualong	.LASF12
	.uleb128 0x7
	.byte	0x4
	.ualong	0xd0
	.uleb128 0x6
	.byte	0x4
	.byte	0x4
	.ualong	.LASF13
	.uleb128 0x8
	.byte	0x4
	.uleb128 0x9
	.byte	0x4
	.byte	0x5
	.string	"int"
	.uleb128 0xa
	.ualong	.LASF14
	.byte	0x2
	.byte	0x8b
	.ualong	0x4a
	.uleb128 0x4
	.byte	0x14
	.byte	0x2
	.byte	0x8d
	.ualong	0x148
	.uleb128 0x5
	.ualong	.LASF4
	.byte	0x2
	.byte	0x8f
	.ualong	0xc3
	.byte	0x2
	.byte	0x23
	.uleb128 0
	.uleb128 0x5
	.ualong	.LASF9
	.byte	0x2
	.byte	0x90
	.ualong	0xc3
	.byte	0x2
	.byte	0x23
	.uleb128 0x2
	.uleb128 0x5
	.ualong	.LASF6
	.byte	0x2
	.byte	0x91
	.ualong	0xca
	.byte	0x2
	.byte	0x23
	.uleb128 0x4
	.uleb128 0x5
	.ualong	.LASF8
	.byte	0x2
	.byte	0x92
	.ualong	0x148
	.byte	0x2
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x5
	.ualong	.LASF10
	.byte	0x2
	.byte	0x93
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0xc
	.uleb128 0x5
	.ualong	.LASF11
	.byte	0x2
	.byte	0x94
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x10
	.byte	0
	.uleb128 0x7
	.byte	0x4
	.ualong	0xc3
	.uleb128 0xa
	.ualong	.LASF15
	.byte	0x2
	.byte	0x95
	.ualong	0xeb
	.uleb128 0x7
	.byte	0x4
	.ualong	0xe0
	.uleb128 0x6
	.byte	0x4
	.byte	0x5
	.ualong	.LASF16
	.uleb128 0x6
	.byte	0x4
	.byte	0x7
	.ualong	.LASF17
	.uleb128 0x6
	.byte	0x1
	.byte	0x6
	.ualong	.LASF18
	.uleb128 0x4
	.byte	0x70
	.byte	0x3
	.byte	0x12
	.ualong	0x3d9
	.uleb128 0x5
	.ualong	.LASF19
	.byte	0x3
	.byte	0x14
	.ualong	0x3d9
	.byte	0x2
	.byte	0x23
	.uleb128 0
	.uleb128 0x5
	.ualong	.LASF20
	.byte	0x3
	.byte	0x15
	.ualong	0x3d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x1
	.uleb128 0x5
	.ualong	.LASF21
	.byte	0x3
	.byte	0x16
	.ualong	0x3d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x2
	.uleb128 0x5
	.ualong	.LASF22
	.byte	0x3
	.byte	0x17
	.ualong	0x3d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x3
	.uleb128 0x5
	.ualong	.LASF23
	.byte	0x3
	.byte	0x18
	.ualong	0x3e0
	.byte	0x2
	.byte	0x23
	.uleb128 0x4
	.uleb128 0x5
	.ualong	.LASF24
	.byte	0x3
	.byte	0x19
	.ualong	0x3d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x5
	.ualong	.LASF25
	.byte	0x3
	.byte	0x1a
	.ualong	0x3d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x9
	.uleb128 0x5
	.ualong	.LASF26
	.byte	0x3
	.byte	0x1b
	.ualong	0x3d9
	.byte	0x2
	.byte	0x23
	.uleb128 0xa
	.uleb128 0x5
	.ualong	.LASF27
	.byte	0x3
	.byte	0x1c
	.ualong	0x3d9
	.byte	0x2
	.byte	0x23
	.uleb128 0xb
	.uleb128 0x5
	.ualong	.LASF28
	.byte	0x3
	.byte	0x40
	.ualong	0x3d9
	.byte	0x2
	.byte	0x23
	.uleb128 0xc
	.uleb128 0x5
	.ualong	.LASF29
	.byte	0x3
	.byte	0x41
	.ualong	0x3d9
	.byte	0x2
	.byte	0x23
	.uleb128 0xd
	.uleb128 0x5
	.ualong	.LASF30
	.byte	0x3
	.byte	0x42
	.ualong	0x3d9
	.byte	0x2
	.byte	0x23
	.uleb128 0xe
	.uleb128 0x5
	.ualong	.LASF31
	.byte	0x3
	.byte	0x43
	.ualong	0x3d9
	.byte	0x2
	.byte	0x23
	.uleb128 0xf
	.uleb128 0x5
	.ualong	.LASF32
	.byte	0x3
	.byte	0x44
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x5
	.ualong	.LASF33
	.byte	0x3
	.byte	0x45
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x5
	.ualong	.LASF34
	.byte	0x3
	.byte	0x46
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x5
	.ualong	.LASF35
	.byte	0x3
	.byte	0x47
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x1c
	.uleb128 0x5
	.ualong	.LASF36
	.byte	0x3
	.byte	0x48
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x20
	.uleb128 0x5
	.ualong	.LASF37
	.byte	0x3
	.byte	0x49
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x24
	.uleb128 0x5
	.ualong	.LASF38
	.byte	0x3
	.byte	0x4a
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x28
	.uleb128 0x5
	.ualong	.LASF39
	.byte	0x3
	.byte	0x50
	.ualong	0x3d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x2c
	.uleb128 0x5
	.ualong	.LASF40
	.byte	0x3
	.byte	0x51
	.ualong	0x3d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x2d
	.uleb128 0x5
	.ualong	.LASF41
	.byte	0x3
	.byte	0x52
	.ualong	0x3d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x2e
	.uleb128 0x5
	.ualong	.LASF42
	.byte	0x3
	.byte	0x53
	.ualong	0x3d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x2f
	.uleb128 0x5
	.ualong	.LASF43
	.byte	0x3
	.byte	0x54
	.ualong	0x3d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x30
	.uleb128 0x5
	.ualong	.LASF44
	.byte	0x3
	.byte	0x55
	.ualong	0x3d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x31
	.uleb128 0x5
	.ualong	.LASF45
	.byte	0x3
	.byte	0x56
	.ualong	0x3d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x32
	.uleb128 0x5
	.ualong	.LASF46
	.byte	0x3
	.byte	0x57
	.ualong	0x16d
	.byte	0x2
	.byte	0x23
	.uleb128 0x33
	.uleb128 0x5
	.ualong	.LASF47
	.byte	0x3
	.byte	0x58
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x34
	.uleb128 0x5
	.ualong	.LASF48
	.byte	0x3
	.byte	0x59
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x38
	.uleb128 0x5
	.ualong	.LASF49
	.byte	0x3
	.byte	0x5a
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x3c
	.uleb128 0x5
	.ualong	.LASF50
	.byte	0x3
	.byte	0x5b
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x40
	.uleb128 0x5
	.ualong	.LASF51
	.byte	0x3
	.byte	0x5c
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x44
	.uleb128 0x5
	.ualong	.LASF52
	.byte	0x3
	.byte	0x5d
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x48
	.uleb128 0x5
	.ualong	.LASF53
	.byte	0x3
	.byte	0x5e
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x4c
	.uleb128 0x5
	.ualong	.LASF54
	.byte	0x3
	.byte	0x5f
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x50
	.uleb128 0x5
	.ualong	.LASF55
	.byte	0x3
	.byte	0x60
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x54
	.uleb128 0x5
	.ualong	.LASF56
	.byte	0x3
	.byte	0x61
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x58
	.uleb128 0x5
	.ualong	.LASF57
	.byte	0x3
	.byte	0x62
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x5c
	.uleb128 0x5
	.ualong	.LASF58
	.byte	0x3
	.byte	0x63
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x60
	.uleb128 0x5
	.ualong	.LASF59
	.byte	0x3
	.byte	0x64
	.ualong	0xd0
	.byte	0x2
	.byte	0x23
	.uleb128 0x64
	.uleb128 0xb
	.ualong	.LASF60
	.byte	0x3
	.uaword	0x110
	.ualong	0x15f
	.byte	0x2
	.byte	0x23
	.uleb128 0x68
	.uleb128 0xb
	.ualong	.LASF61
	.byte	0x3
	.uaword	0x111
	.ualong	0x16d
	.byte	0x2
	.byte	0x23
	.uleb128 0x6c
	.byte	0
	.uleb128 0x6
	.byte	0x1
	.byte	0x8
	.ualong	.LASF62
	.uleb128 0x6
	.byte	0x4
	.byte	0x7
	.ualong	.LASF63
	.uleb128 0xc
	.ualong	.LASF64
	.byte	0x3
	.uaword	0x115
	.ualong	0x174
	.uleb128 0xd
	.byte	0x1
	.ualong	.LASF78
	.byte	0x1
	.byte	0x13
	.byte	0x1
	.ualong	0xd0
	.ualong	.LFB0
	.ualong	.LFE0
	.ualong	.LLST0
	.byte	0x1
	.byte	0x40
	.ualong	0x43d
	.uleb128 0xe
	.ualong	.LASF65
	.byte	0x1
	.byte	0x13
	.ualong	0x43d
	.byte	0x2
	.byte	0x91
	.sleb128 -20
	.uleb128 0xe
	.ualong	.LASF66
	.byte	0x1
	.byte	0x13
	.ualong	0xd0
	.byte	0x2
	.byte	0x91
	.sleb128 -24
	.uleb128 0xf
	.ualong	.LASF79
	.byte	0x1
	.byte	0x2a
	.ualong	0xd0
	.byte	0x2
	.byte	0x91
	.sleb128 -16
	.byte	0
	.uleb128 0x7
	.byte	0x4
	.ualong	0x14e
	.uleb128 0x10
	.byte	0x1
	.ualong	0xd0
	.ualong	0x45d
	.uleb128 0x11
	.ualong	0x159
	.uleb128 0x11
	.ualong	0xd0
	.uleb128 0x11
	.ualong	0xd0
	.byte	0
	.uleb128 0x12
	.ualong	.LASF67
	.byte	0x4
	.byte	0x5f
	.ualong	0x46a
	.byte	0x1
	.byte	0x1
	.uleb128 0x7
	.byte	0x4
	.ualong	0x443
	.uleb128 0x10
	.byte	0x1
	.ualong	0xd0
	.ualong	0x485
	.uleb128 0x11
	.ualong	0x43d
	.uleb128 0x11
	.ualong	0xd0
	.byte	0
	.uleb128 0x12
	.ualong	.LASF68
	.byte	0x4
	.byte	0x60
	.ualong	0x492
	.byte	0x1
	.byte	0x1
	.uleb128 0x7
	.byte	0x4
	.ualong	0x470
	.uleb128 0x12
	.ualong	.LASF69
	.byte	0x4
	.byte	0x71
	.ualong	0xe0
	.byte	0x1
	.byte	0x1
	.uleb128 0x12
	.ualong	.LASF70
	.byte	0x4
	.byte	0x75
	.ualong	0xe0
	.byte	0x1
	.byte	0x1
	.uleb128 0x12
	.ualong	.LASF71
	.byte	0x4
	.byte	0x76
	.ualong	0xe0
	.byte	0x1
	.byte	0x1
	.uleb128 0x12
	.ualong	.LASF72
	.byte	0x4
	.byte	0xd7
	.ualong	0xd0
	.byte	0x1
	.byte	0x1
	.uleb128 0x12
	.ualong	.LASF73
	.byte	0x4
	.byte	0xd8
	.ualong	0xd0
	.byte	0x1
	.byte	0x1
	.uleb128 0x12
	.ualong	.LASF74
	.byte	0x4
	.byte	0xd9
	.ualong	0xd0
	.byte	0x1
	.byte	0x1
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x55
	.uleb128 0x6
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x52
	.uleb128 0x1
	.uleb128 0x10
	.uleb128 0x6
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x4
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x28
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x1c
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x8
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x16
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x16
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x27
	.uleb128 0xc
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.uleb128 0x40
	.uleb128 0x6
	.uleb128 0x2116
	.uleb128 0xc
	.uleb128 0x36
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0x15
	.byte	0x1
	.uleb128 0x27
	.uleb128 0xc
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0x5
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3c
	.uleb128 0xc
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_loc,"",@progbits
.Ldebug_loc0:
.LLST0:
	.ualong	.LFB0
	.ualong	.LCFI0
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI0
	.ualong	.LCFI1
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI1
	.ualong	.LCFI2
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI2
	.ualong	.LCFI3
	.uaword	0x2
	.byte	0x7f
	.sleb128 12
	.ualong	.LCFI3
	.ualong	.LCFI4
	.uaword	0x2
	.byte	0x7f
	.sleb128 24
	.ualong	.LCFI4
	.ualong	.LFE0
	.uaword	0x2
	.byte	0x7e
	.sleb128 24
	.ualong	0
	.ualong	0
	.section	.debug_aranges,"",@progbits
	.ualong	0x1c
	.uaword	0x2
	.ualong	.Ldebug_info0
	.byte	0x4
	.byte	0
	.uaword	0
	.uaword	0
	.ualong	.LFB0
	.ualong	.LFE0-.LFB0
	.ualong	0
	.ualong	0
	.section	.debug_ranges,"",@progbits
.Ldebug_ranges0:
	.ualong	.LFB0
	.ualong	.LFE0
	.ualong	0
	.ualong	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF66:
	.string	"MafVoltage"
.LASF41:
	.string	"FlatFootShiftMode"
.LASF45:
	.string	"FFSGear"
.LASF52:
	.string	"LaunchControlCut"
.LASF55:
	.string	"FlatFootShiftRpmThreshold"
.LASF77:
	.string	"MafModeValues"
.LASF73:
	.string	"Displacement"
.LASF10:
	.string	"multiplier"
.LASF67:
	.string	"Pull3DHooked"
.LASF31:
	.string	"sdempty1"
.LASF12:
	.string	"short int"
.LASF37:
	.string	"SDMafBlendRatio"
.LASF29:
	.string	"MafMode"
.LASF17:
	.string	"sizetype"
.LASF79:
	.string	"intakeAirTempInKelvin"
.LASF72:
	.string	"CelsiusToKelvin"
.LASF7:
	.string	"rowHeaderArray"
.LASF65:
	.string	"MafScalingTable"
.LASF19:
	.string	"RamVariableStart"
.LASF23:
	.string	"ECUIdentifier"
.LASF4:
	.string	"columnCount"
.LASF0:
	.string	"MafModeUndefined"
.LASF28:
	.string	"SDInitFlag"
.LASF53:
	.string	"LaunchControlHyst"
.LASF21:
	.string	"CruiseCoastLast"
.LASF59:
	.string	"FlatFootShiftSpeedThreshold"
.LASF38:
	.string	"SDMafFromBlend"
.LASF47:
	.string	"RevLimCut"
.LASF34:
	.string	"MafFromSensor"
.LASF69:
	.string	"VolumetricEfficiencyTable1"
.LASF13:
	.string	"float"
.LASF6:
	.string	"columnHeaderArray"
.LASF8:
	.string	"tableCells"
.LASF32:
	.string	"VolumetricEfficiency"
.LASF16:
	.string	"long int"
.LASF11:
	.string	"offset"
.LASF56:
	.string	"FlatFootShiftAutoDelta"
.LASF64:
	.string	"RamVariables"
.LASF3:
	.string	"MafModeBlending"
.LASF70:
	.string	"AtmosphericCompensationTable"
.LASF50:
	.string	"RedLineHyst"
.LASF62:
	.string	"unsigned char"
.LASF74:
	.string	"SpeedDensityConstant"
.LASF2:
	.string	"MafModeSpeedDensity"
.LASF9:
	.string	"tableType"
.LASF39:
	.string	"RevLimInitFlag"
.LASF75:
	.string	"GNU C 4.7-GNUSH_v13.01"
.LASF63:
	.string	"long unsigned int"
.LASF54:
	.string	"FFSRPM"
.LASF61:
	.string	"RamHoleEndMarker"
.LASF58:
	.string	"FlatFootShiftHyst"
.LASF18:
	.string	"char"
.LASF36:
	.string	"DeltaMapCompensation"
.LASF33:
	.string	"MafFromSpeedDensity"
.LASF25:
	.string	"blank0"
.LASF26:
	.string	"blank1"
.LASF27:
	.string	"blank2"
.LASF20:
	.string	"VinAuth"
.LASF22:
	.string	"CruiseResumeLast"
.LASF30:
	.string	"SDempty"
.LASF68:
	.string	"Pull2DHooked"
.LASF78:
	.string	"ComputeMassAirFlow"
.LASF42:
	.string	"LCEngaged"
.LASF43:
	.string	"FFSEngaged"
.LASF15:
	.string	"TwoDTable"
.LASF48:
	.string	"RevLimResume"
.LASF40:
	.string	"RevLimMode"
.LASF5:
	.string	"rowCount"
.LASF24:
	.string	"HardResetFlag"
.LASF57:
	.string	"FlatFootShiftStaticDelta"
.LASF35:
	.string	"AtmosphericCompensation"
.LASF49:
	.string	"RedLineCut"
.LASF1:
	.string	"MafModeSensor"
.LASF60:
	.string	"RamHoleSpace"
.LASF46:
	.string	"eleemee2"
.LASF14:
	.string	"ThreeDTable"
.LASF71:
	.string	"SDBlendingTable"
.LASF44:
	.string	"ClutchSwitchLast"
.LASF76:
	.string	"C:\\Dev\\MerpMod\\MerpMod\\SpeedDensity.c"
.LASF51:
	.string	"LaunchControlSpeedMax"
	.ident	"GCC: (GNU) 4.7-GNUSH_v13.01"
