	.file	"Metadata.c"
	.text
	.text
.Ltext0:
	.cfi_sections	.debug_frame
	.global	_HERPDERP
	.section	TestSection1,"a",@progbits
	.align 2
	.type	_HERPDERP, @object
	.size	_HERPDERP, 4
_HERPDERP:
	.long	305419896
	.global	_metadataheader
	.section	MetaDataHeader,"a",@progbits
	.align 2
	.type	_metadataheader, @object
	.size	_metadataheader, 276
_metadataheader:
	.long	305397760
	.long	9
	.long	305397761
	.long	8192
	.long	8
	.ascii	"A8DH202X"
	.string	""
	.string	""
	.string	""
	.string	""
	.string	""
	.string	""
	.string	""
	.zero	1
	.ascii	"FFFFFFFF"
	.string	""
	.string	""
	.string	""
	.string	""
	.string	""
	.string	""
	.string	""
	.zero	1
	.long	305397775
	.long	_ModIdentifier
	.string	"A8DH202X.MeRpMoD.Gratis.Debug.v0.1-73-g8720d20.23.08.26.13.08"
	.zero	38
	.string	""
	.string	""
	.string	""
	.string	""
	.string	""
	.string	""
	.string	""
	.zero	1
	.long	305397771
	.long	850828
	.long	10
	.ascii	"4312584206"
	.string	""
	.string	""
	.string	""
	.string	""
	.string	""
	.string	""
	.string	""
	.zero	1
	.zero	2
	.long	305397772
	.ascii	"CC3BFECC69"
	.string	""
	.string	""
	.string	""
	.string	""
	.string	""
	.string	""
	.string	""
	.zero	1
	.zero	2
	.long	305397768
	.string	"Merp"
	.zero	11
	.long	305397769
	.string	"Debug"
	.zero	10
	.string	""
	.string	""
	.string	""
	.string	""
	.string	""
	.string	""
	.string	""
	.zero	1
	.long	305397773
	.string	"Speed Density load calculation with MAF blending__Launch control and flat foot shifting (static or gear based calculation)__"
	.string	""
	.string	""
	.string	""
	.string	""
	.string	""
	.string	""
	.global	_RevLimitDelete
	.section	MetaData,"a",@progbits
	.align 2
	.type	_RevLimitDelete, @object
	.size	_RevLimitDelete, 16
_RevLimitDelete:
	.long	305397763
	.long	85684
	.long	212328
	.long	_RevLimHook
	.string	"Rev Limit Subroutine Hook"
	.global	_MemResetSubHook
	.align 2
	.type	_MemResetSubHook, @object
	.size	_MemResetSubHook, 16
_MemResetSubHook:
	.long	305397763
	.long	56264
	.long	64684
	.long	_Initializer
	.string	"Memory Reset Subroutine Hook"
	.global	_SDHookPatch
	.align 2
	.type	_SDHookPatch, @object
	.size	_SDHookPatch, 16
_SDHookPatch:
	.long	305397763
	.long	33556
	.long	8348
	.long	_ComputeMassAirFlow
	.string	"Speed Density Maf Subroutine Hook"
	.global	_WGDCHook
	.align 2
	.type	_WGDCHook, @object
	.size	_WGDCHook, 16
_WGDCHook:
	.long	305397763
	.long	84324
	.long	94816
	.long	_WGDCHack
	.string	"Main Subroutine Hook WGDC"
	.global	_RomHoleCodePatch
	.align 2
	.type	_RomHoleCodePatch, @object
	.size	_RomHoleCodePatch, 12
_RomHoleCodePatch:
	.long	305397764
	.long	_ModIdentifier
	.long	_RomHoleEndMarker
	.string	"Rom Hole Code Patch"
	.global	_endoffile
	.align 2
	.type	_endoffile, @object
	.size	_endoffile, 8
_endoffile:
	.long	589833
	.long	589833
	.text
.Letext0:
	.file 1 "C:\\Dev\\MerpMod\\MerpMod\\Metadata.c"
	.file 2 "C:\\Dev\\MerpMod\\MerpMod\\Externs.h"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.ualong	0x49d
	.uaword	0x2
	.ualong	.Ldebug_abbrev0
	.byte	0x4
	.uleb128 0x1
	.ualong	.LASF70
	.byte	0x1
	.ualong	.LASF71
	.ualong	.Ldebug_line0
	.uleb128 0x2
	.byte	0x2
	.byte	0x5
	.ualong	.LASF0
	.uleb128 0x2
	.byte	0x4
	.byte	0x4
	.ualong	.LASF1
	.uleb128 0x3
	.byte	0x4
	.byte	0x5
	.string	"int"
	.uleb128 0x2
	.byte	0x4
	.byte	0x5
	.ualong	.LASF2
	.uleb128 0x2
	.byte	0x4
	.byte	0x7
	.ualong	.LASF3
	.uleb128 0x2
	.byte	0x1
	.byte	0x6
	.ualong	.LASF4
	.uleb128 0x2
	.byte	0x1
	.byte	0x8
	.ualong	.LASF5
	.uleb128 0x2
	.byte	0x4
	.byte	0x7
	.ualong	.LASF6
	.uleb128 0x4
	.byte	0xc
	.byte	0x1
	.byte	0x14
	.ualong	0x91
	.uleb128 0x5
	.string	"op"
	.byte	0x1
	.byte	0x16
	.ualong	0x2e
	.byte	0x2
	.byte	0x23
	.uleb128 0
	.uleb128 0x6
	.ualong	.LASF7
	.byte	0x1
	.byte	0x17
	.ualong	0x2e
	.byte	0x2
	.byte	0x23
	.uleb128 0x4
	.uleb128 0x6
	.ualong	.LASF8
	.byte	0x1
	.byte	0x18
	.ualong	0x2e
	.byte	0x2
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x6
	.ualong	.LASF9
	.byte	0x1
	.byte	0x19
	.ualong	0x91
	.byte	0x2
	.byte	0x23
	.uleb128 0xc
	.byte	0
	.uleb128 0x7
	.ualong	0x3c
	.ualong	0xa0
	.uleb128 0x8
	.ualong	0x35
	.byte	0
	.uleb128 0x9
	.ualong	.LASF13
	.byte	0x1
	.byte	0x1b
	.ualong	0x51
	.uleb128 0x4
	.byte	0x10
	.byte	0x1
	.byte	0x26
	.ualong	0xf9
	.uleb128 0x5
	.string	"op"
	.byte	0x1
	.byte	0x28
	.ualong	0x2e
	.byte	0x2
	.byte	0x23
	.uleb128 0
	.uleb128 0x6
	.ualong	.LASF10
	.byte	0x1
	.byte	0x29
	.ualong	0x2e
	.byte	0x2
	.byte	0x23
	.uleb128 0x4
	.uleb128 0x6
	.ualong	.LASF11
	.byte	0x1
	.byte	0x2a
	.ualong	0x2e
	.byte	0x2
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x6
	.ualong	.LASF12
	.byte	0x1
	.byte	0x2b
	.ualong	0x2e
	.byte	0x2
	.byte	0x23
	.uleb128 0xc
	.uleb128 0x6
	.ualong	.LASF9
	.byte	0x1
	.byte	0x2c
	.ualong	0x91
	.byte	0x2
	.byte	0x23
	.uleb128 0x10
	.byte	0
	.uleb128 0x9
	.ualong	.LASF14
	.byte	0x1
	.byte	0x2d
	.ualong	0xab
	.uleb128 0xa
	.ualong	.LASF72
	.byte	0x4
	.byte	0x1
	.byte	0x38
	.ualong	0x1b1
	.uleb128 0xb
	.ualong	.LASF15
	.sleb128 305397760
	.uleb128 0xb
	.ualong	.LASF16
	.sleb128 305397761
	.uleb128 0xb
	.ualong	.LASF17
	.sleb128 305397762
	.uleb128 0xb
	.ualong	.LASF18
	.sleb128 305397778
	.uleb128 0xb
	.ualong	.LASF19
	.sleb128 305397763
	.uleb128 0xb
	.ualong	.LASF20
	.sleb128 305397779
	.uleb128 0xb
	.ualong	.LASF21
	.sleb128 305397764
	.uleb128 0xb
	.ualong	.LASF22
	.sleb128 305397780
	.uleb128 0xb
	.ualong	.LASF23
	.sleb128 305397768
	.uleb128 0xb
	.ualong	.LASF24
	.sleb128 305397769
	.uleb128 0xb
	.ualong	.LASF25
	.sleb128 305397770
	.uleb128 0xb
	.ualong	.LASF26
	.sleb128 305397771
	.uleb128 0xb
	.ualong	.LASF27
	.sleb128 305397772
	.uleb128 0xb
	.ualong	.LASF28
	.sleb128 305397773
	.uleb128 0xb
	.ualong	.LASF29
	.sleb128 305397774
	.uleb128 0xb
	.ualong	.LASF30
	.sleb128 305397775
	.byte	0
	.uleb128 0xc
	.uaword	0x114
	.byte	0x1
	.byte	0x4e
	.ualong	0x353
	.uleb128 0x6
	.ualong	.LASF31
	.byte	0x1
	.byte	0x50
	.ualong	0x2e
	.byte	0x2
	.byte	0x23
	.uleb128 0
	.uleb128 0x6
	.ualong	.LASF32
	.byte	0x1
	.byte	0x51
	.ualong	0x2e
	.byte	0x2
	.byte	0x23
	.uleb128 0x4
	.uleb128 0x6
	.ualong	.LASF33
	.byte	0x1
	.byte	0x52
	.ualong	0x2e
	.byte	0x2
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x6
	.ualong	.LASF34
	.byte	0x1
	.byte	0x53
	.ualong	0x2e
	.byte	0x2
	.byte	0x23
	.uleb128 0xc
	.uleb128 0x6
	.ualong	.LASF35
	.byte	0x1
	.byte	0x54
	.ualong	0x2e
	.byte	0x2
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x6
	.ualong	.LASF36
	.byte	0x1
	.byte	0x55
	.ualong	0x353
	.byte	0x2
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x6
	.ualong	.LASF37
	.byte	0x1
	.byte	0x56
	.ualong	0x353
	.byte	0x2
	.byte	0x23
	.uleb128 0x1c
	.uleb128 0x6
	.ualong	.LASF38
	.byte	0x1
	.byte	0x57
	.ualong	0x353
	.byte	0x2
	.byte	0x23
	.uleb128 0x24
	.uleb128 0x6
	.ualong	.LASF39
	.byte	0x1
	.byte	0x58
	.ualong	0x353
	.byte	0x2
	.byte	0x23
	.uleb128 0x2c
	.uleb128 0x6
	.ualong	.LASF40
	.byte	0x1
	.byte	0x5a
	.ualong	0x2e
	.byte	0x2
	.byte	0x23
	.uleb128 0x34
	.uleb128 0x6
	.ualong	.LASF41
	.byte	0x1
	.byte	0x5b
	.ualong	0x2e
	.byte	0x2
	.byte	0x23
	.uleb128 0x38
	.uleb128 0x6
	.ualong	.LASF42
	.byte	0x1
	.byte	0x5c
	.ualong	0x363
	.byte	0x2
	.byte	0x23
	.uleb128 0x3c
	.uleb128 0x6
	.ualong	.LASF43
	.byte	0x1
	.byte	0x5d
	.ualong	0x353
	.byte	0x3
	.byte	0x23
	.uleb128 0xa0
	.uleb128 0x6
	.ualong	.LASF44
	.byte	0x1
	.byte	0x5f
	.ualong	0x2e
	.byte	0x3
	.byte	0x23
	.uleb128 0xa8
	.uleb128 0x6
	.ualong	.LASF45
	.byte	0x1
	.byte	0x60
	.ualong	0x2e
	.byte	0x3
	.byte	0x23
	.uleb128 0xac
	.uleb128 0x6
	.ualong	.LASF46
	.byte	0x1
	.byte	0x61
	.ualong	0x2e
	.byte	0x3
	.byte	0x23
	.uleb128 0xb0
	.uleb128 0x6
	.ualong	.LASF47
	.byte	0x1
	.byte	0x62
	.ualong	0x373
	.byte	0x3
	.byte	0x23
	.uleb128 0xb4
	.uleb128 0x6
	.ualong	.LASF48
	.byte	0x1
	.byte	0x63
	.ualong	0x353
	.byte	0x3
	.byte	0x23
	.uleb128 0xbe
	.uleb128 0x6
	.ualong	.LASF49
	.byte	0x1
	.byte	0x64
	.ualong	0x2e
	.byte	0x3
	.byte	0x23
	.uleb128 0xc8
	.uleb128 0x6
	.ualong	.LASF50
	.byte	0x1
	.byte	0x65
	.ualong	0x373
	.byte	0x3
	.byte	0x23
	.uleb128 0xcc
	.uleb128 0x6
	.ualong	.LASF51
	.byte	0x1
	.byte	0x66
	.ualong	0x353
	.byte	0x3
	.byte	0x23
	.uleb128 0xd6
	.uleb128 0x6
	.ualong	.LASF52
	.byte	0x1
	.byte	0x69
	.ualong	0x2e
	.byte	0x3
	.byte	0x23
	.uleb128 0xe0
	.uleb128 0x6
	.ualong	.LASF53
	.byte	0x1
	.byte	0x6a
	.ualong	0x383
	.byte	0x3
	.byte	0x23
	.uleb128 0xe4
	.uleb128 0x6
	.ualong	.LASF54
	.byte	0x1
	.byte	0x6b
	.ualong	0x2e
	.byte	0x3
	.byte	0x23
	.uleb128 0xf4
	.uleb128 0x6
	.ualong	.LASF55
	.byte	0x1
	.byte	0x6c
	.ualong	0x383
	.byte	0x3
	.byte	0x23
	.uleb128 0xf8
	.uleb128 0x6
	.ualong	.LASF56
	.byte	0x1
	.byte	0x6d
	.ualong	0x393
	.byte	0x3
	.byte	0x23
	.uleb128 0x108
	.uleb128 0x6
	.ualong	.LASF57
	.byte	0x1
	.byte	0x6e
	.ualong	0x2e
	.byte	0x3
	.byte	0x23
	.uleb128 0x110
	.uleb128 0x6
	.ualong	.LASF58
	.byte	0x1
	.byte	0x6f
	.ualong	0x3a3
	.byte	0x3
	.byte	0x23
	.uleb128 0x114
	.byte	0
	.uleb128 0x7
	.ualong	0x43
	.ualong	0x363
	.uleb128 0xd
	.ualong	0x35
	.byte	0x7
	.byte	0
	.uleb128 0x7
	.ualong	0x43
	.ualong	0x373
	.uleb128 0xd
	.ualong	0x35
	.byte	0x63
	.byte	0
	.uleb128 0x7
	.ualong	0x43
	.ualong	0x383
	.uleb128 0xd
	.ualong	0x35
	.byte	0x9
	.byte	0
	.uleb128 0x7
	.ualong	0x43
	.ualong	0x393
	.uleb128 0xd
	.ualong	0x35
	.byte	0xf
	.byte	0
	.uleb128 0x7
	.ualong	0x3c
	.ualong	0x3a3
	.uleb128 0xd
	.ualong	0x35
	.byte	0x7
	.byte	0
	.uleb128 0x7
	.ualong	0x43
	.ualong	0x3b2
	.uleb128 0x8
	.ualong	0x35
	.byte	0
	.uleb128 0x9
	.ualong	.LASF59
	.byte	0x1
	.byte	0x70
	.ualong	0x1b1
	.uleb128 0xe
	.ualong	.LASF60
	.byte	0x2
	.uaword	0x12f
	.ualong	0x2e
	.byte	0x1
	.byte	0x1
	.uleb128 0x7
	.ualong	0x43
	.ualong	0x3d6
	.uleb128 0xf
	.byte	0
	.uleb128 0xe
	.ualong	.LASF61
	.byte	0x1
	.uaword	0x293
	.ualong	0x3cb
	.byte	0x1
	.byte	0x1
	.uleb128 0x10
	.ualong	.LASF62
	.byte	0x1
	.byte	0x11
	.ualong	0x3f6
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_HERPDERP
	.uleb128 0x11
	.ualong	0x2e
	.uleb128 0x10
	.ualong	.LASF63
	.byte	0x1
	.byte	0x72
	.ualong	0x40d
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_metadataheader
	.uleb128 0x11
	.ualong	0x3b2
	.uleb128 0x10
	.ualong	.LASF64
	.byte	0x1
	.byte	0xbc
	.ualong	0x424
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_RevLimitDelete
	.uleb128 0x11
	.ualong	0xf9
	.uleb128 0x10
	.ualong	.LASF65
	.byte	0x1
	.byte	0xcd
	.ualong	0x424
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_MemResetSubHook
	.uleb128 0x10
	.ualong	.LASF66
	.byte	0x1
	.byte	0xe7
	.ualong	0x424
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_SDHookPatch
	.uleb128 0x12
	.ualong	.LASF67
	.byte	0x1
	.uaword	0x108
	.ualong	0x424
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_WGDCHook
	.uleb128 0x12
	.ualong	.LASF68
	.byte	0x1
	.uaword	0x294
	.ualong	0x473
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_RomHoleCodePatch
	.uleb128 0x11
	.ualong	0xa0
	.uleb128 0x7
	.ualong	0x2e
	.ualong	0x488
	.uleb128 0xd
	.ualong	0x35
	.byte	0x1
	.byte	0
	.uleb128 0x12
	.ualong	.LASF69
	.byte	0x1
	.uaword	0x29c
	.ualong	0x49b
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_endoffile
	.uleb128 0x11
	.ualong	0x478
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x10
	.uleb128 0x6
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x8
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x16
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x4
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x28
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x1c
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0x5
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3c
	.uleb128 0xc
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0x21
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.ualong	0x14
	.uaword	0x2
	.ualong	.Ldebug_info0
	.byte	0x4
	.byte	0
	.uaword	0
	.uaword	0
	.ualong	0
	.ualong	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF64:
	.string	"RevLimitDelete"
.LASF55:
	.string	"modbuild"
.LASF37:
	.string	"pad1"
.LASF52:
	.string	"modauthorop"
.LASF70:
	.string	"GNU C 4.7-GNUSH_v13.01"
.LASF29:
	.string	"OpModAuth"
.LASF35:
	.string	"calidchars"
.LASF71:
	.string	"C:\\Dev\\MerpMod\\MerpMod\\Metadata.c"
.LASF17:
	.string	"OpPatch"
.LASF67:
	.string	"WGDCHook"
.LASF12:
	.string	"newval"
.LASF30:
	.string	"OpModId"
.LASF65:
	.string	"MemResetSubHook"
.LASF21:
	.string	"OpNewPatch"
.LASF40:
	.string	"modidop"
.LASF58:
	.string	"modinfo"
.LASF2:
	.string	"long int"
.LASF14:
	.string	"MetaReplace"
.LASF19:
	.string	"OpReplace4Bytes"
.LASF38:
	.string	"newcalid"
.LASF63:
	.string	"metadataheader"
.LASF15:
	.string	"OpRequireVersion"
.LASF66:
	.string	"SDHookPatch"
.LASF16:
	.string	"OpCalibrationId"
.LASF46:
	.string	"ecuidbytes"
.LASF13:
	.string	"MetaPatch"
.LASF6:
	.string	"long unsigned int"
.LASF9:
	.string	"name"
.LASF43:
	.string	"padmod"
.LASF49:
	.string	"newecuidop"
.LASF36:
	.string	"calid"
.LASF45:
	.string	"ecuidoffset"
.LASF3:
	.string	"sizetype"
.LASF10:
	.string	"address"
.LASF62:
	.string	"HERPDERP"
.LASF57:
	.string	"modinfoop"
.LASF26:
	.string	"OpECUID"
.LASF59:
	.string	"MetaHeader"
.LASF1:
	.string	"float"
.LASF20:
	.string	"OpReplaceLast2Of4Bytes"
.LASF69:
	.string	"endoffile"
.LASF5:
	.string	"unsigned char"
.LASF50:
	.string	"newecuid"
.LASF27:
	.string	"OpNewECUID"
.LASF0:
	.string	"short int"
.LASF25:
	.string	"OpJSRHook"
.LASF42:
	.string	"modid"
.LASF7:
	.string	"startaddress"
.LASF54:
	.string	"modbuildop"
.LASF32:
	.string	"reqversion"
.LASF61:
	.string	"ModIdentifier"
.LASF11:
	.string	"oldval"
.LASF60:
	.string	"RomHoleEndMarker"
.LASF68:
	.string	"RomHoleCodePatch"
.LASF33:
	.string	"calidop"
.LASF4:
	.string	"char"
.LASF44:
	.string	"ecuidop"
.LASF22:
	.string	"OpCopyNewPatch"
.LASF23:
	.string	"OpModAuthor"
.LASF18:
	.string	"OpCopyPatch"
.LASF72:
	.string	"MetaOps"
.LASF28:
	.string	"OpModInfo"
.LASF39:
	.string	"pad2"
.LASF48:
	.string	"pad3"
.LASF51:
	.string	"pad4"
.LASF56:
	.string	"pad5"
.LASF47:
	.string	"ecuid"
.LASF41:
	.string	"modidoffset"
.LASF34:
	.string	"calidoffset"
.LASF24:
	.string	"OpModBuild"
.LASF8:
	.string	"endaddress"
.LASF53:
	.string	"authname"
.LASF31:
	.string	"reqversionop"
	.ident	"GCC: (GNU) 4.7-GNUSH_v13.01"
