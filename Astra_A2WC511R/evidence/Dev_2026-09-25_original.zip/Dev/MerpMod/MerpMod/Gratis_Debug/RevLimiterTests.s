	.file	"RevLimiterTests.c"
	.text
	.text
.Ltext0:
	.cfi_sections	.debug_frame
	.section	Misc,"ax",@progbits
	.align 1
	.global	_SetClutch
	.type	_SetClutch, @function
_SetClutch:
.LFB0:
	.file 1 "C:\\Dev\\MerpMod\\MerpMod\\RevLimiterTests.c"
	.loc 1 26 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI0:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	add	#-4,r15
.LCFI1:
	.cfi_def_cfa_offset 8
	mov	r15,r14
.LCFI2:
	.cfi_def_cfa_register 14
	mov	r14,r1
	add	#-60,r1
	mov.l	r4,@(60,r1)
	.loc 1 27 0
	mov	r14,r1
	add	#-60,r1
	mov.l	@(60,r1),r1
	tst	r1,r1
	bf.s	.L2
	nop
	.loc 1 29 0
	mov.l	.L7,r1
	mov.l	.L7,r2
	mov.b	@r2,r2
	extu.b	r2,r2
	mov	#127,r3
	and	r3,r2
	extu.b	r2,r2
	mov.b	r2,@r1
	bra	.L1
	nop
	.align 1
.L2:
	.loc 1 33 0
	mov.l	.L7,r1
	mov.l	.L7,r2
	mov.b	@r2,r2
	extu.b	r2,r3
	mov	#-128,r2
	or	r3,r2
	extu.b	r2,r2
	mov.b	r2,@r1
.L1:
	.loc 1 35 0
	add	#4,r14
	mov	r14,r15
	mov.l   @r15+,r14
	rts	
	nop
.L8:
	.align 2
.L7:
	.long	-38415
	.cfi_endproc
.LFE0:
	.size	_SetClutch, .-_SetClutch
	.align 1
	.global	_SetBrake
	.type	_SetBrake, @function
_SetBrake:
.LFB1:
	.loc 1 40 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI3:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	add	#-4,r15
.LCFI4:
	.cfi_def_cfa_offset 8
	mov	r15,r14
.LCFI5:
	.cfi_def_cfa_register 14
	mov	r14,r1
	add	#-60,r1
	mov.l	r4,@(60,r1)
	.loc 1 41 0
	mov	r14,r1
	add	#-60,r1
	mov.l	@(60,r1),r1
	tst	r1,r1
	bf.s	.L10
	nop
	.loc 1 43 0
	mov.l	.L15,r1
	mov.l	.L15,r2
	mov.b	@r2,r2
	extu.b	r2,r2
	mov	#127,r3
	and	r3,r2
	extu.b	r2,r2
	mov.b	r2,@r1
	bra	.L9
	nop
	.align 1
.L10:
	.loc 1 47 0
	mov.l	.L15,r1
	mov.l	.L15,r2
	mov.b	@r2,r2
	extu.b	r2,r3
	mov	#-128,r2
	or	r3,r2
	extu.b	r2,r2
	mov.b	r2,@r1
.L9:
	.loc 1 49 0
	add	#4,r14
	mov	r14,r15
	mov.l   @r15+,r14
	rts	
	nop
.L16:
	.align 2
.L15:
	.long	-39760
	.cfi_endproc
.LFE1:
	.size	_SetBrake, .-_SetBrake
	.align 1
	.global	_GetFuelCutFlag
	.type	_GetFuelCutFlag, @function
_GetFuelCutFlag:
.LFB2:
	.loc 1 58 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI6:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	add	#-4,r15
.LCFI7:
	.cfi_def_cfa_offset 8
	mov	r15,r14
.LCFI8:
	.cfi_def_cfa_register 14
	.loc 1 60 0
	mov.l	.L20,r1
	mov.b	@r1,r1
	extu.b	r1,r3
	mov	r14,r1
	add	#3,r1
	mov	#-128,r2
	and	r3,r2
	mov.b	r2,@r1
	.loc 1 61 0
	mov	r14,r1
	add	#3,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bf.s	.L18
	nop
	.loc 1 62 0
	mov	r14,r1
	add	#3,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	bra	.L19
	nop
	.align 1
.L18:
	.loc 1 63 0
	mov	#1,r1
.L19:
	.loc 1 64 0
	mov	r1,r0
	add	#4,r14
	mov	r14,r15
	mov.l   @r15+,r14
	rts	
	nop
.L21:
	.align 2
.L20:
	.long	-35604
	.cfi_endproc
.LFE2:
	.size	_GetFuelCutFlag, .-_GetFuelCutFlag
	.align 1
	.global	_RevLimUnitTest
	.type	_RevLimUnitTest, @function
_RevLimUnitTest:
.LFB3:
	.loc 1 68 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI9:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	sts.l	pr,@-r15
.LCFI10:
	.cfi_def_cfa_offset 8
	.cfi_offset 17, -8
	add	#-24,r15
.LCFI11:
	.cfi_def_cfa_offset 32
	mov	r15,r14
.LCFI12:
	.cfi_def_cfa_register 14
	mov	r14,r1
	add	#23,r1
	mov.b	r4,@r1
	mov	r14,r1
	add	#-40,r1
	mov.l	r5,@(56,r1)
	mov	r14,r1
	add	#-40,r1
	mov.l	r6,@(52,r1)
	mov	r14,r1
	add	#8,r1
	fmov.s	fr4,@r1
	mov	r14,r1
	add	#4,r1
	fmov.s	fr5,@r1
	mov	r14,r1
	fmov.s	fr6,@r1
	.loc 1 70 0
	mov.l	.L23,r1
	jsr	@r1
	nop
	.loc 1 72 0
	mov.l	.L24,r1
	jsr	@r1
	nop
	.loc 1 80 0
	mov	r14,r1
	add	#-40,r1
	mov.l	@(56,r1),r1
	mov	r1,r4
	mov.l	.L25,r1
	jsr	@r1
	nop
	.loc 1 83 0
	mov	r14,r1
	add	#-40,r1
	mov.l	@(52,r1),r1
	mov	r1,r4
	mov.l	.L26,r1
	jsr	@r1
	nop
	.loc 1 84 0
	mov.l	.L27,r1
	mov	r14,r2
	add	#8,r2
	fmov.s	@r2,fr1
	fmov.s	fr1,@r1
	.loc 1 85 0
	mov.l	.L28,r1
	mov	r14,r2
	fmov.s	@r2,fr1
	fmov.s	fr1,@r1
	.loc 1 86 0
	mov.l	.L29,r1
	mov	r14,r2
	add	#4,r2
	fmov.s	@r2,fr1
	fmov.s	fr1,@r1
	.loc 1 89 0
	mov.l	.L30,r1
	mov	r14,r2
	add	#23,r2
	mov.b	@r2,r2
	mov.b	r2,@r1
	.loc 1 91 0
	mov.l	.L31,r1
	jsr	@r1
	nop
	.loc 1 92 0
	add	#24,r14
	mov	r14,r15
	lds.l   @r15+,pr
	mov.l   @r15+,r14
	rts	
	nop
.L32:
	.align 2
.L23:
	.long	_ClearRam
.L24:
	.long	_PopulateRamVariables
.L25:
	.long	_SetBrake
.L26:
	.long	_SetClutch
.L27:
	.long	-39108
.L28:
	.long	-38376
.L29:
	.long	-38384
.L30:
	.long	-35604
.L31:
	.long	_RevLimCode
	.cfi_endproc
.LFE3:
	.size	_RevLimUnitTest, .-_RevLimUnitTest
	.section	.rodata
	.align 2
.LC0:
	.string	"RedLine: Allow fuel at RedLineCut - 1 RPM, moving, clutch not pressed !FuelCut"
	.align 2
.LC1:
	.string	"RedLine: Allow fuel at RedLineCut - 1 RPM, moving, clutch not pressed, !LCEngaged"
	.align 2
.LC2:
	.string	"RedLine: Cut fuel at RedLineCut + 1 RPM, moving, clutch not pressed"
	.align 2
.LC3:
	.string	"RedLine: Resume fuel at RedLineResume - 1 RPM, moving, clutch not pressed"
	.align 2
.LC4:
	.string	"Normal stopped: Allow fuel at LaunchControlCut + 1000 RPM, stopped, no clutch"
	.align 2
.LC5:
	.string	"Normal moving: Allow fuel at LaunchControlCut + 1000 RPM, moving, no clutch"
	.align 2
.LC6:
	.string	"Launch Control Test 3 Failed: standstill, clutch pressed"
	.align 2
.LC7:
	.string	"Launch Control Test 4 Failed: 0 mph, 100 thr, rpm below limit"
	.align 2
.LC8:
	.string	"Launch Control: Cut fuel at LaunchControlCut + 1 RPM, standstill, clutch pressed"
	.align 2
.LC9:
	.string	"Launch Control: Resume fuel at LaunchControlResume - 1 RPM, standstill, clutch pressed"
	.align 2
.LC10:
	.string	"Flat Foot Shifting: Resume fuel at FlatFootShiftResume - 1 RPM, moving, clutch pressed"
	.align 2
.LC11:
	.string	"FFS Intermediate step"
	.align 2
.LC12:
	.string	"Flat Foot Shifting: Cut fuel at FlatFootShiftCut + 1 RPM, moving, clutch pressed"
	.align 2
.LC13:
	.string	"FFS resume when rpm drops"
	.align 2
.LC14:
	.string	"When rev limit flag is set, no other bits are set."
	.align 2
.LC15:
	.string	"When rev limit flag is cleared, no other bits are cleared."
	.align 2
.LC16:
	.string	"RedLine cut/resume sanity."
	.align 2
.LC17:
	.string	"LaunchControl cut/resume sanity."
	.section	Misc
	.align 1
	.global	_RevLimUnitTests
	.type	_RevLimUnitTests, @function
_RevLimUnitTests:
.LFB4:
	.loc 1 97 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI13:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	sts.l	pr,@-r15
.LCFI14:
	.cfi_def_cfa_offset 8
	.cfi_offset 17, -8
	add	#-4,r15
.LCFI15:
	.cfi_def_cfa_offset 12
	mov	r15,r14
.LCFI16:
	.cfi_def_cfa_register 14
	.loc 1 101 0
	mov.l	.L82,r1
	fmov.s	@r1,fr2
	fldi1	fr1
	fmov	fr2,fr3
	fsub	fr1,fr3
	fmov	fr3,fr1
	mova	.L74,r0
	fmov.s	@r0+,fr3
	fmov.s	@r0,fr2
	mov	#0,r4
	mov	#0,r5
	mov	#0,r6
	fmov	fr3,fr4
	fmov	fr2,fr5
	fmov	fr1,fr6
	mov.l	.L91,r1
	jsr	@r1
	nop
	.loc 1 102 0
	mov.l	.L92,r1
	jsr	@r1
	nop
	mov	r0,r1
	extu.b	r1,r1
	tst	r1,r1
	movt	r1
	extu.b	r1,r1
	lds	r1,fpul
	fsts	fpul,fr1
	mov.l	.L68,r1
	flds	fr1,fpul
	sts	fpul,r4
	mov	r1,r5
	mov.l	.L88,r1
	jsr	@r1
	nop
	.loc 1 103 0
	mov.w	.L93,r1
	add	#47,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	movt	r1
	extu.b	r1,r1
	lds	r1,fpul
	fsts	fpul,fr1
	mov.l	.L71,r1
	flds	fr1,fpul
	sts	fpul,r4
	mov	r1,r5
	mov.l	.L88,r1
	jsr	@r1
	nop
	.loc 1 106 0
	mov.l	.L82,r1
	fmov.s	@r1,fr2
	fldi1	fr1
	fadd	fr2,fr1
	mova	.L74,r0
	fmov.s	@r0,fr3
	mova	.L75,r0
	fmov.s	@r0,fr2
	mov	#0,r4
	mov	#0,r5
	mov	#0,r6
	fmov	fr3,fr4
	fmov	fr2,fr5
	fmov	fr1,fr6
	mov.l	.L91,r1
	jsr	@r1
	nop
	.loc 1 107 0
	mov.l	.L92,r1
	jsr	@r1
	nop
	mov	r0,r1
	extu.b	r1,r1
	tst	r1,r1
	bt.s	.L34
	nop
	.loc 1 107 0 is_stmt 0 discriminator 1
	mov.w	.L93,r1
	add	#47,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bf.s	.L34
	nop
	.loc 1 107 0 discriminator 3
	mov	#1,r1
	bra	.L35
	nop
	.align 1
.L34:
	.loc 1 107 0 discriminator 2
	mov	#0,r1
.L35:
	.loc 1 107 0 discriminator 4
	mov.l	.L79,r2
	mov	r1,r4
	mov	r2,r5
	mov.l	.L88,r1
	jsr	@r1
	nop
	.loc 1 110 0 is_stmt 1 discriminator 4
	mov.l	.L81,r1
	mov.l	.L82,r2
	fmov.s	@r2,fr2
	mov.l	.L83,r2
	fmov.s	@r2,fr1
	fsub	fr1,fr2
	fldi1	fr1
	fmov	fr2,fr3
	fsub	fr1,fr3
	fmov	fr3,fr1
	fmov.s	fr1,@r1
	.loc 1 111 0 discriminator 4
	mov.l	.L84,r1
	jsr	@r1
	nop
	.loc 1 112 0 discriminator 4
	mov.l	.L92,r1
	jsr	@r1
	nop
	mov	r0,r1
	extu.b	r1,r1
	tst	r1,r1
	bf.s	.L36
	nop
	.loc 1 112 0 is_stmt 0 discriminator 1
	mov.w	.L93,r1
	add	#47,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bf.s	.L36
	nop
	.loc 1 112 0 discriminator 3
	mov	#1,r1
	bra	.L37
	nop
	.align 1
.L36:
	.loc 1 112 0 discriminator 2
	mov	#0,r1
.L37:
	.loc 1 112 0 discriminator 4
	mov.l	.L87,r2
	mov	r1,r4
	mov	r2,r5
	mov.l	.L88,r1
	jsr	@r1
	nop
	.loc 1 122 0 is_stmt 1 discriminator 4
	mov.l	.L89,r1
	fmov.s	@r1,fr1
	mova	.L90,r0
	fmov.s	@r0+,fr2
	fadd	fr2,fr1
	fmov.s	@r0,fr3
	fldi0	fr2
	mov	#0,r4
	mov	#0,r5
	mov	#0,r6
	fmov	fr3,fr4
	fmov	fr2,fr5
	fmov	fr1,fr6
	mov.l	.L91,r1
	jsr	@r1
	nop
	.loc 1 124 0 discriminator 4
	mov.l	.L92,r1
	jsr	@r1
	nop
	mov	r0,r1
	extu.b	r1,r1
	tst	r1,r1
	bf.s	.L38
	nop
	.loc 1 124 0 is_stmt 0 discriminator 1
	mov.w	.L93,r1
	add	#47,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bf.s	.L38
	nop
	.loc 1 124 0 discriminator 3
	mov	#1,r1
	bra	.L39
	nop
	.align 1
.L93:
	.short	-26944
.L94:
	.align 2
.L82:
	.long	_DefaultRedLineCut
.L74:
	.long	1112014848
	.long	1100480512
.L91:
	.long	_RevLimUnitTest
.L92:
	.long	_GetFuelCutFlag
.L68:
	.long	.LC0
.L88:
	.long	_Assert
.L71:
	.long	.LC1
.L75:
	.long	1099956224
.L79:
	.long	.LC2
.L81:
	.long	-38376
.L83:
	.long	_DefaultRedLineHyst
.L84:
	.long	_RevLimCode
.L87:
	.long	.LC3
.L89:
	.long	_DefaultLaunchControlCut
.L90:
	.long	1148846080
	.long	1120403456
	.align 1
.L38:
	.loc 1 124 0 discriminator 2
	mov	#0,r1
.L39:
	.loc 1 124 0 discriminator 4
	mov.l	.L95,r2
	mov	r1,r4
	mov	r2,r5
	mov.l	.L110,r1
	jsr	@r1
	nop
	.loc 1 129 0 is_stmt 1 discriminator 4
	mov.l	.L111,r1
	fmov.s	@r1,fr1
	mova	.L98,r0
	fmov.s	@r0+,fr2
	fadd	fr2,fr1
	fmov.s	@r0+,fr3
	fmov.s	@r0,fr2
	mov	#0,r4
	mov	#0,r5
	mov	#0,r6
	fmov	fr3,fr4
	fmov	fr2,fr5
	fmov	fr1,fr6
	mov.l	.L113,r1
	jsr	@r1
	nop
	.loc 1 130 0 discriminator 4
	mov.l	.L114,r1
	jsr	@r1
	nop
	mov	r0,r1
	extu.b	r1,r1
	tst	r1,r1
	bf.s	.L40
	nop
	.loc 1 130 0 is_stmt 0 discriminator 1
	mov.w	.L115,r1
	add	#47,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bf.s	.L40
	nop
	.loc 1 130 0 discriminator 3
	mov	#1,r1
	bra	.L41
	nop
	.align 1
.L40:
	.loc 1 130 0 discriminator 2
	mov	#0,r1
.L41:
	.loc 1 130 0 discriminator 4
	mov.l	.L102,r2
	mov	r1,r4
	mov	r2,r5
	mov.l	.L110,r1
	jsr	@r1
	nop
	.loc 1 136 0 is_stmt 1 discriminator 4
	mov.l	.L111,r1
	fmov.s	@r1,fr2
	fldi1	fr1
	fmov	fr2,fr3
	fsub	fr1,fr3
	fmov	fr3,fr1
	mova	.L105,r0
	fmov.s	@r0,fr3
	fldi0	fr2
	mov	#0,r4
	mov	#0,r5
	mov	#1,r6
	fmov	fr3,fr4
	fmov	fr2,fr5
	fmov	fr1,fr6
	mov.l	.L113,r1
	jsr	@r1
	nop
	.loc 1 137 0 discriminator 4
	mov.l	.L114,r1
	jsr	@r1
	nop
	mov	r0,r1
	extu.b	r1,r1
	tst	r1,r1
	bf.s	.L42
	nop
	.loc 1 137 0 is_stmt 0 discriminator 1
	mov.w	.L115,r1
	add	#47,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bf.s	.L42
	nop
	.loc 1 137 0 discriminator 3
	mov	#1,r1
	bra	.L43
	nop
	.align 1
.L42:
	.loc 1 137 0 discriminator 2
	mov	#0,r1
.L43:
	.loc 1 137 0 discriminator 4
	mov.l	.L109,r2
	mov	r1,r4
	mov	r2,r5
	mov.l	.L110,r1
	jsr	@r1
	nop
	.loc 1 141 0 is_stmt 1 discriminator 4
	mov.l	.L111,r1
	fmov.s	@r1,fr2
	fldi1	fr1
	fmov	fr2,fr3
	fsub	fr1,fr3
	fmov	fr3,fr1
	mova	.L112,r0
	fmov.s	@r0,fr3
	fldi0	fr2
	mov	#0,r4
	mov	#0,r5
	mov	#1,r6
	fmov	fr3,fr4
	fmov	fr2,fr5
	fmov	fr1,fr6
	mov.l	.L113,r1
	jsr	@r1
	nop
	.loc 1 142 0 discriminator 4
	mov.l	.L114,r1
	jsr	@r1
	nop
	mov	r0,r1
	extu.b	r1,r1
	tst	r1,r1
	bf.s	.L44
	nop
	.loc 1 142 0 is_stmt 0 discriminator 1
	mov.w	.L115,r1
	add	#47,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bt.s	.L44
	nop
	.loc 1 142 0 discriminator 3
	mov	#1,r1
	bra	.L45
	nop
	.align 1
.L115:
	.short	-26944
.L116:
	.align 2
.L95:
	.long	.LC4
.L110:
	.long	_Assert
.L111:
	.long	_DefaultLaunchControlCut
.L98:
	.long	1148846080
.L112:
	.long	1120403456
	.long	1112014848
.L113:
	.long	_RevLimUnitTest
.L114:
	.long	_GetFuelCutFlag
.L102:
	.long	.LC5
.L105:
	.long	1092616192
.L109:
	.long	.LC6
	.align 1
.L44:
	.loc 1 142 0 discriminator 2
	mov	#0,r1
.L45:
	.loc 1 142 0 discriminator 4
	mov.l	.L117,r2
	mov	r1,r4
	mov	r2,r5
	mov.l	.L140,r1
	jsr	@r1
	nop
	.loc 1 147 0 is_stmt 1 discriminator 4
	mov.l	.L134,r1
	fmov.s	@r1,fr2
	fldi1	fr1
	fadd	fr2,fr1
	mova	.L120,r0
	fmov.s	@r0,fr3
	fldi0	fr2
	mov	#0,r4
	mov	#0,r5
	mov	#1,r6
	fmov	fr3,fr4
	fmov	fr2,fr5
	fmov	fr1,fr6
	mov.l	.L144,r1
	jsr	@r1
	nop
	.loc 1 148 0 discriminator 4
	mov.l	.L145,r1
	jsr	@r1
	nop
	mov	r0,r1
	extu.b	r1,r1
	tst	r1,r1
	bt.s	.L46
	nop
	.loc 1 148 0 is_stmt 0 discriminator 1
	mov.w	.L146,r1
	add	#47,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bt.s	.L46
	nop
	.loc 1 148 0 discriminator 3
	mov	#1,r1
	bra	.L47
	nop
	.align 1
.L46:
	.loc 1 148 0 discriminator 2
	mov	#0,r1
.L47:
	.loc 1 148 0 discriminator 4
	mov.l	.L124,r2
	mov	r1,r4
	mov	r2,r5
	mov.l	.L140,r1
	jsr	@r1
	nop
	.loc 1 153 0 is_stmt 1 discriminator 4
	mov.l	.L133,r1
	mov.l	.L134,r2
	fmov.s	@r2,fr2
	fldi1	fr1
	fmov	fr2,fr3
	fsub	fr1,fr3
	fmov	fr3,fr1
	fmov.s	fr1,@r1
	.loc 1 154 0 discriminator 4
	mov.l	.L136,r1
	jsr	@r1
	nop
	.loc 1 155 0 discriminator 4
	mov.l	.L145,r1
	jsr	@r1
	nop
	mov	r0,r1
	extu.b	r1,r1
	tst	r1,r1
	bt.s	.L48
	nop
	.loc 1 155 0 is_stmt 0 discriminator 1
	mov.w	.L146,r1
	add	#47,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bt.s	.L48
	nop
	.loc 1 155 0 discriminator 3
	mov	#1,r1
	bra	.L49
	nop
	.align 1
.L48:
	.loc 1 155 0 discriminator 2
	mov	#0,r1
.L49:
	.loc 1 155 0 discriminator 4
	mov.l	.L139,r2
	mov	r1,r4
	mov	r2,r5
	mov.l	.L140,r1
	jsr	@r1
	nop
	.loc 1 162 0 is_stmt 1 discriminator 4
	mov.l	.L133,r1
	mov.l	.L134,r2
	fmov.s	@r2,fr2
	mov.l	.L135,r2
	fmov.s	@r2,fr1
	fsub	fr1,fr2
	fldi1	fr1
	fmov	fr2,fr4
	fsub	fr1,fr4
	fmov	fr4,fr1
	fmov.s	fr1,@r1
	.loc 1 163 0 discriminator 4
	mov.l	.L136,r1
	jsr	@r1
	nop
	.loc 1 164 0 discriminator 4
	mov.l	.L145,r1
	jsr	@r1
	nop
	mov	r0,r1
	extu.b	r1,r1
	tst	r1,r1
	bf.s	.L50
	nop
	.loc 1 164 0 is_stmt 0 discriminator 1
	mov.w	.L146,r1
	add	#47,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bt.s	.L50
	nop
	.loc 1 164 0 discriminator 3
	mov	#1,r1
	bra	.L51
	nop
	.align 1
.L50:
	.loc 1 164 0 discriminator 2
	mov	#0,r1
.L51:
	.loc 1 164 0 discriminator 4
	mov.l	.L139,r2
	mov	r1,r4
	mov	r2,r5
	mov.l	.L140,r1
	jsr	@r1
	nop
	.loc 1 168 0 is_stmt 1 discriminator 4
	mov.l	.L141,r1
	fmov.s	@r1,fr2
	fldi1	fr1
	fmov	fr2,fr3
	fadd	fr1,fr3
	mov.l	.L142,r1
	fmov.s	@r1,fr1
	mova	.L143,r0
	fmov.s	@r0,fr2
	fsub	fr2,fr1
	fldi0	fr2
	mov	#0,r4
	mov	#0,r5
	mov	#1,r6
	fmov	fr3,fr4
	fmov	fr2,fr5
	fmov	fr1,fr6
	mov.l	.L144,r1
	jsr	@r1
	nop
	.loc 1 170 0 discriminator 4
	mov.l	.L145,r1
	jsr	@r1
	nop
	mov	r0,r1
	extu.b	r1,r1
	tst	r1,r1
	bt.s	.L52
	nop
	.loc 1 170 0 is_stmt 0 discriminator 1
	mov.w	.L146,r1
	add	#47,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bt.s	.L52
	nop
	.loc 1 170 0 discriminator 3
	mov	#1,r1
	bra	.L53
	nop
	.align 1
.L146:
	.short	-26944
.L147:
	.align 2
.L117:
	.long	.LC7
.L140:
	.long	_Assert
.L134:
	.long	_DefaultLaunchControlCut
.L120:
	.long	1120403456
.L144:
	.long	_RevLimUnitTest
.L145:
	.long	_GetFuelCutFlag
.L124:
	.long	.LC8
.L133:
	.long	-38376
.L136:
	.long	_RevLimCode
.L139:
	.long	.LC9
.L135:
	.long	_DefaultLaunchControlHyst
.L141:
	.long	_LCMinimumThrottle
.L142:
	.long	_DefaultRedLineCut
.L143:
	.long	1128792064
	.align 1
.L52:
	.loc 1 170 0 discriminator 2
	mov	#0,r1
.L53:
	.loc 1 170 0 discriminator 4
	mov.l	.L156,r2
	mov	r1,r4
	mov	r2,r5
	mov.l	.L185,r1
	jsr	@r1
	nop
	.loc 1 171 0 is_stmt 1 discriminator 4
	mov.l	.L177,r1
	mov.l	.L177,r2
	fmov.s	@r2,fr1
	mova	.L152,r0
	fmov.s	@r0,fr2
	fsub	fr2,fr1
	fmov.s	fr1,@r1
	.loc 1 172 0 discriminator 4
	mov.l	.L186,r1
	jsr	@r1
	nop
	.loc 1 173 0 discriminator 4
	mov.l	.L187,r1
	jsr	@r1
	nop
	mov	r0,r1
	extu.b	r1,r1
	tst	r1,r1
	bf.s	.L54
	nop
	.loc 1 173 0 is_stmt 0 discriminator 1
	mov.w	.L188,r1
	add	#47,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bf.s	.L54
	nop
	.loc 1 173 0 discriminator 3
	mov	#1,r1
	bra	.L55
	nop
	.align 1
.L54:
	.loc 1 173 0 discriminator 2
	mov	#0,r1
.L55:
	.loc 1 173 0 discriminator 4
	mov.l	.L156,r2
	mov	r1,r4
	mov	r2,r5
	mov.l	.L185,r1
	jsr	@r1
	nop
	.loc 1 210 0 is_stmt 1 discriminator 4
	mov.l	.L158,r1
	mov	#4,r2
	mov.b	r2,@r1
	.loc 1 213 0 discriminator 4
	mov.l	.L177,r1
	mova	.L160,r0
	fmov.s	@r0,fr1
	fmov.s	fr1,@r1
	.loc 1 214 0 discriminator 4
	mov.l	.L161,r1
	mova	.L162,r0
	fmov.s	@r0,fr1
	fmov.s	fr1,@r1
	.loc 1 215 0 discriminator 4
	mov.l	.L174,r1
	mov.w	.L188,r2
	add	#72,r2
	fmov.s	@r2,fr1
	mova	.L165,r0
	fmov.s	@r0,fr2
	fsub	fr2,fr1
	fmov.s	fr1,@r1
	.loc 1 216 0 discriminator 4
	mov	#0,r4
	mov.l	.L181,r1
	jsr	@r1
	nop
	.loc 1 217 0 discriminator 4
	mov.l	.L186,r1
	jsr	@r1
	nop
	.loc 1 218 0 discriminator 4
	mov	#1,r4
	mov.l	.L181,r1
	jsr	@r1
	nop
	.loc 1 219 0 discriminator 4
	mov.l	.L186,r1
	jsr	@r1
	nop
	.loc 1 221 0 discriminator 4
	mov.l	.L187,r1
	jsr	@r1
	nop
	mov	r0,r1
	extu.b	r1,r1
	tst	r1,r1
	bf.s	.L56
	nop
	.loc 1 221 0 is_stmt 0 discriminator 1
	mov.w	.L188,r1
	add	#47,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bf.s	.L56
	nop
	.loc 1 221 0 discriminator 3
	mov	#1,r1
	bra	.L57
	nop
	.align 1
.L56:
	.loc 1 221 0 discriminator 2
	mov	#0,r1
.L57:
	.loc 1 221 0 discriminator 4
	mov.l	.L172,r2
	mov	r1,r4
	mov	r2,r5
	mov.l	.L185,r1
	jsr	@r1
	nop
	.loc 1 225 0 is_stmt 1 discriminator 4
	mov.l	.L174,r1
	mov.w	.L188,r2
	add	#84,r2
	fmov.s	@r2,fr1
	mova	.L176,r0
	fmov.s	@r0,fr2
	fadd	fr2,fr1
	fmov.s	fr1,@r1
	.loc 1 226 0 discriminator 4
	mov.l	.L177,r1
	mov.l	.L178,r2
	fmov.s	@r2,fr2
	fldi1	fr1
	fadd	fr2,fr1
	fmov.s	fr1,@r1
	.loc 1 227 0 discriminator 4
	mov	#0,r4
	mov.l	.L181,r1
	jsr	@r1
	nop
	.loc 1 228 0 discriminator 4
	mov.l	.L186,r1
	jsr	@r1
	nop
	.loc 1 229 0 discriminator 4
	mov	#1,r4
	mov.l	.L181,r1
	jsr	@r1
	nop
	.loc 1 230 0 discriminator 4
	mov.l	.L186,r1
	jsr	@r1
	nop
	.loc 1 231 0 discriminator 4
	mov.w	.L188,r1
	add	#48,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	mov	r1,r0
	cmp/eq	#1,r0
	movt	r1
	extu.b	r1,r1
	lds	r1,fpul
	fsts	fpul,fr1
	mov.l	.L184,r1
	flds	fr1,fpul
	sts	fpul,r4
	mov	r1,r5
	mov.l	.L185,r1
	jsr	@r1
	nop
	.loc 1 232 0 discriminator 4
	mov.l	.L186,r1
	jsr	@r1
	nop
	.loc 1 233 0 discriminator 4
	mov.l	.L187,r1
	jsr	@r1
	nop
	mov	r0,r1
	extu.b	r1,r1
	tst	r1,r1
	bt.s	.L58
	nop
	.loc 1 233 0 is_stmt 0 discriminator 1
	mov.w	.L188,r1
	add	#48,r1
	mov.b	@r1,r1
	extu.b	r1,r2
	mov	#2,r1
	cmp/eq	r1,r2
	bf.s	.L58
	nop
	.loc 1 233 0 discriminator 3
	mov	#1,r1
	bra	.L59
	nop
	.align 1
.L188:
	.short	-26944
.L189:
	.align 2
.L156:
	.long	.LC9
.L185:
	.long	_Assert
.L177:
	.long	-39108
.L152:
	.long	1092616192
.L186:
	.long	_RevLimCode
.L187:
	.long	_GetFuelCutFlag
.L158:
	.long	-38111
.L160:
	.long	1101004800
.L161:
	.long	-38384
.L162:
	.long	1112014848
.L174:
	.long	-38376
.L165:
	.long	1120403456
.L181:
	.long	_SetClutch
.L172:
	.long	.LC10
.L176:
	.long	1140457472
.L178:
	.long	_FFSMinimumThrottle
.L184:
	.long	.LC11
	.align 1
.L58:
	.loc 1 233 0 discriminator 2
	mov	#0,r1
.L59:
	.loc 1 233 0 discriminator 4
	mov.l	.L190,r2
	mov	r1,r4
	mov	r2,r5
	mov.l	.L198,r1
	jsr	@r1
	nop
	.loc 1 237 0 is_stmt 1 discriminator 4
	mov.l	.L199,r1
	mov.w	.L205,r2
	add	#56,r2
	fmov.s	@r2,fr2
	fldi1	fr1
	fmov	fr2,fr3
	fsub	fr1,fr3
	fmov	fr3,fr1
	fmov.s	fr1,@r1
	.loc 1 238 0 discriminator 4
	mov.l	.L203,r1
	jsr	@r1
	nop
	.loc 1 239 0 discriminator 4
	mov.l	.L204,r1
	jsr	@r1
	nop
	mov	r0,r1
	extu.b	r1,r1
	tst	r1,r1
	bf.s	.L60
	nop
	.loc 1 239 0 is_stmt 0 discriminator 1
	mov.w	.L205,r1
	add	#48,r1
	mov.b	@r1,r1
	extu.b	r1,r2
	mov	#2,r1
	cmp/eq	r1,r2
	bf.s	.L60
	nop
	.loc 1 239 0 discriminator 3
	mov	#1,r1
	bra	.L61
	nop
	.align 1
.L60:
	.loc 1 239 0 discriminator 2
	mov	#0,r1
.L61:
	.loc 1 239 0 discriminator 4
	mov.l	.L197,r2
	mov	r1,r4
	mov	r2,r5
	mov.l	.L198,r1
	jsr	@r1
	nop
	.loc 1 242 0 is_stmt 1 discriminator 4
	mov.l	.L199,r1
	mov.w	.L205,r2
	add	#84,r2
	fmov.s	@r2,fr1
	mova	.L201,r0
	fmov.s	@r0,fr2
	fadd	fr2,fr1
	fmov.s	fr1,@r1
	.loc 1 243 0 discriminator 4
	mov.l	.L203,r1
	jsr	@r1
	nop
	.loc 1 244 0 discriminator 4
	mov.l	.L203,r1
	jsr	@r1
	nop
	.loc 1 245 0 discriminator 4
	mov.l	.L204,r1
	jsr	@r1
	nop
	mov	r0,r1
	extu.b	r1,r1
	tst	r1,r1
	bt.s	.L62
	nop
	.loc 1 245 0 is_stmt 0 discriminator 1
	mov.w	.L205,r1
	add	#48,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bt.s	.L62
	nop
	.loc 1 245 0 discriminator 3
	mov	#1,r1
	bra	.L63
	nop
	.align 1
.L205:
	.short	-26944
.L206:
	.align 2
.L190:
	.long	.LC12
.L198:
	.long	_Assert
.L199:
	.long	-38376
.L203:
	.long	_RevLimCode
.L204:
	.long	_GetFuelCutFlag
.L197:
	.long	.LC13
.L201:
	.long	1140457472
	.align 1
.L62:
	.loc 1 245 0 discriminator 2
	mov	#0,r1
.L63:
	.loc 1 245 0 discriminator 4
	mov.l	.L207,r2
	mov	r1,r4
	mov	r2,r5
	mov.l	.L251,r1
	jsr	@r1
	nop
	.loc 1 247 0 is_stmt 1 discriminator 4
	mov.l	.L219,r1
	mov.l	.L210,r2
	fmov.s	@r2,fr2
	fldi1	fr1
	fmov	fr2,fr3
	fsub	fr1,fr3
	fmov	fr3,fr1
	fmov.s	fr1,@r1
	.loc 1 248 0 discriminator 4
	mov.l	.L234,r1
	mova	.L212,r0
	fmov.s	@r0,fr1
	fmov.s	fr1,@r1
	.loc 1 249 0 discriminator 4
	mov	#1,r4
	mov.l	.L235,r1
	jsr	@r1
	nop
	.loc 1 250 0 discriminator 4
	mov.l	.L237,r1
	jsr	@r1
	nop
	.loc 1 251 0 discriminator 4
	mov.l	.L237,r1
	jsr	@r1
	nop
	.loc 1 252 0 discriminator 4
	mov.l	.L216,r1
	jsr	@r1
	nop
	mov	r0,r1
	extu.b	r1,r1
	tst	r1,r1
	movt	r1
	extu.b	r1,r1
	lds	r1,fpul
	fsts	fpul,fr1
	mov.l	.L217,r1
	flds	fr1,fpul
	sts	fpul,r4
	mov	r1,r5
	mov.l	.L251,r1
	jsr	@r1
	nop
	.loc 1 253 0 discriminator 4
	mov.l	.L219,r1
	mova	.L220,r0
	fmov.s	@r0,fr1
	fmov.s	fr1,@r1
	.loc 1 258 0 discriminator 4
	mov.l	.L232,r1
	mova	.L222,r0
	fmov.s	@r0,fr1
	fmov.s	fr1,@r1
	.loc 1 259 0 discriminator 4
	mov.l	.L234,r1
	fldi0	fr1
	fmov.s	fr1,@r1
	.loc 1 260 0 discriminator 4
	mov	#1,r4
	mov.l	.L235,r1
	jsr	@r1
	nop
	.loc 1 262 0 discriminator 4
	mov	#0,r4
	mov.l	.L225,r1
	jsr	@r1
	nop
	.loc 1 264 0 discriminator 4
	mov.l	.L238,r1
	mov	#0,r2
	mov.b	r2,@r1
	.loc 1 265 0 discriminator 4
	mov.l	.L237,r1
	jsr	@r1
	nop
	.loc 1 266 0 discriminator 4
	mov.l	.L238,r2
	mov	r14,r1
	add	#3,r1
	mov.b	@r2,r2
	mov.b	r2,@r1
	.loc 1 267 0 discriminator 4
	mov	r14,r1
	add	#3,r1
	mov.b	@r1,r1
	extu.b	r1,r2
	mov.w	.L239,r1
	cmp/eq	r1,r2
	movt	r1
	extu.b	r1,r1
	lds	r1,fpul
	fsts	fpul,fr1
	mov.l	.L230,r1
	flds	fr1,fpul
	sts	fpul,r4
	mov	r1,r5
	mov.l	.L251,r1
	jsr	@r1
	nop
	.loc 1 270 0 discriminator 4
	mov.l	.L232,r1
	mova	.L233,r0
	fmov.s	@r0,fr1
	fmov.s	fr1,@r1
	.loc 1 271 0 discriminator 4
	mov.l	.L234,r1
	fldi0	fr1
	fmov.s	fr1,@r1
	.loc 1 272 0 discriminator 4
	mov	#0,r4
	mov.l	.L235,r1
	jsr	@r1
	nop
	.loc 1 273 0 discriminator 4
	mov.l	.L238,r1
	mov	#-1,r2
	mov.b	r2,@r1
	.loc 1 274 0 discriminator 4
	mov.l	.L237,r1
	jsr	@r1
	nop
	.loc 1 275 0 discriminator 4
	mov.l	.L238,r1
	mov.b	@r1,r1
	extu.b	r1,r2
	mov	r14,r1
	add	#3,r1
	not	r2,r2
	mov.b	r2,@r1
	.loc 1 276 0 discriminator 4
	mov	r14,r1
	add	#3,r1
	mov.b	@r1,r1
	extu.b	r1,r2
	mov.w	.L239,r1
	cmp/eq	r1,r2
	movt	r1
	extu.b	r1,r1
	lds	r1,fpul
	fsts	fpul,fr1
	mov.l	.L240,r1
	flds	fr1,fpul
	sts	fpul,r4
	mov	r1,r5
	mov.l	.L251,r1
	jsr	@r1
	nop
	.loc 1 279 0 discriminator 4
	mov.w	.L249,r1
	add	#60,r1
	fmov.s	@r1,fr2
	mov.w	.L249,r1
	add	#60,r1
	fmov.s	@r1,fr3
	mov.w	.L249,r1
	add	#64,r1
	fmov.s	@r1,fr1
	fmov	fr3,fr4
	fsub	fr1,fr4
	fmov	fr4,fr1
	fcmp/gt	fr1,fr2
	movt	r1
	extu.b	r1,r1
	lds	r1,fpul
	fsts	fpul,fr1
	mov.l	.L245,r1
	flds	fr1,fpul
	sts	fpul,r4
	mov	r1,r5
	mov.l	.L251,r1
	jsr	@r1
	nop
	.loc 1 280 0 discriminator 4
	mov.w	.L249,r1
	add	#72,r1
	fmov.s	@r1,fr2
	mov.w	.L249,r1
	add	#72,r1
	fmov.s	@r1,fr3
	mov.w	.L249,r1
	add	#76,r1
	fmov.s	@r1,fr1
	fmov	fr3,fr4
	fsub	fr1,fr4
	fmov	fr4,fr1
	fcmp/gt	fr1,fr2
	movt	r1
	extu.b	r1,r1
	lds	r1,fpul
	fsts	fpul,fr1
	mov.l	.L250,r1
	flds	fr1,fpul
	sts	fpul,r4
	mov	r1,r5
	mov.l	.L251,r1
	jsr	@r1
	nop
	.loc 1 281 0 discriminator 4
	add	#4,r14
	mov	r14,r15
	lds.l   @r15+,pr
	mov.l   @r15+,r14
	rts	
	nop
	.align 1
.L239:
	.short	128
.L249:
	.short	-26944
.L252:
	.align 2
.L207:
	.long	.LC12
.L251:
	.long	_Assert
.L219:
	.long	-39108
.L210:
	.long	_FFSMinimumThrottle
.L234:
	.long	-38384
.L212:
	.long	1100480512
.L235:
	.long	_SetClutch
.L237:
	.long	_RevLimCode
.L216:
	.long	_GetFuelCutFlag
.L217:
	.long	.LC10
.L220:
	.long	1120403456
.L232:
	.long	-38376
.L222:
	.long	1169915904
.L225:
	.long	_SetBrake
.L238:
	.long	-35604
.L230:
	.long	.LC14
.L233:
	.long	1148846080
.L240:
	.long	.LC15
.L245:
	.long	.LC16
.L250:
	.long	.LC17
	.cfi_endproc
.LFE4:
	.size	_RevLimUnitTests, .-_RevLimUnitTests
	.text
.Letext0:
	.file 2 "C:\\Dev\\MerpMod\\MerpMod\\RamVariables.h"
	.file 3 "C:\\Dev\\MerpMod\\MerpMod\\Externs.h"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.ualong	0x448
	.uaword	0x2
	.ualong	.Ldebug_abbrev0
	.byte	0x4
	.uleb128 0x1
	.ualong	.LASF67
	.byte	0x1
	.ualong	.LASF68
	.ualong	.Ldebug_ranges0+0
	.ualong	0
	.ualong	0
	.ualong	.Ldebug_line0
	.uleb128 0x2
	.byte	0x2
	.byte	0x5
	.ualong	.LASF0
	.uleb128 0x2
	.byte	0x4
	.byte	0x4
	.ualong	.LASF1
	.uleb128 0x3
	.byte	0x4
	.byte	0x5
	.string	"int"
	.uleb128 0x2
	.byte	0x4
	.byte	0x5
	.ualong	.LASF2
	.uleb128 0x2
	.byte	0x4
	.byte	0x7
	.ualong	.LASF3
	.uleb128 0x2
	.byte	0x1
	.byte	0x6
	.ualong	.LASF4
	.uleb128 0x4
	.byte	0x70
	.byte	0x2
	.byte	0x12
	.ualong	0x2b4
	.uleb128 0x5
	.ualong	.LASF5
	.byte	0x2
	.byte	0x14
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0
	.uleb128 0x5
	.ualong	.LASF6
	.byte	0x2
	.byte	0x15
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x1
	.uleb128 0x5
	.ualong	.LASF7
	.byte	0x2
	.byte	0x16
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x2
	.uleb128 0x5
	.ualong	.LASF8
	.byte	0x2
	.byte	0x17
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x3
	.uleb128 0x5
	.ualong	.LASF9
	.byte	0x2
	.byte	0x18
	.ualong	0x2bb
	.byte	0x2
	.byte	0x23
	.uleb128 0x4
	.uleb128 0x5
	.ualong	.LASF10
	.byte	0x2
	.byte	0x19
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x5
	.ualong	.LASF11
	.byte	0x2
	.byte	0x1a
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x9
	.uleb128 0x5
	.ualong	.LASF12
	.byte	0x2
	.byte	0x1b
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0xa
	.uleb128 0x5
	.ualong	.LASF13
	.byte	0x2
	.byte	0x1c
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0xb
	.uleb128 0x5
	.ualong	.LASF14
	.byte	0x2
	.byte	0x40
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0xc
	.uleb128 0x5
	.ualong	.LASF15
	.byte	0x2
	.byte	0x41
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0xd
	.uleb128 0x5
	.ualong	.LASF16
	.byte	0x2
	.byte	0x42
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0xe
	.uleb128 0x5
	.ualong	.LASF17
	.byte	0x2
	.byte	0x43
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0xf
	.uleb128 0x5
	.ualong	.LASF18
	.byte	0x2
	.byte	0x44
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x5
	.ualong	.LASF19
	.byte	0x2
	.byte	0x45
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x5
	.ualong	.LASF20
	.byte	0x2
	.byte	0x46
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x5
	.ualong	.LASF21
	.byte	0x2
	.byte	0x47
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x1c
	.uleb128 0x5
	.ualong	.LASF22
	.byte	0x2
	.byte	0x48
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x20
	.uleb128 0x5
	.ualong	.LASF23
	.byte	0x2
	.byte	0x49
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x24
	.uleb128 0x5
	.ualong	.LASF24
	.byte	0x2
	.byte	0x4a
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x28
	.uleb128 0x5
	.ualong	.LASF25
	.byte	0x2
	.byte	0x50
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x2c
	.uleb128 0x5
	.ualong	.LASF26
	.byte	0x2
	.byte	0x51
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x2d
	.uleb128 0x5
	.ualong	.LASF27
	.byte	0x2
	.byte	0x52
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x2e
	.uleb128 0x5
	.ualong	.LASF28
	.byte	0x2
	.byte	0x53
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x2f
	.uleb128 0x5
	.ualong	.LASF29
	.byte	0x2
	.byte	0x54
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x30
	.uleb128 0x5
	.ualong	.LASF30
	.byte	0x2
	.byte	0x55
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x31
	.uleb128 0x5
	.ualong	.LASF31
	.byte	0x2
	.byte	0x56
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x32
	.uleb128 0x5
	.ualong	.LASF32
	.byte	0x2
	.byte	0x57
	.ualong	0x48
	.byte	0x2
	.byte	0x23
	.uleb128 0x33
	.uleb128 0x5
	.ualong	.LASF33
	.byte	0x2
	.byte	0x58
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x34
	.uleb128 0x5
	.ualong	.LASF34
	.byte	0x2
	.byte	0x59
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x38
	.uleb128 0x5
	.ualong	.LASF35
	.byte	0x2
	.byte	0x5a
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x3c
	.uleb128 0x5
	.ualong	.LASF36
	.byte	0x2
	.byte	0x5b
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x40
	.uleb128 0x5
	.ualong	.LASF37
	.byte	0x2
	.byte	0x5c
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x44
	.uleb128 0x5
	.ualong	.LASF38
	.byte	0x2
	.byte	0x5d
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x48
	.uleb128 0x5
	.ualong	.LASF39
	.byte	0x2
	.byte	0x5e
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x4c
	.uleb128 0x5
	.ualong	.LASF40
	.byte	0x2
	.byte	0x5f
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x50
	.uleb128 0x5
	.ualong	.LASF41
	.byte	0x2
	.byte	0x60
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x54
	.uleb128 0x5
	.ualong	.LASF42
	.byte	0x2
	.byte	0x61
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x58
	.uleb128 0x5
	.ualong	.LASF43
	.byte	0x2
	.byte	0x62
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x5c
	.uleb128 0x5
	.ualong	.LASF44
	.byte	0x2
	.byte	0x63
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x60
	.uleb128 0x5
	.ualong	.LASF45
	.byte	0x2
	.byte	0x64
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x64
	.uleb128 0x6
	.ualong	.LASF46
	.byte	0x2
	.uaword	0x110
	.ualong	0x3a
	.byte	0x2
	.byte	0x23
	.uleb128 0x68
	.uleb128 0x6
	.ualong	.LASF47
	.byte	0x2
	.uaword	0x111
	.ualong	0x48
	.byte	0x2
	.byte	0x23
	.uleb128 0x6c
	.byte	0
	.uleb128 0x2
	.byte	0x1
	.byte	0x8
	.ualong	.LASF48
	.uleb128 0x2
	.byte	0x4
	.byte	0x7
	.ualong	.LASF49
	.uleb128 0x7
	.ualong	.LASF69
	.byte	0x2
	.uaword	0x115
	.ualong	0x4f
	.uleb128 0x8
	.byte	0x1
	.ualong	.LASF50
	.byte	0x1
	.byte	0x19
	.byte	0x1
	.ualong	.LFB0
	.ualong	.LFE0
	.ualong	.LLST0
	.byte	0x1
	.byte	0x40
	.ualong	0x2f8
	.uleb128 0x9
	.ualong	.LASF52
	.byte	0x1
	.byte	0x19
	.ualong	0x33
	.byte	0x2
	.byte	0x91
	.sleb128 -8
	.byte	0
	.uleb128 0x8
	.byte	0x1
	.ualong	.LASF51
	.byte	0x1
	.byte	0x27
	.byte	0x1
	.ualong	.LFB1
	.ualong	.LFE1
	.ualong	.LLST1
	.byte	0x1
	.byte	0x40
	.ualong	0x322
	.uleb128 0x9
	.ualong	.LASF52
	.byte	0x1
	.byte	0x27
	.ualong	0x33
	.byte	0x2
	.byte	0x91
	.sleb128 -8
	.byte	0
	.uleb128 0xa
	.byte	0x1
	.ualong	.LASF53
	.byte	0x1
	.byte	0x39
	.ualong	0x2b4
	.ualong	.LFB2
	.ualong	.LFE2
	.ualong	.LLST2
	.byte	0x1
	.byte	0x40
	.ualong	0x34f
	.uleb128 0xb
	.ualong	.LASF59
	.byte	0x1
	.byte	0x3c
	.ualong	0x2b4
	.byte	0x2
	.byte	0x91
	.sleb128 -5
	.byte	0
	.uleb128 0xc
	.byte	0x1
	.ualong	.LASF54
	.byte	0x1
	.byte	0x44
	.byte	0x1
	.ualong	.LFB3
	.ualong	.LFE3
	.ualong	.LLST3
	.byte	0x1
	.byte	0x40
	.ualong	0x3cf
	.uleb128 0x9
	.ualong	.LASF55
	.byte	0x1
	.byte	0x44
	.ualong	0x2b4
	.byte	0x2
	.byte	0x91
	.sleb128 -9
	.uleb128 0x9
	.ualong	.LASF56
	.byte	0x1
	.byte	0x44
	.ualong	0x33
	.byte	0x2
	.byte	0x91
	.sleb128 -16
	.uleb128 0x9
	.ualong	.LASF57
	.byte	0x1
	.byte	0x44
	.ualong	0x33
	.byte	0x2
	.byte	0x91
	.sleb128 -20
	.uleb128 0x9
	.ualong	.LASF58
	.byte	0x1
	.byte	0x44
	.ualong	0x2c
	.byte	0x2
	.byte	0x91
	.sleb128 -24
	.uleb128 0xd
	.string	"mph"
	.byte	0x1
	.byte	0x44
	.ualong	0x2c
	.byte	0x2
	.byte	0x91
	.sleb128 -28
	.uleb128 0xd
	.string	"rpm"
	.byte	0x1
	.byte	0x44
	.ualong	0x2c
	.byte	0x2
	.byte	0x91
	.sleb128 -32
	.uleb128 0xe
	.byte	0x1
	.ualong	.LASF70
	.byte	0x1
	.byte	0x46
	.ualong	0x33
	.byte	0x1
	.byte	0x40
	.uleb128 0xf
	.byte	0
	.byte	0
	.uleb128 0x10
	.byte	0x1
	.ualong	.LASF71
	.byte	0x1
	.byte	0x60
	.ualong	.LFB4
	.ualong	.LFE4
	.ualong	.LLST4
	.byte	0x1
	.byte	0x40
	.ualong	0x3f9
	.uleb128 0x11
	.ualong	.LASF60
	.byte	0x1
	.uaword	0x10a
	.ualong	0x2b4
	.byte	0x2
	.byte	0x91
	.sleb128 -9
	.byte	0
	.uleb128 0x12
	.ualong	.LASF61
	.byte	0x3
	.byte	0xd0
	.ualong	0x2c
	.byte	0x1
	.byte	0x1
	.uleb128 0x12
	.ualong	.LASF62
	.byte	0x3
	.byte	0xd1
	.ualong	0x2c
	.byte	0x1
	.byte	0x1
	.uleb128 0x13
	.ualong	.LASF63
	.byte	0x3
	.uaword	0x107
	.ualong	0x2c
	.byte	0x1
	.byte	0x1
	.uleb128 0x13
	.ualong	.LASF64
	.byte	0x3
	.uaword	0x108
	.ualong	0x2c
	.byte	0x1
	.byte	0x1
	.uleb128 0x13
	.ualong	.LASF65
	.byte	0x3
	.uaword	0x10a
	.ualong	0x2c
	.byte	0x1
	.byte	0x1
	.uleb128 0x13
	.ualong	.LASF66
	.byte	0x3
	.uaword	0x10b
	.ualong	0x2c
	.byte	0x1
	.byte	0x1
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x55
	.uleb128 0x6
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x52
	.uleb128 0x1
	.uleb128 0x10
	.uleb128 0x6
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x8
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x16
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x27
	.uleb128 0xc
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.uleb128 0x40
	.uleb128 0x6
	.uleb128 0x2117
	.uleb128 0xc
	.uleb128 0x36
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.uleb128 0x40
	.uleb128 0x6
	.uleb128 0x2117
	.uleb128 0xc
	.uleb128 0x36
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x27
	.uleb128 0xc
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.uleb128 0x40
	.uleb128 0x6
	.uleb128 0x2116
	.uleb128 0xc
	.uleb128 0x36
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3c
	.uleb128 0xc
	.uleb128 0x36
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0x18
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.uleb128 0x40
	.uleb128 0x6
	.uleb128 0x2116
	.uleb128 0xc
	.uleb128 0x36
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3c
	.uleb128 0xc
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3c
	.uleb128 0xc
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_loc,"",@progbits
.Ldebug_loc0:
.LLST0:
	.ualong	.LFB0
	.ualong	.LCFI0
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI0
	.ualong	.LCFI1
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI1
	.ualong	.LCFI2
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI2
	.ualong	.LFE0
	.uaword	0x2
	.byte	0x7e
	.sleb128 8
	.ualong	0
	.ualong	0
.LLST1:
	.ualong	.LFB1
	.ualong	.LCFI3
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI3
	.ualong	.LCFI4
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI4
	.ualong	.LCFI5
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI5
	.ualong	.LFE1
	.uaword	0x2
	.byte	0x7e
	.sleb128 8
	.ualong	0
	.ualong	0
.LLST2:
	.ualong	.LFB2
	.ualong	.LCFI6
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI6
	.ualong	.LCFI7
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI7
	.ualong	.LCFI8
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI8
	.ualong	.LFE2
	.uaword	0x2
	.byte	0x7e
	.sleb128 8
	.ualong	0
	.ualong	0
.LLST3:
	.ualong	.LFB3
	.ualong	.LCFI9
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI9
	.ualong	.LCFI10
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI10
	.ualong	.LCFI11
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI11
	.ualong	.LCFI12
	.uaword	0x2
	.byte	0x7f
	.sleb128 32
	.ualong	.LCFI12
	.ualong	.LFE3
	.uaword	0x2
	.byte	0x7e
	.sleb128 32
	.ualong	0
	.ualong	0
.LLST4:
	.ualong	.LFB4
	.ualong	.LCFI13
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI13
	.ualong	.LCFI14
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI14
	.ualong	.LCFI15
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI15
	.ualong	.LCFI16
	.uaword	0x2
	.byte	0x7f
	.sleb128 12
	.ualong	.LCFI16
	.ualong	.LFE4
	.uaword	0x2
	.byte	0x7e
	.sleb128 12
	.ualong	0
	.ualong	0
	.section	.debug_aranges,"",@progbits
	.ualong	0x3c
	.uaword	0x2
	.ualong	.Ldebug_info0
	.byte	0x4
	.byte	0
	.uaword	0
	.uaword	0
	.ualong	.LFB0
	.ualong	.LFE0-.LFB0
	.ualong	.LFB1
	.ualong	.LFE1-.LFB1
	.ualong	.LFB2
	.ualong	.LFE2-.LFB2
	.ualong	.LFB3
	.ualong	.LFE3-.LFB3
	.ualong	.LFB4
	.ualong	.LFE4-.LFB4
	.ualong	0
	.ualong	0
	.section	.debug_ranges,"",@progbits
.Ldebug_ranges0:
	.ualong	.LFB0
	.ualong	.LFE0
	.ualong	.LFB1
	.ualong	.LFE1
	.ualong	.LFB2
	.ualong	.LFE2
	.ualong	.LFB3
	.ualong	.LFE3
	.ualong	.LFB4
	.ualong	.LFE4
	.ualong	0
	.ualong	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF27:
	.string	"FlatFootShiftMode"
.LASF31:
	.string	"FFSGear"
.LASF38:
	.string	"LaunchControlCut"
.LASF41:
	.string	"FlatFootShiftRpmThreshold"
.LASF58:
	.string	"throttle"
.LASF17:
	.string	"sdempty1"
.LASF0:
	.string	"short int"
.LASF23:
	.string	"SDMafBlendRatio"
.LASF15:
	.string	"MafMode"
.LASF3:
	.string	"sizetype"
.LASF56:
	.string	"brake"
.LASF5:
	.string	"RamVariableStart"
.LASF9:
	.string	"ECUIdentifier"
.LASF14:
	.string	"SDInitFlag"
.LASF39:
	.string	"LaunchControlHyst"
.LASF7:
	.string	"CruiseCoastLast"
.LASF45:
	.string	"FlatFootShiftSpeedThreshold"
.LASF24:
	.string	"SDMafFromBlend"
.LASF33:
	.string	"RevLimCut"
.LASF20:
	.string	"MafFromSensor"
.LASF1:
	.string	"float"
.LASF53:
	.string	"GetFuelCutFlag"
.LASF61:
	.string	"FFSMinimumThrottle"
.LASF18:
	.string	"VolumetricEfficiency"
.LASF2:
	.string	"long int"
.LASF59:
	.string	"result"
.LASF69:
	.string	"RamVariables"
.LASF36:
	.string	"RedLineHyst"
.LASF62:
	.string	"LCMinimumThrottle"
.LASF71:
	.string	"RevLimUnitTests"
.LASF48:
	.string	"unsigned char"
.LASF70:
	.string	"ClearRam"
.LASF60:
	.string	"flags"
.LASF42:
	.string	"FlatFootShiftAutoDelta"
.LASF25:
	.string	"RevLimInitFlag"
.LASF67:
	.string	"GNU C 4.7-GNUSH_v13.01"
.LASF49:
	.string	"long unsigned int"
.LASF40:
	.string	"FFSRPM"
.LASF47:
	.string	"RamHoleEndMarker"
.LASF65:
	.string	"DefaultLaunchControlCut"
.LASF44:
	.string	"FlatFootShiftHyst"
.LASF4:
	.string	"char"
.LASF22:
	.string	"DeltaMapCompensation"
.LASF57:
	.string	"clutch"
.LASF19:
	.string	"MafFromSpeedDensity"
.LASF11:
	.string	"blank0"
.LASF12:
	.string	"blank1"
.LASF13:
	.string	"blank2"
.LASF6:
	.string	"VinAuth"
.LASF8:
	.string	"CruiseResumeLast"
.LASF16:
	.string	"SDempty"
.LASF28:
	.string	"LCEngaged"
.LASF29:
	.string	"FFSEngaged"
.LASF26:
	.string	"RevLimMode"
.LASF34:
	.string	"RevLimResume"
.LASF64:
	.string	"DefaultRedLineHyst"
.LASF10:
	.string	"HardResetFlag"
.LASF43:
	.string	"FlatFootShiftStaticDelta"
.LASF21:
	.string	"AtmosphericCompensation"
.LASF68:
	.string	"C:\\Dev\\MerpMod\\MerpMod\\RevLimiterTests.c"
.LASF35:
	.string	"RedLineCut"
.LASF51:
	.string	"SetBrake"
.LASF46:
	.string	"RamHoleSpace"
.LASF50:
	.string	"SetClutch"
.LASF55:
	.string	"flag"
.LASF32:
	.string	"eleemee2"
.LASF63:
	.string	"DefaultRedLineCut"
.LASF52:
	.string	"value"
.LASF66:
	.string	"DefaultLaunchControlHyst"
.LASF54:
	.string	"RevLimUnitTest"
.LASF30:
	.string	"ClutchSwitchLast"
.LASF37:
	.string	"LaunchControlSpeedMax"
	.ident	"GCC: (GNU) 4.7-GNUSH_v13.01"
