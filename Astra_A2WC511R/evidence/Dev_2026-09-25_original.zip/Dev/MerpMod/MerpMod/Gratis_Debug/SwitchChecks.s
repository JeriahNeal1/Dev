	.file	"SwitchChecks.c"
	.text
	.text
.Ltext0:
	.cfi_sections	.debug_frame
	.section	RomHole_Code,"ax",@progbits
	.align 2
	.global	_TestTestModeSwitch
	.type	_TestTestModeSwitch, @function
_TestTestModeSwitch:
.LFB0:
	.file 1 "C:\\Dev\\MerpMod\\MerpMod\\SwitchChecks.c"
	.loc 1 19 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI0:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	add	#-4,r15
.LCFI1:
	.cfi_def_cfa_offset 8
	mov	r15,r14
.LCFI2:
	.cfi_def_cfa_register 14
	.loc 1 20 0
	mov.l	.L4,r1
	mov.b	@r1,r1
	extu.b	r1,r2
	mov	r14,r1
	add	#3,r1
	mov	#32,r3
	and	r3,r2
	mov.b	r2,@r1
	.loc 1 21 0
	mov	r14,r1
	add	#3,r1
	mov.b	@r1,r1
	extu.b	r1,r2
	mov	#32,r1
	cmp/eq	r1,r2
	bf.s	.L2
	nop
	.loc 1 22 0
	mov	#1,r1
	bra	.L3
	nop
	.align 1
.L2:
	.loc 1 24 0
	mov	#0,r1
.L3:
	.loc 1 25 0
	mov	r1,r0
	add	#4,r14
	mov	r14,r15
	mov.l   @r15+,r14
	rts	
	nop
.L5:
	.align 2
.L4:
	.long	-38420
	.cfi_endproc
.LFE0:
	.size	_TestTestModeSwitch, .-_TestTestModeSwitch
	.align 2
	.global	_TestDefogSwitch
	.type	_TestDefogSwitch, @function
_TestDefogSwitch:
.LFB1:
	.loc 1 30 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI3:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	add	#-4,r15
.LCFI4:
	.cfi_def_cfa_offset 8
	mov	r15,r14
.LCFI5:
	.cfi_def_cfa_register 14
	.loc 1 31 0
	mov.l	.L9,r1
	mov.b	@r1,r1
	extu.b	r1,r2
	mov	r14,r1
	add	#3,r1
	mov	#32,r3
	and	r3,r2
	mov.b	r2,@r1
	.loc 1 32 0
	mov	r14,r1
	add	#3,r1
	mov.b	@r1,r1
	extu.b	r1,r2
	mov	#32,r1
	cmp/eq	r1,r2
	bf.s	.L7
	nop
	.loc 1 33 0
	mov	#1,r1
	bra	.L8
	nop
	.align 1
.L7:
	.loc 1 35 0
	mov	#0,r1
.L8:
	.loc 1 36 0
	mov	r1,r0
	add	#4,r14
	mov	r14,r15
	mov.l   @r15+,r14
	rts	
	nop
.L10:
	.align 2
.L9:
	.long	-38417
	.cfi_endproc
.LFE1:
	.size	_TestDefogSwitch, .-_TestDefogSwitch
	.align 2
	.global	_TestBrakeSwitch
	.type	_TestBrakeSwitch, @function
_TestBrakeSwitch:
.LFB2:
	.loc 1 41 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI6:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	add	#-4,r15
.LCFI7:
	.cfi_def_cfa_offset 8
	mov	r15,r14
.LCFI8:
	.cfi_def_cfa_register 14
	.loc 1 42 0
	mov.l	.L14,r1
	mov.b	@r1,r1
	extu.b	r1,r3
	mov	r14,r1
	add	#3,r1
	mov	#-128,r2
	and	r3,r2
	mov.b	r2,@r1
	.loc 1 43 0
	mov	r14,r1
	add	#3,r1
	mov.b	@r1,r1
	extu.b	r1,r2
	mov.w	.L15,r1
	cmp/eq	r1,r2
	bf.s	.L12
	nop
	.loc 1 44 0
	mov	#1,r1
	bra	.L13
	nop
	.align 1
.L12:
	.loc 1 46 0
	mov	#0,r1
.L13:
	.loc 1 47 0
	mov	r1,r0
	add	#4,r14
	mov	r14,r15
	mov.l   @r15+,r14
	rts	
	nop
	.align 1
.L15:
	.short	128
.L16:
	.align 2
.L14:
	.long	-39760
	.cfi_endproc
.LFE2:
	.size	_TestBrakeSwitch, .-_TestBrakeSwitch
	.align 2
	.global	_TestClutchSwitch
	.type	_TestClutchSwitch, @function
_TestClutchSwitch:
.LFB3:
	.loc 1 52 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI9:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	add	#-4,r15
.LCFI10:
	.cfi_def_cfa_offset 8
	mov	r15,r14
.LCFI11:
	.cfi_def_cfa_register 14
	.loc 1 53 0
	mov.l	.L20,r1
	mov.b	@r1,r1
	extu.b	r1,r3
	mov	r14,r1
	add	#3,r1
	mov	#-128,r2
	and	r3,r2
	mov.b	r2,@r1
	.loc 1 54 0
	mov	r14,r1
	add	#3,r1
	mov.b	@r1,r1
	extu.b	r1,r2
	mov.w	.L21,r1
	cmp/eq	r1,r2
	bf.s	.L18
	nop
	.loc 1 55 0
	mov	#1,r1
	bra	.L19
	nop
	.align 1
.L18:
	.loc 1 57 0
	mov	#0,r1
.L19:
	.loc 1 58 0
	mov	r1,r0
	add	#4,r14
	mov	r14,r15
	mov.l   @r15+,r14
	rts	
	nop
	.align 1
.L21:
	.short	128
.L22:
	.align 2
.L20:
	.long	-38415
	.cfi_endproc
.LFE3:
	.size	_TestClutchSwitch, .-_TestClutchSwitch
	.align 2
	.global	_TestCruiseResumeSwitch
	.type	_TestCruiseResumeSwitch, @function
_TestCruiseResumeSwitch:
.LFB4:
	.loc 1 63 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI12:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	add	#-4,r15
.LCFI13:
	.cfi_def_cfa_offset 8
	mov	r15,r14
.LCFI14:
	.cfi_def_cfa_register 14
	.loc 1 64 0
	mov.l	.L26,r1
	mov.b	@r1,r1
	extu.b	r1,r2
	mov	r14,r1
	add	#3,r1
	mov	#4,r3
	and	r3,r2
	mov.b	r2,@r1
	.loc 1 65 0
	mov	r14,r1
	add	#3,r1
	mov.b	@r1,r1
	extu.b	r1,r2
	mov	#4,r1
	cmp/eq	r1,r2
	bf.s	.L24
	nop
	.loc 1 66 0
	mov	#1,r1
	bra	.L25
	nop
	.align 1
.L24:
	.loc 1 68 0
	mov	#0,r1
.L25:
	.loc 1 69 0
	mov	r1,r0
	add	#4,r14
	mov	r14,r15
	mov.l   @r15+,r14
	rts	
	nop
.L27:
	.align 2
.L26:
	.long	-39760
	.cfi_endproc
.LFE4:
	.size	_TestCruiseResumeSwitch, .-_TestCruiseResumeSwitch
	.align 2
	.global	_TestCruiseCoastSwitch
	.type	_TestCruiseCoastSwitch, @function
_TestCruiseCoastSwitch:
.LFB5:
	.loc 1 74 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI15:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	add	#-4,r15
.LCFI16:
	.cfi_def_cfa_offset 8
	mov	r15,r14
.LCFI17:
	.cfi_def_cfa_register 14
	.loc 1 75 0
	mov.l	.L31,r1
	mov.b	@r1,r1
	extu.b	r1,r2
	mov	r14,r1
	add	#3,r1
	mov	#2,r3
	and	r3,r2
	mov.b	r2,@r1
	.loc 1 76 0
	mov	r14,r1
	add	#3,r1
	mov.b	@r1,r1
	extu.b	r1,r2
	mov	#2,r1
	cmp/eq	r1,r2
	bf.s	.L29
	nop
	.loc 1 77 0
	mov	#1,r1
	bra	.L30
	nop
	.align 1
.L29:
	.loc 1 79 0
	mov	#0,r1
.L30:
	.loc 1 80 0
	mov	r1,r0
	add	#4,r14
	mov	r14,r15
	mov.l   @r15+,r14
	rts	
	nop
.L32:
	.align 2
.L31:
	.long	-39760
	.cfi_endproc
.LFE5:
	.size	_TestCruiseCoastSwitch, .-_TestCruiseCoastSwitch
	.align 2
	.global	_TestCruiseControlToggles
	.type	_TestCruiseControlToggles, @function
_TestCruiseControlToggles:
.LFB6:
	.loc 1 85 0
	.cfi_startproc
	mov.l	r8,@-r15
.LCFI18:
	.cfi_def_cfa_offset 4
	.cfi_offset 8, -4
	mov.l	r14,@-r15
.LCFI19:
	.cfi_def_cfa_offset 8
	.cfi_offset 14, -8
	sts.l	pr,@-r15
.LCFI20:
	.cfi_def_cfa_offset 12
	.cfi_offset 17, -12
	add	#-8,r15
.LCFI21:
	.cfi_def_cfa_offset 20
	mov	r15,r14
.LCFI22:
	.cfi_def_cfa_register 14
	.loc 1 86 0
	mov	r14,r8
	add	#7,r8
	mov.l	.L36,r1
	jsr	@r1
	nop
	mov	r0,r1
	mov.b	r1,@r8
	.loc 1 87 0
	mov	r14,r8
	add	#6,r8
	mov.l	.L37,r1
	jsr	@r1
	nop
	mov	r0,r1
	mov.b	r1,@r8
	.loc 1 89 0
	mov.w	.L42,r1
	add	#3,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	mov	r14,r2
	add	#7,r2
	mov.b	@r2,r2
	extu.b	r2,r2
	cmp/eq	r1,r2
	bt.s	.L34
	nop
	.loc 1 90 0
	mov.w	.L42,r1
	add	#2,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	mov	r14,r2
	add	#6,r2
	mov.b	@r2,r2
	extu.b	r2,r2
	cmp/eq	r1,r2
	bt.s	.L35
	nop
	.loc 1 92 0
	mov	r14,r1
	add	#7,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bt.s	.L34
	nop
	.loc 1 92 0 is_stmt 0 discriminator 1
	mov	r14,r1
	add	#6,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bt.s	.L34
	nop
.LBB2:
	.loc 1 95 0 is_stmt 1
	mov	r14,r1
	add	#-56,r1
	mov	#0,r2
	mov.l	r2,@(56,r1)
	bra	.L34
	nop
	.align 1
.L35:
.LBE2:
	.loc 1 98 0
	mov.w	.L42,r1
	add	#3,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	mov	r14,r2
	add	#7,r2
	mov.b	@r2,r2
	extu.b	r2,r2
	cmp/eq	r1,r2
.L34:
	.loc 1 122 0
	mov.w	.L42,r1
	add	#2,r1
	mov	r14,r2
	add	#6,r2
	mov.b	@r2,r2
	mov.b	r2,@r1
	.loc 1 123 0
	mov.w	.L42,r1
	add	#3,r1
	mov	r14,r2
	add	#7,r2
	mov.b	@r2,r2
	mov.b	r2,@r1
	.loc 1 124 0
	add	#8,r14
	mov	r14,r15
	lds.l   @r15+,pr
	mov.l   @r15+,r14
	mov.l   @r15+,r8
	rts	
	nop
	.align 1
.L42:
	.short	-26944
.L43:
	.align 2
.L36:
	.long	_TestCruiseResumeSwitch
.L37:
	.long	_TestCruiseCoastSwitch
	.cfi_endproc
.LFE6:
	.size	_TestCruiseControlToggles, .-_TestCruiseControlToggles
	.text
.Letext0:
	.file 2 "C:\\Dev\\MerpMod\\MerpMod\\RamVariables.h"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.ualong	0x422
	.uaword	0x2
	.ualong	.Ldebug_abbrev0
	.byte	0x4
	.uleb128 0x1
	.ualong	.LASF59
	.byte	0x1
	.ualong	.LASF60
	.ualong	.Ldebug_ranges0+0
	.ualong	0
	.ualong	0
	.ualong	.Ldebug_line0
	.uleb128 0x2
	.byte	0x2
	.byte	0x5
	.ualong	.LASF0
	.uleb128 0x2
	.byte	0x4
	.byte	0x4
	.ualong	.LASF1
	.uleb128 0x3
	.byte	0x4
	.byte	0x5
	.string	"int"
	.uleb128 0x2
	.byte	0x4
	.byte	0x5
	.ualong	.LASF2
	.uleb128 0x2
	.byte	0x4
	.byte	0x7
	.ualong	.LASF3
	.uleb128 0x2
	.byte	0x1
	.byte	0x6
	.ualong	.LASF4
	.uleb128 0x4
	.byte	0x70
	.byte	0x2
	.byte	0x12
	.ualong	0x2b4
	.uleb128 0x5
	.ualong	.LASF5
	.byte	0x2
	.byte	0x14
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0
	.uleb128 0x5
	.ualong	.LASF6
	.byte	0x2
	.byte	0x15
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x1
	.uleb128 0x5
	.ualong	.LASF7
	.byte	0x2
	.byte	0x16
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x2
	.uleb128 0x5
	.ualong	.LASF8
	.byte	0x2
	.byte	0x17
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x3
	.uleb128 0x5
	.ualong	.LASF9
	.byte	0x2
	.byte	0x18
	.ualong	0x2bb
	.byte	0x2
	.byte	0x23
	.uleb128 0x4
	.uleb128 0x5
	.ualong	.LASF10
	.byte	0x2
	.byte	0x19
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x5
	.ualong	.LASF11
	.byte	0x2
	.byte	0x1a
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x9
	.uleb128 0x5
	.ualong	.LASF12
	.byte	0x2
	.byte	0x1b
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0xa
	.uleb128 0x5
	.ualong	.LASF13
	.byte	0x2
	.byte	0x1c
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0xb
	.uleb128 0x5
	.ualong	.LASF14
	.byte	0x2
	.byte	0x40
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0xc
	.uleb128 0x5
	.ualong	.LASF15
	.byte	0x2
	.byte	0x41
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0xd
	.uleb128 0x5
	.ualong	.LASF16
	.byte	0x2
	.byte	0x42
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0xe
	.uleb128 0x5
	.ualong	.LASF17
	.byte	0x2
	.byte	0x43
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0xf
	.uleb128 0x5
	.ualong	.LASF18
	.byte	0x2
	.byte	0x44
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x5
	.ualong	.LASF19
	.byte	0x2
	.byte	0x45
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x5
	.ualong	.LASF20
	.byte	0x2
	.byte	0x46
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x5
	.ualong	.LASF21
	.byte	0x2
	.byte	0x47
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x1c
	.uleb128 0x5
	.ualong	.LASF22
	.byte	0x2
	.byte	0x48
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x20
	.uleb128 0x5
	.ualong	.LASF23
	.byte	0x2
	.byte	0x49
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x24
	.uleb128 0x5
	.ualong	.LASF24
	.byte	0x2
	.byte	0x4a
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x28
	.uleb128 0x5
	.ualong	.LASF25
	.byte	0x2
	.byte	0x50
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x2c
	.uleb128 0x5
	.ualong	.LASF26
	.byte	0x2
	.byte	0x51
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x2d
	.uleb128 0x5
	.ualong	.LASF27
	.byte	0x2
	.byte	0x52
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x2e
	.uleb128 0x5
	.ualong	.LASF28
	.byte	0x2
	.byte	0x53
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x2f
	.uleb128 0x5
	.ualong	.LASF29
	.byte	0x2
	.byte	0x54
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x30
	.uleb128 0x5
	.ualong	.LASF30
	.byte	0x2
	.byte	0x55
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x31
	.uleb128 0x5
	.ualong	.LASF31
	.byte	0x2
	.byte	0x56
	.ualong	0x2b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x32
	.uleb128 0x5
	.ualong	.LASF32
	.byte	0x2
	.byte	0x57
	.ualong	0x48
	.byte	0x2
	.byte	0x23
	.uleb128 0x33
	.uleb128 0x5
	.ualong	.LASF33
	.byte	0x2
	.byte	0x58
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x34
	.uleb128 0x5
	.ualong	.LASF34
	.byte	0x2
	.byte	0x59
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x38
	.uleb128 0x5
	.ualong	.LASF35
	.byte	0x2
	.byte	0x5a
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x3c
	.uleb128 0x5
	.ualong	.LASF36
	.byte	0x2
	.byte	0x5b
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x40
	.uleb128 0x5
	.ualong	.LASF37
	.byte	0x2
	.byte	0x5c
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x44
	.uleb128 0x5
	.ualong	.LASF38
	.byte	0x2
	.byte	0x5d
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x48
	.uleb128 0x5
	.ualong	.LASF39
	.byte	0x2
	.byte	0x5e
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x4c
	.uleb128 0x5
	.ualong	.LASF40
	.byte	0x2
	.byte	0x5f
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x50
	.uleb128 0x5
	.ualong	.LASF41
	.byte	0x2
	.byte	0x60
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x54
	.uleb128 0x5
	.ualong	.LASF42
	.byte	0x2
	.byte	0x61
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x58
	.uleb128 0x5
	.ualong	.LASF43
	.byte	0x2
	.byte	0x62
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x5c
	.uleb128 0x5
	.ualong	.LASF44
	.byte	0x2
	.byte	0x63
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x60
	.uleb128 0x5
	.ualong	.LASF45
	.byte	0x2
	.byte	0x64
	.ualong	0x2c
	.byte	0x2
	.byte	0x23
	.uleb128 0x64
	.uleb128 0x6
	.ualong	.LASF46
	.byte	0x2
	.uaword	0x110
	.ualong	0x3a
	.byte	0x2
	.byte	0x23
	.uleb128 0x68
	.uleb128 0x6
	.ualong	.LASF47
	.byte	0x2
	.uaword	0x111
	.ualong	0x48
	.byte	0x2
	.byte	0x23
	.uleb128 0x6c
	.byte	0
	.uleb128 0x2
	.byte	0x1
	.byte	0x8
	.ualong	.LASF48
	.uleb128 0x2
	.byte	0x4
	.byte	0x7
	.ualong	.LASF49
	.uleb128 0x7
	.ualong	.LASF61
	.byte	0x2
	.uaword	0x115
	.ualong	0x4f
	.uleb128 0x8
	.byte	0x1
	.ualong	.LASF50
	.byte	0x1
	.byte	0x12
	.ualong	0x2b4
	.ualong	.LFB0
	.ualong	.LFE0
	.ualong	.LLST0
	.byte	0x1
	.byte	0x40
	.ualong	0x2fb
	.uleb128 0x9
	.ualong	.LASF52
	.byte	0x1
	.byte	0x14
	.ualong	0x2b4
	.byte	0x2
	.byte	0x91
	.sleb128 -5
	.byte	0
	.uleb128 0x8
	.byte	0x1
	.ualong	.LASF51
	.byte	0x1
	.byte	0x1d
	.ualong	0x2b4
	.ualong	.LFB1
	.ualong	.LFE1
	.ualong	.LLST1
	.byte	0x1
	.byte	0x40
	.ualong	0x328
	.uleb128 0x9
	.ualong	.LASF52
	.byte	0x1
	.byte	0x1f
	.ualong	0x2b4
	.byte	0x2
	.byte	0x91
	.sleb128 -5
	.byte	0
	.uleb128 0x8
	.byte	0x1
	.ualong	.LASF53
	.byte	0x1
	.byte	0x28
	.ualong	0x2b4
	.ualong	.LFB2
	.ualong	.LFE2
	.ualong	.LLST2
	.byte	0x1
	.byte	0x40
	.ualong	0x355
	.uleb128 0x9
	.ualong	.LASF52
	.byte	0x1
	.byte	0x2a
	.ualong	0x2b4
	.byte	0x2
	.byte	0x91
	.sleb128 -5
	.byte	0
	.uleb128 0x8
	.byte	0x1
	.ualong	.LASF54
	.byte	0x1
	.byte	0x33
	.ualong	0x2b4
	.ualong	.LFB3
	.ualong	.LFE3
	.ualong	.LLST3
	.byte	0x1
	.byte	0x40
	.ualong	0x382
	.uleb128 0x9
	.ualong	.LASF52
	.byte	0x1
	.byte	0x35
	.ualong	0x2b4
	.byte	0x2
	.byte	0x91
	.sleb128 -5
	.byte	0
	.uleb128 0x8
	.byte	0x1
	.ualong	.LASF55
	.byte	0x1
	.byte	0x3e
	.ualong	0x2b4
	.ualong	.LFB4
	.ualong	.LFE4
	.ualong	.LLST4
	.byte	0x1
	.byte	0x40
	.ualong	0x3af
	.uleb128 0x9
	.ualong	.LASF52
	.byte	0x1
	.byte	0x40
	.ualong	0x2b4
	.byte	0x2
	.byte	0x91
	.sleb128 -5
	.byte	0
	.uleb128 0x8
	.byte	0x1
	.ualong	.LASF56
	.byte	0x1
	.byte	0x49
	.ualong	0x2b4
	.ualong	.LFB5
	.ualong	.LFE5
	.ualong	.LLST5
	.byte	0x1
	.byte	0x40
	.ualong	0x3dc
	.uleb128 0x9
	.ualong	.LASF52
	.byte	0x1
	.byte	0x4b
	.ualong	0x2b4
	.byte	0x2
	.byte	0x91
	.sleb128 -5
	.byte	0
	.uleb128 0xa
	.byte	0x1
	.ualong	.LASF62
	.byte	0x1
	.byte	0x54
	.ualong	.LFB6
	.ualong	.LFE6
	.ualong	.LLST6
	.byte	0x1
	.byte	0x40
	.uleb128 0x9
	.ualong	.LASF57
	.byte	0x1
	.byte	0x56
	.ualong	0x2b4
	.byte	0x2
	.byte	0x91
	.sleb128 -13
	.uleb128 0x9
	.ualong	.LASF58
	.byte	0x1
	.byte	0x57
	.ualong	0x2b4
	.byte	0x2
	.byte	0x91
	.sleb128 -14
	.uleb128 0xb
	.ualong	.LBB2
	.ualong	.LBE2
	.uleb128 0xc
	.string	"i"
	.byte	0x1
	.byte	0x5f
	.ualong	0x33
	.byte	0x2
	.byte	0x91
	.sleb128 -20
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x55
	.uleb128 0x6
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x52
	.uleb128 0x1
	.uleb128 0x10
	.uleb128 0x6
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x8
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x16
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.uleb128 0x40
	.uleb128 0x6
	.uleb128 0x2117
	.uleb128 0xc
	.uleb128 0x36
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.uleb128 0x40
	.uleb128 0x6
	.uleb128 0x2116
	.uleb128 0xc
	.uleb128 0x36
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_loc,"",@progbits
.Ldebug_loc0:
.LLST0:
	.ualong	.LFB0
	.ualong	.LCFI0
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI0
	.ualong	.LCFI1
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI1
	.ualong	.LCFI2
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI2
	.ualong	.LFE0
	.uaword	0x2
	.byte	0x7e
	.sleb128 8
	.ualong	0
	.ualong	0
.LLST1:
	.ualong	.LFB1
	.ualong	.LCFI3
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI3
	.ualong	.LCFI4
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI4
	.ualong	.LCFI5
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI5
	.ualong	.LFE1
	.uaword	0x2
	.byte	0x7e
	.sleb128 8
	.ualong	0
	.ualong	0
.LLST2:
	.ualong	.LFB2
	.ualong	.LCFI6
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI6
	.ualong	.LCFI7
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI7
	.ualong	.LCFI8
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI8
	.ualong	.LFE2
	.uaword	0x2
	.byte	0x7e
	.sleb128 8
	.ualong	0
	.ualong	0
.LLST3:
	.ualong	.LFB3
	.ualong	.LCFI9
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI9
	.ualong	.LCFI10
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI10
	.ualong	.LCFI11
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI11
	.ualong	.LFE3
	.uaword	0x2
	.byte	0x7e
	.sleb128 8
	.ualong	0
	.ualong	0
.LLST4:
	.ualong	.LFB4
	.ualong	.LCFI12
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI12
	.ualong	.LCFI13
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI13
	.ualong	.LCFI14
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI14
	.ualong	.LFE4
	.uaword	0x2
	.byte	0x7e
	.sleb128 8
	.ualong	0
	.ualong	0
.LLST5:
	.ualong	.LFB5
	.ualong	.LCFI15
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI15
	.ualong	.LCFI16
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI16
	.ualong	.LCFI17
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI17
	.ualong	.LFE5
	.uaword	0x2
	.byte	0x7e
	.sleb128 8
	.ualong	0
	.ualong	0
.LLST6:
	.ualong	.LFB6
	.ualong	.LCFI18
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI18
	.ualong	.LCFI19
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI19
	.ualong	.LCFI20
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI20
	.ualong	.LCFI21
	.uaword	0x2
	.byte	0x7f
	.sleb128 12
	.ualong	.LCFI21
	.ualong	.LCFI22
	.uaword	0x2
	.byte	0x7f
	.sleb128 20
	.ualong	.LCFI22
	.ualong	.LFE6
	.uaword	0x2
	.byte	0x7e
	.sleb128 20
	.ualong	0
	.ualong	0
	.section	.debug_aranges,"",@progbits
	.ualong	0x4c
	.uaword	0x2
	.ualong	.Ldebug_info0
	.byte	0x4
	.byte	0
	.uaword	0
	.uaword	0
	.ualong	.LFB0
	.ualong	.LFE0-.LFB0
	.ualong	.LFB1
	.ualong	.LFE1-.LFB1
	.ualong	.LFB2
	.ualong	.LFE2-.LFB2
	.ualong	.LFB3
	.ualong	.LFE3-.LFB3
	.ualong	.LFB4
	.ualong	.LFE4-.LFB4
	.ualong	.LFB5
	.ualong	.LFE5-.LFB5
	.ualong	.LFB6
	.ualong	.LFE6-.LFB6
	.ualong	0
	.ualong	0
	.section	.debug_ranges,"",@progbits
.Ldebug_ranges0:
	.ualong	.LFB0
	.ualong	.LFE0
	.ualong	.LFB1
	.ualong	.LFE1
	.ualong	.LFB2
	.ualong	.LFE2
	.ualong	.LFB3
	.ualong	.LFE3
	.ualong	.LFB4
	.ualong	.LFE4
	.ualong	.LFB5
	.ualong	.LFE5
	.ualong	.LFB6
	.ualong	.LFE6
	.ualong	0
	.ualong	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF27:
	.string	"FlatFootShiftMode"
.LASF31:
	.string	"FFSGear"
.LASF38:
	.string	"LaunchControlCut"
.LASF41:
	.string	"FlatFootShiftRpmThreshold"
.LASF17:
	.string	"sdempty1"
.LASF0:
	.string	"short int"
.LASF23:
	.string	"SDMafBlendRatio"
.LASF15:
	.string	"MafMode"
.LASF3:
	.string	"sizetype"
.LASF5:
	.string	"RamVariableStart"
.LASF9:
	.string	"ECUIdentifier"
.LASF14:
	.string	"SDInitFlag"
.LASF39:
	.string	"LaunchControlHyst"
.LASF57:
	.string	"resume"
.LASF43:
	.string	"FlatFootShiftStaticDelta"
.LASF7:
	.string	"CruiseCoastLast"
.LASF45:
	.string	"FlatFootShiftSpeedThreshold"
.LASF56:
	.string	"TestCruiseCoastSwitch"
.LASF24:
	.string	"SDMafFromBlend"
.LASF33:
	.string	"RevLimCut"
.LASF20:
	.string	"MafFromSensor"
.LASF62:
	.string	"TestCruiseControlToggles"
.LASF1:
	.string	"float"
.LASF18:
	.string	"VolumetricEfficiency"
.LASF2:
	.string	"long int"
.LASF52:
	.string	"result"
.LASF53:
	.string	"TestBrakeSwitch"
.LASF54:
	.string	"TestClutchSwitch"
.LASF61:
	.string	"RamVariables"
.LASF36:
	.string	"RedLineHyst"
.LASF48:
	.string	"unsigned char"
.LASF42:
	.string	"FlatFootShiftAutoDelta"
.LASF25:
	.string	"RevLimInitFlag"
.LASF59:
	.string	"GNU C 4.7-GNUSH_v13.01"
.LASF49:
	.string	"long unsigned int"
.LASF40:
	.string	"FFSRPM"
.LASF47:
	.string	"RamHoleEndMarker"
.LASF51:
	.string	"TestDefogSwitch"
.LASF44:
	.string	"FlatFootShiftHyst"
.LASF4:
	.string	"char"
.LASF22:
	.string	"DeltaMapCompensation"
.LASF58:
	.string	"coast"
.LASF19:
	.string	"MafFromSpeedDensity"
.LASF11:
	.string	"blank0"
.LASF12:
	.string	"blank1"
.LASF13:
	.string	"blank2"
.LASF6:
	.string	"VinAuth"
.LASF8:
	.string	"CruiseResumeLast"
.LASF16:
	.string	"SDempty"
.LASF28:
	.string	"LCEngaged"
.LASF29:
	.string	"FFSEngaged"
.LASF50:
	.string	"TestTestModeSwitch"
.LASF26:
	.string	"RevLimMode"
.LASF34:
	.string	"RevLimResume"
.LASF10:
	.string	"HardResetFlag"
.LASF60:
	.string	"C:\\Dev\\MerpMod\\MerpMod\\SwitchChecks.c"
.LASF21:
	.string	"AtmosphericCompensation"
.LASF35:
	.string	"RedLineCut"
.LASF55:
	.string	"TestCruiseResumeSwitch"
.LASF46:
	.string	"RamHoleSpace"
.LASF32:
	.string	"eleemee2"
.LASF30:
	.string	"ClutchSwitchLast"
.LASF37:
	.string	"LaunchControlSpeedMax"
	.ident	"GCC: (GNU) 4.7-GNUSH_v13.01"
