	.file	"SpeedDensityTests.c"
	.text
	.text
.Ltext0:
	.cfi_sections	.debug_frame
	.section	RomHole_Code,"ax",@progbits
	.align 2
	.global	_CallSpeedDensityHook
	.type	_CallSpeedDensityHook, @function
_CallSpeedDensityHook:
.LFB0:
	.file 1 "C:\\Dev\\MerpMod\\MerpMod\\SpeedDensityTests.c"
	.loc 1 23 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI0:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	sts.l	pr,@-r15
.LCFI1:
	.cfi_def_cfa_offset 8
	.cfi_offset 17, -8
	add	#-4,r15
.LCFI2:
	.cfi_def_cfa_offset 12
	mov	r15,r14
.LCFI3:
	.cfi_def_cfa_register 14
	.loc 1 24 0
	mov	r14,r1
	add	#-60,r1
	mov.l	.L3,r2
	mov.l	r2,@(60,r1)
	.loc 1 25 0
	mov.l	.L4,r1
	mov.w	@r1,r1
	lds	r1,fpul
	fsts	fpul,fr1
	mov	r14,r1
	add	#-60,r1
	mov.l	@(60,r1),r1
	flds	fr1,fpul
	sts	fpul,r4
	jsr	@r1
	nop
	.loc 1 27 0
	mov.l	.L5,r1
	fmov.s	@r1,fr1
	.loc 1 28 0
	fmov	fr1,fr0
	add	#4,r14
	mov	r14,r15
	lds.l   @r15+,pr
	mov.l   @r15+,r14
	rts	
	nop
.L6:
	.align 2
.L3:
	.long	33464
.L4:
	.long	-41986
.L5:
	.long	-41776
	.cfi_endproc
.LFE0:
	.size	_CallSpeedDensityHook, .-_CallSpeedDensityHook
	.section	.rodata
	.align 2
.LC0:
	.string	"First execution should set MafMode to MafModeSensor."
	.align 2
.LC1:
	.string	"First execution should return MAF from sensor."
	.align 2
.LC2:
	.string	"Second execution should return MAF from sensor."
	.align 2
.LC3:
	.string	"MafMode should remain set to MafModeSensor."
	.align 2
.LC4:
	.string	"Second execution should return MAF from speed-density."
	.align 2
.LC5:
	.string	"MafMode should remain set to MafModeSpeedDensity."
	.align 2
.LC6:
	.string	"Checking blend mode code, cell should be zero and return maf sensor value."
	.align 2
.LC7:
	.string	"MafMode should remain set."
	.align 2
.LC8:
	.string	"Checking Blend ratio"
	.align 2
.LC9:
	.string	"Checking SD value"
	.section	Misc,"ax",@progbits
	.align 1
	.global	_SpeedDensityUnitTests
	.type	_SpeedDensityUnitTests, @function
_SpeedDensityUnitTests:
.LFB1:
	.loc 1 35 0
	.cfi_startproc
	mov.l	r8,@-r15
.LCFI4:
	.cfi_def_cfa_offset 4
	.cfi_offset 8, -4
	mov.l	r14,@-r15
.LCFI5:
	.cfi_def_cfa_offset 8
	.cfi_offset 14, -8
	sts.l	pr,@-r15
.LCFI6:
	.cfi_def_cfa_offset 12
	.cfi_offset 17, -12
	add	#-12,r15
.LCFI7:
	.cfi_def_cfa_offset 24
	mov	r15,r14
.LCFI8:
	.cfi_def_cfa_register 14
	.loc 1 36 0
	mov.w	.L61,r1
	add	#13,r1
	mov	#0,r2
	mov.b	r2,@r1
	.loc 1 37 0
	mov.l	.L10,r1
	jsr	@r1
	nop
	.loc 1 42 0
	mov.l	.L11,r1
	jsr	@r1
	nop
	.loc 1 46 0
	mov	r14,r1
	add	#8,r1
	mova	.L12,r0
	fmov.s	@r0+,fr1
	fmov.s	fr1,@r1
	.loc 1 47 0
	mov	r14,r1
	add	#4,r1
	fmov.s	@r0,fr1
	fmov.s	fr1,@r1
	.loc 1 50 0
	mov.w	.L61,r1
	add	#13,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	mov	r1,r0
	cmp/eq	#1,r0
	movt	r1
	extu.b	r1,r1
	lds	r1,fpul
	fsts	fpul,fr1
	mov.l	.L14,r1
	flds	fr1,fpul
	sts	fpul,r4
	mov	r1,r5
	mov.l	.L65,r1
	jsr	@r1
	nop
	.loc 1 52 0
	mov.l	.L16,r1
	mova	.L17,r0
	fmov.s	@r0,fr1
	fmov.s	fr1,@r1
	.loc 1 53 0
	mov.l	.L53,r1
	mova	.L19,r0
	fmov.s	@r0,fr1
	fmov.s	fr1,@r1
	.loc 1 54 0
	mov.l	.L20,r1
	mova	.L54,r0
	fmov.s	@r0,fr1
	fmov.s	fr1,@r1
	.loc 1 55 0
	mov.l	.L22,r1
	mova	.L23,r0
	fmov.s	@r0,fr1
	fmov.s	fr1,@r1
	.loc 1 56 0
	mov.l	.L24,r1
	mov.w	.L25,r2
	mov.w	r2,@r1
	.loc 1 58 0
	mov	r14,r8
	mov.l	.L55,r1
	jsr	@r1
	nop
	fmov	fr0,fr1
	fmov.s	fr1,@r8
	.loc 1 59 0
	mov	r14,r2
	mov	r14,r1
	add	#8,r1
	fmov.s	@r2,fr4
	fmov.s	@r1,fr5
	mov.l	.L63,r1
	jsr	@r1
	nop
	lds	r0,fpul
	fsts	fpul,fr1
	mov.l	.L28,r1
	flds	fr1,fpul
	sts	fpul,r4
	mov	r1,r5
	mov.l	.L65,r1
	jsr	@r1
	nop
	.loc 1 62 0
	mov	r14,r8
	mov.l	.L55,r1
	jsr	@r1
	nop
	fmov	fr0,fr1
	fmov.s	fr1,@r8
	.loc 1 63 0
	mov	r14,r2
	mov	r14,r1
	add	#8,r1
	fmov.s	@r2,fr4
	fmov.s	@r1,fr5
	mov.l	.L63,r1
	jsr	@r1
	nop
	lds	r0,fpul
	fsts	fpul,fr1
	mov.l	.L32,r1
	flds	fr1,fpul
	sts	fpul,r4
	mov	r1,r5
	mov.l	.L65,r1
	jsr	@r1
	nop
	.loc 1 64 0
	mov.w	.L61,r1
	add	#13,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	mov	r1,r0
	cmp/eq	#1,r0
	movt	r1
	extu.b	r1,r1
	lds	r1,fpul
	fsts	fpul,fr1
	mov.l	.L35,r1
	flds	fr1,fpul
	sts	fpul,r4
	mov	r1,r5
	mov.l	.L65,r1
	jsr	@r1
	nop
	.loc 1 67 0
	mov.w	.L61,r1
	add	#13,r1
	mov	#2,r2
	mov.b	r2,@r1
	.loc 1 68 0
	mov	r14,r8
	mov.l	.L55,r1
	jsr	@r1
	nop
	fmov	fr0,fr1
	fmov.s	fr1,@r8
	.loc 1 69 0
	mov	r14,r2
	mov	r14,r1
	add	#4,r1
	fmov.s	@r2,fr4
	fmov.s	@r1,fr5
	mov.l	.L63,r1
	jsr	@r1
	nop
	lds	r0,fpul
	fsts	fpul,fr1
	mov.l	.L40,r1
	flds	fr1,fpul
	sts	fpul,r4
	mov	r1,r5
	mov.l	.L65,r1
	jsr	@r1
	nop
	.loc 1 70 0
	mov.w	.L61,r1
	add	#13,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	mov	r1,r0
	cmp/eq	#2,r0
	movt	r1
	extu.b	r1,r1
	lds	r1,fpul
	fsts	fpul,fr1
	mov.l	.L43,r1
	flds	fr1,fpul
	sts	fpul,r4
	mov	r1,r5
	mov.l	.L65,r1
	jsr	@r1
	nop
	.loc 1 87 0
	mov.w	.L61,r1
	add	#13,r1
	mov	#3,r2
	mov.b	r2,@r1
	.loc 1 88 0
	mov	r14,r8
	mov.l	.L55,r1
	jsr	@r1
	nop
	fmov	fr0,fr1
	fmov.s	fr1,@r8
	.loc 1 89 0
	mov	r14,r2
	mov	r14,r1
	add	#8,r1
	fmov.s	@r2,fr4
	fmov.s	@r1,fr5
	mov.l	.L63,r1
	jsr	@r1
	nop
	lds	r0,fpul
	fsts	fpul,fr1
	mov.l	.L48,r1
	flds	fr1,fpul
	sts	fpul,r4
	mov	r1,r5
	mov.l	.L65,r1
	jsr	@r1
	nop
	.loc 1 90 0
	mov.w	.L61,r1
	add	#13,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	mov	r1,r0
	cmp/eq	#3,r0
	movt	r1
	extu.b	r1,r1
	lds	r1,fpul
	fsts	fpul,fr1
	mov.l	.L51,r1
	flds	fr1,fpul
	sts	fpul,r4
	mov	r1,r5
	mov.l	.L65,r1
	jsr	@r1
	nop
	.loc 1 92 0
	mov.l	.L53,r1
	mova	.L54,r0
	fmov.s	@r0,fr1
	fmov.s	fr1,@r1
	.loc 1 93 0
	mov	r14,r8
	mov.l	.L55,r1
	jsr	@r1
	nop
	fmov	fr0,fr1
	fmov.s	fr1,@r8
	.loc 1 94 0
	mov.w	.L61,r1
	add	#36,r1
	fmov.s	@r1,fr2
	mova	.L57,r0
	fmov.s	@r0,fr1
	fmov	fr2,fr4
	fmov	fr1,fr5
	mov.l	.L63,r1
	jsr	@r1
	nop
	lds	r0,fpul
	fsts	fpul,fr1
	mov.l	.L59,r1
	flds	fr1,fpul
	sts	fpul,r4
	mov	r1,r5
	mov.l	.L65,r1
	jsr	@r1
	nop
	.loc 1 95 0
	mov.w	.L61,r1
	add	#20,r1
	fmov.s	@r1,fr2
	mova	.L62,r0
	fmov.s	@r0,fr1
	fmov	fr2,fr4
	fmov	fr1,fr5
	mov.l	.L63,r1
	jsr	@r1
	nop
	lds	r0,fpul
	fsts	fpul,fr1
	mov.l	.L64,r1
	flds	fr1,fpul
	sts	fpul,r4
	mov	r1,r5
	mov.l	.L65,r1
	jsr	@r1
	nop
	bra	.L8
	nop
	.align 1
.L61:
	.short	-26944
.L25:
	.short	16384
.L66:
	.align 2
.L10:
	.long	_ClearRam
.L11:
	.long	_PopulateRamVariables
.L12:
	.long	1079198681
	.long	1081000193
.L14:
	.long	.LC0
.L65:
	.long	_Assert
.L16:
	.long	-38376
.L17:
	.long	1148846080
.L53:
	.long	-39272
.L19:
	.long	1132885366
.L20:
	.long	-41772
.L54:
	.long	1143930880
.L22:
	.long	-41828
.L23:
	.long	1097859072
.L24:
	.long	-41986
.L55:
	.long	_CallSpeedDensityHook
.L63:
	.long	_AreCloseEnough
.L28:
	.long	.LC1
.L32:
	.long	.LC2
.L35:
	.long	.LC3
.L40:
	.long	.LC4
.L43:
	.long	.LC5
.L48:
	.long	.LC6
.L51:
	.long	.LC7
.L57:
	.long	1057896675
.L59:
	.long	.LC8
.L62:
	.long	1094217231
.L64:
	.long	.LC9
	.align 1
.L8:
	.loc 1 96 0
	mov	r14,r1
	add	#8,r1
	fmov.s	@r1,fr1
	mova	.L67,r0
	fmov.s	@r0+,fr2
	fmul	fr2,fr1
	fmov.s	@r0,fr2
	fadd	fr2,fr1
	mov	r14,r1
	fmov.s	@r1,fr4
	fmov	fr1,fr5
	mov.l	.L68,r1
	jsr	@r1
	nop
	lds	r0,fpul
	fsts	fpul,fr1
	mov.l	.L69,r1
	flds	fr1,fpul
	sts	fpul,r4
	mov	r1,r5
	mov.l	.L73,r1
	jsr	@r1
	nop
	.loc 1 97 0
	mov.w	.L76,r1
	add	#13,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	mov	r1,r0
	cmp/eq	#3,r0
	movt	r1
	extu.b	r1,r1
	lds	r1,fpul
	fsts	fpul,fr1
	mov.l	.L72,r1
	flds	fr1,fpul
	sts	fpul,r4
	mov	r1,r5
	mov.l	.L73,r1
	jsr	@r1
	nop
	.loc 1 99 0
	mov.l	.L74,r1
	mova	.L75,r0
	fmov.s	@r0,fr1
	fmov.s	fr1,@r1
	.loc 1 140 0
	mov.w	.L76,r1
	add	#13,r1
	mov	#1,r2
	mov.b	r2,@r1
	.loc 1 142 0
	add	#12,r14
	mov	r14,r15
	lds.l   @r15+,pr
	mov.l   @r15+,r14
	mov.l   @r15+,r8
	rts	
	nop
	.align 1
.L76:
	.short	-26944
.L77:
	.align 2
.L67:
	.long	1055100474
	.long	1087171600
.L68:
	.long	_AreCloseEnough
.L69:
	.long	.LC6
.L73:
	.long	_Assert
.L72:
	.long	.LC7
.L74:
	.long	-39272
.L75:
	.long	1132885366
	.cfi_endproc
.LFE1:
	.size	_SpeedDensityUnitTests, .-_SpeedDensityUnitTests
	.text
.Letext0:
	.file 2 "C:\\Dev\\MerpMod\\MerpMod\\RamVariables.h"
	.file 3 "C:\\Dev\\MerpMod\\MerpMod\\enums.h"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.ualong	0x37f
	.uaword	0x2
	.ualong	.Ldebug_abbrev0
	.byte	0x4
	.uleb128 0x1
	.ualong	.LASF58
	.byte	0x1
	.ualong	.LASF59
	.ualong	.Ldebug_ranges0+0
	.ualong	0
	.ualong	0
	.ualong	.Ldebug_line0
	.uleb128 0x2
	.ualong	.LASF60
	.byte	0x4
	.byte	0x3
	.byte	0x2e
	.ualong	0x4a
	.uleb128 0x3
	.ualong	.LASF0
	.sleb128 0
	.uleb128 0x3
	.ualong	.LASF1
	.sleb128 1
	.uleb128 0x3
	.ualong	.LASF2
	.sleb128 2
	.uleb128 0x3
	.ualong	.LASF3
	.sleb128 3
	.byte	0
	.uleb128 0x4
	.byte	0x2
	.byte	0x5
	.ualong	.LASF4
	.uleb128 0x4
	.byte	0x4
	.byte	0x4
	.ualong	.LASF5
	.uleb128 0x5
	.byte	0x4
	.byte	0x5
	.string	"int"
	.uleb128 0x4
	.byte	0x4
	.byte	0x5
	.ualong	.LASF6
	.uleb128 0x4
	.byte	0x4
	.byte	0x7
	.ualong	.LASF7
	.uleb128 0x4
	.byte	0x1
	.byte	0x6
	.ualong	.LASF8
	.uleb128 0x6
	.byte	0x70
	.byte	0x2
	.byte	0x12
	.ualong	0x2d9
	.uleb128 0x7
	.ualong	.LASF9
	.byte	0x2
	.byte	0x14
	.ualong	0x2d9
	.byte	0x2
	.byte	0x23
	.uleb128 0
	.uleb128 0x7
	.ualong	.LASF10
	.byte	0x2
	.byte	0x15
	.ualong	0x2d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x1
	.uleb128 0x7
	.ualong	.LASF11
	.byte	0x2
	.byte	0x16
	.ualong	0x2d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x2
	.uleb128 0x7
	.ualong	.LASF12
	.byte	0x2
	.byte	0x17
	.ualong	0x2d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x3
	.uleb128 0x7
	.ualong	.LASF13
	.byte	0x2
	.byte	0x18
	.ualong	0x2e0
	.byte	0x2
	.byte	0x23
	.uleb128 0x4
	.uleb128 0x7
	.ualong	.LASF14
	.byte	0x2
	.byte	0x19
	.ualong	0x2d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x7
	.ualong	.LASF15
	.byte	0x2
	.byte	0x1a
	.ualong	0x2d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x9
	.uleb128 0x7
	.ualong	.LASF16
	.byte	0x2
	.byte	0x1b
	.ualong	0x2d9
	.byte	0x2
	.byte	0x23
	.uleb128 0xa
	.uleb128 0x7
	.ualong	.LASF17
	.byte	0x2
	.byte	0x1c
	.ualong	0x2d9
	.byte	0x2
	.byte	0x23
	.uleb128 0xb
	.uleb128 0x7
	.ualong	.LASF18
	.byte	0x2
	.byte	0x40
	.ualong	0x2d9
	.byte	0x2
	.byte	0x23
	.uleb128 0xc
	.uleb128 0x7
	.ualong	.LASF19
	.byte	0x2
	.byte	0x41
	.ualong	0x2d9
	.byte	0x2
	.byte	0x23
	.uleb128 0xd
	.uleb128 0x7
	.ualong	.LASF20
	.byte	0x2
	.byte	0x42
	.ualong	0x2d9
	.byte	0x2
	.byte	0x23
	.uleb128 0xe
	.uleb128 0x7
	.ualong	.LASF21
	.byte	0x2
	.byte	0x43
	.ualong	0x2d9
	.byte	0x2
	.byte	0x23
	.uleb128 0xf
	.uleb128 0x7
	.ualong	.LASF22
	.byte	0x2
	.byte	0x44
	.ualong	0x51
	.byte	0x2
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x7
	.ualong	.LASF23
	.byte	0x2
	.byte	0x45
	.ualong	0x51
	.byte	0x2
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x7
	.ualong	.LASF24
	.byte	0x2
	.byte	0x46
	.ualong	0x51
	.byte	0x2
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x7
	.ualong	.LASF25
	.byte	0x2
	.byte	0x47
	.ualong	0x51
	.byte	0x2
	.byte	0x23
	.uleb128 0x1c
	.uleb128 0x7
	.ualong	.LASF26
	.byte	0x2
	.byte	0x48
	.ualong	0x51
	.byte	0x2
	.byte	0x23
	.uleb128 0x20
	.uleb128 0x7
	.ualong	.LASF27
	.byte	0x2
	.byte	0x49
	.ualong	0x51
	.byte	0x2
	.byte	0x23
	.uleb128 0x24
	.uleb128 0x7
	.ualong	.LASF28
	.byte	0x2
	.byte	0x4a
	.ualong	0x51
	.byte	0x2
	.byte	0x23
	.uleb128 0x28
	.uleb128 0x7
	.ualong	.LASF29
	.byte	0x2
	.byte	0x50
	.ualong	0x2d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x2c
	.uleb128 0x7
	.ualong	.LASF30
	.byte	0x2
	.byte	0x51
	.ualong	0x2d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x2d
	.uleb128 0x7
	.ualong	.LASF31
	.byte	0x2
	.byte	0x52
	.ualong	0x2d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x2e
	.uleb128 0x7
	.ualong	.LASF32
	.byte	0x2
	.byte	0x53
	.ualong	0x2d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x2f
	.uleb128 0x7
	.ualong	.LASF33
	.byte	0x2
	.byte	0x54
	.ualong	0x2d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x30
	.uleb128 0x7
	.ualong	.LASF34
	.byte	0x2
	.byte	0x55
	.ualong	0x2d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x31
	.uleb128 0x7
	.ualong	.LASF35
	.byte	0x2
	.byte	0x56
	.ualong	0x2d9
	.byte	0x2
	.byte	0x23
	.uleb128 0x32
	.uleb128 0x7
	.ualong	.LASF36
	.byte	0x2
	.byte	0x57
	.ualong	0x6d
	.byte	0x2
	.byte	0x23
	.uleb128 0x33
	.uleb128 0x7
	.ualong	.LASF37
	.byte	0x2
	.byte	0x58
	.ualong	0x51
	.byte	0x2
	.byte	0x23
	.uleb128 0x34
	.uleb128 0x7
	.ualong	.LASF38
	.byte	0x2
	.byte	0x59
	.ualong	0x51
	.byte	0x2
	.byte	0x23
	.uleb128 0x38
	.uleb128 0x7
	.ualong	.LASF39
	.byte	0x2
	.byte	0x5a
	.ualong	0x51
	.byte	0x2
	.byte	0x23
	.uleb128 0x3c
	.uleb128 0x7
	.ualong	.LASF40
	.byte	0x2
	.byte	0x5b
	.ualong	0x51
	.byte	0x2
	.byte	0x23
	.uleb128 0x40
	.uleb128 0x7
	.ualong	.LASF41
	.byte	0x2
	.byte	0x5c
	.ualong	0x51
	.byte	0x2
	.byte	0x23
	.uleb128 0x44
	.uleb128 0x7
	.ualong	.LASF42
	.byte	0x2
	.byte	0x5d
	.ualong	0x51
	.byte	0x2
	.byte	0x23
	.uleb128 0x48
	.uleb128 0x7
	.ualong	.LASF43
	.byte	0x2
	.byte	0x5e
	.ualong	0x51
	.byte	0x2
	.byte	0x23
	.uleb128 0x4c
	.uleb128 0x7
	.ualong	.LASF44
	.byte	0x2
	.byte	0x5f
	.ualong	0x51
	.byte	0x2
	.byte	0x23
	.uleb128 0x50
	.uleb128 0x7
	.ualong	.LASF45
	.byte	0x2
	.byte	0x60
	.ualong	0x51
	.byte	0x2
	.byte	0x23
	.uleb128 0x54
	.uleb128 0x7
	.ualong	.LASF46
	.byte	0x2
	.byte	0x61
	.ualong	0x51
	.byte	0x2
	.byte	0x23
	.uleb128 0x58
	.uleb128 0x7
	.ualong	.LASF47
	.byte	0x2
	.byte	0x62
	.ualong	0x51
	.byte	0x2
	.byte	0x23
	.uleb128 0x5c
	.uleb128 0x7
	.ualong	.LASF48
	.byte	0x2
	.byte	0x63
	.ualong	0x51
	.byte	0x2
	.byte	0x23
	.uleb128 0x60
	.uleb128 0x7
	.ualong	.LASF49
	.byte	0x2
	.byte	0x64
	.ualong	0x51
	.byte	0x2
	.byte	0x23
	.uleb128 0x64
	.uleb128 0x8
	.ualong	.LASF50
	.byte	0x2
	.uaword	0x110
	.ualong	0x5f
	.byte	0x2
	.byte	0x23
	.uleb128 0x68
	.uleb128 0x8
	.ualong	.LASF51
	.byte	0x2
	.uaword	0x111
	.ualong	0x6d
	.byte	0x2
	.byte	0x23
	.uleb128 0x6c
	.byte	0
	.uleb128 0x4
	.byte	0x1
	.byte	0x8
	.ualong	.LASF52
	.uleb128 0x4
	.byte	0x4
	.byte	0x7
	.ualong	.LASF53
	.uleb128 0x9
	.ualong	.LASF61
	.byte	0x2
	.uaword	0x115
	.ualong	0x74
	.uleb128 0xa
	.byte	0x1
	.ualong	.LASF62
	.byte	0x1
	.byte	0x16
	.ualong	0x51
	.ualong	.LFB0
	.ualong	.LFE0
	.ualong	.LLST0
	.byte	0x1
	.byte	0x40
	.ualong	0x320
	.uleb128 0xb
	.ualong	.LASF54
	.byte	0x1
	.byte	0x18
	.ualong	0x327
	.byte	0x2
	.byte	0x91
	.sleb128 -12
	.byte	0
	.uleb128 0xc
	.ualong	0x327
	.uleb128 0xd
	.byte	0
	.uleb128 0xe
	.byte	0x4
	.ualong	0x320
	.uleb128 0xf
	.byte	0x1
	.ualong	.LASF63
	.byte	0x1
	.byte	0x22
	.ualong	.LFB1
	.ualong	.LFE1
	.ualong	.LLST1
	.byte	0x1
	.byte	0x40
	.uleb128 0x10
	.byte	0x1
	.ualong	.LASF64
	.byte	0x1
	.byte	0x25
	.ualong	0x58
	.byte	0x1
	.byte	0x40
	.ualong	0x357
	.uleb128 0xd
	.byte	0
	.uleb128 0xb
	.ualong	.LASF55
	.byte	0x1
	.byte	0x2c
	.ualong	0x51
	.byte	0x2
	.byte	0x91
	.sleb128 -16
	.uleb128 0xb
	.ualong	.LASF56
	.byte	0x1
	.byte	0x2d
	.ualong	0x51
	.byte	0x2
	.byte	0x91
	.sleb128 -20
	.uleb128 0xb
	.ualong	.LASF57
	.byte	0x1
	.byte	0x3a
	.ualong	0x51
	.byte	0x2
	.byte	0x91
	.sleb128 -24
	.byte	0
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x55
	.uleb128 0x6
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x52
	.uleb128 0x1
	.uleb128 0x10
	.uleb128 0x6
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x4
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x28
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x1c
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x8
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x16
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.uleb128 0x40
	.uleb128 0x6
	.uleb128 0x2116
	.uleb128 0xc
	.uleb128 0x36
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x15
	.byte	0x1
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x18
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.uleb128 0x40
	.uleb128 0x6
	.uleb128 0x2116
	.uleb128 0xc
	.uleb128 0x36
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3c
	.uleb128 0xc
	.uleb128 0x36
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_loc,"",@progbits
.Ldebug_loc0:
.LLST0:
	.ualong	.LFB0
	.ualong	.LCFI0
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI0
	.ualong	.LCFI1
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI1
	.ualong	.LCFI2
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI2
	.ualong	.LCFI3
	.uaword	0x2
	.byte	0x7f
	.sleb128 12
	.ualong	.LCFI3
	.ualong	.LFE0
	.uaword	0x2
	.byte	0x7e
	.sleb128 12
	.ualong	0
	.ualong	0
.LLST1:
	.ualong	.LFB1
	.ualong	.LCFI4
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI4
	.ualong	.LCFI5
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI5
	.ualong	.LCFI6
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI6
	.ualong	.LCFI7
	.uaword	0x2
	.byte	0x7f
	.sleb128 12
	.ualong	.LCFI7
	.ualong	.LCFI8
	.uaword	0x2
	.byte	0x7f
	.sleb128 24
	.ualong	.LCFI8
	.ualong	.LFE1
	.uaword	0x2
	.byte	0x7e
	.sleb128 24
	.ualong	0
	.ualong	0
	.section	.debug_aranges,"",@progbits
	.ualong	0x24
	.uaword	0x2
	.ualong	.Ldebug_info0
	.byte	0x4
	.byte	0
	.uaword	0
	.uaword	0
	.ualong	.LFB0
	.ualong	.LFE0-.LFB0
	.ualong	.LFB1
	.ualong	.LFE1-.LFB1
	.ualong	0
	.ualong	0
	.section	.debug_ranges,"",@progbits
.Ldebug_ranges0:
	.ualong	.LFB0
	.ualong	.LFE0
	.ualong	.LFB1
	.ualong	.LFE1
	.ualong	0
	.ualong	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF31:
	.string	"FlatFootShiftMode"
.LASF35:
	.string	"FFSGear"
.LASF42:
	.string	"LaunchControlCut"
.LASF45:
	.string	"FlatFootShiftRpmThreshold"
.LASF60:
	.string	"MafModeValues"
.LASF21:
	.string	"sdempty1"
.LASF4:
	.string	"short int"
.LASF27:
	.string	"SDMafBlendRatio"
.LASF19:
	.string	"MafMode"
.LASF7:
	.string	"sizetype"
.LASF9:
	.string	"RamVariableStart"
.LASF13:
	.string	"ECUIdentifier"
.LASF0:
	.string	"MafModeUndefined"
.LASF18:
	.string	"SDInitFlag"
.LASF43:
	.string	"LaunchControlHyst"
.LASF56:
	.string	"expectedMafFromSpeedDensity"
.LASF11:
	.string	"CruiseCoastLast"
.LASF49:
	.string	"FlatFootShiftSpeedThreshold"
.LASF28:
	.string	"SDMafFromBlend"
.LASF37:
	.string	"RevLimCut"
.LASF24:
	.string	"MafFromSensor"
.LASF5:
	.string	"float"
.LASF54:
	.string	"func"
.LASF22:
	.string	"VolumetricEfficiency"
.LASF6:
	.string	"long int"
.LASF57:
	.string	"result"
.LASF61:
	.string	"RamVariables"
.LASF3:
	.string	"MafModeBlending"
.LASF40:
	.string	"RedLineHyst"
.LASF52:
	.string	"unsigned char"
.LASF64:
	.string	"ClearRam"
.LASF2:
	.string	"MafModeSpeedDensity"
.LASF46:
	.string	"FlatFootShiftAutoDelta"
.LASF29:
	.string	"RevLimInitFlag"
.LASF58:
	.string	"GNU C 4.7-GNUSH_v13.01"
.LASF53:
	.string	"long unsigned int"
.LASF44:
	.string	"FFSRPM"
.LASF51:
	.string	"RamHoleEndMarker"
.LASF48:
	.string	"FlatFootShiftHyst"
.LASF8:
	.string	"char"
.LASF26:
	.string	"DeltaMapCompensation"
.LASF23:
	.string	"MafFromSpeedDensity"
.LASF15:
	.string	"blank0"
.LASF16:
	.string	"blank1"
.LASF17:
	.string	"blank2"
.LASF10:
	.string	"VinAuth"
.LASF12:
	.string	"CruiseResumeLast"
.LASF20:
	.string	"SDempty"
.LASF63:
	.string	"SpeedDensityUnitTests"
.LASF32:
	.string	"LCEngaged"
.LASF55:
	.string	"expectedMafFromSensor"
.LASF33:
	.string	"FFSEngaged"
.LASF30:
	.string	"RevLimMode"
.LASF38:
	.string	"RevLimResume"
.LASF14:
	.string	"HardResetFlag"
.LASF47:
	.string	"FlatFootShiftStaticDelta"
.LASF59:
	.string	"C:\\Dev\\MerpMod\\MerpMod\\SpeedDensityTests.c"
.LASF25:
	.string	"AtmosphericCompensation"
.LASF39:
	.string	"RedLineCut"
.LASF1:
	.string	"MafModeSensor"
.LASF50:
	.string	"RamHoleSpace"
.LASF36:
	.string	"eleemee2"
.LASF62:
	.string	"CallSpeedDensityHook"
.LASF34:
	.string	"ClutchSwitchLast"
.LASF41:
	.string	"LaunchControlSpeedMax"
	.ident	"GCC: (GNU) 4.7-GNUSH_v13.01"
