	.file	"Initializer.c"
	.text
	.text
.Ltext0:
	.cfi_sections	.debug_frame
	.global	_MemoryResetHooked
	.section	RomHole_Functions,"aw",@progbits
	.align 2
	.type	_MemoryResetHooked, @object
	.size	_MemoryResetHooked, 4
_MemoryResetHooked:
	.long	64684
	.section	RomHole_Code,"ax",@progbits
	.align 2
	.global	_Initializer
	.type	_Initializer, @function
_Initializer:
.LFB0:
	.file 1 "C:\\Dev\\MerpMod\\MerpMod\\Initializer.c"
	.loc 1 20 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI0:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	sts.l	pr,@-r15
.LCFI1:
	.cfi_def_cfa_offset 8
	.cfi_offset 17, -8
	mov	r15,r14
.LCFI2:
	.cfi_def_cfa_register 14
	.loc 1 21 0
	mov.l	.L2,r1
	mov.l	@r1,r1
	jsr	@r1
	nop
	.loc 1 25 0
	mov.l	.L3,r1
	jsr	@r1
	nop
	.loc 1 41 0
	mov	r14,r15
	lds.l   @r15+,pr
	mov.l   @r15+,r14
	rts	
	nop
.L4:
	.align 2
.L2:
	.long	_MemoryResetHooked
.L3:
	.long	_ResetRamVariables
	.cfi_endproc
.LFE0:
	.size	_Initializer, .-_Initializer
	.align 2
	.global	_ResetRamVariables
	.type	_ResetRamVariables, @function
_ResetRamVariables:
.LFB1:
	.loc 1 44 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI3:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	sts.l	pr,@-r15
.LCFI4:
	.cfi_def_cfa_offset 8
	.cfi_offset 17, -8
	mov	r15,r14
.LCFI5:
	.cfi_def_cfa_register 14
	.loc 1 45 0
	mov.w	.L6,r2
	mov.w	.L7,r1
	mov	r2,r4
	mov	r1,r5
	mov.l	.L8,r1
	jsr	@r1
	nop
	.loc 1 46 0
	mov.l	.L9,r1
	jsr	@r1
	nop
	.loc 1 47 0
	mov	r14,r15
	lds.l   @r15+,pr
	mov.l   @r15+,r14
	rts	
	nop
	.align 1
.L6:
	.short	-26944
.L7:
	.short	-26836
.L10:
	.align 2
.L8:
	.long	_ClearRamVariables
.L9:
	.long	_PopulateRamVariables
	.cfi_endproc
.LFE1:
	.size	_ResetRamVariables, .-_ResetRamVariables
	.align 2
	.global	_InitRamVariables
	.type	_InitRamVariables, @function
_InitRamVariables:
.LFB2:
	.loc 1 50 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI6:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	sts.l	pr,@-r15
.LCFI7:
	.cfi_def_cfa_offset 8
	.cfi_offset 17, -8
	mov	r15,r14
.LCFI8:
	.cfi_def_cfa_register 14
	.loc 1 51 0
	mov.w	.L16,r1
	mov.l	@(4,r1),r2
	mov.l	.L15,r1
	mov.l	@r1,r1
	cmp/eq	r1,r2
	bf.s	.L12
	nop
	.loc 1 51 0 is_stmt 0 discriminator 1
	mov.w	.L16,r1
	add	#8,r1
	mov.b	@r1,r1
	extu.b	r1,r2
	mov	#1,r1
	cmp/eq	r1,r2
	bf.s	.L11
	nop
.L12:
	.loc 1 53 0 is_stmt 1
	mov.l	.L17,r1
	jsr	@r1
	nop
.L11:
	.loc 1 55 0
	mov	r14,r15
	lds.l   @r15+,pr
	mov.l   @r15+,r14
	rts	
	nop
	.align 1
.L16:
	.short	-26944
.L18:
	.align 2
.L15:
	.long	850828
.L17:
	.long	_ResetRamVariables
	.cfi_endproc
.LFE2:
	.size	_InitRamVariables, .-_InitRamVariables
	.align 2
	.global	_ClearRamVariables
	.type	_ClearRamVariables, @function
_ClearRamVariables:
.LFB3:
	.loc 1 58 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI9:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	add	#-16,r15
.LCFI10:
	.cfi_def_cfa_offset 20
	mov	r15,r14
.LCFI11:
	.cfi_def_cfa_register 14
	mov	r14,r1
	add	#-48,r1
	mov.l	r4,@(52,r1)
	mov	r14,r1
	add	#-48,r1
	mov.l	r5,@(48,r1)
	.loc 1 59 0
	mov	r14,r1
	add	#-48,r1
	mov	r14,r2
	add	#-48,r2
	mov.l	@(48,r2),r2
	mov.l	r2,@(56,r1)
	.loc 1 60 0
	mov	r14,r1
	add	#-48,r1
	mov	r14,r2
	add	#-48,r2
	mov.l	@(52,r2),r2
	mov.l	r2,@(60,r1)
	.loc 1 61 0
	bra	.L20
	nop
	.align 1
.L21:
	.loc 1 63 0
	mov	r14,r1
	add	#-48,r1
	mov.l	@(60,r1),r1
	mov	#0,r2
	mov.l	r2,@r1
	.loc 1 64 0
	mov	r14,r1
	add	#-48,r1
	mov	r14,r2
	add	#-48,r2
	mov.l	@(60,r2),r2
	add	#4,r2
	mov.l	r2,@(60,r1)
.L20:
	.loc 1 61 0 discriminator 1
	mov	r14,r2
	add	#-48,r2
	mov	r14,r1
	add	#-48,r1
	mov.l	@(60,r2),r2
	mov.l	@(56,r1),r1
	cmp/hs       r1,r2
	bf.s	.L21
	nop
	.loc 1 66 0
	add	#16,r14
	mov	r14,r15
	mov.l   @r15+,r14
	rts	
	nop
	.cfi_endproc
.LFE3:
	.size	_ClearRamVariables, .-_ClearRamVariables
	.align 2
	.global	_PopulateRamVariables
	.type	_PopulateRamVariables, @function
_PopulateRamVariables:
.LFB4:
	.loc 1 69 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI12:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	sts.l	pr,@-r15
.LCFI13:
	.cfi_def_cfa_offset 8
	.cfi_offset 17, -8
	mov	r15,r14
.LCFI14:
	.cfi_def_cfa_register 14
	.loc 1 96 0
	mov.w	.L56,r1
	add	#45,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bf.s	.L23
	nop
	.loc 1 98 0
	mov.w	.L56,r1
	mov.l	.L26,r2
	mov.b	@r2,r2
	extu.b	r2,r2
	add	#45,r1
	mov.b	r2,@r1
.L23:
	.loc 1 101 0
	mov.w	.L56,r1
	mov.l	.L28,r2
	mov.b	@r2,r2
	extu.b	r2,r2
	add	#46,r1
	mov.b	r2,@r1
	.loc 1 102 0
	mov.w	.L56,r1
	mov.l	.L30,r2
	fmov.s	@r2,fr1
	add	#60,r1
	fmov.s	fr1,@r1
	.loc 1 103 0
	mov.w	.L56,r1
	mov.l	.L32,r2
	fmov.s	@r2,fr1
	add	#64,r1
	fmov.s	fr1,@r1
	.loc 1 104 0
	mov.w	.L56,r1
	mov.l	.L34,r2
	fmov.s	@r2,fr1
	add	#96,r1
	fmov.s	fr1,@r1
	.loc 1 105 0
	mov.w	.L56,r1
	mov.l	.L36,r2
	fmov.s	@r2,fr1
	add	#88,r1
	fmov.s	fr1,@r1
	.loc 1 106 0
	mov.w	.L56,r1
	mov.l	.L38,r2
	fmov.s	@r2,fr1
	add	#92,r1
	fmov.s	fr1,@r1
	.loc 1 107 0
	mov.w	.L56,r1
	mov.l	.L40,r2
	fmov.s	@r2,fr1
	add	#68,r1
	fmov.s	fr1,@r1
	.loc 1 108 0
	mov.w	.L56,r1
	mov.l	.L42,r2
	fmov.s	@r2,fr1
	add	#72,r1
	fmov.s	fr1,@r1
	.loc 1 109 0
	mov.w	.L56,r1
	mov.l	.L44,r2
	fmov.s	@r2,fr1
	add	#76,r1
	fmov.s	fr1,@r1
	.loc 1 110 0
	mov.w	.L56,r1
	mov.l	.L46,r2
	fmov.s	@r2,fr1
	add	#100,r1
	fmov.s	fr1,@r1
	.loc 1 111 0
	mov.w	.L56,r1
	mov.l	.L48,r2
	fmov.s	@r2,fr1
	add	#84,r1
	fmov.s	fr1,@r1
	.loc 1 112 0
	mov.w	.L56,r1
	mov.l	.L50,r2
	mov.b	@r2,r2
	extu.b	r2,r3
	mov	#-128,r2
	and	r3,r2
	extu.b	r2,r2
	add	#49,r1
	mov.b	r2,@r1
	.loc 1 113 0
	mov.l	.L51,r1
	jsr	@r1
	nop
	.loc 1 152 0
	mov.w	.L56,r1
	mov.l	.L53,r2
	mov.b	@r2,r2
	extu.b	r2,r2
	add	#13,r1
	mov.b	r2,@r1
	.loc 1 155 0
	mov.w	.L56,r1
	mov.l	.L55,r2
	mov.l	@r2,r2
	lds	r2,fpul
	fsts	fpul,fr1
	flds	fr1,fpul
	sts	fpul,r2
	mov.l	r2,@(4,r1)
	.loc 1 156 0
	mov.w	.L56,r1
	add	#8,r1
	mov	#0,r2
	mov.b	r2,@r1
	.loc 1 158 0
	mov	r14,r15
	lds.l   @r15+,pr
	mov.l   @r15+,r14
	rts	
	nop
	.align 1
.L56:
	.short	-26944
.L57:
	.align 2
.L26:
	.long	_DefaultRevLimMode
.L28:
	.long	_DefaultFlatFootShiftMode
.L30:
	.long	_DefaultRedLineCut
.L32:
	.long	_DefaultRedLineHyst
.L34:
	.long	_DefaultFlatFootShiftHyst
.L36:
	.long	_DefaultFlatFootShiftAutoDelta
.L38:
	.long	_DefaultFlatFootShiftStaticDelta
.L40:
	.long	_DefaultLaunchControlSpeedMax
.L42:
	.long	_DefaultLaunchControlCut
.L44:
	.long	_DefaultLaunchControlHyst
.L46:
	.long	_DefaultFlatFootShiftSpeedThreshold
.L48:
	.long	_DefaultFlatFootShiftRpmThreshold
.L50:
	.long	-38415
.L51:
	.long	_RevLimReset
.L53:
	.long	_DefaultMafMode
.L55:
	.long	850828
	.cfi_endproc
.LFE4:
	.size	_PopulateRamVariables, .-_PopulateRamVariables
	.text
.Letext0:
	.file 2 "C:\\Dev\\MerpMod\\MerpMod\\enums.h"
	.file 3 "C:\\Dev\\MerpMod\\MerpMod\\RamVariables.h"
	.file 4 "C:\\Dev\\MerpMod\\MerpMod\\Externs.h"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.ualong	0x48f
	.uaword	0x2
	.ualong	.Ldebug_abbrev0
	.byte	0x4
	.uleb128 0x1
	.ualong	.LASF79
	.byte	0x1
	.ualong	.LASF80
	.ualong	.Ldebug_ranges0+0
	.ualong	0
	.ualong	0
	.ualong	.Ldebug_line0
	.uleb128 0x2
	.ualong	.LASF4
	.byte	0x4
	.byte	0x2
	.byte	0x35
	.ualong	0x4a
	.uleb128 0x3
	.ualong	.LASF0
	.sleb128 0
	.uleb128 0x3
	.ualong	.LASF1
	.sleb128 1
	.uleb128 0x3
	.ualong	.LASF2
	.sleb128 2
	.uleb128 0x3
	.ualong	.LASF3
	.sleb128 3
	.byte	0
	.uleb128 0x2
	.ualong	.LASF5
	.byte	0x4
	.byte	0x2
	.byte	0x5d
	.ualong	0x63
	.uleb128 0x3
	.ualong	.LASF6
	.sleb128 0
	.uleb128 0x3
	.ualong	.LASF7
	.sleb128 1
	.byte	0
	.uleb128 0x4
	.byte	0x2
	.byte	0x5
	.ualong	.LASF8
	.uleb128 0x4
	.byte	0x4
	.byte	0x4
	.ualong	.LASF9
	.uleb128 0x5
	.byte	0x4
	.byte	0x5
	.string	"int"
	.uleb128 0x4
	.byte	0x4
	.byte	0x5
	.ualong	.LASF10
	.uleb128 0x4
	.byte	0x4
	.byte	0x7
	.ualong	.LASF11
	.uleb128 0x4
	.byte	0x1
	.byte	0x6
	.ualong	.LASF12
	.uleb128 0x6
	.byte	0x70
	.byte	0x3
	.byte	0x12
	.ualong	0x2f2
	.uleb128 0x7
	.ualong	.LASF13
	.byte	0x3
	.byte	0x14
	.ualong	0x2f2
	.byte	0x2
	.byte	0x23
	.uleb128 0
	.uleb128 0x7
	.ualong	.LASF14
	.byte	0x3
	.byte	0x15
	.ualong	0x2f2
	.byte	0x2
	.byte	0x23
	.uleb128 0x1
	.uleb128 0x7
	.ualong	.LASF15
	.byte	0x3
	.byte	0x16
	.ualong	0x2f2
	.byte	0x2
	.byte	0x23
	.uleb128 0x2
	.uleb128 0x7
	.ualong	.LASF16
	.byte	0x3
	.byte	0x17
	.ualong	0x2f2
	.byte	0x2
	.byte	0x23
	.uleb128 0x3
	.uleb128 0x7
	.ualong	.LASF17
	.byte	0x3
	.byte	0x18
	.ualong	0x2f9
	.byte	0x2
	.byte	0x23
	.uleb128 0x4
	.uleb128 0x7
	.ualong	.LASF18
	.byte	0x3
	.byte	0x19
	.ualong	0x2f2
	.byte	0x2
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x7
	.ualong	.LASF19
	.byte	0x3
	.byte	0x1a
	.ualong	0x2f2
	.byte	0x2
	.byte	0x23
	.uleb128 0x9
	.uleb128 0x7
	.ualong	.LASF20
	.byte	0x3
	.byte	0x1b
	.ualong	0x2f2
	.byte	0x2
	.byte	0x23
	.uleb128 0xa
	.uleb128 0x7
	.ualong	.LASF21
	.byte	0x3
	.byte	0x1c
	.ualong	0x2f2
	.byte	0x2
	.byte	0x23
	.uleb128 0xb
	.uleb128 0x7
	.ualong	.LASF22
	.byte	0x3
	.byte	0x40
	.ualong	0x2f2
	.byte	0x2
	.byte	0x23
	.uleb128 0xc
	.uleb128 0x7
	.ualong	.LASF23
	.byte	0x3
	.byte	0x41
	.ualong	0x2f2
	.byte	0x2
	.byte	0x23
	.uleb128 0xd
	.uleb128 0x7
	.ualong	.LASF24
	.byte	0x3
	.byte	0x42
	.ualong	0x2f2
	.byte	0x2
	.byte	0x23
	.uleb128 0xe
	.uleb128 0x7
	.ualong	.LASF25
	.byte	0x3
	.byte	0x43
	.ualong	0x2f2
	.byte	0x2
	.byte	0x23
	.uleb128 0xf
	.uleb128 0x7
	.ualong	.LASF26
	.byte	0x3
	.byte	0x44
	.ualong	0x6a
	.byte	0x2
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x7
	.ualong	.LASF27
	.byte	0x3
	.byte	0x45
	.ualong	0x6a
	.byte	0x2
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x7
	.ualong	.LASF28
	.byte	0x3
	.byte	0x46
	.ualong	0x6a
	.byte	0x2
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x7
	.ualong	.LASF29
	.byte	0x3
	.byte	0x47
	.ualong	0x6a
	.byte	0x2
	.byte	0x23
	.uleb128 0x1c
	.uleb128 0x7
	.ualong	.LASF30
	.byte	0x3
	.byte	0x48
	.ualong	0x6a
	.byte	0x2
	.byte	0x23
	.uleb128 0x20
	.uleb128 0x7
	.ualong	.LASF31
	.byte	0x3
	.byte	0x49
	.ualong	0x6a
	.byte	0x2
	.byte	0x23
	.uleb128 0x24
	.uleb128 0x7
	.ualong	.LASF32
	.byte	0x3
	.byte	0x4a
	.ualong	0x6a
	.byte	0x2
	.byte	0x23
	.uleb128 0x28
	.uleb128 0x7
	.ualong	.LASF33
	.byte	0x3
	.byte	0x50
	.ualong	0x2f2
	.byte	0x2
	.byte	0x23
	.uleb128 0x2c
	.uleb128 0x7
	.ualong	.LASF34
	.byte	0x3
	.byte	0x51
	.ualong	0x2f2
	.byte	0x2
	.byte	0x23
	.uleb128 0x2d
	.uleb128 0x7
	.ualong	.LASF35
	.byte	0x3
	.byte	0x52
	.ualong	0x2f2
	.byte	0x2
	.byte	0x23
	.uleb128 0x2e
	.uleb128 0x7
	.ualong	.LASF36
	.byte	0x3
	.byte	0x53
	.ualong	0x2f2
	.byte	0x2
	.byte	0x23
	.uleb128 0x2f
	.uleb128 0x7
	.ualong	.LASF37
	.byte	0x3
	.byte	0x54
	.ualong	0x2f2
	.byte	0x2
	.byte	0x23
	.uleb128 0x30
	.uleb128 0x7
	.ualong	.LASF38
	.byte	0x3
	.byte	0x55
	.ualong	0x2f2
	.byte	0x2
	.byte	0x23
	.uleb128 0x31
	.uleb128 0x7
	.ualong	.LASF39
	.byte	0x3
	.byte	0x56
	.ualong	0x2f2
	.byte	0x2
	.byte	0x23
	.uleb128 0x32
	.uleb128 0x7
	.ualong	.LASF40
	.byte	0x3
	.byte	0x57
	.ualong	0x86
	.byte	0x2
	.byte	0x23
	.uleb128 0x33
	.uleb128 0x7
	.ualong	.LASF41
	.byte	0x3
	.byte	0x58
	.ualong	0x6a
	.byte	0x2
	.byte	0x23
	.uleb128 0x34
	.uleb128 0x7
	.ualong	.LASF42
	.byte	0x3
	.byte	0x59
	.ualong	0x6a
	.byte	0x2
	.byte	0x23
	.uleb128 0x38
	.uleb128 0x7
	.ualong	.LASF43
	.byte	0x3
	.byte	0x5a
	.ualong	0x6a
	.byte	0x2
	.byte	0x23
	.uleb128 0x3c
	.uleb128 0x7
	.ualong	.LASF44
	.byte	0x3
	.byte	0x5b
	.ualong	0x6a
	.byte	0x2
	.byte	0x23
	.uleb128 0x40
	.uleb128 0x7
	.ualong	.LASF45
	.byte	0x3
	.byte	0x5c
	.ualong	0x6a
	.byte	0x2
	.byte	0x23
	.uleb128 0x44
	.uleb128 0x7
	.ualong	.LASF46
	.byte	0x3
	.byte	0x5d
	.ualong	0x6a
	.byte	0x2
	.byte	0x23
	.uleb128 0x48
	.uleb128 0x7
	.ualong	.LASF47
	.byte	0x3
	.byte	0x5e
	.ualong	0x6a
	.byte	0x2
	.byte	0x23
	.uleb128 0x4c
	.uleb128 0x7
	.ualong	.LASF48
	.byte	0x3
	.byte	0x5f
	.ualong	0x6a
	.byte	0x2
	.byte	0x23
	.uleb128 0x50
	.uleb128 0x7
	.ualong	.LASF49
	.byte	0x3
	.byte	0x60
	.ualong	0x6a
	.byte	0x2
	.byte	0x23
	.uleb128 0x54
	.uleb128 0x7
	.ualong	.LASF50
	.byte	0x3
	.byte	0x61
	.ualong	0x6a
	.byte	0x2
	.byte	0x23
	.uleb128 0x58
	.uleb128 0x7
	.ualong	.LASF51
	.byte	0x3
	.byte	0x62
	.ualong	0x6a
	.byte	0x2
	.byte	0x23
	.uleb128 0x5c
	.uleb128 0x7
	.ualong	.LASF52
	.byte	0x3
	.byte	0x63
	.ualong	0x6a
	.byte	0x2
	.byte	0x23
	.uleb128 0x60
	.uleb128 0x7
	.ualong	.LASF53
	.byte	0x3
	.byte	0x64
	.ualong	0x6a
	.byte	0x2
	.byte	0x23
	.uleb128 0x64
	.uleb128 0x8
	.ualong	.LASF54
	.byte	0x3
	.uaword	0x110
	.ualong	0x78
	.byte	0x2
	.byte	0x23
	.uleb128 0x68
	.uleb128 0x8
	.ualong	.LASF55
	.byte	0x3
	.uaword	0x111
	.ualong	0x86
	.byte	0x2
	.byte	0x23
	.uleb128 0x6c
	.byte	0
	.uleb128 0x4
	.byte	0x1
	.byte	0x8
	.ualong	.LASF56
	.uleb128 0x4
	.byte	0x4
	.byte	0x7
	.ualong	.LASF57
	.uleb128 0x9
	.ualong	.LASF81
	.byte	0x3
	.uaword	0x115
	.ualong	0x8d
	.uleb128 0xa
	.byte	0x1
	.ualong	.LASF58
	.byte	0x1
	.byte	0x13
	.ualong	.LFB0
	.ualong	.LFE0
	.ualong	.LLST0
	.byte	0x1
	.byte	0x40
	.uleb128 0xa
	.byte	0x1
	.ualong	.LASF59
	.byte	0x1
	.byte	0x2b
	.ualong	.LFB1
	.ualong	.LFE1
	.ualong	.LLST1
	.byte	0x1
	.byte	0x40
	.uleb128 0xa
	.byte	0x1
	.ualong	.LASF60
	.byte	0x1
	.byte	0x31
	.ualong	.LFB2
	.ualong	.LFE2
	.ualong	.LLST2
	.byte	0x1
	.byte	0x40
	.uleb128 0xb
	.byte	0x1
	.ualong	.LASF82
	.byte	0x1
	.byte	0x39
	.byte	0x1
	.ualong	.LFB3
	.ualong	.LFE3
	.ualong	.LLST3
	.byte	0x1
	.byte	0x40
	.ualong	0x3a2
	.uleb128 0xc
	.ualong	.LASF61
	.byte	0x1
	.byte	0x39
	.ualong	0x3a2
	.byte	0x2
	.byte	0x91
	.sleb128 -16
	.uleb128 0xd
	.string	"end"
	.byte	0x1
	.byte	0x39
	.ualong	0x3a2
	.byte	0x2
	.byte	0x91
	.sleb128 -20
	.uleb128 0xe
	.ualong	.LASF62
	.byte	0x1
	.byte	0x3b
	.ualong	0x3a2
	.byte	0x2
	.byte	0x91
	.sleb128 -12
	.uleb128 0xe
	.ualong	.LASF63
	.byte	0x1
	.byte	0x3c
	.ualong	0x3a2
	.byte	0x2
	.byte	0x91
	.sleb128 -8
	.byte	0
	.uleb128 0xf
	.byte	0x4
	.ualong	0x78
	.uleb128 0xa
	.byte	0x1
	.ualong	.LASF64
	.byte	0x1
	.byte	0x44
	.ualong	.LFB4
	.ualong	.LFE4
	.ualong	.LLST4
	.byte	0x1
	.byte	0x40
	.uleb128 0x10
	.ualong	.LASF65
	.byte	0x4
	.byte	0xda
	.ualong	0x2f2
	.byte	0x1
	.byte	0x1
	.uleb128 0x11
	.ualong	.LASF66
	.byte	0x4
	.uaword	0x105
	.ualong	0x2f2
	.byte	0x1
	.byte	0x1
	.uleb128 0x11
	.ualong	.LASF67
	.byte	0x4
	.uaword	0x106
	.ualong	0x2f2
	.byte	0x1
	.byte	0x1
	.uleb128 0x11
	.ualong	.LASF68
	.byte	0x4
	.uaword	0x107
	.ualong	0x6a
	.byte	0x1
	.byte	0x1
	.uleb128 0x11
	.ualong	.LASF69
	.byte	0x4
	.uaword	0x108
	.ualong	0x6a
	.byte	0x1
	.byte	0x1
	.uleb128 0x11
	.ualong	.LASF70
	.byte	0x4
	.uaword	0x109
	.ualong	0x6a
	.byte	0x1
	.byte	0x1
	.uleb128 0x11
	.ualong	.LASF71
	.byte	0x4
	.uaword	0x10a
	.ualong	0x6a
	.byte	0x1
	.byte	0x1
	.uleb128 0x11
	.ualong	.LASF72
	.byte	0x4
	.uaword	0x10b
	.ualong	0x6a
	.byte	0x1
	.byte	0x1
	.uleb128 0x11
	.ualong	.LASF73
	.byte	0x4
	.uaword	0x10c
	.ualong	0x6a
	.byte	0x1
	.byte	0x1
	.uleb128 0x11
	.ualong	.LASF74
	.byte	0x4
	.uaword	0x10d
	.ualong	0x6a
	.byte	0x1
	.byte	0x1
	.uleb128 0x11
	.ualong	.LASF75
	.byte	0x4
	.uaword	0x10e
	.ualong	0x6a
	.byte	0x1
	.byte	0x1
	.uleb128 0x11
	.ualong	.LASF76
	.byte	0x4
	.uaword	0x10f
	.ualong	0x6a
	.byte	0x1
	.byte	0x1
	.uleb128 0x11
	.ualong	.LASF77
	.byte	0x4
	.uaword	0x110
	.ualong	0x6a
	.byte	0x1
	.byte	0x1
	.uleb128 0x12
	.ualong	0x47a
	.uleb128 0x13
	.byte	0
	.uleb128 0x14
	.ualong	.LASF78
	.byte	0x1
	.byte	0x11
	.ualong	0x48c
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_MemoryResetHooked
	.uleb128 0xf
	.byte	0x4
	.ualong	0x473
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x55
	.uleb128 0x6
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x52
	.uleb128 0x1
	.uleb128 0x10
	.uleb128 0x6
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x4
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x28
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x1c
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x8
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x16
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.uleb128 0x40
	.uleb128 0x6
	.uleb128 0x2116
	.uleb128 0xc
	.uleb128 0x36
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x27
	.uleb128 0xc
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.uleb128 0x40
	.uleb128 0x6
	.uleb128 0x2117
	.uleb128 0xc
	.uleb128 0x36
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3c
	.uleb128 0xc
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3c
	.uleb128 0xc
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0x15
	.byte	0x1
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0x18
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x14
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_loc,"",@progbits
.Ldebug_loc0:
.LLST0:
	.ualong	.LFB0
	.ualong	.LCFI0
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI0
	.ualong	.LCFI1
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI1
	.ualong	.LCFI2
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI2
	.ualong	.LFE0
	.uaword	0x2
	.byte	0x7e
	.sleb128 8
	.ualong	0
	.ualong	0
.LLST1:
	.ualong	.LFB1
	.ualong	.LCFI3
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI3
	.ualong	.LCFI4
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI4
	.ualong	.LCFI5
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI5
	.ualong	.LFE1
	.uaword	0x2
	.byte	0x7e
	.sleb128 8
	.ualong	0
	.ualong	0
.LLST2:
	.ualong	.LFB2
	.ualong	.LCFI6
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI6
	.ualong	.LCFI7
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI7
	.ualong	.LCFI8
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI8
	.ualong	.LFE2
	.uaword	0x2
	.byte	0x7e
	.sleb128 8
	.ualong	0
	.ualong	0
.LLST3:
	.ualong	.LFB3
	.ualong	.LCFI9
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI9
	.ualong	.LCFI10
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI10
	.ualong	.LCFI11
	.uaword	0x2
	.byte	0x7f
	.sleb128 20
	.ualong	.LCFI11
	.ualong	.LFE3
	.uaword	0x2
	.byte	0x7e
	.sleb128 20
	.ualong	0
	.ualong	0
.LLST4:
	.ualong	.LFB4
	.ualong	.LCFI12
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI12
	.ualong	.LCFI13
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI13
	.ualong	.LCFI14
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI14
	.ualong	.LFE4
	.uaword	0x2
	.byte	0x7e
	.sleb128 8
	.ualong	0
	.ualong	0
	.section	.debug_aranges,"",@progbits
	.ualong	0x3c
	.uaword	0x2
	.ualong	.Ldebug_info0
	.byte	0x4
	.byte	0
	.uaword	0
	.uaword	0
	.ualong	.LFB0
	.ualong	.LFE0-.LFB0
	.ualong	.LFB1
	.ualong	.LFE1-.LFB1
	.ualong	.LFB2
	.ualong	.LFE2-.LFB2
	.ualong	.LFB3
	.ualong	.LFE3-.LFB3
	.ualong	.LFB4
	.ualong	.LFE4-.LFB4
	.ualong	0
	.ualong	0
	.section	.debug_ranges,"",@progbits
.Ldebug_ranges0:
	.ualong	.LFB0
	.ualong	.LFE0
	.ualong	.LFB1
	.ualong	.LFE1
	.ualong	.LFB2
	.ualong	.LFE2
	.ualong	.LFB3
	.ualong	.LFE3
	.ualong	.LFB4
	.ualong	.LFE4
	.ualong	0
	.ualong	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF59:
	.string	"ResetRamVariables"
.LASF35:
	.string	"FlatFootShiftMode"
.LASF0:
	.string	"RevLimModeUndefined"
.LASF46:
	.string	"LaunchControlCut"
.LASF49:
	.string	"FlatFootShiftRpmThreshold"
.LASF1:
	.string	"RevLimModeFuelCut"
.LASF5:
	.string	"HardResetFlagValues"
.LASF25:
	.string	"sdempty1"
.LASF8:
	.string	"short int"
.LASF31:
	.string	"SDMafBlendRatio"
.LASF23:
	.string	"MafMode"
.LASF11:
	.string	"sizetype"
.LASF13:
	.string	"RamVariableStart"
.LASF17:
	.string	"ECUIdentifier"
.LASF22:
	.string	"SDInitFlag"
.LASF47:
	.string	"LaunchControlHyst"
.LASF77:
	.string	"DefaultFlatFootShiftRpmThreshold"
.LASF15:
	.string	"CruiseCoastLast"
.LASF67:
	.string	"DefaultFlatFootShiftMode"
.LASF53:
	.string	"FlatFootShiftSpeedThreshold"
.LASF32:
	.string	"SDMafFromBlend"
.LASF41:
	.string	"RevLimCut"
.LASF4:
	.string	"RevLimModeValues"
.LASF28:
	.string	"MafFromSensor"
.LASF9:
	.string	"float"
.LASF26:
	.string	"VolumetricEfficiency"
.LASF10:
	.string	"long int"
.LASF64:
	.string	"PopulateRamVariables"
.LASF80:
	.string	"C:\\Dev\\MerpMod\\MerpMod\\Initializer.c"
.LASF81:
	.string	"RamVariables"
.LASF63:
	.string	"pointy"
.LASF2:
	.string	"RevLimModeSparkCut"
.LASF65:
	.string	"DefaultMafMode"
.LASF73:
	.string	"DefaultFlatFootShiftAutoDelta"
.LASF76:
	.string	"DefaultFlatFootShiftSpeedThreshold"
.LASF44:
	.string	"RedLineHyst"
.LASF14:
	.string	"VinAuth"
.LASF56:
	.string	"unsigned char"
.LASF60:
	.string	"InitRamVariables"
.LASF78:
	.string	"MemoryResetHooked"
.LASF50:
	.string	"FlatFootShiftAutoDelta"
.LASF33:
	.string	"RevLimInitFlag"
.LASF79:
	.string	"GNU C 4.7-GNUSH_v13.01"
.LASF57:
	.string	"long unsigned int"
.LASF48:
	.string	"FFSRPM"
.LASF6:
	.string	"HardResetFlagDisabled"
.LASF55:
	.string	"RamHoleEndMarker"
.LASF70:
	.string	"DefaultLaunchControlSpeedMax"
.LASF61:
	.string	"start"
.LASF52:
	.string	"FlatFootShiftHyst"
.LASF12:
	.string	"char"
.LASF30:
	.string	"DeltaMapCompensation"
.LASF27:
	.string	"MafFromSpeedDensity"
.LASF19:
	.string	"blank0"
.LASF20:
	.string	"blank1"
.LASF21:
	.string	"blank2"
.LASF39:
	.string	"FFSGear"
.LASF3:
	.string	"RevLimModeComboCut"
.LASF7:
	.string	"HardResetFlagEnabled"
.LASF16:
	.string	"CruiseResumeLast"
.LASF24:
	.string	"SDempty"
.LASF36:
	.string	"LCEngaged"
.LASF62:
	.string	"pend"
.LASF74:
	.string	"DefaultFlatFootShiftStaticDelta"
.LASF37:
	.string	"FFSEngaged"
.LASF58:
	.string	"Initializer"
.LASF34:
	.string	"RevLimMode"
.LASF42:
	.string	"RevLimResume"
.LASF69:
	.string	"DefaultRedLineHyst"
.LASF18:
	.string	"HardResetFlag"
.LASF51:
	.string	"FlatFootShiftStaticDelta"
.LASF29:
	.string	"AtmosphericCompensation"
.LASF75:
	.string	"DefaultFlatFootShiftHyst"
.LASF43:
	.string	"RedLineCut"
.LASF66:
	.string	"DefaultRevLimMode"
.LASF54:
	.string	"RamHoleSpace"
.LASF40:
	.string	"eleemee2"
.LASF68:
	.string	"DefaultRedLineCut"
.LASF71:
	.string	"DefaultLaunchControlCut"
.LASF72:
	.string	"DefaultLaunchControlHyst"
.LASF82:
	.string	"ClearRamVariables"
.LASF38:
	.string	"ClutchSwitchLast"
.LASF45:
	.string	"LaunchControlSpeedMax"
	.ident	"GCC: (GNU) 4.7-GNUSH_v13.01"
