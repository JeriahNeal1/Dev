	.file	"Definition.c"
	.text
	.text
.Ltext0:
	.cfi_sections	.debug_frame
	.global	_dEcuId_1DDef
	.section	DefinitionData,"a",@progbits
	.align 2
	.type	_dEcuId_1DDef, @object
	.size	_dEcuId_1DDef, 8
_dEcuId_1DDef:
	.long	1126236162
	.long	850828
	.string	"ECU Identifier"
	.global	_dLoadSmoothingA_1DDef
	.align 2
	.type	_dLoadSmoothingA_1DDef, @object
	.size	_dLoadSmoothingA_1DDef, 8
_dLoadSmoothingA_1DDef:
	.long	1126236162
	.long	795576
	.string	"Engine Load Smoothing Factor A"
	.global	_dLoadSmoothingB_1DDef
	.align 2
	.type	_dLoadSmoothingB_1DDef, @object
	.size	_dLoadSmoothingB_1DDef, 8
_dLoadSmoothingB_1DDef:
	.long	1126236162
	.long	795580
	.string	"Engine Load Smoothing Factor B"
	.global	_dLoadSmoothingFinal_1DDef
	.align 2
	.type	_dLoadSmoothingFinal_1DDef, @object
	.size	_dLoadSmoothingFinal_1DDef, 8
_dLoadSmoothingFinal_1DDef:
	.long	1126236162
	.long	795592
	.string	"Engine Load Smoothing Factor Final"
	.global	_pClutchFlags_ParamBitDef
	.align 2
	.type	_pClutchFlags_ParamBitDef, @object
	.size	_pClutchFlags_ParamBitDef, 24
_pClutchFlags_ParamBitDef:
	.long	1126236176
	.long	-38415
	.string	"E"
	.zero	6
	.long	589833
	.long	128
	.string	"MerpMod Clutch Switch"
	.global	_pBrakeFlags_ParamBitDef
	.align 2
	.type	_pBrakeFlags_ParamBitDef, @object
	.size	_pBrakeFlags_ParamBitDef, 24
_pBrakeFlags_ParamBitDef:
	.long	1126236176
	.long	-39760
	.string	"E"
	.zero	6
	.long	589833
	.long	128
	.string	"MerpMod Brake Switch"
	.global	_pResumeFlags_ParamBitDef
	.align 2
	.type	_pResumeFlags_ParamBitDef, @object
	.size	_pResumeFlags_ParamBitDef, 24
_pResumeFlags_ParamBitDef:
	.long	1126236176
	.long	-39760
	.string	"E"
	.zero	6
	.long	589833
	.long	4
	.string	"MerpMod Cruise Resume Switch"
	.global	_pCoastFlags_ParamBitDef
	.align 2
	.type	_pCoastFlags_ParamBitDef, @object
	.size	_pCoastFlags_ParamBitDef, 24
_pCoastFlags_ParamBitDef:
	.long	1126236176
	.long	-39760
	.string	"E"
	.zero	6
	.long	589833
	.long	2
	.string	"MerpMod Cruise Coast Switch"
	.global	_pFlagsRevLim_ParamBitDef
	.align 2
	.type	_pFlagsRevLim_ParamBitDef, @object
	.size	_pFlagsRevLim_ParamBitDef, 24
_pFlagsRevLim_ParamBitDef:
	.long	1126236176
	.long	-35604
	.string	"E"
	.zero	6
	.long	589833
	.long	128
	.string	"MerpMod Rev Limit Fuel Cut Switch"
	.global	_MafMode_ParamDef
	.align 2
	.type	_MafMode_ParamDef, @object
	.size	_MafMode_ParamDef, 32
_MafMode_ParamDef:
	.long	1126236168
	.long	-26931
	.string	"E"
	.zero	6
	.long	589833
	.string	"uint8"
	.zero	2
	.long	589833
	.string	"MerpMod SD Mode Switch"
	.global	_VolumetricEfficiency_ParamDef
	.align 2
	.type	_VolumetricEfficiency_ParamDef, @object
	.size	_VolumetricEfficiency_ParamDef, 32
_VolumetricEfficiency_ParamDef:
	.long	1126236168
	.long	-26928
	.string	"E"
	.zero	6
	.long	589833
	.string	"float"
	.zero	2
	.long	589833
	.string	"MerpMod SD Volumetric Efficiency"
	.global	_MafFromSpeedDensity_ParamDef
	.align 2
	.type	_MafFromSpeedDensity_ParamDef, @object
	.size	_MafFromSpeedDensity_ParamDef, 32
_MafFromSpeedDensity_ParamDef:
	.long	1126236168
	.long	-26924
	.string	"E"
	.zero	6
	.long	589833
	.string	"float"
	.zero	2
	.long	589833
	.string	"MerpMod SD Airflow Final Output"
	.global	_MafFromSensor_ParamDef
	.align 2
	.type	_MafFromSensor_ParamDef, @object
	.size	_MafFromSensor_ParamDef, 32
_MafFromSensor_ParamDef:
	.long	1126236168
	.long	-26920
	.string	"E"
	.zero	6
	.long	589833
	.string	"float"
	.zero	2
	.long	589833
	.string	"MerpMod SD Airflow Maf Sensor"
	.global	_AtmosphericCompensation_ParamDef
	.align 2
	.type	_AtmosphericCompensation_ParamDef, @object
	.size	_AtmosphericCompensation_ParamDef, 32
_AtmosphericCompensation_ParamDef:
	.long	1126236168
	.long	-26916
	.string	"E"
	.zero	6
	.long	589833
	.string	"float"
	.zero	2
	.long	589833
	.string	"MerpMod SD Atmospheric Compensation"
	.global	_SDMafBlendRatio_ParamDef
	.align 2
	.type	_SDMafBlendRatio_ParamDef, @object
	.size	_SDMafBlendRatio_ParamDef, 32
_SDMafBlendRatio_ParamDef:
	.long	1126236168
	.long	-26908
	.string	"E"
	.zero	6
	.long	589833
	.string	"float"
	.zero	2
	.long	589833
	.string	"MerpMod SD Blending Ratio"
	.global	_SDMafFromBlend_ParamDef
	.align 2
	.type	_SDMafFromBlend_ParamDef, @object
	.size	_SDMafFromBlend_ParamDef, 32
_SDMafFromBlend_ParamDef:
	.long	1126236168
	.long	-26904
	.string	"E"
	.zero	6
	.long	589833
	.string	"float"
	.zero	2
	.long	589833
	.string	"MerpMod SD Airflow Blending"
	.global	_VolumetricEfficiencyTable1_3DDef
	.align 2
	.type	_VolumetricEfficiencyTable1_3DDef, @object
	.size	_VolumetricEfficiencyTable1_3DDef, 8
_VolumetricEfficiencyTable1_3DDef:
	.long	1126236164
	.long	_VolumetricEfficiencyTable1
	.string	"Volumetric Efficiency Table 1"
	.global	_AtmosphericCompensationTable_3DDef
	.align 2
	.type	_AtmosphericCompensationTable_3DDef, @object
	.size	_AtmosphericCompensationTable_3DDef, 8
_AtmosphericCompensationTable_3DDef:
	.long	1126236164
	.long	_AtmosphericCompensationTable
	.string	"Atmospheric Pressure Compensation"
	.global	_SDBlendingTable_3DDef
	.align 2
	.type	_SDBlendingTable_3DDef, @object
	.size	_SDBlendingTable_3DDef, 8
_SDBlendingTable_3DDef:
	.long	1126236164
	.long	_SDBlendingTable
	.string	"SD Blending Table"
	.global	_Displacement_1DDef
	.align 2
	.type	_Displacement_1DDef, @object
	.size	_Displacement_1DDef, 8
_Displacement_1DDef:
	.long	1126236162
	.long	_Displacement
	.string	"Engine Displacement"
	.global	_DefaultMafMode_1DDef
	.align 2
	.type	_DefaultMafMode_1DDef, @object
	.size	_DefaultMafMode_1DDef, 8
_DefaultMafMode_1DDef:
	.long	1126236162
	.long	_DefaultMafMode
	.string	"Speed Density Mode"
	.global	_SpeedDensityConstant_1DDef
	.align 2
	.type	_SpeedDensityConstant_1DDef, @object
	.size	_SpeedDensityConstant_1DDef, 8
_SpeedDensityConstant_1DDef:
	.long	1126236162
	.long	_SpeedDensityConstant
	.string	"Speed Density Constant"
	.global	_DefaultRedLineCut_1DDef
	.align 2
	.type	_DefaultRedLineCut_1DDef, @object
	.size	_DefaultRedLineCut_1DDef, 8
_DefaultRedLineCut_1DDef:
	.long	1126236162
	.long	_DefaultRedLineCut
	.string	"Rev Limit (Redline)"
	.global	_DefaultFlatFootShiftMode_1DDef
	.align 2
	.type	_DefaultFlatFootShiftMode_1DDef, @object
	.size	_DefaultFlatFootShiftMode_1DDef, 8
_DefaultFlatFootShiftMode_1DDef:
	.long	1126236162
	.long	_DefaultFlatFootShiftMode
	.string	"Flat Foot Shift Mode"
	.global	_DefaultFlatFootShiftAutoDelta_1DDef
	.align 2
	.type	_DefaultFlatFootShiftAutoDelta_1DDef, @object
	.size	_DefaultFlatFootShiftAutoDelta_1DDef, 8
_DefaultFlatFootShiftAutoDelta_1DDef:
	.long	1126236162
	.long	_DefaultFlatFootShiftAutoDelta
	.string	"Flat Foot Shift Delta (Automatic Limit)"
	.global	_DefaultFlatFootShiftStaticDelta_1DDef
	.align 2
	.type	_DefaultFlatFootShiftStaticDelta_1DDef, @object
	.size	_DefaultFlatFootShiftStaticDelta_1DDef, 8
_DefaultFlatFootShiftStaticDelta_1DDef:
	.long	1126236162
	.long	_DefaultFlatFootShiftStaticDelta
	.string	"Flat Foot Shift Delta (Static Limit)"
	.global	_DefaultFlatFootShiftSpeedThreshold_1DDef
	.align 2
	.type	_DefaultFlatFootShiftSpeedThreshold_1DDef, @object
	.size	_DefaultFlatFootShiftSpeedThreshold_1DDef, 8
_DefaultFlatFootShiftSpeedThreshold_1DDef:
	.long	1126236162
	.long	_DefaultFlatFootShiftSpeedThreshold
	.string	"Flat Foot Shift Minimum Speed Threshold"
	.global	_DefaultFlatFootShiftRpmThreshold_1DDef
	.align 2
	.type	_DefaultFlatFootShiftRpmThreshold_1DDef, @object
	.size	_DefaultFlatFootShiftRpmThreshold_1DDef, 8
_DefaultFlatFootShiftRpmThreshold_1DDef:
	.long	1126236162
	.long	_DefaultFlatFootShiftRpmThreshold
	.string	"Flat Foot Shift Minimum RPM Threshold"
	.global	_DefaultLaunchControlSpeedMax_1DDef
	.align 2
	.type	_DefaultLaunchControlSpeedMax_1DDef, @object
	.size	_DefaultLaunchControlSpeedMax_1DDef, 8
_DefaultLaunchControlSpeedMax_1DDef:
	.long	1126236162
	.long	_DefaultLaunchControlSpeedMax
	.string	"LC Maximum Speed Threshold"
	.global	_LCMinimumThrottle_1DDef
	.align 2
	.type	_LCMinimumThrottle_1DDef, @object
	.size	_LCMinimumThrottle_1DDef, 8
_LCMinimumThrottle_1DDef:
	.long	1126236162
	.long	_LCMinimumThrottle
	.string	"LC Minimum Throttle Threshold"
	.global	_FFSMinimumThrottle_1DDef
	.align 2
	.type	_FFSMinimumThrottle_1DDef, @object
	.size	_FFSMinimumThrottle_1DDef, 8
_FFSMinimumThrottle_1DDef:
	.long	1126236162
	.long	_FFSMinimumThrottle
	.string	"FFS Minimum Throttle Threshold"
	.global	_GearRatios_1DDef
	.align 2
	.type	_GearRatios_1DDef, @object
	.size	_GearRatios_1DDef, 8
_GearRatios_1DDef:
	.long	1126236162
	.long	_GearRatios
	.string	"FFS Gear Ratios"
	.global	_DefaultLaunchControlCut_1DDef
	.align 2
	.type	_DefaultLaunchControlCut_1DDef, @object
	.size	_DefaultLaunchControlCut_1DDef, 8
_DefaultLaunchControlCut_1DDef:
	.long	1126236162
	.long	_DefaultLaunchControlCut
	.string	"Rev Limit (Launch Control)"
	.global	_FlatFootShiftMode_ParamDef
	.align 2
	.type	_FlatFootShiftMode_ParamDef, @object
	.size	_FlatFootShiftMode_ParamDef, 32
_FlatFootShiftMode_ParamDef:
	.long	1126236168
	.long	-26898
	.string	"E"
	.zero	6
	.long	589833
	.string	"uint8"
	.zero	2
	.long	589833
	.string	"MerpMod FFS Mode"
	.global	_LCEngaged_ParamDef
	.align 2
	.type	_LCEngaged_ParamDef, @object
	.size	_LCEngaged_ParamDef, 32
_LCEngaged_ParamDef:
	.long	1126236168
	.long	-26897
	.string	"E"
	.zero	6
	.long	589833
	.string	"uint8"
	.zero	2
	.long	589833
	.string	"MerpMod LC Engaged Signal"
	.global	_FFSEngaged_ParamDef
	.align 2
	.type	_FFSEngaged_ParamDef, @object
	.size	_FFSEngaged_ParamDef, 32
_FFSEngaged_ParamDef:
	.long	1126236168
	.long	-26896
	.string	"E"
	.zero	6
	.long	589833
	.string	"uint8"
	.zero	2
	.long	589833
	.string	"MerpMod FFS Engaged Signal"
	.global	_FFSGear_ParamDef
	.align 2
	.type	_FFSGear_ParamDef, @object
	.size	_FFSGear_ParamDef, 32
_FFSGear_ParamDef:
	.long	1126236168
	.long	-26894
	.string	"E"
	.zero	6
	.long	589833
	.string	"uint8"
	.zero	2
	.long	589833
	.string	"MerpMod FFS Gear Monitor 1-Byte"
	.global	_RevLimCut_ParamDef
	.align 2
	.type	_RevLimCut_ParamDef, @object
	.size	_RevLimCut_ParamDef, 32
_RevLimCut_ParamDef:
	.long	1126236168
	.long	-26892
	.string	"E"
	.zero	6
	.long	589833
	.string	"float"
	.zero	2
	.long	589833
	.string	"MerpMod RevLimit Active Cut RPM"
	.global	_RevLimResume_ParamDef
	.align 2
	.type	_RevLimResume_ParamDef, @object
	.size	_RevLimResume_ParamDef, 32
_RevLimResume_ParamDef:
	.long	1126236168
	.long	-26888
	.string	"E"
	.zero	6
	.long	589833
	.string	"float"
	.zero	2
	.long	589833
	.string	"MerpMod RevLimit Active Resume RPM"
	.global	_RedLineCut_ParamDef
	.align 2
	.type	_RedLineCut_ParamDef, @object
	.size	_RedLineCut_ParamDef, 32
_RedLineCut_ParamDef:
	.long	1126236168
	.long	-26884
	.string	"E"
	.zero	6
	.long	589833
	.string	"float"
	.zero	2
	.long	589833
	.string	"MerpMod RedLine Cut RPM"
	.global	_RedLineHyst_ParamDef
	.align 2
	.type	_RedLineHyst_ParamDef, @object
	.size	_RedLineHyst_ParamDef, 32
_RedLineHyst_ParamDef:
	.long	1126236168
	.long	-26880
	.string	"E"
	.zero	6
	.long	589833
	.string	"float"
	.zero	2
	.long	589833
	.string	"MerpMod RedLine Hysteresis"
	.global	_LaunchControlCut_ParamDef
	.align 2
	.type	_LaunchControlCut_ParamDef, @object
	.size	_LaunchControlCut_ParamDef, 32
_LaunchControlCut_ParamDef:
	.long	1126236168
	.long	-26872
	.string	"E"
	.zero	6
	.long	589833
	.string	"float"
	.zero	2
	.long	589833
	.string	"MerpMod Launch Control RPM"
	.global	_LaunchControlHyst_ParamDef
	.align 2
	.type	_LaunchControlHyst_ParamDef, @object
	.size	_LaunchControlHyst_ParamDef, 32
_LaunchControlHyst_ParamDef:
	.long	1126236168
	.long	-26868
	.string	"E"
	.zero	6
	.long	589833
	.string	"float"
	.zero	2
	.long	589833
	.string	"MerpMod Launch Control Hysteresis"
	.global	_FlatFootShiftAutoDelta_ParamDef
	.align 2
	.type	_FlatFootShiftAutoDelta_ParamDef, @object
	.size	_FlatFootShiftAutoDelta_ParamDef, 32
_FlatFootShiftAutoDelta_ParamDef:
	.long	1126236168
	.long	-26856
	.string	"E"
	.zero	6
	.long	589833
	.string	"float"
	.zero	2
	.long	589833
	.string	"MerpMod FFS Delta (Auto)"
	.global	_FlatFootShiftStaticDelta_ParamDef
	.align 2
	.type	_FlatFootShiftStaticDelta_ParamDef, @object
	.size	_FlatFootShiftStaticDelta_ParamDef, 32
_FlatFootShiftStaticDelta_ParamDef:
	.long	1126236168
	.long	-26852
	.string	"E"
	.zero	6
	.long	589833
	.string	"float"
	.zero	2
	.long	589833
	.string	"MerpMod FFS Delta (Static)"
	.global	_FFSRPM_ParamDef
	.align 2
	.type	_FFSRPM_ParamDef, @object
	.size	_FFSRPM_ParamDef, 32
_FFSRPM_ParamDef:
	.long	1126236168
	.long	-26864
	.string	"E"
	.zero	6
	.long	589833
	.string	"float"
	.zero	2
	.long	589833
	.string	"MerpMod FFS Engagement RPM"
	.global	_FlatFootShiftSpeedThreshold_ParamDef
	.align 2
	.type	_FlatFootShiftSpeedThreshold_ParamDef, @object
	.size	_FlatFootShiftSpeedThreshold_ParamDef, 32
_FlatFootShiftSpeedThreshold_ParamDef:
	.long	1126236168
	.long	-26844
	.string	"E"
	.zero	6
	.long	589833
	.string	"float"
	.zero	2
	.long	589833
	.string	"MerpMod FFS Speed Threshold"
	.global	_LaunchControlSpeedMax_ParamDef
	.align 2
	.type	_LaunchControlSpeedMax_ParamDef, @object
	.size	_LaunchControlSpeedMax_ParamDef, 32
_LaunchControlSpeedMax_ParamDef:
	.long	1126236168
	.long	-26876
	.string	"E"
	.zero	6
	.long	589833
	.string	"float"
	.zero	2
	.long	589833
	.string	"MerpMod LC Speed Threshold"
	.global	_endofdeffile
	.section	DefinitionDataEnd,"a",@progbits
	.align 2
	.type	_endofdeffile, @object
	.size	_endofdeffile, 4
_endofdeffile:
	.long	589833
	.global	_endofdeffile1
	.align 2
	.type	_endofdeffile1, @object
	.size	_endofdeffile1, 4
_endofdeffile1:
	.long	589833
	.global	_endofdeffile2
	.align 2
	.type	_endofdeffile2, @object
	.size	_endofdeffile2, 4
_endofdeffile2:
	.long	589833
	.global	_endofdeffile3
	.align 2
	.type	_endofdeffile3, @object
	.size	_endofdeffile3, 4
_endofdeffile3:
	.long	589833
	.text
.Letext0:
	.file 1 "C:\\Dev\\MerpMod\\MerpMod\\enums.h"
	.file 2 "C:\\Dev\\MerpMod\\MerpMod\\RamVariables.h"
	.file 3 "C:\\Dev\\MerpMod\\MerpMod\\Definition.c"
	.file 4 "C:\\Dev\\MerpMod\\MerpMod\\Externs.h"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.ualong	0x9d9
	.uaword	0x2
	.ualong	.Ldebug_abbrev0
	.byte	0x4
	.uleb128 0x1
	.ualong	.LASF146
	.byte	0x1
	.ualong	.LASF147
	.ualong	.Ldebug_line0
	.uleb128 0x2
	.byte	0x1c
	.byte	0x1
	.byte	0x81
	.ualong	0x92
	.uleb128 0x3
	.ualong	.LASF0
	.byte	0x1
	.byte	0x83
	.ualong	0x92
	.byte	0x2
	.byte	0x23
	.uleb128 0
	.uleb128 0x3
	.ualong	.LASF1
	.byte	0x1
	.byte	0x84
	.ualong	0x92
	.byte	0x2
	.byte	0x23
	.uleb128 0x2
	.uleb128 0x3
	.ualong	.LASF2
	.byte	0x1
	.byte	0x85
	.ualong	0x99
	.byte	0x2
	.byte	0x23
	.uleb128 0x4
	.uleb128 0x3
	.ualong	.LASF3
	.byte	0x1
	.byte	0x86
	.ualong	0x99
	.byte	0x2
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x3
	.ualong	.LASF4
	.byte	0x1
	.byte	0x87
	.ualong	0xa6
	.byte	0x2
	.byte	0x23
	.uleb128 0xc
	.uleb128 0x3
	.ualong	.LASF5
	.byte	0x1
	.byte	0x88
	.ualong	0xa8
	.byte	0x2
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x3
	.ualong	.LASF6
	.byte	0x1
	.byte	0x89
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x3
	.ualong	.LASF7
	.byte	0x1
	.byte	0x8a
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x18
	.byte	0
	.uleb128 0x4
	.byte	0x2
	.byte	0x5
	.ualong	.LASF8
	.uleb128 0x5
	.byte	0x4
	.ualong	0x9f
	.uleb128 0x4
	.byte	0x4
	.byte	0x4
	.ualong	.LASF9
	.uleb128 0x6
	.byte	0x4
	.uleb128 0x7
	.byte	0x4
	.byte	0x5
	.string	"int"
	.uleb128 0x8
	.ualong	.LASF58
	.byte	0x1
	.byte	0x8b
	.ualong	0x19
	.uleb128 0x4
	.byte	0x4
	.byte	0x5
	.ualong	.LASF10
	.uleb128 0x4
	.byte	0x4
	.byte	0x7
	.ualong	.LASF11
	.uleb128 0x4
	.byte	0x1
	.byte	0x6
	.ualong	.LASF12
	.uleb128 0x2
	.byte	0x70
	.byte	0x2
	.byte	0x12
	.ualong	0x334
	.uleb128 0x3
	.ualong	.LASF13
	.byte	0x2
	.byte	0x14
	.ualong	0x334
	.byte	0x2
	.byte	0x23
	.uleb128 0
	.uleb128 0x3
	.ualong	.LASF14
	.byte	0x2
	.byte	0x15
	.ualong	0x334
	.byte	0x2
	.byte	0x23
	.uleb128 0x1
	.uleb128 0x3
	.ualong	.LASF15
	.byte	0x2
	.byte	0x16
	.ualong	0x334
	.byte	0x2
	.byte	0x23
	.uleb128 0x2
	.uleb128 0x3
	.ualong	.LASF16
	.byte	0x2
	.byte	0x17
	.ualong	0x334
	.byte	0x2
	.byte	0x23
	.uleb128 0x3
	.uleb128 0x3
	.ualong	.LASF17
	.byte	0x2
	.byte	0x18
	.ualong	0x33b
	.byte	0x2
	.byte	0x23
	.uleb128 0x4
	.uleb128 0x3
	.ualong	.LASF18
	.byte	0x2
	.byte	0x19
	.ualong	0x334
	.byte	0x2
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x3
	.ualong	.LASF19
	.byte	0x2
	.byte	0x1a
	.ualong	0x334
	.byte	0x2
	.byte	0x23
	.uleb128 0x9
	.uleb128 0x3
	.ualong	.LASF20
	.byte	0x2
	.byte	0x1b
	.ualong	0x334
	.byte	0x2
	.byte	0x23
	.uleb128 0xa
	.uleb128 0x3
	.ualong	.LASF21
	.byte	0x2
	.byte	0x1c
	.ualong	0x334
	.byte	0x2
	.byte	0x23
	.uleb128 0xb
	.uleb128 0x3
	.ualong	.LASF22
	.byte	0x2
	.byte	0x40
	.ualong	0x334
	.byte	0x2
	.byte	0x23
	.uleb128 0xc
	.uleb128 0x3
	.ualong	.LASF23
	.byte	0x2
	.byte	0x41
	.ualong	0x334
	.byte	0x2
	.byte	0x23
	.uleb128 0xd
	.uleb128 0x3
	.ualong	.LASF24
	.byte	0x2
	.byte	0x42
	.ualong	0x334
	.byte	0x2
	.byte	0x23
	.uleb128 0xe
	.uleb128 0x3
	.ualong	.LASF25
	.byte	0x2
	.byte	0x43
	.ualong	0x334
	.byte	0x2
	.byte	0x23
	.uleb128 0xf
	.uleb128 0x3
	.ualong	.LASF26
	.byte	0x2
	.byte	0x44
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x3
	.ualong	.LASF27
	.byte	0x2
	.byte	0x45
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x3
	.ualong	.LASF28
	.byte	0x2
	.byte	0x46
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x3
	.ualong	.LASF29
	.byte	0x2
	.byte	0x47
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x1c
	.uleb128 0x3
	.ualong	.LASF30
	.byte	0x2
	.byte	0x48
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x20
	.uleb128 0x3
	.ualong	.LASF31
	.byte	0x2
	.byte	0x49
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x24
	.uleb128 0x3
	.ualong	.LASF32
	.byte	0x2
	.byte	0x4a
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x28
	.uleb128 0x3
	.ualong	.LASF33
	.byte	0x2
	.byte	0x50
	.ualong	0x334
	.byte	0x2
	.byte	0x23
	.uleb128 0x2c
	.uleb128 0x3
	.ualong	.LASF34
	.byte	0x2
	.byte	0x51
	.ualong	0x334
	.byte	0x2
	.byte	0x23
	.uleb128 0x2d
	.uleb128 0x3
	.ualong	.LASF35
	.byte	0x2
	.byte	0x52
	.ualong	0x334
	.byte	0x2
	.byte	0x23
	.uleb128 0x2e
	.uleb128 0x3
	.ualong	.LASF36
	.byte	0x2
	.byte	0x53
	.ualong	0x334
	.byte	0x2
	.byte	0x23
	.uleb128 0x2f
	.uleb128 0x3
	.ualong	.LASF37
	.byte	0x2
	.byte	0x54
	.ualong	0x334
	.byte	0x2
	.byte	0x23
	.uleb128 0x30
	.uleb128 0x3
	.ualong	.LASF38
	.byte	0x2
	.byte	0x55
	.ualong	0x334
	.byte	0x2
	.byte	0x23
	.uleb128 0x31
	.uleb128 0x3
	.ualong	.LASF39
	.byte	0x2
	.byte	0x56
	.ualong	0x334
	.byte	0x2
	.byte	0x23
	.uleb128 0x32
	.uleb128 0x3
	.ualong	.LASF40
	.byte	0x2
	.byte	0x57
	.ualong	0xc8
	.byte	0x2
	.byte	0x23
	.uleb128 0x33
	.uleb128 0x3
	.ualong	.LASF41
	.byte	0x2
	.byte	0x58
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x34
	.uleb128 0x3
	.ualong	.LASF42
	.byte	0x2
	.byte	0x59
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x38
	.uleb128 0x3
	.ualong	.LASF43
	.byte	0x2
	.byte	0x5a
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x3c
	.uleb128 0x3
	.ualong	.LASF44
	.byte	0x2
	.byte	0x5b
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x40
	.uleb128 0x3
	.ualong	.LASF45
	.byte	0x2
	.byte	0x5c
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x44
	.uleb128 0x3
	.ualong	.LASF46
	.byte	0x2
	.byte	0x5d
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x48
	.uleb128 0x3
	.ualong	.LASF47
	.byte	0x2
	.byte	0x5e
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x4c
	.uleb128 0x3
	.ualong	.LASF48
	.byte	0x2
	.byte	0x5f
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x50
	.uleb128 0x3
	.ualong	.LASF49
	.byte	0x2
	.byte	0x60
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x54
	.uleb128 0x3
	.ualong	.LASF50
	.byte	0x2
	.byte	0x61
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x58
	.uleb128 0x3
	.ualong	.LASF51
	.byte	0x2
	.byte	0x62
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x5c
	.uleb128 0x3
	.ualong	.LASF52
	.byte	0x2
	.byte	0x63
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x60
	.uleb128 0x3
	.ualong	.LASF53
	.byte	0x2
	.byte	0x64
	.ualong	0x9f
	.byte	0x2
	.byte	0x23
	.uleb128 0x64
	.uleb128 0x9
	.ualong	.LASF54
	.byte	0x2
	.uaword	0x110
	.ualong	0xba
	.byte	0x2
	.byte	0x23
	.uleb128 0x68
	.uleb128 0x9
	.ualong	.LASF55
	.byte	0x2
	.uaword	0x111
	.ualong	0xc8
	.byte	0x2
	.byte	0x23
	.uleb128 0x6c
	.byte	0
	.uleb128 0x4
	.byte	0x1
	.byte	0x8
	.ualong	.LASF56
	.uleb128 0x4
	.byte	0x4
	.byte	0x7
	.ualong	.LASF57
	.uleb128 0xa
	.ualong	.LASF59
	.byte	0x2
	.uaword	0x115
	.ualong	0xcf
	.uleb128 0x2
	.byte	0x8
	.byte	0x3
	.byte	0x12
	.ualong	0x380
	.uleb128 0xb
	.string	"op"
	.byte	0x3
	.byte	0x14
	.ualong	0xba
	.byte	0x2
	.byte	0x23
	.uleb128 0
	.uleb128 0x3
	.ualong	.LASF60
	.byte	0x3
	.byte	0x15
	.ualong	0xba
	.byte	0x2
	.byte	0x23
	.uleb128 0x4
	.uleb128 0x3
	.ualong	.LASF61
	.byte	0x3
	.byte	0x16
	.ualong	0x380
	.byte	0x2
	.byte	0x23
	.uleb128 0x8
	.byte	0
	.uleb128 0xc
	.ualong	0xc8
	.ualong	0x38f
	.uleb128 0xd
	.ualong	0xc1
	.byte	0
	.uleb128 0x8
	.ualong	.LASF62
	.byte	0x3
	.byte	0x17
	.ualong	0x34e
	.uleb128 0x2
	.byte	0x20
	.byte	0x3
	.byte	0x28
	.ualong	0x403
	.uleb128 0xb
	.string	"op"
	.byte	0x3
	.byte	0x2a
	.ualong	0xba
	.byte	0x2
	.byte	0x23
	.uleb128 0
	.uleb128 0x3
	.ualong	.LASF60
	.byte	0x3
	.byte	0x2b
	.ualong	0xba
	.byte	0x2
	.byte	0x23
	.uleb128 0x4
	.uleb128 0xb
	.string	"id"
	.byte	0x3
	.byte	0x2c
	.ualong	0x403
	.byte	0x2
	.byte	0x23
	.uleb128 0x8
	.uleb128 0xb
	.string	"buf"
	.byte	0x3
	.byte	0x2d
	.ualong	0xba
	.byte	0x2
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x3
	.ualong	.LASF63
	.byte	0x3
	.byte	0x2e
	.ualong	0x403
	.byte	0x2
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x3
	.ualong	.LASF64
	.byte	0x3
	.byte	0x2f
	.ualong	0xba
	.byte	0x2
	.byte	0x23
	.uleb128 0x1c
	.uleb128 0x3
	.ualong	.LASF61
	.byte	0x3
	.byte	0x30
	.ualong	0x380
	.byte	0x2
	.byte	0x23
	.uleb128 0x20
	.byte	0
	.uleb128 0xc
	.ualong	0xc8
	.ualong	0x413
	.uleb128 0xe
	.ualong	0xc1
	.byte	0x7
	.byte	0
	.uleb128 0x8
	.ualong	.LASF65
	.byte	0x3
	.byte	0x31
	.ualong	0x39a
	.uleb128 0x2
	.byte	0x18
	.byte	0x3
	.byte	0x33
	.ualong	0x479
	.uleb128 0xb
	.string	"op"
	.byte	0x3
	.byte	0x35
	.ualong	0xba
	.byte	0x2
	.byte	0x23
	.uleb128 0
	.uleb128 0x3
	.ualong	.LASF60
	.byte	0x3
	.byte	0x36
	.ualong	0xba
	.byte	0x2
	.byte	0x23
	.uleb128 0x4
	.uleb128 0xb
	.string	"id"
	.byte	0x3
	.byte	0x37
	.ualong	0x403
	.byte	0x2
	.byte	0x23
	.uleb128 0x8
	.uleb128 0xb
	.string	"buf"
	.byte	0x3
	.byte	0x38
	.ualong	0xba
	.byte	0x2
	.byte	0x23
	.uleb128 0x10
	.uleb128 0xb
	.string	"bit"
	.byte	0x3
	.byte	0x39
	.ualong	0xba
	.byte	0x2
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x3
	.ualong	.LASF61
	.byte	0x3
	.byte	0x3a
	.ualong	0x380
	.byte	0x2
	.byte	0x23
	.uleb128 0x18
	.byte	0
	.uleb128 0x8
	.ualong	.LASF66
	.byte	0x3
	.byte	0x3b
	.ualong	0x41e
	.uleb128 0xf
	.ualong	.LASF148
	.byte	0x4
	.byte	0x3
	.byte	0x45
	.ualong	0x507
	.uleb128 0x10
	.ualong	.LASF67
	.sleb128 1126236160
	.uleb128 0x10
	.ualong	.LASF68
	.sleb128 1126236161
	.uleb128 0x10
	.ualong	.LASF69
	.sleb128 1126236162
	.uleb128 0x10
	.ualong	.LASF70
	.sleb128 1126236163
	.uleb128 0x10
	.ualong	.LASF71
	.sleb128 1126236164
	.uleb128 0x11
	.string	"OpX"
	.sleb128 1126236165
	.uleb128 0x11
	.string	"OpY"
	.sleb128 1126236166
	.uleb128 0x10
	.ualong	.LASF72
	.sleb128 1126236167
	.uleb128 0x10
	.ualong	.LASF73
	.sleb128 1126236168
	.uleb128 0x10
	.ualong	.LASF74
	.sleb128 1126236176
	.uleb128 0x10
	.ualong	.LASF75
	.sleb128 1126236177
	.uleb128 0x10
	.ualong	.LASF76
	.sleb128 589833
	.byte	0
	.uleb128 0x12
	.ualong	.LASF77
	.byte	0x4
	.byte	0x71
	.ualong	0xaf
	.byte	0x1
	.byte	0x1
	.uleb128 0x12
	.ualong	.LASF78
	.byte	0x4
	.byte	0x75
	.ualong	0xaf
	.byte	0x1
	.byte	0x1
	.uleb128 0x12
	.ualong	.LASF79
	.byte	0x4
	.byte	0x76
	.ualong	0xaf
	.byte	0x1
	.byte	0x1
	.uleb128 0xc
	.ualong	0x9f
	.ualong	0x53e
	.uleb128 0xe
	.ualong	0xc1
	.byte	0x5
	.byte	0
	.uleb128 0x12
	.ualong	.LASF80
	.byte	0x4
	.byte	0xce
	.ualong	0x52e
	.byte	0x1
	.byte	0x1
	.uleb128 0x12
	.ualong	.LASF81
	.byte	0x4
	.byte	0xd0
	.ualong	0x9f
	.byte	0x1
	.byte	0x1
	.uleb128 0x12
	.ualong	.LASF82
	.byte	0x4
	.byte	0xd1
	.ualong	0x9f
	.byte	0x1
	.byte	0x1
	.uleb128 0x12
	.ualong	.LASF83
	.byte	0x4
	.byte	0xd8
	.ualong	0x9f
	.byte	0x1
	.byte	0x1
	.uleb128 0x12
	.ualong	.LASF84
	.byte	0x4
	.byte	0xd9
	.ualong	0x9f
	.byte	0x1
	.byte	0x1
	.uleb128 0x12
	.ualong	.LASF85
	.byte	0x4
	.byte	0xda
	.ualong	0x334
	.byte	0x1
	.byte	0x1
	.uleb128 0x13
	.ualong	.LASF86
	.byte	0x4
	.uaword	0x106
	.ualong	0x334
	.byte	0x1
	.byte	0x1
	.uleb128 0x13
	.ualong	.LASF87
	.byte	0x4
	.uaword	0x107
	.ualong	0x9f
	.byte	0x1
	.byte	0x1
	.uleb128 0x13
	.ualong	.LASF88
	.byte	0x4
	.uaword	0x109
	.ualong	0x9f
	.byte	0x1
	.byte	0x1
	.uleb128 0x13
	.ualong	.LASF89
	.byte	0x4
	.uaword	0x10a
	.ualong	0x9f
	.byte	0x1
	.byte	0x1
	.uleb128 0x13
	.ualong	.LASF90
	.byte	0x4
	.uaword	0x10c
	.ualong	0x9f
	.byte	0x1
	.byte	0x1
	.uleb128 0x13
	.ualong	.LASF91
	.byte	0x4
	.uaword	0x10d
	.ualong	0x9f
	.byte	0x1
	.byte	0x1
	.uleb128 0x13
	.ualong	.LASF92
	.byte	0x4
	.uaword	0x10f
	.ualong	0x9f
	.byte	0x1
	.byte	0x1
	.uleb128 0x13
	.ualong	.LASF93
	.byte	0x4
	.uaword	0x110
	.ualong	0x9f
	.byte	0x1
	.byte	0x1
	.uleb128 0x14
	.ualong	.LASF94
	.byte	0x3
	.byte	0xcc
	.ualong	0x60e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_dEcuId_1DDef
	.uleb128 0x15
	.ualong	0x38f
	.uleb128 0x14
	.ualong	.LASF95
	.byte	0x3
	.byte	0xcf
	.ualong	0x60e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_dLoadSmoothingA_1DDef
	.uleb128 0x14
	.ualong	.LASF96
	.byte	0x3
	.byte	0xd0
	.ualong	0x60e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_dLoadSmoothingB_1DDef
	.uleb128 0x14
	.ualong	.LASF97
	.byte	0x3
	.byte	0xd7
	.ualong	0x60e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_dLoadSmoothingFinal_1DDef
	.uleb128 0x14
	.ualong	.LASF98
	.byte	0x3
	.byte	0xdc
	.ualong	0x65b
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_pClutchFlags_ParamBitDef
	.uleb128 0x15
	.ualong	0x479
	.uleb128 0x14
	.ualong	.LASF99
	.byte	0x3
	.byte	0xe0
	.ualong	0x65b
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_pBrakeFlags_ParamBitDef
	.uleb128 0x14
	.ualong	.LASF100
	.byte	0x3
	.byte	0xe4
	.ualong	0x65b
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_pResumeFlags_ParamBitDef
	.uleb128 0x14
	.ualong	.LASF101
	.byte	0x3
	.byte	0xe7
	.ualong	0x65b
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_pCoastFlags_ParamBitDef
	.uleb128 0x14
	.ualong	.LASF102
	.byte	0x3
	.byte	0xea
	.ualong	0x65b
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_pFlagsRevLim_ParamBitDef
	.uleb128 0x14
	.ualong	.LASF103
	.byte	0x3
	.byte	0xf9
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_MafMode_ParamDef
	.uleb128 0x15
	.ualong	0x413
	.uleb128 0x14
	.ualong	.LASF104
	.byte	0x3
	.byte	0xfa
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_VolumetricEfficiency_ParamDef
	.uleb128 0x14
	.ualong	.LASF105
	.byte	0x3
	.byte	0xfb
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_MafFromSpeedDensity_ParamDef
	.uleb128 0x14
	.ualong	.LASF106
	.byte	0x3
	.byte	0xfc
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_MafFromSensor_ParamDef
	.uleb128 0x14
	.ualong	.LASF107
	.byte	0x3
	.byte	0xfd
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_AtmosphericCompensation_ParamDef
	.uleb128 0x14
	.ualong	.LASF108
	.byte	0x3
	.byte	0xfe
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_SDMafBlendRatio_ParamDef
	.uleb128 0x14
	.ualong	.LASF109
	.byte	0x3
	.byte	0xff
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_SDMafFromBlend_ParamDef
	.uleb128 0x16
	.ualong	.LASF110
	.byte	0x3
	.uaword	0x100
	.ualong	0x60e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_VolumetricEfficiencyTable1_3DDef
	.uleb128 0x16
	.ualong	.LASF111
	.byte	0x3
	.uaword	0x10c
	.ualong	0x60e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_AtmosphericCompensationTable_3DDef
	.uleb128 0x16
	.ualong	.LASF112
	.byte	0x3
	.uaword	0x10d
	.ualong	0x60e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_SDBlendingTable_3DDef
	.uleb128 0x16
	.ualong	.LASF113
	.byte	0x3
	.uaword	0x10e
	.ualong	0x60e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_Displacement_1DDef
	.uleb128 0x16
	.ualong	.LASF114
	.byte	0x3
	.uaword	0x10f
	.ualong	0x60e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_DefaultMafMode_1DDef
	.uleb128 0x16
	.ualong	.LASF115
	.byte	0x3
	.uaword	0x110
	.ualong	0x60e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_SpeedDensityConstant_1DDef
	.uleb128 0x16
	.ualong	.LASF116
	.byte	0x3
	.uaword	0x11a
	.ualong	0x60e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_DefaultRedLineCut_1DDef
	.uleb128 0x16
	.ualong	.LASF117
	.byte	0x3
	.uaword	0x11c
	.ualong	0x60e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_DefaultFlatFootShiftMode_1DDef
	.uleb128 0x16
	.ualong	.LASF118
	.byte	0x3
	.uaword	0x11d
	.ualong	0x60e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_DefaultFlatFootShiftAutoDelta_1DDef
	.uleb128 0x16
	.ualong	.LASF119
	.byte	0x3
	.uaword	0x11f
	.ualong	0x60e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_DefaultFlatFootShiftStaticDelta_1DDef
	.uleb128 0x16
	.ualong	.LASF120
	.byte	0x3
	.uaword	0x120
	.ualong	0x60e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_DefaultFlatFootShiftSpeedThreshold_1DDef
	.uleb128 0x16
	.ualong	.LASF121
	.byte	0x3
	.uaword	0x121
	.ualong	0x60e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_DefaultFlatFootShiftRpmThreshold_1DDef
	.uleb128 0x16
	.ualong	.LASF122
	.byte	0x3
	.uaword	0x122
	.ualong	0x60e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_DefaultLaunchControlSpeedMax_1DDef
	.uleb128 0x16
	.ualong	.LASF123
	.byte	0x3
	.uaword	0x123
	.ualong	0x60e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_LCMinimumThrottle_1DDef
	.uleb128 0x16
	.ualong	.LASF124
	.byte	0x3
	.uaword	0x124
	.ualong	0x60e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_FFSMinimumThrottle_1DDef
	.uleb128 0x16
	.ualong	.LASF125
	.byte	0x3
	.uaword	0x126
	.ualong	0x60e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_GearRatios_1DDef
	.uleb128 0x16
	.ualong	.LASF126
	.byte	0x3
	.uaword	0x128
	.ualong	0x60e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_DefaultLaunchControlCut_1DDef
	.uleb128 0x16
	.ualong	.LASF127
	.byte	0x3
	.uaword	0x12b
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_FlatFootShiftMode_ParamDef
	.uleb128 0x16
	.ualong	.LASF128
	.byte	0x3
	.uaword	0x12c
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_LCEngaged_ParamDef
	.uleb128 0x16
	.ualong	.LASF129
	.byte	0x3
	.uaword	0x12d
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_FFSEngaged_ParamDef
	.uleb128 0x16
	.ualong	.LASF130
	.byte	0x3
	.uaword	0x12e
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_FFSGear_ParamDef
	.uleb128 0x16
	.ualong	.LASF131
	.byte	0x3
	.uaword	0x12f
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_RevLimCut_ParamDef
	.uleb128 0x16
	.ualong	.LASF132
	.byte	0x3
	.uaword	0x130
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_RevLimResume_ParamDef
	.uleb128 0x16
	.ualong	.LASF133
	.byte	0x3
	.uaword	0x131
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_RedLineCut_ParamDef
	.uleb128 0x16
	.ualong	.LASF134
	.byte	0x3
	.uaword	0x132
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_RedLineHyst_ParamDef
	.uleb128 0x16
	.ualong	.LASF135
	.byte	0x3
	.uaword	0x133
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_LaunchControlCut_ParamDef
	.uleb128 0x16
	.ualong	.LASF136
	.byte	0x3
	.uaword	0x134
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_LaunchControlHyst_ParamDef
	.uleb128 0x16
	.ualong	.LASF137
	.byte	0x3
	.uaword	0x135
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_FlatFootShiftAutoDelta_ParamDef
	.uleb128 0x16
	.ualong	.LASF138
	.byte	0x3
	.uaword	0x136
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_FlatFootShiftStaticDelta_ParamDef
	.uleb128 0x16
	.ualong	.LASF139
	.byte	0x3
	.uaword	0x137
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_FFSRPM_ParamDef
	.uleb128 0x16
	.ualong	.LASF140
	.byte	0x3
	.uaword	0x138
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_FlatFootShiftSpeedThreshold_ParamDef
	.uleb128 0x16
	.ualong	.LASF141
	.byte	0x3
	.uaword	0x139
	.ualong	0x6ba
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_LaunchControlSpeedMax_ParamDef
	.uleb128 0x16
	.ualong	.LASF142
	.byte	0x3
	.uaword	0x241
	.ualong	0x99e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_endofdeffile
	.uleb128 0x15
	.ualong	0xba
	.uleb128 0x16
	.ualong	.LASF143
	.byte	0x3
	.uaword	0x242
	.ualong	0x99e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_endofdeffile1
	.uleb128 0x16
	.ualong	.LASF144
	.byte	0x3
	.uaword	0x243
	.ualong	0x99e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_endofdeffile2
	.uleb128 0x16
	.ualong	.LASF145
	.byte	0x3
	.uaword	0x244
	.ualong	0x99e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_endofdeffile3
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x10
	.uleb128 0x6
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x8
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x16
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x16
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0x4
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0x28
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x1c
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0x28
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x1c
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3c
	.uleb128 0xc
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3c
	.uleb128 0xc
	.byte	0
	.byte	0
	.uleb128 0x14
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0x15
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x16
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.ualong	0x14
	.uaword	0x2
	.ualong	.Ldebug_info0
	.byte	0x4
	.byte	0
	.uaword	0
	.uaword	0
	.ualong	0
	.ualong	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF103:
	.string	"MafMode_ParamDef"
.LASF52:
	.string	"FlatFootShiftHyst"
.LASF47:
	.string	"LaunchControlHyst"
.LASF138:
	.string	"FlatFootShiftStaticDelta_ParamDef"
.LASF119:
	.string	"DefaultFlatFootShiftStaticDelta_1DDef"
.LASF51:
	.string	"FlatFootShiftStaticDelta"
.LASF78:
	.string	"AtmosphericCompensationTable"
.LASF34:
	.string	"RevLimMode"
.LASF97:
	.string	"dLoadSmoothingFinal_1DDef"
.LASF36:
	.string	"LCEngaged"
.LASF69:
	.string	"OpTable1d"
.LASF146:
	.string	"GNU C 4.7-GNUSH_v13.01"
.LASF64:
	.string	"buf2"
.LASF43:
	.string	"RedLineCut"
.LASF125:
	.string	"GearRatios_1DDef"
.LASF83:
	.string	"Displacement"
.LASF44:
	.string	"RedLineHyst"
.LASF58:
	.string	"ThreeDTable"
.LASF31:
	.string	"SDMafBlendRatio"
.LASF77:
	.string	"VolumetricEfficiencyTable1"
.LASF122:
	.string	"DefaultLaunchControlSpeedMax_1DDef"
.LASF126:
	.string	"DefaultLaunchControlCut_1DDef"
.LASF84:
	.string	"SpeedDensityConstant"
.LASF99:
	.string	"pBrakeFlags_ParamBitDef"
.LASF16:
	.string	"CruiseResumeLast"
.LASF30:
	.string	"DeltaMapCompensation"
.LASF114:
	.string	"DefaultMafMode_1DDef"
.LASF63:
	.string	"storagetype"
.LASF102:
	.string	"pFlagsRevLim_ParamBitDef"
.LASF10:
	.string	"long int"
.LASF13:
	.string	"RamVariableStart"
.LASF70:
	.string	"OpTable2d"
.LASF98:
	.string	"pClutchFlags_ParamBitDef"
.LASF109:
	.string	"SDMafFromBlend_ParamDef"
.LASF140:
	.string	"FlatFootShiftSpeedThreshold_ParamDef"
.LASF110:
	.string	"VolumetricEfficiencyTable1_3DDef"
.LASF15:
	.string	"CruiseCoastLast"
.LASF17:
	.string	"ECUIdentifier"
.LASF108:
	.string	"SDMafBlendRatio_ParamDef"
.LASF79:
	.string	"SDBlendingTable"
.LASF143:
	.string	"endofdeffile1"
.LASF91:
	.string	"DefaultFlatFootShiftStaticDelta"
.LASF35:
	.string	"FlatFootShiftMode"
.LASF124:
	.string	"FFSMinimumThrottle_1DDef"
.LASF65:
	.string	"ParamDef"
.LASF75:
	.string	"OpRAMAllBits"
.LASF131:
	.string	"RevLimCut_ParamDef"
.LASF28:
	.string	"MafFromSensor"
.LASF54:
	.string	"RamHoleSpace"
.LASF39:
	.string	"FFSGear"
.LASF71:
	.string	"OpTable3d"
.LASF132:
	.string	"RevLimResume_ParamDef"
.LASF57:
	.string	"long unsigned int"
.LASF61:
	.string	"name"
.LASF136:
	.string	"LaunchControlHyst_ParamDef"
.LASF133:
	.string	"RedLineCut_ParamDef"
.LASF41:
	.string	"RevLimCut"
.LASF62:
	.string	"TableDef"
.LASF49:
	.string	"FlatFootShiftRpmThreshold"
.LASF50:
	.string	"FlatFootShiftAutoDelta"
.LASF116:
	.string	"DefaultRedLineCut_1DDef"
.LASF24:
	.string	"SDempty"
.LASF148:
	.string	"DefOps"
.LASF40:
	.string	"eleemee2"
.LASF117:
	.string	"DefaultFlatFootShiftMode_1DDef"
.LASF95:
	.string	"dLoadSmoothingA_1DDef"
.LASF87:
	.string	"DefaultRedLineCut"
.LASF85:
	.string	"DefaultMafMode"
.LASF5:
	.string	"tableType"
.LASF90:
	.string	"DefaultFlatFootShiftAutoDelta"
.LASF11:
	.string	"sizetype"
.LASF26:
	.string	"VolumetricEfficiency"
.LASF60:
	.string	"address"
.LASF111:
	.string	"AtmosphericCompensationTable_3DDef"
.LASF81:
	.string	"FFSMinimumThrottle"
.LASF67:
	.string	"OpIdent"
.LASF45:
	.string	"LaunchControlSpeedMax"
.LASF6:
	.string	"multiplier"
.LASF38:
	.string	"ClutchSwitchLast"
.LASF135:
	.string	"LaunchControlCut_ParamDef"
.LASF2:
	.string	"columnHeaderArray"
.LASF127:
	.string	"FlatFootShiftMode_ParamDef"
.LASF101:
	.string	"pCoastFlags_ParamBitDef"
.LASF82:
	.string	"LCMinimumThrottle"
.LASF106:
	.string	"MafFromSensor_ParamDef"
.LASF9:
	.string	"float"
.LASF100:
	.string	"pResumeFlags_ParamBitDef"
.LASF42:
	.string	"RevLimResume"
.LASF141:
	.string	"LaunchControlSpeedMax_ParamDef"
.LASF22:
	.string	"SDInitFlag"
.LASF147:
	.string	"C:\\Dev\\MerpMod\\MerpMod\\Definition.c"
.LASF56:
	.string	"unsigned char"
.LASF73:
	.string	"OpRAM"
.LASF123:
	.string	"LCMinimumThrottle_1DDef"
.LASF4:
	.string	"tableCells"
.LASF86:
	.string	"DefaultFlatFootShiftMode"
.LASF14:
	.string	"VinAuth"
.LASF8:
	.string	"short int"
.LASF66:
	.string	"ParamBitDef"
.LASF46:
	.string	"LaunchControlCut"
.LASF74:
	.string	"OpRAMBit"
.LASF80:
	.string	"GearRatios"
.LASF88:
	.string	"DefaultLaunchControlSpeedMax"
.LASF25:
	.string	"sdempty1"
.LASF72:
	.string	"OpStaticY"
.LASF0:
	.string	"columnCount"
.LASF92:
	.string	"DefaultFlatFootShiftSpeedThreshold"
.LASF53:
	.string	"FlatFootShiftSpeedThreshold"
.LASF105:
	.string	"MafFromSpeedDensity_ParamDef"
.LASF68:
	.string	"OpIdentAddr"
.LASF12:
	.string	"char"
.LASF130:
	.string	"FFSGear_ParamDef"
.LASF120:
	.string	"DefaultFlatFootShiftSpeedThreshold_1DDef"
.LASF23:
	.string	"MafMode"
.LASF129:
	.string	"FFSEngaged_ParamDef"
.LASF134:
	.string	"RedLineHyst_ParamDef"
.LASF112:
	.string	"SDBlendingTable_3DDef"
.LASF144:
	.string	"endofdeffile2"
.LASF145:
	.string	"endofdeffile3"
.LASF27:
	.string	"MafFromSpeedDensity"
.LASF7:
	.string	"offset"
.LASF139:
	.string	"FFSRPM_ParamDef"
.LASF18:
	.string	"HardResetFlag"
.LASF128:
	.string	"LCEngaged_ParamDef"
.LASF118:
	.string	"DefaultFlatFootShiftAutoDelta_1DDef"
.LASF121:
	.string	"DefaultFlatFootShiftRpmThreshold_1DDef"
.LASF59:
	.string	"RamVariables"
.LASF113:
	.string	"Displacement_1DDef"
.LASF115:
	.string	"SpeedDensityConstant_1DDef"
.LASF107:
	.string	"AtmosphericCompensation_ParamDef"
.LASF32:
	.string	"SDMafFromBlend"
.LASF1:
	.string	"rowCount"
.LASF94:
	.string	"dEcuId_1DDef"
.LASF19:
	.string	"blank0"
.LASF20:
	.string	"blank1"
.LASF21:
	.string	"blank2"
.LASF104:
	.string	"VolumetricEfficiency_ParamDef"
.LASF3:
	.string	"rowHeaderArray"
.LASF89:
	.string	"DefaultLaunchControlCut"
.LASF33:
	.string	"RevLimInitFlag"
.LASF37:
	.string	"FFSEngaged"
.LASF29:
	.string	"AtmosphericCompensation"
.LASF142:
	.string	"endofdeffile"
.LASF55:
	.string	"RamHoleEndMarker"
.LASF96:
	.string	"dLoadSmoothingB_1DDef"
.LASF76:
	.string	"OpEnd"
.LASF93:
	.string	"DefaultFlatFootShiftRpmThreshold"
.LASF137:
	.string	"FlatFootShiftAutoDelta_ParamDef"
.LASF48:
	.string	"FFSRPM"
	.ident	"GCC: (GNU) 4.7-GNUSH_v13.01"
