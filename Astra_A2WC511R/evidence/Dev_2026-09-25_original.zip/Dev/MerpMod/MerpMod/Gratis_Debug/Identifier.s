	.file	"Identifier.c"
	.text
	.text
.Ltext0:
	.cfi_sections	.debug_frame
	.global	_ModIdentifier
	.section	RomHole_Identifier,"aw",@progbits
	.align 2
	.type	_ModIdentifier, @object
	.size	_ModIdentifier, 62
_ModIdentifier:
	.string	"A8DH202X.MeRpMoD.Gratis.Debug.v0.1-73-g8720d20.23.08.26.13.08"
	.global	_ModDisclaimer
	.section	RomHole_Misc,"aw",@progbits
	.align 2
	.type	_ModDisclaimer, @object
	.size	_ModDisclaimer, 424
_ModDisclaimer:
	.ascii	"COPYRIGHT 2012,2013 Merrill A. Myers III, merrillamyersiii@g"
	.ascii	"mail.com merrillamyersiii@gmail.com. UNAUTHORIZED DISTRIBUTI"
	.ascii	"ON STRICTLY PROHIBITED. OFFROAD USE ONLY. NO WA"
	.string	"RRANTY. THIS SOFTWARE IS LICENSED TO YOU \223AS IS,\224 AND WITHOUT ANY WARRANTY OF ANY KIND, WHETHER ORAL, WRITTEN, EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT."
	.global	_RomHoleEndMarker
	.section	.rodata
	.align 2
.LC0:
	.string	"0xA5A5A5A5"
	.section	RomHole_RomHoleEndMarker,"aw",@progbits
	.align 2
	.type	_RomHoleEndMarker, @object
	.size	_RomHoleEndMarker, 4
_RomHoleEndMarker:
	.long	.LC0
	.text
.Letext0:
	.file 1 "C:\\Dev\\MerpMod\\MerpMod\\Identifier.c"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.ualong	0xa5
	.uaword	0x2
	.ualong	.Ldebug_abbrev0
	.byte	0x4
	.uleb128 0x1
	.ualong	.LASF10
	.byte	0x1
	.ualong	.LASF11
	.ualong	.Ldebug_line0
	.uleb128 0x2
	.byte	0x2
	.byte	0x5
	.ualong	.LASF0
	.uleb128 0x2
	.byte	0x4
	.byte	0x4
	.ualong	.LASF1
	.uleb128 0x3
	.byte	0x4
	.byte	0x5
	.string	"int"
	.uleb128 0x2
	.byte	0x4
	.byte	0x5
	.ualong	.LASF2
	.uleb128 0x2
	.byte	0x4
	.byte	0x7
	.ualong	.LASF3
	.uleb128 0x2
	.byte	0x1
	.byte	0x6
	.ualong	.LASF4
	.uleb128 0x2
	.byte	0x1
	.byte	0x8
	.ualong	.LASF5
	.uleb128 0x2
	.byte	0x4
	.byte	0x7
	.ualong	.LASF6
	.uleb128 0x4
	.ualong	.LASF7
	.byte	0x1
	.byte	0x3f
	.ualong	0x2e
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_RomHoleEndMarker
	.uleb128 0x5
	.ualong	0x43
	.ualong	0x73
	.uleb128 0x6
	.ualong	0x35
	.byte	0x3d
	.byte	0
	.uleb128 0x4
	.ualong	.LASF8
	.byte	0x1
	.byte	0x19
	.ualong	0x63
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_ModIdentifier
	.uleb128 0x5
	.ualong	0x43
	.ualong	0x96
	.uleb128 0x7
	.ualong	0x35
	.uaword	0x1a7
	.byte	0
	.uleb128 0x4
	.ualong	.LASF9
	.byte	0x1
	.byte	0x20
	.ualong	0x85
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_ModDisclaimer
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x10
	.uleb128 0x6
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x8
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0x5
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.ualong	0x14
	.uaword	0x2
	.ualong	.Ldebug_info0
	.byte	0x4
	.byte	0
	.uaword	0
	.uaword	0
	.ualong	0
	.ualong	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF10:
	.string	"GNU C 4.7-GNUSH_v13.01"
.LASF1:
	.string	"float"
.LASF7:
	.string	"RomHoleEndMarker"
.LASF11:
	.string	"C:\\Dev\\MerpMod\\MerpMod\\Identifier.c"
.LASF0:
	.string	"short int"
.LASF8:
	.string	"ModIdentifier"
.LASF5:
	.string	"unsigned char"
.LASF2:
	.string	"long int"
.LASF3:
	.string	"sizetype"
.LASF6:
	.string	"long unsigned int"
.LASF4:
	.string	"char"
.LASF9:
	.string	"ModDisclaimer"
	.ident	"GCC: (GNU) 4.7-GNUSH_v13.01"
