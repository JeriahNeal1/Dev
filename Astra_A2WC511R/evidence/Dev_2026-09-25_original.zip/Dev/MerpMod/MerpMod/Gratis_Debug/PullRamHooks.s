	.file	"PullRamHooks.c"
	.text
	.text
.Ltext0:
	.cfi_sections	.debug_frame
	.global	_Pull3DHooked
	.section	RomHole_Functions,"aw",@progbits
	.align 2
	.type	_Pull3DHooked, @object
	.size	_Pull3DHooked, 4
_Pull3DHooked:
	.long	8528
	.global	_Pull2DHooked
	.align 2
	.type	_Pull2DHooked, @object
	.size	_Pull2DHooked, 4
_Pull2DHooked:
	.long	8348
	.section	RomHole_Code,"ax",@progbits
	.align 2
	.global	_Pull3DRamHook
	.type	_Pull3DRamHook, @function
_Pull3DRamHook:
.LFB0:
	.file 1 "C:\\Dev\\MerpMod\\MerpMod\\PullRamHooks.c"
	.loc 1 25 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI0:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	sts.l	pr,@-r15
.LCFI1:
	.cfi_def_cfa_offset 8
	.cfi_offset 17, -8
	add	#-12,r15
.LCFI2:
	.cfi_def_cfa_offset 20
	mov	r15,r14
.LCFI3:
	.cfi_def_cfa_register 14
	mov	r14,r1
	add	#-52,r1
	mov.l	r4,@(60,r1)
	mov	r14,r1
	add	#4,r1
	fmov.s	fr4,@r1
	mov	r14,r1
	fmov.s	fr5,@r1
	.loc 1 29 0
	mov	r14,r1
	add	#-52,r1
	mov.l	@(60,r1),r2
	mov.w	.L4,r1
	cmp/hi	r1,r2
	bf.s	.L2
	nop
	.loc 1 29 0 is_stmt 0 discriminator 1
	mov	r14,r1
	add	#-52,r1
	mov.l	@(60,r1),r2
	mov.w	.L5,r1
	cmp/hi	r1,r2
	bt.s	.L2
	nop
	.loc 1 31 0 is_stmt 1
	mov	r14,r1
	add	#-52,r1
	mov.l	@(60,r1),r1
	fmov.s	@r1,fr1
	bra	.L3
	nop
	.align 1
.L2:
	.loc 1 35 0
	mov.l	.L6,r1
	mov.l	@r1,r1
	mov	r14,r2
	add	#-52,r2
	mov.l	@(60,r2),r7
	mov	r14,r3
	add	#4,r3
	mov	r14,r2
	mov	r7,r4
	fmov.s	@r3,fr4
	fmov.s	@r2,fr5
	jsr	@r1
	nop
	fmov	fr0,fr1
.L3:
	.loc 1 37 0
	fmov	fr1,fr0
	add	#12,r14
	mov	r14,r15
	lds.l   @r15+,pr
	mov.l   @r15+,r14
	rts	
	nop
	.align 1
.L4:
	.short	-26944
.L5:
	.short	-26837
.L7:
	.align 2
.L6:
	.long	_Pull3DHooked
	.cfi_endproc
.LFE0:
	.size	_Pull3DRamHook, .-_Pull3DRamHook
	.align 2
	.global	_Pull2DRamHook
	.type	_Pull2DRamHook, @function
_Pull2DRamHook:
.LFB1:
	.loc 1 40 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI4:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	sts.l	pr,@-r15
.LCFI5:
	.cfi_def_cfa_offset 8
	.cfi_offset 17, -8
	add	#-8,r15
.LCFI6:
	.cfi_def_cfa_offset 16
	mov	r15,r14
.LCFI7:
	.cfi_def_cfa_register 14
	mov	r14,r1
	add	#-56,r1
	mov.l	r4,@(60,r1)
	mov	r14,r1
	fmov.s	fr4,@r1
	.loc 1 42 0
	mov	r14,r1
	add	#-56,r1
	mov.l	@(60,r1),r2
	mov.w	.L11,r1
	cmp/hi	r1,r2
	bf.s	.L9
	nop
	.loc 1 44 0
	mov	r14,r1
	add	#-56,r1
	mov.l	@(60,r1),r1
	fmov.s	@r1,fr1
	bra	.L10
	nop
	.align 1
.L9:
	.loc 1 48 0
	mov.l	.L12,r1
	mov.l	@r1,r1
	mov	r14,r2
	add	#-56,r2
	mov.l	@(60,r2),r3
	mov	r14,r2
	mov	r3,r4
	fmov.s	@r2,fr4
	jsr	@r1
	nop
	fmov	fr0,fr1
.L10:
	.loc 1 50 0
	fmov	fr1,fr0
	add	#8,r14
	mov	r14,r15
	lds.l   @r15+,pr
	mov.l   @r15+,r14
	rts	
	nop
	.align 1
.L11:
	.short	-26944
.L13:
	.align 2
.L12:
	.long	_Pull2DHooked
	.cfi_endproc
.LFE1:
	.size	_Pull2DRamHook, .-_Pull2DRamHook
	.text
.Letext0:
	.file 2 "C:\\Dev\\MerpMod\\MerpMod\\enums.h"
	.file 3 "C:\\Dev\\MerpMod\\MerpMod\\RamVariables.h"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.ualong	0x4b6
	.uaword	0x2
	.ualong	.Ldebug_abbrev0
	.byte	0x4
	.uleb128 0x1
	.ualong	.LASF68
	.byte	0x1
	.ualong	.LASF69
	.ualong	.Ldebug_ranges0+0
	.ualong	0
	.ualong	0
	.ualong	.Ldebug_line0
	.uleb128 0x2
	.byte	0x1c
	.byte	0x2
	.byte	0x81
	.ualong	0x9e
	.uleb128 0x3
	.ualong	.LASF0
	.byte	0x2
	.byte	0x83
	.ualong	0x9e
	.byte	0x2
	.byte	0x23
	.uleb128 0
	.uleb128 0x3
	.ualong	.LASF1
	.byte	0x2
	.byte	0x84
	.ualong	0x9e
	.byte	0x2
	.byte	0x23
	.uleb128 0x2
	.uleb128 0x3
	.ualong	.LASF2
	.byte	0x2
	.byte	0x85
	.ualong	0xa5
	.byte	0x2
	.byte	0x23
	.uleb128 0x4
	.uleb128 0x3
	.ualong	.LASF3
	.byte	0x2
	.byte	0x86
	.ualong	0xa5
	.byte	0x2
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x3
	.ualong	.LASF4
	.byte	0x2
	.byte	0x87
	.ualong	0xb2
	.byte	0x2
	.byte	0x23
	.uleb128 0xc
	.uleb128 0x3
	.ualong	.LASF5
	.byte	0x2
	.byte	0x88
	.ualong	0xb4
	.byte	0x2
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x3
	.ualong	.LASF6
	.byte	0x2
	.byte	0x89
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x3
	.ualong	.LASF7
	.byte	0x2
	.byte	0x8a
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x18
	.byte	0
	.uleb128 0x4
	.byte	0x2
	.byte	0x5
	.ualong	.LASF8
	.uleb128 0x5
	.byte	0x4
	.ualong	0xab
	.uleb128 0x4
	.byte	0x4
	.byte	0x4
	.ualong	.LASF9
	.uleb128 0x6
	.byte	0x4
	.uleb128 0x7
	.byte	0x4
	.byte	0x5
	.string	"int"
	.uleb128 0x8
	.ualong	.LASF10
	.byte	0x2
	.byte	0x8b
	.ualong	0x25
	.uleb128 0x2
	.byte	0x14
	.byte	0x2
	.byte	0x8d
	.ualong	0x123
	.uleb128 0x3
	.ualong	.LASF0
	.byte	0x2
	.byte	0x8f
	.ualong	0x9e
	.byte	0x2
	.byte	0x23
	.uleb128 0
	.uleb128 0x3
	.ualong	.LASF5
	.byte	0x2
	.byte	0x90
	.ualong	0x9e
	.byte	0x2
	.byte	0x23
	.uleb128 0x2
	.uleb128 0x3
	.ualong	.LASF2
	.byte	0x2
	.byte	0x91
	.ualong	0xa5
	.byte	0x2
	.byte	0x23
	.uleb128 0x4
	.uleb128 0x3
	.ualong	.LASF4
	.byte	0x2
	.byte	0x92
	.ualong	0x123
	.byte	0x2
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x3
	.ualong	.LASF6
	.byte	0x2
	.byte	0x93
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0xc
	.uleb128 0x3
	.ualong	.LASF7
	.byte	0x2
	.byte	0x94
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x10
	.byte	0
	.uleb128 0x5
	.byte	0x4
	.ualong	0x9e
	.uleb128 0x8
	.ualong	.LASF11
	.byte	0x2
	.byte	0x95
	.ualong	0xc6
	.uleb128 0x5
	.byte	0x4
	.ualong	0xbb
	.uleb128 0x4
	.byte	0x4
	.byte	0x5
	.ualong	.LASF12
	.uleb128 0x4
	.byte	0x4
	.byte	0x7
	.ualong	.LASF13
	.uleb128 0x4
	.byte	0x1
	.byte	0x6
	.ualong	.LASF14
	.uleb128 0x2
	.byte	0x70
	.byte	0x3
	.byte	0x12
	.ualong	0x3b4
	.uleb128 0x3
	.ualong	.LASF15
	.byte	0x3
	.byte	0x14
	.ualong	0x3b4
	.byte	0x2
	.byte	0x23
	.uleb128 0
	.uleb128 0x3
	.ualong	.LASF16
	.byte	0x3
	.byte	0x15
	.ualong	0x3b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x1
	.uleb128 0x3
	.ualong	.LASF17
	.byte	0x3
	.byte	0x16
	.ualong	0x3b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x2
	.uleb128 0x3
	.ualong	.LASF18
	.byte	0x3
	.byte	0x17
	.ualong	0x3b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x3
	.uleb128 0x3
	.ualong	.LASF19
	.byte	0x3
	.byte	0x18
	.ualong	0x3bb
	.byte	0x2
	.byte	0x23
	.uleb128 0x4
	.uleb128 0x3
	.ualong	.LASF20
	.byte	0x3
	.byte	0x19
	.ualong	0x3b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x3
	.ualong	.LASF21
	.byte	0x3
	.byte	0x1a
	.ualong	0x3b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x9
	.uleb128 0x3
	.ualong	.LASF22
	.byte	0x3
	.byte	0x1b
	.ualong	0x3b4
	.byte	0x2
	.byte	0x23
	.uleb128 0xa
	.uleb128 0x3
	.ualong	.LASF23
	.byte	0x3
	.byte	0x1c
	.ualong	0x3b4
	.byte	0x2
	.byte	0x23
	.uleb128 0xb
	.uleb128 0x3
	.ualong	.LASF24
	.byte	0x3
	.byte	0x40
	.ualong	0x3b4
	.byte	0x2
	.byte	0x23
	.uleb128 0xc
	.uleb128 0x3
	.ualong	.LASF25
	.byte	0x3
	.byte	0x41
	.ualong	0x3b4
	.byte	0x2
	.byte	0x23
	.uleb128 0xd
	.uleb128 0x3
	.ualong	.LASF26
	.byte	0x3
	.byte	0x42
	.ualong	0x3b4
	.byte	0x2
	.byte	0x23
	.uleb128 0xe
	.uleb128 0x3
	.ualong	.LASF27
	.byte	0x3
	.byte	0x43
	.ualong	0x3b4
	.byte	0x2
	.byte	0x23
	.uleb128 0xf
	.uleb128 0x3
	.ualong	.LASF28
	.byte	0x3
	.byte	0x44
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x3
	.ualong	.LASF29
	.byte	0x3
	.byte	0x45
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x3
	.ualong	.LASF30
	.byte	0x3
	.byte	0x46
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x3
	.ualong	.LASF31
	.byte	0x3
	.byte	0x47
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x1c
	.uleb128 0x3
	.ualong	.LASF32
	.byte	0x3
	.byte	0x48
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x20
	.uleb128 0x3
	.ualong	.LASF33
	.byte	0x3
	.byte	0x49
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x24
	.uleb128 0x3
	.ualong	.LASF34
	.byte	0x3
	.byte	0x4a
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x28
	.uleb128 0x3
	.ualong	.LASF35
	.byte	0x3
	.byte	0x50
	.ualong	0x3b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x2c
	.uleb128 0x3
	.ualong	.LASF36
	.byte	0x3
	.byte	0x51
	.ualong	0x3b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x2d
	.uleb128 0x3
	.ualong	.LASF37
	.byte	0x3
	.byte	0x52
	.ualong	0x3b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x2e
	.uleb128 0x3
	.ualong	.LASF38
	.byte	0x3
	.byte	0x53
	.ualong	0x3b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x2f
	.uleb128 0x3
	.ualong	.LASF39
	.byte	0x3
	.byte	0x54
	.ualong	0x3b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x30
	.uleb128 0x3
	.ualong	.LASF40
	.byte	0x3
	.byte	0x55
	.ualong	0x3b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x31
	.uleb128 0x3
	.ualong	.LASF41
	.byte	0x3
	.byte	0x56
	.ualong	0x3b4
	.byte	0x2
	.byte	0x23
	.uleb128 0x32
	.uleb128 0x3
	.ualong	.LASF42
	.byte	0x3
	.byte	0x57
	.ualong	0x148
	.byte	0x2
	.byte	0x23
	.uleb128 0x33
	.uleb128 0x3
	.ualong	.LASF43
	.byte	0x3
	.byte	0x58
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x34
	.uleb128 0x3
	.ualong	.LASF44
	.byte	0x3
	.byte	0x59
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x38
	.uleb128 0x3
	.ualong	.LASF45
	.byte	0x3
	.byte	0x5a
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x3c
	.uleb128 0x3
	.ualong	.LASF46
	.byte	0x3
	.byte	0x5b
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x40
	.uleb128 0x3
	.ualong	.LASF47
	.byte	0x3
	.byte	0x5c
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x44
	.uleb128 0x3
	.ualong	.LASF48
	.byte	0x3
	.byte	0x5d
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x48
	.uleb128 0x3
	.ualong	.LASF49
	.byte	0x3
	.byte	0x5e
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x4c
	.uleb128 0x3
	.ualong	.LASF50
	.byte	0x3
	.byte	0x5f
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x50
	.uleb128 0x3
	.ualong	.LASF51
	.byte	0x3
	.byte	0x60
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x54
	.uleb128 0x3
	.ualong	.LASF52
	.byte	0x3
	.byte	0x61
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x58
	.uleb128 0x3
	.ualong	.LASF53
	.byte	0x3
	.byte	0x62
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x5c
	.uleb128 0x3
	.ualong	.LASF54
	.byte	0x3
	.byte	0x63
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x60
	.uleb128 0x3
	.ualong	.LASF55
	.byte	0x3
	.byte	0x64
	.ualong	0xab
	.byte	0x2
	.byte	0x23
	.uleb128 0x64
	.uleb128 0x9
	.ualong	.LASF56
	.byte	0x3
	.uaword	0x110
	.ualong	0x13a
	.byte	0x2
	.byte	0x23
	.uleb128 0x68
	.uleb128 0x9
	.ualong	.LASF57
	.byte	0x3
	.uaword	0x111
	.ualong	0x148
	.byte	0x2
	.byte	0x23
	.uleb128 0x6c
	.byte	0
	.uleb128 0x4
	.byte	0x1
	.byte	0x8
	.ualong	.LASF58
	.uleb128 0x4
	.byte	0x4
	.byte	0x7
	.ualong	.LASF59
	.uleb128 0xa
	.ualong	.LASF60
	.byte	0x3
	.uaword	0x115
	.ualong	0x14f
	.uleb128 0xb
	.byte	0x1
	.ualong	.LASF64
	.byte	0x1
	.byte	0x18
	.byte	0x1
	.ualong	0xab
	.ualong	.LFB0
	.ualong	.LFE0
	.ualong	.LLST0
	.byte	0x1
	.byte	0x40
	.ualong	0x418
	.uleb128 0xc
	.ualong	.LASF61
	.byte	0x1
	.byte	0x18
	.ualong	0xa5
	.byte	0x2
	.byte	0x91
	.sleb128 -12
	.uleb128 0xc
	.ualong	.LASF62
	.byte	0x1
	.byte	0x18
	.ualong	0xab
	.byte	0x2
	.byte	0x91
	.sleb128 -16
	.uleb128 0xc
	.ualong	.LASF63
	.byte	0x1
	.byte	0x18
	.ualong	0xab
	.byte	0x2
	.byte	0x91
	.sleb128 -20
	.byte	0
	.uleb128 0xb
	.byte	0x1
	.ualong	.LASF65
	.byte	0x1
	.byte	0x27
	.byte	0x1
	.ualong	0xab
	.ualong	.LFB1
	.ualong	.LFE1
	.ualong	.LLST1
	.byte	0x1
	.byte	0x40
	.ualong	0x454
	.uleb128 0xc
	.ualong	.LASF61
	.byte	0x1
	.byte	0x27
	.ualong	0xa5
	.byte	0x2
	.byte	0x91
	.sleb128 -12
	.uleb128 0xc
	.ualong	.LASF62
	.byte	0x1
	.byte	0x27
	.ualong	0xab
	.byte	0x2
	.byte	0x91
	.sleb128 -16
	.byte	0
	.uleb128 0xd
	.byte	0x1
	.ualong	0xab
	.ualong	0x46e
	.uleb128 0xe
	.ualong	0x134
	.uleb128 0xe
	.ualong	0xab
	.uleb128 0xe
	.ualong	0xab
	.byte	0
	.uleb128 0xf
	.ualong	.LASF66
	.byte	0x1
	.byte	0x11
	.ualong	0x480
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_Pull3DHooked
	.uleb128 0x5
	.byte	0x4
	.ualong	0x454
	.uleb128 0xd
	.byte	0x1
	.ualong	0xab
	.ualong	0x49b
	.uleb128 0xe
	.ualong	0x49b
	.uleb128 0xe
	.ualong	0xab
	.byte	0
	.uleb128 0x5
	.byte	0x4
	.ualong	0x129
	.uleb128 0xf
	.ualong	.LASF67
	.byte	0x1
	.byte	0x12
	.ualong	0x4b3
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_Pull2DHooked
	.uleb128 0x5
	.byte	0x4
	.ualong	0x486
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x55
	.uleb128 0x6
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x52
	.uleb128 0x1
	.uleb128 0x10
	.uleb128 0x6
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x8
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x16
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x16
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x27
	.uleb128 0xc
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.uleb128 0x40
	.uleb128 0x6
	.uleb128 0x2116
	.uleb128 0xc
	.uleb128 0x36
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x15
	.byte	0x1
	.uleb128 0x27
	.uleb128 0xc
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x5
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_loc,"",@progbits
.Ldebug_loc0:
.LLST0:
	.ualong	.LFB0
	.ualong	.LCFI0
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI0
	.ualong	.LCFI1
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI1
	.ualong	.LCFI2
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI2
	.ualong	.LCFI3
	.uaword	0x2
	.byte	0x7f
	.sleb128 20
	.ualong	.LCFI3
	.ualong	.LFE0
	.uaword	0x2
	.byte	0x7e
	.sleb128 20
	.ualong	0
	.ualong	0
.LLST1:
	.ualong	.LFB1
	.ualong	.LCFI4
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI4
	.ualong	.LCFI5
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI5
	.ualong	.LCFI6
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI6
	.ualong	.LCFI7
	.uaword	0x2
	.byte	0x7f
	.sleb128 16
	.ualong	.LCFI7
	.ualong	.LFE1
	.uaword	0x2
	.byte	0x7e
	.sleb128 16
	.ualong	0
	.ualong	0
	.section	.debug_aranges,"",@progbits
	.ualong	0x24
	.uaword	0x2
	.ualong	.Ldebug_info0
	.byte	0x4
	.byte	0
	.uaword	0
	.uaword	0
	.ualong	.LFB0
	.ualong	.LFE0-.LFB0
	.ualong	.LFB1
	.ualong	.LFE1-.LFB1
	.ualong	0
	.ualong	0
	.section	.debug_ranges,"",@progbits
.Ldebug_ranges0:
	.ualong	.LFB0
	.ualong	.LFE0
	.ualong	.LFB1
	.ualong	.LFE1
	.ualong	0
	.ualong	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF37:
	.string	"FlatFootShiftMode"
.LASF41:
	.string	"FFSGear"
.LASF48:
	.string	"LaunchControlCut"
.LASF51:
	.string	"FlatFootShiftRpmThreshold"
.LASF64:
	.string	"Pull3DRamHook"
.LASF6:
	.string	"multiplier"
.LASF62:
	.string	"xLookup"
.LASF27:
	.string	"sdempty1"
.LASF8:
	.string	"short int"
.LASF33:
	.string	"SDMafBlendRatio"
.LASF25:
	.string	"MafMode"
.LASF13:
	.string	"sizetype"
.LASF66:
	.string	"Pull3DHooked"
.LASF3:
	.string	"rowHeaderArray"
.LASF15:
	.string	"RamVariableStart"
.LASF19:
	.string	"ECUIdentifier"
.LASF0:
	.string	"columnCount"
.LASF24:
	.string	"SDInitFlag"
.LASF49:
	.string	"LaunchControlHyst"
.LASF17:
	.string	"CruiseCoastLast"
.LASF55:
	.string	"FlatFootShiftSpeedThreshold"
.LASF34:
	.string	"SDMafFromBlend"
.LASF43:
	.string	"RevLimCut"
.LASF30:
	.string	"MafFromSensor"
.LASF9:
	.string	"float"
.LASF2:
	.string	"columnHeaderArray"
.LASF4:
	.string	"tableCells"
.LASF28:
	.string	"VolumetricEfficiency"
.LASF12:
	.string	"long int"
.LASF7:
	.string	"offset"
.LASF52:
	.string	"FlatFootShiftAutoDelta"
.LASF60:
	.string	"RamVariables"
.LASF46:
	.string	"RedLineHyst"
.LASF58:
	.string	"unsigned char"
.LASF5:
	.string	"tableType"
.LASF35:
	.string	"RevLimInitFlag"
.LASF68:
	.string	"GNU C 4.7-GNUSH_v13.01"
.LASF59:
	.string	"long unsigned int"
.LASF50:
	.string	"FFSRPM"
.LASF57:
	.string	"RamHoleEndMarker"
.LASF63:
	.string	"yLookup"
.LASF54:
	.string	"FlatFootShiftHyst"
.LASF14:
	.string	"char"
.LASF32:
	.string	"DeltaMapCompensation"
.LASF29:
	.string	"MafFromSpeedDensity"
.LASF21:
	.string	"blank0"
.LASF22:
	.string	"blank1"
.LASF23:
	.string	"blank2"
.LASF16:
	.string	"VinAuth"
.LASF18:
	.string	"CruiseResumeLast"
.LASF26:
	.string	"SDempty"
.LASF67:
	.string	"Pull2DHooked"
.LASF38:
	.string	"LCEngaged"
.LASF69:
	.string	"C:\\Dev\\MerpMod\\MerpMod\\PullRamHooks.c"
.LASF39:
	.string	"FFSEngaged"
.LASF11:
	.string	"TwoDTable"
.LASF44:
	.string	"RevLimResume"
.LASF36:
	.string	"RevLimMode"
.LASF1:
	.string	"rowCount"
.LASF65:
	.string	"Pull2DRamHook"
.LASF20:
	.string	"HardResetFlag"
.LASF53:
	.string	"FlatFootShiftStaticDelta"
.LASF31:
	.string	"AtmosphericCompensation"
.LASF45:
	.string	"RedLineCut"
.LASF56:
	.string	"RamHoleSpace"
.LASF61:
	.string	"table"
.LASF42:
	.string	"eleemee2"
.LASF10:
	.string	"ThreeDTable"
.LASF40:
	.string	"ClutchSwitchLast"
.LASF47:
	.string	"LaunchControlSpeedMax"
	.ident	"GCC: (GNU) 4.7-GNUSH_v13.01"
