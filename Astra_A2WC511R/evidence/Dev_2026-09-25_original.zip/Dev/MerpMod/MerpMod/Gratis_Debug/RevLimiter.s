	.file	"RevLimiter.c"
	.text
	.text
.Ltext0:
	.cfi_sections	.debug_frame
	.section	RomHole_Code,"ax",@progbits
	.align 2
	.global	_RevLimReset
	.type	_RevLimReset, @function
_RevLimReset:
.LFB0:
	.file 1 "C:\\Dev\\MerpMod\\MerpMod\\RevLimiter.c"
	.loc 1 51 0
	.cfi_startproc
	mov.l	r8,@-r15
.LCFI0:
	.cfi_def_cfa_offset 4
	.cfi_offset 8, -4
	mov.l	r14,@-r15
.LCFI1:
	.cfi_def_cfa_offset 8
	.cfi_offset 14, -8
	fmov.s	fr12,@-r15
.LCFI2:
	.cfi_def_cfa_offset 12
	.cfi_offset 37, -12
	sts.l	pr,@-r15
.LCFI3:
	.cfi_def_cfa_offset 16
	.cfi_offset 17, -16
	mov	r15,r14
.LCFI4:
	.cfi_def_cfa_register 14
	.loc 1 61 0
	mov.w	.L12,r1
	mov.w	.L12,r2
	add	#60,r2
	fmov.s	@r2,fr1
	add	#52,r1
	fmov.s	fr1,@r1
	.loc 1 62 0
	mov.w	.L12,r8
	mov.w	.L12,r1
	add	#52,r1
	fmov.s	@r1,fr12
	mov.w	.L12,r1
	add	#64,r1
	fmov.s	@r1,fr2
	fldi0	fr1
	fmov	fr2,fr4
	fmov	fr1,fr5
	mov.l	.L8,r1
	jsr	@r1
	nop
	fmov	fr0,fr1
	fmov	fr12,fr2
	fsub	fr1,fr2
	fmov	fr2,fr1
	mov	r8,r1
	add	#56,r1
	fmov.s	fr1,@r1
	.loc 1 68 0
	mov.w	.L12,r1
	add	#48,r1
	mov	#0,r2
	mov.b	r2,@r1
	.loc 1 69 0
	mov.w	.L12,r1
	add	#47,r1
	mov	#0,r2
	mov.b	r2,@r1
	.loc 1 71 0
	mov.l	.L13,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bt.s	.L1
	nop
	.loc 1 73 0
	mov.w	.L12,r1
	mov.l	.L13,r2
	mov.b	@r2,r2
	extu.b	r2,r2
	add	#50,r1
	mov.b	r2,@r1
.L1:
	.loc 1 76 0
	mov	r14,r15
	lds.l   @r15+,pr
	fmov.s	@r15+,fr12
	mov.l   @r15+,r14
	mov.l   @r15+,r8
	rts	
	nop
	.align 1
.L12:
	.short	-26944
.L14:
	.align 2
.L8:
	.long	_HighPass
.L13:
	.long	-38111
	.cfi_endproc
.LFE0:
	.size	_RevLimReset, .-_RevLimReset
	.align 2
	.global	_TestFFSEntry
	.type	_TestFFSEntry, @function
_TestFFSEntry:
.LFB1:
	.loc 1 79 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI5:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	mov	r15,r14
.LCFI6:
	.cfi_def_cfa_register 14
	.loc 1 81 0
	mov.l	.L26,r1
	fmov.s	@r1,fr2
	mov.w	.L38,r1
	add	#100,r1
	fmov.s	@r1,fr1
	fcmp/gt	fr1,fr2
	bt	.L40
	fcmp/eq	fr1,fr2
	bf.s	.L16
	nop
.L40:
.L22:
	.loc 1 82 0
	mov.w	.L38,r1
	add	#46,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bt.s	.L16
	nop
	.loc 1 83 0
	mov.l	.L29,r1
	fmov.s	@r1,fr2
	mov.l	.L30,r1
	fmov.s	@r1,fr1
	fcmp/gt	fr1,fr2
	bt	.L41
	fcmp/eq	fr1,fr2
	bf.s	.L16
	nop
.L41:
.L23:
	.loc 1 86 0
	mov.w	.L38,r1
	add	#47,r1
	mov	#0,r2
	mov.b	r2,@r1
	.loc 1 89 0
	mov.w	.L38,r1
	add	#48,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bf.s	.L15
	nop
	.loc 1 89 0 is_stmt 0 discriminator 1
	mov.l	.L37,r1
	fmov.s	@r1,fr2
	mov.w	.L38,r1
	add	#84,r1
	fmov.s	@r1,fr1
	fcmp/gt	fr1,fr2
	bf.s	.L25
	nop
.L24:
	.loc 1 91 0 is_stmt 1
	mov.w	.L38,r1
	add	#48,r1
	mov	#1,r2
	mov.b	r2,@r1
	.loc 1 92 0
	mov.w	.L38,r1
	mov.l	.L37,r2
	fmov.s	@r2,fr1
	add	#80,r1
	fmov.s	fr1,@r1
	.loc 1 89 0
	bra	.L15
	nop
	.align 1
.L25:
	.loc 1 89 0 is_stmt 0 discriminator 2
	bra	.L15
	nop
	.align 1
.L16:
	.loc 1 97 0 is_stmt 1
	mov.w	.L38,r1
	add	#48,r1
	mov	#0,r2
	mov.b	r2,@r1
.L15:
	.loc 1 99 0
	mov	r14,r15
	mov.l   @r15+,r14
	rts	
	nop
	.align 1
.L38:
	.short	-26944
.L39:
	.align 2
.L26:
	.long	-38384
.L29:
	.long	-39108
.L30:
	.long	_FFSMinimumThrottle
.L37:
	.long	-38376
	.cfi_endproc
.LFE1:
	.size	_TestFFSEntry, .-_TestFFSEntry
	.align 2
	.global	_TestLCEntry
	.type	_TestLCEntry, @function
_TestLCEntry:
.LFB2:
	.loc 1 102 0
	.cfi_startproc
	mov.l	r8,@-r15
.LCFI7:
	.cfi_def_cfa_offset 4
	.cfi_offset 8, -4
	mov.l	r14,@-r15
.LCFI8:
	.cfi_def_cfa_offset 8
	.cfi_offset 14, -8
	fmov.s	fr12,@-r15
.LCFI9:
	.cfi_def_cfa_offset 12
	.cfi_offset 37, -12
	sts.l	pr,@-r15
.LCFI10:
	.cfi_def_cfa_offset 16
	.cfi_offset 17, -16
	mov	r15,r14
.LCFI11:
	.cfi_def_cfa_register 14
	.loc 1 103 0
	mov.w	.L58,r1
	add	#48,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bf.s	.L42
	nop
	.loc 1 103 0 is_stmt 0 discriminator 1
	mov.l	.L49,r1
	fmov.s	@r1,fr1
	mov.w	.L58,r1
	add	#68,r1
	fmov.s	@r1,fr2
	fcmp/gt	fr1,fr2
	bt	.L61
	fcmp/eq	fr1,fr2
	bf.s	.L42
	nop
.L61:
.L46:
	mov.l	.L51,r1
	fmov.s	@r1,fr2
	mov.l	.L52,r1
	fmov.s	@r1,fr1
	fcmp/gt	fr1,fr2
	bt	.L62
	fcmp/eq	fr1,fr2
	bf.s	.L42
	nop
.L62:
.L47:
	.loc 1 110 0 is_stmt 1
	mov.w	.L58,r1
	add	#47,r1
	mov	#1,r2
	mov.b	r2,@r1
	.loc 1 111 0
	mov.w	.L58,r1
	mov.w	.L58,r2
	add	#72,r2
	fmov.s	@r2,fr1
	add	#52,r1
	fmov.s	fr1,@r1
	.loc 1 112 0
	mov.w	.L58,r8
	mov.w	.L58,r1
	add	#72,r1
	fmov.s	@r1,fr12
	mov.w	.L58,r1
	add	#76,r1
	fmov.s	@r1,fr2
	fldi0	fr1
	fmov	fr2,fr4
	fmov	fr1,fr5
	mov.l	.L59,r1
	jsr	@r1
	nop
	fmov	fr0,fr1
	fmov	fr12,fr2
	fsub	fr1,fr2
	fmov	fr2,fr1
	mov	r8,r1
	add	#56,r1
	fmov.s	fr1,@r1
.L42:
	.loc 1 114 0
	mov	r14,r15
	lds.l   @r15+,pr
	fmov.s	@r15+,fr12
	mov.l   @r15+,r14
	mov.l   @r15+,r8
	rts	
	nop
	.align 1
.L58:
	.short	-26944
.L60:
	.align 2
.L49:
	.long	-38384
.L51:
	.long	-39108
.L52:
	.long	_LCMinimumThrottle
.L59:
	.long	_HighPass
	.cfi_endproc
.LFE2:
	.size	_TestLCEntry, .-_TestLCEntry
	.align 2
	.global	_TestClutchSwitchDepressedEvent
	.type	_TestClutchSwitchDepressedEvent, @function
_TestClutchSwitchDepressedEvent:
.LFB3:
	.loc 1 117 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI12:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	sts.l	pr,@-r15
.LCFI13:
	.cfi_def_cfa_offset 8
	.cfi_offset 17, -8
	add	#-4,r15
.LCFI14:
	.cfi_def_cfa_offset 12
	mov	r15,r14
.LCFI15:
	.cfi_def_cfa_register 14
	.loc 1 118 0
	mov	r14,r1
	add	#3,r1
	mov	#0,r2
	mov.b	r2,@r1
	.loc 1 119 0
	mov.l	.L66,r1
	mov.b	@r1,r1
	extu.b	r1,r3
	mov	r14,r1
	add	#2,r1
	mov	#-128,r2
	and	r3,r2
	mov.b	r2,@r1
	.loc 1 120 0
	mov.w	.L69,r1
	add	#49,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	mov	r14,r2
	add	#2,r2
	mov.b	@r2,r2
	extu.b	r2,r2
	cmp/eq	r1,r2
	bt.s	.L64
	nop
	.loc 1 120 0 is_stmt 0 discriminator 1
	mov.l	.L68,r1
	jsr	@r1
	nop
	mov	r0,r1
	extu.b	r1,r1
	tst	r1,r1
	bt.s	.L64
	nop
	.loc 1 122 0 is_stmt 1
	mov	r14,r1
	add	#3,r1
	mov	#1,r2
	mov.b	r2,@r1
.L64:
	.loc 1 124 0
	mov.w	.L69,r1
	add	#49,r1
	mov	r14,r2
	add	#2,r2
	mov.b	@r2,r2
	mov.b	r2,@r1
	.loc 1 125 0
	mov	r14,r1
	add	#3,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	.loc 1 126 0
	mov	r1,r0
	add	#4,r14
	mov	r14,r15
	lds.l   @r15+,pr
	mov.l   @r15+,r14
	rts	
	nop
	.align 1
.L69:
	.short	-26944
.L70:
	.align 2
.L66:
	.long	-38415
.L68:
	.long	_TestClutchSwitch
	.cfi_endproc
.LFE3:
	.size	_TestClutchSwitchDepressedEvent, .-_TestClutchSwitchDepressedEvent
	.align 2
	.global	_TestLCExit
	.type	_TestLCExit, @function
_TestLCExit:
.LFB4:
	.loc 1 129 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI16:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	sts.l	pr,@-r15
.LCFI17:
	.cfi_def_cfa_offset 8
	.cfi_offset 17, -8
	mov	r15,r14
.LCFI18:
	.cfi_def_cfa_register 14
	.loc 1 130 0
	mov.l	.L75,r1
	fmov.s	@r1,fr2
	mov.w	.L76,r1
	add	#68,r1
	fmov.s	@r1,fr1
	fcmp/gt	fr1,fr2
	bt.s	.L72
	nop
	.loc 1 130 0 is_stmt 0 discriminator 1
	mov.l	.L77,r1
	fmov.s	@r1,fr1
	mov.l	.L78,r1
	fmov.s	@r1,fr2
	fcmp/gt	fr1,fr2
	bf.s	.L71
	nop
.L72:
	.loc 1 132 0 is_stmt 1
	mov.l	.L79,r1
	jsr	@r1
	nop
.L71:
	.loc 1 134 0
	mov	r14,r15
	lds.l   @r15+,pr
	mov.l   @r15+,r14
	rts	
	nop
	.align 1
.L76:
	.short	-26944
.L80:
	.align 2
.L75:
	.long	-38384
.L77:
	.long	-39108
.L78:
	.long	_LCMinimumThrottle
.L79:
	.long	_RevLimReset
	.cfi_endproc
.LFE4:
	.size	_TestLCExit, .-_TestLCExit
	.align 2
	.global	_TestFFSExit
	.type	_TestFFSExit, @function
_TestFFSExit:
.LFB5:
	.loc 1 137 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI19:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	sts.l	pr,@-r15
.LCFI20:
	.cfi_def_cfa_offset 8
	.cfi_offset 17, -8
	mov	r15,r14
.LCFI21:
	.cfi_def_cfa_register 14
	.loc 1 138 0
	mov.l	.L85,r1
	fmov.s	@r1,fr1
	mov.w	.L86,r1
	add	#100,r1
	fmov.s	@r1,fr2
	fcmp/gt	fr1,fr2
	bt.s	.L82
	nop
	.loc 1 138 0 is_stmt 0 discriminator 1
	mov.l	.L87,r1
	fmov.s	@r1,fr1
	mov.l	.L88,r1
	fmov.s	@r1,fr2
	fcmp/gt	fr1,fr2
	bf.s	.L81
	nop
.L82:
	.loc 1 140 0 is_stmt 1
	mov.l	.L89,r1
	jsr	@r1
	nop
.L81:
	.loc 1 142 0
	mov	r14,r15
	lds.l   @r15+,pr
	mov.l   @r15+,r14
	rts	
	nop
	.align 1
.L86:
	.short	-26944
.L90:
	.align 2
.L85:
	.long	-38384
.L87:
	.long	-39108
.L88:
	.long	_FFSMinimumThrottle
.L89:
	.long	_RevLimReset
	.cfi_endproc
.LFE5:
	.size	_TestFFSExit, .-_TestFFSExit
	.align 2
	.global	_RevLimCode
	.type	_RevLimCode, @function
_RevLimCode:
.LFB6:
	.loc 1 145 0
	.cfi_startproc
	mov.l	r8,@-r15
.LCFI22:
	.cfi_def_cfa_offset 4
	.cfi_offset 8, -4
	mov.l	r14,@-r15
.LCFI23:
	.cfi_def_cfa_offset 8
	.cfi_offset 14, -8
	fmov.s	fr12,@-r15
.LCFI24:
	.cfi_def_cfa_offset 12
	.cfi_offset 37, -12
	sts.l	pr,@-r15
.LCFI25:
	.cfi_def_cfa_offset 16
	.cfi_offset 17, -16
	add	#-28,r15
.LCFI26:
	.cfi_def_cfa_offset 44
	mov	r15,r14
.LCFI27:
	.cfi_def_cfa_register 14
	.loc 1 157 0
	mov	r14,r8
	add	#27,r8
	mov.l	.L108,r1
	jsr	@r1
	nop
	mov	r0,r1
	mov.b	r1,@r8
	.loc 1 159 0
	mov.l	.L109,r1
	jsr	@r1
	nop
	mov	r0,r1
	extu.b	r1,r1
	tst	r1,r1
	bt.s	.L92
	nop
	.loc 1 159 0 is_stmt 0 discriminator 1
	mov.l	.L110,r1
	jsr	@r1
	nop
	mov	r0,r1
	extu.b	r1,r1
	tst	r1,r1
	bt.s	.L93
	nop
.L92:
	.loc 1 164 0 is_stmt 1
	mov.l	.L111,r1
	jsr	@r1
	nop
	bra	.L94
	nop
	.align 1
.L93:
	.loc 1 166 0
	mov.w	.L114,r1
	add	#47,r1
	mov.b	@r1,r1
	extu.b	r1,r2
	mov	#1,r1
	cmp/eq	r1,r2
	bf.s	.L95
	nop
	.loc 1 168 0
	mov.l	.L113,r1
	jsr	@r1
	nop
	bra	.L94
	nop
	.align 1
.L95:
	.loc 1 170 0
	mov.w	.L114,r1
	add	#48,r1
	mov.b	@r1,r1
	extu.b	r1,r2
	mov	#2,r1
	cmp/eq	r1,r2
	bf.s	.L96
	nop
	.loc 1 172 0
	mov.l	.L115,r1
	jsr	@r1
	nop
	bra	.L94
	nop
	.align 1
.L96:
	.loc 1 175 0
	mov	r14,r1
	add	#27,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bt.s	.L97
	nop
	.loc 1 177 0
	mov.l	.L116,r1
	jsr	@r1
	nop
	bra	.L94
	nop
	.align 1
.L114:
	.short	-26944
.L117:
	.align 2
.L108:
	.long	_TestClutchSwitchDepressedEvent
.L109:
	.long	_TestClutchSwitch
.L110:
	.long	_TestBrakeSwitch
.L111:
	.long	_RevLimReset
.L113:
	.long	_TestLCExit
.L115:
	.long	_TestFFSExit
.L116:
	.long	_TestFFSEntry
	.align 1
.L97:
	.loc 1 179 0
	mov.w	.L144,r1
	add	#48,r1
	mov.b	@r1,r1
	extu.b	r1,r2
	mov	#1,r1
	cmp/eq	r1,r2
	bt.s	.L161
	nop
	bra	.L98
	nop
.L161:
	.loc 1 182 0
	mov.w	.L144,r1
	add	#46,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	tst	r1,r1
	bt.s	.L160
	nop
	bra	.L99
	nop
.L160:
.LBB2:
	.loc 1 184 0
	mov.w	.L144,r2
	mov	r14,r1
	add	#20,r1
	add	#80,r2
	fmov.s	@r2,fr1
	fmov.s	fr1,@r1
	.loc 1 186 0
	mov.w	.L144,r1
	add	#50,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	add	#-1,r1
	mov	r14,r8
	add	#-36,r8
	mov	r1,r4
	mov	#0,r5
	mov	#5,r6
	mov.l	.L124,r1
	jsr	@r1
	nop
	lds	r0,fpul
	fsts	fpul,fr1
	flds	fr1,fpul
	sts	fpul,r1
	mov.l	r1,@(52,r8)
	.loc 1 188 0
	mov.w	.L144,r1
	add	#50,r1
	mov.b	@r1,r1
	extu.b	r1,r1
	lds	r1,fpul
	fsts	fpul,fr1
	mov	r14,r8
	add	#-36,r8
	flds	fr1,fpul
	sts	fpul,r4
	mov	#0,r5
	mov	#5,r6
	mov.l	.L124,r1
	jsr	@r1
	nop
	lds	r0,fpul
	fsts	fpul,fr1
	flds	fr1,fpul
	sts	fpul,r1
	mov.l	r1,@(48,r8)
	.loc 1 189 0
	mov	r14,r1
	add	#8,r1
	mov.l	.L126,r3
	mov	r14,r2
	add	#-36,r2
	mov.l	@(52,r2),r2
	shll2	r2
	add	r3,r2
	fmov.s	@r2,fr1
	fmov.s	fr1,@r1
	.loc 1 190 0
	mov	r14,r1
	add	#4,r1
	mov.l	.L126,r3
	mov	r14,r2
	add	#-36,r2
	mov.l	@(48,r2),r2
	shll2	r2
	add	r3,r2
	fmov.s	@r2,fr1
	fmov.s	fr1,@r1
	.loc 1 191 0
	mov	r14,r1
	add	#20,r1
	mov	r14,r3
	add	#20,r3
	mov	r14,r2
	add	#4,r2
	fmov.s	@r3,fr2
	fmov.s	@r2,fr1
	fmul	fr2,fr1
	fmov.s	fr1,@r1
	.loc 1 192 0
	mov	r14,r1
	add	#8,r1
	fldi1	fr2
	fmov.s	@r1,fr1
	fdiv	fr1,fr2
	mov	r14,r1
	add	#20,r1
	mov	r14,r2
	add	#20,r2
	fmov.s	@r2,fr1
	fmul	fr2,fr1
	fmov.s	fr1,@r1
	.loc 1 195 0
	mov.w	.L144,r1
	add	#88,r1
	fmov.s	@r1,fr2
	mov	r14,r1
	add	#20,r1
	mov	r14,r2
	add	#20,r2
	fmov.s	@r2,fr1
	fadd	fr2,fr1
	fmov.s	fr1,@r1
	.loc 1 196 0
	mov.w	.L144,r8
	mov.w	.L144,r1
	add	#60,r1
	fmov.s	@r1,fr1
	mov	r14,r1
	add	#20,r1
	fmov.s	@r1,fr4
	fmov	fr1,fr5
	mov.l	.L140,r1
	jsr	@r1
	nop
	fmov	fr0,fr1
	mov	r8,r1
	add	#52,r1
	fmov.s	fr1,@r1
	.loc 1 197 0
	mov.w	.L144,r8
	mov.w	.L144,r1
	add	#52,r1
	fmov.s	@r1,fr12
	mov.w	.L144,r1
	add	#96,r1
	fmov.s	@r1,fr2
	fldi0	fr1
	fmov	fr2,fr4
	fmov	fr1,fr5
	mov.l	.L143,r1
	jsr	@r1
	nop
	fmov	fr0,fr1
	fmov	fr12,fr2
	fsub	fr1,fr2
	fmov	fr2,fr1
	mov	r8,r1
	add	#56,r1
	fmov.s	fr1,@r1
	bra	.L100
	nop
	.align 1
.L99:
.LBE2:
.LBB3:
	.loc 1 203 0
	mov.w	.L144,r1
	add	#60,r1
	fmov.s	@r1,fr12
	mov.w	.L144,r1
	add	#92,r1
	fmov.s	@r1,fr2
	fldi0	fr1
	fmov	fr2,fr4
	fmov	fr1,fr5
	mov.l	.L143,r1
	jsr	@r1
	nop
	fmov	fr0,fr1
	mov	r14,r1
	fmov	fr12,fr3
	fsub	fr1,fr3
	fmov	fr3,fr1
	fmov.s	fr1,@r1
	.loc 1 204 0
	mov.w	.L144,r8
	mov.w	.L144,r1
	add	#60,r1
	fmov.s	@r1,fr1
	mov	r14,r1
	fmov.s	@r1,fr4
	fmov	fr1,fr5
	mov.l	.L140,r1
	jsr	@r1
	nop
	fmov	fr0,fr1
	mov	r8,r1
	add	#52,r1
	fmov.s	fr1,@r1
	.loc 1 205 0
	mov.w	.L144,r8
	mov.w	.L144,r1
	add	#96,r1
	fmov.s	@r1,fr2
	fldi0	fr1
	fmov	fr2,fr4
	fmov	fr1,fr5
	mov.l	.L143,r1
	jsr	@r1
	nop
	fmov	fr0,fr1
	mov	r14,r1
	fmov.s	@r1,fr2
	fmov	fr2,fr3
	fsub	fr1,fr3
	fmov	fr3,fr1
	mov	r8,r1
	add	#56,r1
	fmov.s	fr1,@r1
.L100:
.LBE3:
	.loc 1 210 0
	mov.w	.L144,r1
	add	#48,r1
	mov	#2,r2
	mov.b	r2,@r1
	bra	.L94
	nop
	.align 1
.L144:
	.short	-26944
.L145:
	.align 2
.L124:
	.long	_BandPassInt
.L126:
	.long	_GearRatios
.L140:
	.long	_LowPass
.L143:
	.long	_HighPass
	.align 1
.L98:
	.loc 1 214 0
	mov.l	.L146,r1
	jsr	@r1
	nop
.L94:
	.loc 1 267 0
	mov.l	.L153,r1
	fmov.s	@r1,fr2
	mov.w	.L154,r1
	add	#52,r1
	fmov.s	@r1,fr1
	fcmp/gt	fr1,fr2
	bt.s	.L101
	nop
	.loc 1 267 0 is_stmt 0 discriminator 1
	mov.l	.L153,r1
	fmov.s	@r1,fr2
	mov.w	.L154,r1
	add	#60,r1
	fmov.s	@r1,fr1
	fcmp/gt	fr1,fr2
	bf.s	.L107
	nop
.L101:
	.loc 1 269 0 is_stmt 1
	mov.l	.L156,r1
	mov.l	.L156,r2
	mov.b	@r2,r2
	extu.b	r2,r3
	mov	#-128,r2
	or	r3,r2
	extu.b	r2,r2
	mov.b	r2,@r1
	bra	.L91
	nop
	.align 1
.L107:
	.loc 1 271 0
	mov.l	.L153,r1
	fmov.s	@r1,fr1
	mov.w	.L154,r1
	add	#56,r1
	fmov.s	@r1,fr2
	fcmp/gt	fr1,fr2
	bf.s	.L91
	nop
.L106:
	.loc 1 273 0
	mov.l	.L156,r1
	mov.l	.L156,r2
	mov.b	@r2,r2
	extu.b	r2,r2
	mov	#127,r3
	and	r3,r2
	extu.b	r2,r2
	mov.b	r2,@r1
.L91:
	.loc 1 282 0
	add	#28,r14
	mov	r14,r15
	lds.l   @r15+,pr
	fmov.s	@r15+,fr12
	mov.l   @r15+,r14
	mov.l   @r15+,r8
	rts	
	nop
	.align 1
.L154:
	.short	-26944
.L157:
	.align 2
.L146:
	.long	_TestLCEntry
.L153:
	.long	-38376
.L156:
	.long	-35604
	.cfi_endproc
.LFE6:
	.size	_RevLimCode, .-_RevLimCode
	.text
.Letext0:
	.file 2 "C:\\Dev\\MerpMod\\MerpMod\\RamVariables.h"
	.file 3 "C:\\Dev\\MerpMod\\MerpMod\\Externs.h"
	.file 4 "C:\\Dev\\MerpMod\\MerpMod\\enums.h"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.ualong	0x45f
	.uaword	0x2
	.ualong	.Ldebug_abbrev0
	.byte	0x4
	.uleb128 0x1
	.ualong	.LASF67
	.byte	0x1
	.ualong	.LASF68
	.ualong	.Ldebug_ranges0+0
	.ualong	0
	.ualong	0
	.ualong	.Ldebug_line0
	.uleb128 0x2
	.ualong	.LASF69
	.byte	0x4
	.byte	0x4
	.byte	0x4a
	.ualong	0x44
	.uleb128 0x3
	.ualong	.LASF0
	.sleb128 0
	.uleb128 0x3
	.ualong	.LASF1
	.sleb128 1
	.uleb128 0x3
	.ualong	.LASF2
	.sleb128 0
	.byte	0
	.uleb128 0x4
	.byte	0x2
	.byte	0x5
	.ualong	.LASF3
	.uleb128 0x4
	.byte	0x4
	.byte	0x4
	.ualong	.LASF4
	.uleb128 0x5
	.byte	0x4
	.byte	0x5
	.string	"int"
	.uleb128 0x4
	.byte	0x4
	.byte	0x5
	.ualong	.LASF5
	.uleb128 0x4
	.byte	0x4
	.byte	0x7
	.ualong	.LASF6
	.uleb128 0x4
	.byte	0x1
	.byte	0x6
	.ualong	.LASF7
	.uleb128 0x6
	.byte	0x70
	.byte	0x2
	.byte	0x12
	.ualong	0x2d3
	.uleb128 0x7
	.ualong	.LASF8
	.byte	0x2
	.byte	0x14
	.ualong	0x2d3
	.byte	0x2
	.byte	0x23
	.uleb128 0
	.uleb128 0x7
	.ualong	.LASF9
	.byte	0x2
	.byte	0x15
	.ualong	0x2d3
	.byte	0x2
	.byte	0x23
	.uleb128 0x1
	.uleb128 0x7
	.ualong	.LASF10
	.byte	0x2
	.byte	0x16
	.ualong	0x2d3
	.byte	0x2
	.byte	0x23
	.uleb128 0x2
	.uleb128 0x7
	.ualong	.LASF11
	.byte	0x2
	.byte	0x17
	.ualong	0x2d3
	.byte	0x2
	.byte	0x23
	.uleb128 0x3
	.uleb128 0x7
	.ualong	.LASF12
	.byte	0x2
	.byte	0x18
	.ualong	0x2da
	.byte	0x2
	.byte	0x23
	.uleb128 0x4
	.uleb128 0x7
	.ualong	.LASF13
	.byte	0x2
	.byte	0x19
	.ualong	0x2d3
	.byte	0x2
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x7
	.ualong	.LASF14
	.byte	0x2
	.byte	0x1a
	.ualong	0x2d3
	.byte	0x2
	.byte	0x23
	.uleb128 0x9
	.uleb128 0x7
	.ualong	.LASF15
	.byte	0x2
	.byte	0x1b
	.ualong	0x2d3
	.byte	0x2
	.byte	0x23
	.uleb128 0xa
	.uleb128 0x7
	.ualong	.LASF16
	.byte	0x2
	.byte	0x1c
	.ualong	0x2d3
	.byte	0x2
	.byte	0x23
	.uleb128 0xb
	.uleb128 0x7
	.ualong	.LASF17
	.byte	0x2
	.byte	0x40
	.ualong	0x2d3
	.byte	0x2
	.byte	0x23
	.uleb128 0xc
	.uleb128 0x7
	.ualong	.LASF18
	.byte	0x2
	.byte	0x41
	.ualong	0x2d3
	.byte	0x2
	.byte	0x23
	.uleb128 0xd
	.uleb128 0x7
	.ualong	.LASF19
	.byte	0x2
	.byte	0x42
	.ualong	0x2d3
	.byte	0x2
	.byte	0x23
	.uleb128 0xe
	.uleb128 0x7
	.ualong	.LASF20
	.byte	0x2
	.byte	0x43
	.ualong	0x2d3
	.byte	0x2
	.byte	0x23
	.uleb128 0xf
	.uleb128 0x7
	.ualong	.LASF21
	.byte	0x2
	.byte	0x44
	.ualong	0x4b
	.byte	0x2
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x7
	.ualong	.LASF22
	.byte	0x2
	.byte	0x45
	.ualong	0x4b
	.byte	0x2
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x7
	.ualong	.LASF23
	.byte	0x2
	.byte	0x46
	.ualong	0x4b
	.byte	0x2
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x7
	.ualong	.LASF24
	.byte	0x2
	.byte	0x47
	.ualong	0x4b
	.byte	0x2
	.byte	0x23
	.uleb128 0x1c
	.uleb128 0x7
	.ualong	.LASF25
	.byte	0x2
	.byte	0x48
	.ualong	0x4b
	.byte	0x2
	.byte	0x23
	.uleb128 0x20
	.uleb128 0x7
	.ualong	.LASF26
	.byte	0x2
	.byte	0x49
	.ualong	0x4b
	.byte	0x2
	.byte	0x23
	.uleb128 0x24
	.uleb128 0x7
	.ualong	.LASF27
	.byte	0x2
	.byte	0x4a
	.ualong	0x4b
	.byte	0x2
	.byte	0x23
	.uleb128 0x28
	.uleb128 0x7
	.ualong	.LASF28
	.byte	0x2
	.byte	0x50
	.ualong	0x2d3
	.byte	0x2
	.byte	0x23
	.uleb128 0x2c
	.uleb128 0x7
	.ualong	.LASF29
	.byte	0x2
	.byte	0x51
	.ualong	0x2d3
	.byte	0x2
	.byte	0x23
	.uleb128 0x2d
	.uleb128 0x7
	.ualong	.LASF30
	.byte	0x2
	.byte	0x52
	.ualong	0x2d3
	.byte	0x2
	.byte	0x23
	.uleb128 0x2e
	.uleb128 0x7
	.ualong	.LASF31
	.byte	0x2
	.byte	0x53
	.ualong	0x2d3
	.byte	0x2
	.byte	0x23
	.uleb128 0x2f
	.uleb128 0x7
	.ualong	.LASF32
	.byte	0x2
	.byte	0x54
	.ualong	0x2d3
	.byte	0x2
	.byte	0x23
	.uleb128 0x30
	.uleb128 0x7
	.ualong	.LASF33
	.byte	0x2
	.byte	0x55
	.ualong	0x2d3
	.byte	0x2
	.byte	0x23
	.uleb128 0x31
	.uleb128 0x7
	.ualong	.LASF34
	.byte	0x2
	.byte	0x56
	.ualong	0x2d3
	.byte	0x2
	.byte	0x23
	.uleb128 0x32
	.uleb128 0x7
	.ualong	.LASF35
	.byte	0x2
	.byte	0x57
	.ualong	0x67
	.byte	0x2
	.byte	0x23
	.uleb128 0x33
	.uleb128 0x7
	.ualong	.LASF36
	.byte	0x2
	.byte	0x58
	.ualong	0x4b
	.byte	0x2
	.byte	0x23
	.uleb128 0x34
	.uleb128 0x7
	.ualong	.LASF37
	.byte	0x2
	.byte	0x59
	.ualong	0x4b
	.byte	0x2
	.byte	0x23
	.uleb128 0x38
	.uleb128 0x7
	.ualong	.LASF38
	.byte	0x2
	.byte	0x5a
	.ualong	0x4b
	.byte	0x2
	.byte	0x23
	.uleb128 0x3c
	.uleb128 0x7
	.ualong	.LASF39
	.byte	0x2
	.byte	0x5b
	.ualong	0x4b
	.byte	0x2
	.byte	0x23
	.uleb128 0x40
	.uleb128 0x7
	.ualong	.LASF40
	.byte	0x2
	.byte	0x5c
	.ualong	0x4b
	.byte	0x2
	.byte	0x23
	.uleb128 0x44
	.uleb128 0x7
	.ualong	.LASF41
	.byte	0x2
	.byte	0x5d
	.ualong	0x4b
	.byte	0x2
	.byte	0x23
	.uleb128 0x48
	.uleb128 0x7
	.ualong	.LASF42
	.byte	0x2
	.byte	0x5e
	.ualong	0x4b
	.byte	0x2
	.byte	0x23
	.uleb128 0x4c
	.uleb128 0x7
	.ualong	.LASF43
	.byte	0x2
	.byte	0x5f
	.ualong	0x4b
	.byte	0x2
	.byte	0x23
	.uleb128 0x50
	.uleb128 0x7
	.ualong	.LASF44
	.byte	0x2
	.byte	0x60
	.ualong	0x4b
	.byte	0x2
	.byte	0x23
	.uleb128 0x54
	.uleb128 0x7
	.ualong	.LASF45
	.byte	0x2
	.byte	0x61
	.ualong	0x4b
	.byte	0x2
	.byte	0x23
	.uleb128 0x58
	.uleb128 0x7
	.ualong	.LASF46
	.byte	0x2
	.byte	0x62
	.ualong	0x4b
	.byte	0x2
	.byte	0x23
	.uleb128 0x5c
	.uleb128 0x7
	.ualong	.LASF47
	.byte	0x2
	.byte	0x63
	.ualong	0x4b
	.byte	0x2
	.byte	0x23
	.uleb128 0x60
	.uleb128 0x7
	.ualong	.LASF48
	.byte	0x2
	.byte	0x64
	.ualong	0x4b
	.byte	0x2
	.byte	0x23
	.uleb128 0x64
	.uleb128 0x8
	.ualong	.LASF49
	.byte	0x2
	.uaword	0x110
	.ualong	0x59
	.byte	0x2
	.byte	0x23
	.uleb128 0x68
	.uleb128 0x8
	.ualong	.LASF50
	.byte	0x2
	.uaword	0x111
	.ualong	0x67
	.byte	0x2
	.byte	0x23
	.uleb128 0x6c
	.byte	0
	.uleb128 0x4
	.byte	0x1
	.byte	0x8
	.ualong	.LASF51
	.uleb128 0x4
	.byte	0x4
	.byte	0x7
	.ualong	.LASF52
	.uleb128 0x9
	.ualong	.LASF70
	.byte	0x2
	.uaword	0x115
	.ualong	0x6e
	.uleb128 0xa
	.byte	0x1
	.ualong	.LASF53
	.byte	0x1
	.byte	0x32
	.ualong	.LFB0
	.ualong	.LFE0
	.ualong	.LLST0
	.byte	0x1
	.byte	0x40
	.uleb128 0xb
	.byte	0x1
	.ualong	.LASF54
	.byte	0x1
	.byte	0x4e
	.ualong	.LFB1
	.ualong	.LFE1
	.ualong	.LLST1
	.byte	0x1
	.byte	0x40
	.uleb128 0xa
	.byte	0x1
	.ualong	.LASF55
	.byte	0x1
	.byte	0x65
	.ualong	.LFB2
	.ualong	.LFE2
	.ualong	.LLST2
	.byte	0x1
	.byte	0x40
	.uleb128 0xc
	.byte	0x1
	.ualong	.LASF71
	.byte	0x1
	.byte	0x74
	.ualong	0x2d3
	.ualong	.LFB3
	.ualong	.LFE3
	.ualong	.LLST3
	.byte	0x1
	.byte	0x40
	.ualong	0x36a
	.uleb128 0xd
	.string	"ret"
	.byte	0x1
	.byte	0x76
	.ualong	0x2d3
	.byte	0x2
	.byte	0x91
	.sleb128 -9
	.uleb128 0xe
	.ualong	.LASF56
	.byte	0x1
	.byte	0x77
	.ualong	0x2d3
	.byte	0x2
	.byte	0x91
	.sleb128 -10
	.byte	0
	.uleb128 0xa
	.byte	0x1
	.ualong	.LASF57
	.byte	0x1
	.byte	0x80
	.ualong	.LFB4
	.ualong	.LFE4
	.ualong	.LLST4
	.byte	0x1
	.byte	0x40
	.uleb128 0xa
	.byte	0x1
	.ualong	.LASF58
	.byte	0x1
	.byte	0x88
	.ualong	.LFB5
	.ualong	.LFE5
	.ualong	.LLST5
	.byte	0x1
	.byte	0x40
	.uleb128 0xf
	.byte	0x1
	.ualong	.LASF72
	.byte	0x1
	.byte	0x90
	.ualong	.LFB6
	.ualong	.LFE6
	.ualong	.LLST6
	.byte	0x1
	.byte	0x40
	.ualong	0x42b
	.uleb128 0xe
	.ualong	.LASF59
	.byte	0x1
	.byte	0x9d
	.ualong	0x2d3
	.byte	0x2
	.byte	0x91
	.sleb128 -17
	.uleb128 0x10
	.ualong	.LBB2
	.ualong	.LBE2
	.ualong	0x412
	.uleb128 0xd
	.string	"cut"
	.byte	0x1
	.byte	0xb8
	.ualong	0x4b
	.byte	0x2
	.byte	0x91
	.sleb128 -24
	.uleb128 0xe
	.ualong	.LASF60
	.byte	0x1
	.byte	0xba
	.ualong	0x52
	.byte	0x2
	.byte	0x91
	.sleb128 -28
	.uleb128 0xe
	.ualong	.LASF61
	.byte	0x1
	.byte	0xbc
	.ualong	0x52
	.byte	0x2
	.byte	0x91
	.sleb128 -32
	.uleb128 0xe
	.ualong	.LASF62
	.byte	0x1
	.byte	0xbd
	.ualong	0x4b
	.byte	0x2
	.byte	0x91
	.sleb128 -36
	.uleb128 0xe
	.ualong	.LASF63
	.byte	0x1
	.byte	0xbe
	.ualong	0x4b
	.byte	0x2
	.byte	0x91
	.sleb128 -40
	.byte	0
	.uleb128 0x11
	.ualong	.LBB3
	.ualong	.LBE3
	.uleb128 0xd
	.string	"cut"
	.byte	0x1
	.byte	0xcb
	.ualong	0x4b
	.byte	0x2
	.byte	0x91
	.sleb128 -44
	.byte	0
	.byte	0
	.uleb128 0x12
	.ualong	0x4b
	.ualong	0x43b
	.uleb128 0x13
	.ualong	0x60
	.byte	0x5
	.byte	0
	.uleb128 0x14
	.ualong	.LASF64
	.byte	0x3
	.byte	0xce
	.ualong	0x42b
	.byte	0x1
	.byte	0x1
	.uleb128 0x14
	.ualong	.LASF65
	.byte	0x3
	.byte	0xd0
	.ualong	0x4b
	.byte	0x1
	.byte	0x1
	.uleb128 0x14
	.ualong	.LASF66
	.byte	0x3
	.byte	0xd1
	.ualong	0x4b
	.byte	0x1
	.byte	0x1
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x55
	.uleb128 0x6
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x52
	.uleb128 0x1
	.uleb128 0x10
	.uleb128 0x6
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x4
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x28
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x1c
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x8
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x16
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.uleb128 0x40
	.uleb128 0x6
	.uleb128 0x2116
	.uleb128 0xc
	.uleb128 0x36
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.uleb128 0x40
	.uleb128 0x6
	.uleb128 0x2117
	.uleb128 0xc
	.uleb128 0x36
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.uleb128 0x40
	.uleb128 0x6
	.uleb128 0x2116
	.uleb128 0xc
	.uleb128 0x36
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.uleb128 0x40
	.uleb128 0x6
	.uleb128 0x2116
	.uleb128 0xc
	.uleb128 0x36
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x14
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3c
	.uleb128 0xc
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_loc,"",@progbits
.Ldebug_loc0:
.LLST0:
	.ualong	.LFB0
	.ualong	.LCFI0
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI0
	.ualong	.LCFI1
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI1
	.ualong	.LCFI2
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI2
	.ualong	.LCFI3
	.uaword	0x2
	.byte	0x7f
	.sleb128 12
	.ualong	.LCFI3
	.ualong	.LCFI4
	.uaword	0x2
	.byte	0x7f
	.sleb128 16
	.ualong	.LCFI4
	.ualong	.LFE0
	.uaword	0x2
	.byte	0x7e
	.sleb128 16
	.ualong	0
	.ualong	0
.LLST1:
	.ualong	.LFB1
	.ualong	.LCFI5
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI5
	.ualong	.LCFI6
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI6
	.ualong	.LFE1
	.uaword	0x2
	.byte	0x7e
	.sleb128 4
	.ualong	0
	.ualong	0
.LLST2:
	.ualong	.LFB2
	.ualong	.LCFI7
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI7
	.ualong	.LCFI8
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI8
	.ualong	.LCFI9
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI9
	.ualong	.LCFI10
	.uaword	0x2
	.byte	0x7f
	.sleb128 12
	.ualong	.LCFI10
	.ualong	.LCFI11
	.uaword	0x2
	.byte	0x7f
	.sleb128 16
	.ualong	.LCFI11
	.ualong	.LFE2
	.uaword	0x2
	.byte	0x7e
	.sleb128 16
	.ualong	0
	.ualong	0
.LLST3:
	.ualong	.LFB3
	.ualong	.LCFI12
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI12
	.ualong	.LCFI13
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI13
	.ualong	.LCFI14
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI14
	.ualong	.LCFI15
	.uaword	0x2
	.byte	0x7f
	.sleb128 12
	.ualong	.LCFI15
	.ualong	.LFE3
	.uaword	0x2
	.byte	0x7e
	.sleb128 12
	.ualong	0
	.ualong	0
.LLST4:
	.ualong	.LFB4
	.ualong	.LCFI16
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI16
	.ualong	.LCFI17
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI17
	.ualong	.LCFI18
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI18
	.ualong	.LFE4
	.uaword	0x2
	.byte	0x7e
	.sleb128 8
	.ualong	0
	.ualong	0
.LLST5:
	.ualong	.LFB5
	.ualong	.LCFI19
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI19
	.ualong	.LCFI20
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI20
	.ualong	.LCFI21
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI21
	.ualong	.LFE5
	.uaword	0x2
	.byte	0x7e
	.sleb128 8
	.ualong	0
	.ualong	0
.LLST6:
	.ualong	.LFB6
	.ualong	.LCFI22
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI22
	.ualong	.LCFI23
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI23
	.ualong	.LCFI24
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI24
	.ualong	.LCFI25
	.uaword	0x2
	.byte	0x7f
	.sleb128 12
	.ualong	.LCFI25
	.ualong	.LCFI26
	.uaword	0x2
	.byte	0x7f
	.sleb128 16
	.ualong	.LCFI26
	.ualong	.LCFI27
	.uaword	0x2
	.byte	0x7f
	.sleb128 44
	.ualong	.LCFI27
	.ualong	.LFE6
	.uaword	0x2
	.byte	0x7e
	.sleb128 44
	.ualong	0
	.ualong	0
	.section	.debug_aranges,"",@progbits
	.ualong	0x4c
	.uaword	0x2
	.ualong	.Ldebug_info0
	.byte	0x4
	.byte	0
	.uaword	0
	.uaword	0
	.ualong	.LFB0
	.ualong	.LFE0-.LFB0
	.ualong	.LFB1
	.ualong	.LFE1-.LFB1
	.ualong	.LFB2
	.ualong	.LFE2-.LFB2
	.ualong	.LFB3
	.ualong	.LFE3-.LFB3
	.ualong	.LFB4
	.ualong	.LFE4-.LFB4
	.ualong	.LFB5
	.ualong	.LFE5-.LFB5
	.ualong	.LFB6
	.ualong	.LFE6-.LFB6
	.ualong	0
	.ualong	0
	.section	.debug_ranges,"",@progbits
.Ldebug_ranges0:
	.ualong	.LFB0
	.ualong	.LFE0
	.ualong	.LFB1
	.ualong	.LFE1
	.ualong	.LFB2
	.ualong	.LFE2
	.ualong	.LFB3
	.ualong	.LFE3
	.ualong	.LFB4
	.ualong	.LFE4
	.ualong	.LFB5
	.ualong	.LFE5
	.ualong	.LFB6
	.ualong	.LFE6
	.ualong	0
	.ualong	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF30:
	.string	"FlatFootShiftMode"
.LASF34:
	.string	"FFSGear"
.LASF41:
	.string	"LaunchControlCut"
.LASF44:
	.string	"FlatFootShiftRpmThreshold"
.LASF55:
	.string	"TestLCEntry"
.LASF20:
	.string	"sdempty1"
.LASF3:
	.string	"short int"
.LASF26:
	.string	"SDMafBlendRatio"
.LASF18:
	.string	"MafMode"
.LASF6:
	.string	"sizetype"
.LASF8:
	.string	"RamVariableStart"
.LASF12:
	.string	"ECUIdentifier"
.LASF17:
	.string	"SDInitFlag"
.LASF42:
	.string	"LaunchControlHyst"
.LASF72:
	.string	"RevLimCode"
.LASF68:
	.string	"C:\\Dev\\MerpMod\\MerpMod\\RevLimiter.c"
.LASF10:
	.string	"CruiseCoastLast"
.LASF48:
	.string	"FlatFootShiftSpeedThreshold"
.LASF2:
	.string	"FlatFootShiftModeAuto"
.LASF27:
	.string	"SDMafFromBlend"
.LASF36:
	.string	"RevLimCut"
.LASF23:
	.string	"MafFromSensor"
.LASF4:
	.string	"float"
.LASF65:
	.string	"FFSMinimumThrottle"
.LASF21:
	.string	"VolumetricEfficiency"
.LASF5:
	.string	"long int"
.LASF56:
	.string	"result"
.LASF70:
	.string	"RamVariables"
.LASF53:
	.string	"RevLimReset"
.LASF39:
	.string	"RedLineHyst"
.LASF66:
	.string	"LCMinimumThrottle"
.LASF51:
	.string	"unsigned char"
.LASF64:
	.string	"GearRatios"
.LASF45:
	.string	"FlatFootShiftAutoDelta"
.LASF28:
	.string	"RevLimInitFlag"
.LASF67:
	.string	"GNU C 4.7-GNUSH_v13.01"
.LASF52:
	.string	"long unsigned int"
.LASF43:
	.string	"FFSRPM"
.LASF50:
	.string	"RamHoleEndMarker"
.LASF47:
	.string	"FlatFootShiftHyst"
.LASF7:
	.string	"char"
.LASF25:
	.string	"DeltaMapCompensation"
.LASF22:
	.string	"MafFromSpeedDensity"
.LASF14:
	.string	"blank0"
.LASF15:
	.string	"blank1"
.LASF16:
	.string	"blank2"
.LASF58:
	.string	"TestFFSExit"
.LASF0:
	.string	"FlatFootShiftModeDisabled"
.LASF9:
	.string	"VinAuth"
.LASF11:
	.string	"CruiseResumeLast"
.LASF19:
	.string	"SDempty"
.LASF60:
	.string	"gear1"
.LASF61:
	.string	"gear2"
.LASF31:
	.string	"LCEngaged"
.LASF1:
	.string	"FlatFootShiftModeStatic"
.LASF32:
	.string	"FFSEngaged"
.LASF37:
	.string	"RevLimResume"
.LASF62:
	.string	"ratio1"
.LASF63:
	.string	"ratio2"
.LASF29:
	.string	"RevLimMode"
.LASF69:
	.string	"FlatFootShiftModeValues"
.LASF13:
	.string	"HardResetFlag"
.LASF46:
	.string	"FlatFootShiftStaticDelta"
.LASF24:
	.string	"AtmosphericCompensation"
.LASF59:
	.string	"testClutchDepressed"
.LASF38:
	.string	"RedLineCut"
.LASF71:
	.string	"TestClutchSwitchDepressedEvent"
.LASF49:
	.string	"RamHoleSpace"
.LASF57:
	.string	"TestLCExit"
.LASF54:
	.string	"TestFFSEntry"
.LASF35:
	.string	"eleemee2"
.LASF33:
	.string	"ClutchSwitchLast"
.LASF40:
	.string	"LaunchControlSpeedMax"
	.ident	"GCC: (GNU) 4.7-GNUSH_v13.01"
