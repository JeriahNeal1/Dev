	.file	"Functions.c"
	.text
	.text
.Ltext0:
	.cfi_sections	.debug_frame
	.section	RomHole_Code,"ax",@progbits
	.align 2
	.global	_Abs
	.type	_Abs, @function
_Abs:
.LFB0:
	.file 1 "C:\\Dev\\MerpMod\\MerpMod\\Functions.c"
	.loc 1 18 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI0:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	add	#-4,r15
.LCFI1:
	.cfi_def_cfa_offset 8
	mov	r15,r14
.LCFI2:
	.cfi_def_cfa_register 14
	mov	r14,r1
	fmov.s	fr4,@r1
	.loc 1 19 0
	mov	r14,r1
	fmov.s	@r1,fr2
	fldi0	fr1
	fcmp/gt	fr1,fr2
	bf.s	.L6
	nop
.L5:
	.loc 1 20 0
	mov	r14,r1
	fmov.s	@r1,fr1
	bra	.L4
	nop
	.align 1
.L6:
	.loc 1 22 0
	mov	r14,r1
	fmov.s	@r1,fr1
	fneg	fr1
.L4:
	.loc 1 23 0
	fmov	fr1,fr0
	add	#4,r14
	mov	r14,r15
	mov.l   @r15+,r14
	rts	
	nop
	.cfi_endproc
.LFE0:
	.size	_Abs, .-_Abs
	.align 2
	.global	_LowPass
	.type	_LowPass, @function
_LowPass:
.LFB1:
	.loc 1 26 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI3:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	add	#-8,r15
.LCFI4:
	.cfi_def_cfa_offset 12
	mov	r15,r14
.LCFI5:
	.cfi_def_cfa_register 14
	mov	r14,r1
	add	#4,r1
	fmov.s	fr4,@r1
	mov	r14,r1
	fmov.s	fr5,@r1
	.loc 1 27 0
	mov	r14,r2
	add	#4,r2
	mov	r14,r1
	fmov.s	@r2,fr1
	fmov.s	@r1,fr2
	fcmp/gt	fr1,fr2
	bf.s	.L12
	nop
.L11:
	.loc 1 28 0
	mov	r14,r1
	add	#4,r1
	fmov.s	@r1,fr1
	bra	.L10
	nop
	.align 1
.L12:
	.loc 1 30 0
	mov	r14,r1
	fmov.s	@r1,fr1
.L10:
	.loc 1 31 0
	fmov	fr1,fr0
	add	#8,r14
	mov	r14,r15
	mov.l   @r15+,r14
	rts	
	nop
	.cfi_endproc
.LFE1:
	.size	_LowPass, .-_LowPass
	.align 2
	.global	_HighPass
	.type	_HighPass, @function
_HighPass:
.LFB2:
	.loc 1 34 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI6:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	add	#-8,r15
.LCFI7:
	.cfi_def_cfa_offset 12
	mov	r15,r14
.LCFI8:
	.cfi_def_cfa_register 14
	mov	r14,r1
	add	#4,r1
	fmov.s	fr4,@r1
	mov	r14,r1
	fmov.s	fr5,@r1
	.loc 1 35 0
	mov	r14,r2
	add	#4,r2
	mov	r14,r1
	fmov.s	@r2,fr2
	fmov.s	@r1,fr1
	fcmp/gt	fr1,fr2
	bf.s	.L18
	nop
.L17:
	.loc 1 36 0
	mov	r14,r1
	add	#4,r1
	fmov.s	@r1,fr1
	bra	.L16
	nop
	.align 1
.L18:
	.loc 1 38 0
	mov	r14,r1
	fmov.s	@r1,fr1
.L16:
	.loc 1 39 0
	fmov	fr1,fr0
	add	#8,r14
	mov	r14,r15
	mov.l   @r15+,r14
	rts	
	nop
	.cfi_endproc
.LFE2:
	.size	_HighPass, .-_HighPass
	.align 2
	.global	_BandPass
	.type	_BandPass, @function
_BandPass:
.LFB3:
	.loc 1 42 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI9:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	add	#-12,r15
.LCFI10:
	.cfi_def_cfa_offset 16
	mov	r15,r14
.LCFI11:
	.cfi_def_cfa_register 14
	mov	r14,r1
	add	#8,r1
	fmov.s	fr4,@r1
	mov	r14,r1
	add	#4,r1
	fmov.s	fr5,@r1
	mov	r14,r1
	fmov.s	fr6,@r1
	.loc 1 43 0
	mov	r14,r2
	add	#8,r2
	mov	r14,r1
	fmov.s	@r2,fr2
	fmov.s	@r1,fr1
	fcmp/gt	fr1,fr2
	bf.s	.L27
	nop
.L25:
	.loc 1 44 0
	mov	r14,r1
	fmov.s	@r1,fr1
	bra	.L22
	nop
	.align 1
.L27:
	.loc 1 45 0
	mov	r14,r2
	add	#8,r2
	mov	r14,r1
	add	#4,r1
	fmov.s	@r2,fr1
	fmov.s	@r1,fr2
	fcmp/gt	fr1,fr2
	bf.s	.L28
	nop
.L26:
	.loc 1 46 0
	mov	r14,r1
	add	#4,r1
	fmov.s	@r1,fr1
	bra	.L22
	nop
	.align 1
.L28:
	.loc 1 48 0
	mov	r14,r1
	add	#8,r1
	fmov.s	@r1,fr1
.L22:
	.loc 1 49 0
	fmov	fr1,fr0
	add	#12,r14
	mov	r14,r15
	mov.l   @r15+,r14
	rts	
	nop
	.cfi_endproc
.LFE3:
	.size	_BandPass, .-_BandPass
	.align 2
	.global	_BandPassInt
	.type	_BandPassInt, @function
_BandPassInt:
.LFB4:
	.loc 1 52 0
	.cfi_startproc
	mov.l	r14,@-r15
.LCFI12:
	.cfi_def_cfa_offset 4
	.cfi_offset 14, -4
	add	#-12,r15
.LCFI13:
	.cfi_def_cfa_offset 16
	mov	r15,r14
.LCFI14:
	.cfi_def_cfa_register 14
	mov	r14,r1
	add	#-52,r1
	mov.l	r4,@(60,r1)
	mov	r14,r1
	add	#-52,r1
	mov.l	r5,@(56,r1)
	mov	r14,r1
	add	#-52,r1
	mov.l	r6,@(52,r1)
	.loc 1 53 0
	mov	r14,r2
	add	#-52,r2
	mov	r14,r1
	add	#-52,r1
	mov.l	@(60,r2),r2
	mov.l	@(52,r1),r1
	cmp/gt	r1,r2
	bf.s	.L30
	nop
	.loc 1 54 0
	mov	r14,r1
	add	#-52,r1
	mov.l	@(52,r1),r1
	bra	.L31
	nop
	.align 1
.L30:
	.loc 1 55 0
	mov	r14,r2
	add	#-52,r2
	mov	r14,r1
	add	#-52,r1
	mov.l	@(60,r2),r2
	mov.l	@(56,r1),r1
	cmp/ge	r1,r2
	bt.s	.L32
	nop
	.loc 1 56 0
	mov	r14,r1
	add	#-52,r1
	mov.l	@(56,r1),r1
	bra	.L31
	nop
	.align 1
.L32:
	.loc 1 58 0
	mov	r14,r1
	add	#-52,r1
	mov.l	@(60,r1),r1
.L31:
	lds	r1,fpul
	fsts	fpul,fr1
	.loc 1 59 0
	flds	fr1,fpul
	sts	fpul,r0
	add	#12,r14
	mov	r14,r15
	mov.l   @r15+,r14
	rts	
	nop
	.cfi_endproc
.LFE4:
	.size	_BandPassInt, .-_BandPassInt
	.align 2
	.global	_Smooth
	.type	_Smooth, @function
_Smooth:
.LFB5:
	.loc 1 62 0
	.cfi_startproc
	mov.l	r8,@-r15
.LCFI15:
	.cfi_def_cfa_offset 4
	.cfi_offset 8, -4
	mov.l	r14,@-r15
.LCFI16:
	.cfi_def_cfa_offset 8
	.cfi_offset 14, -8
	sts.l	pr,@-r15
.LCFI17:
	.cfi_def_cfa_offset 12
	.cfi_offset 17, -12
	add	#-24,r15
.LCFI18:
	.cfi_def_cfa_offset 36
	mov	r15,r14
.LCFI19:
	.cfi_def_cfa_register 14
	mov	r14,r1
	add	#8,r1
	fmov.s	fr4,@r1
	mov	r14,r1
	add	#4,r1
	fmov.s	fr5,@r1
	mov	r14,r1
	fmov.s	fr6,@r1
	.loc 1 63 0
	mov	r14,r1
	add	#20,r1
	mov	r14,r2
	fmov.s	@r2,fr1
	fmov.s	fr1,@r1
	.loc 1 64 0
	mov	r14,r1
	add	#16,r1
	mov	r14,r3
	add	#4,r3
	mov	r14,r2
	fmov.s	@r3,fr2
	fmov.s	@r2,fr1
	fmov	fr2,fr3
	fsub	fr1,fr3
	fmov	fr3,fr1
	fmov.s	fr1,@r1
	.loc 1 65 0
	mov	r14,r8
	add	#12,r8
	mov	r14,r1
	add	#8,r1
	mova	.L35,r0
	fmov.s	@r0,fr2
	fldi1	fr1
	fmov.s	@r1,fr4
	fmov	fr2,fr5
	fmov	fr1,fr6
	mov.l	.L36,r1
	jsr	@r1
	nop
	fmov	fr0,fr1
	fmov.s	fr1,@r8
	.loc 1 66 0
	mov	r14,r2
	add	#16,r2
	mov	r14,r1
	add	#12,r1
	fmov.s	@r2,fr2
	fmov.s	@r1,fr1
	fmul	fr1,fr2
	mov	r14,r1
	add	#20,r1
	mov	r14,r2
	add	#20,r2
	fmov.s	@r2,fr1
	fadd	fr2,fr1
	fmov.s	fr1,@r1
	.loc 1 67 0
	mov	r14,r1
	add	#20,r1
	fmov.s	@r1,fr1
	.loc 1 68 0
	fmov	fr1,fr0
	add	#24,r14
	mov	r14,r15
	lds.l   @r15+,pr
	mov.l   @r15+,r14
	mov.l   @r15+,r8
	rts	
	nop
.L37:
	.align 2
.L35:
	.long	1036831949
.L36:
	.long	_BandPass
	.cfi_endproc
.LFE5:
	.size	_Smooth, .-_Smooth
	.text
.Letext0:
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.ualong	0x204
	.uaword	0x2
	.ualong	.Ldebug_abbrev0
	.byte	0x4
	.uleb128 0x1
	.ualong	.LASF20
	.byte	0x1
	.ualong	.LASF21
	.ualong	.Ldebug_ranges0+0
	.ualong	0
	.ualong	0
	.ualong	.Ldebug_line0
	.uleb128 0x2
	.byte	0x2
	.byte	0x5
	.ualong	.LASF0
	.uleb128 0x2
	.byte	0x4
	.byte	0x4
	.ualong	.LASF1
	.uleb128 0x3
	.byte	0x4
	.byte	0x5
	.string	"int"
	.uleb128 0x2
	.byte	0x4
	.byte	0x5
	.ualong	.LASF2
	.uleb128 0x2
	.byte	0x4
	.byte	0x7
	.ualong	.LASF3
	.uleb128 0x2
	.byte	0x1
	.byte	0x6
	.ualong	.LASF4
	.uleb128 0x2
	.byte	0x1
	.byte	0x8
	.ualong	.LASF5
	.uleb128 0x2
	.byte	0x4
	.byte	0x7
	.ualong	.LASF6
	.uleb128 0x4
	.byte	0x1
	.string	"Abs"
	.byte	0x1
	.byte	0x11
	.byte	0x1
	.ualong	0x2c
	.ualong	.LFB0
	.ualong	.LFE0
	.ualong	.LLST0
	.byte	0x1
	.byte	0x40
	.ualong	0x8b
	.uleb128 0x5
	.ualong	.LASF8
	.byte	0x1
	.byte	0x11
	.ualong	0x2c
	.byte	0x2
	.byte	0x91
	.sleb128 -8
	.byte	0
	.uleb128 0x6
	.byte	0x1
	.ualong	.LASF7
	.byte	0x1
	.byte	0x19
	.byte	0x1
	.ualong	0x2c
	.ualong	.LFB1
	.ualong	.LFE1
	.ualong	.LLST1
	.byte	0x1
	.byte	0x40
	.ualong	0xc7
	.uleb128 0x5
	.ualong	.LASF8
	.byte	0x1
	.byte	0x19
	.ualong	0x2c
	.byte	0x2
	.byte	0x91
	.sleb128 -8
	.uleb128 0x5
	.ualong	.LASF9
	.byte	0x1
	.byte	0x19
	.ualong	0x2c
	.byte	0x2
	.byte	0x91
	.sleb128 -12
	.byte	0
	.uleb128 0x6
	.byte	0x1
	.ualong	.LASF10
	.byte	0x1
	.byte	0x21
	.byte	0x1
	.ualong	0x2c
	.ualong	.LFB2
	.ualong	.LFE2
	.ualong	.LLST2
	.byte	0x1
	.byte	0x40
	.ualong	0x103
	.uleb128 0x5
	.ualong	.LASF8
	.byte	0x1
	.byte	0x21
	.ualong	0x2c
	.byte	0x2
	.byte	0x91
	.sleb128 -8
	.uleb128 0x5
	.ualong	.LASF9
	.byte	0x1
	.byte	0x21
	.ualong	0x2c
	.byte	0x2
	.byte	0x91
	.sleb128 -12
	.byte	0
	.uleb128 0x6
	.byte	0x1
	.ualong	.LASF11
	.byte	0x1
	.byte	0x29
	.byte	0x1
	.ualong	0x2c
	.ualong	.LFB3
	.ualong	.LFE3
	.ualong	.LLST3
	.byte	0x1
	.byte	0x40
	.ualong	0x14d
	.uleb128 0x5
	.ualong	.LASF8
	.byte	0x1
	.byte	0x29
	.ualong	0x2c
	.byte	0x2
	.byte	0x91
	.sleb128 -8
	.uleb128 0x5
	.ualong	.LASF12
	.byte	0x1
	.byte	0x29
	.ualong	0x2c
	.byte	0x2
	.byte	0x91
	.sleb128 -12
	.uleb128 0x5
	.ualong	.LASF13
	.byte	0x1
	.byte	0x29
	.ualong	0x2c
	.byte	0x2
	.byte	0x91
	.sleb128 -16
	.byte	0
	.uleb128 0x6
	.byte	0x1
	.ualong	.LASF14
	.byte	0x1
	.byte	0x33
	.byte	0x1
	.ualong	0x33
	.ualong	.LFB4
	.ualong	.LFE4
	.ualong	.LLST4
	.byte	0x1
	.byte	0x40
	.ualong	0x197
	.uleb128 0x5
	.ualong	.LASF8
	.byte	0x1
	.byte	0x33
	.ualong	0x33
	.byte	0x2
	.byte	0x91
	.sleb128 -8
	.uleb128 0x5
	.ualong	.LASF12
	.byte	0x1
	.byte	0x33
	.ualong	0x33
	.byte	0x2
	.byte	0x91
	.sleb128 -12
	.uleb128 0x5
	.ualong	.LASF13
	.byte	0x1
	.byte	0x33
	.ualong	0x33
	.byte	0x2
	.byte	0x91
	.sleb128 -16
	.byte	0
	.uleb128 0x7
	.byte	0x1
	.ualong	.LASF22
	.byte	0x1
	.byte	0x3d
	.byte	0x1
	.ualong	0x2c
	.ualong	.LFB5
	.ualong	.LFE5
	.ualong	.LLST5
	.byte	0x1
	.byte	0x40
	.uleb128 0x5
	.ualong	.LASF15
	.byte	0x1
	.byte	0x3d
	.ualong	0x2c
	.byte	0x2
	.byte	0x91
	.sleb128 -28
	.uleb128 0x5
	.ualong	.LASF8
	.byte	0x1
	.byte	0x3d
	.ualong	0x2c
	.byte	0x2
	.byte	0x91
	.sleb128 -32
	.uleb128 0x5
	.ualong	.LASF16
	.byte	0x1
	.byte	0x3d
	.ualong	0x2c
	.byte	0x2
	.byte	0x91
	.sleb128 -36
	.uleb128 0x8
	.ualong	.LASF17
	.byte	0x1
	.byte	0x3f
	.ualong	0x2c
	.byte	0x2
	.byte	0x91
	.sleb128 -16
	.uleb128 0x8
	.ualong	.LASF18
	.byte	0x1
	.byte	0x40
	.ualong	0x2c
	.byte	0x2
	.byte	0x91
	.sleb128 -20
	.uleb128 0x8
	.ualong	.LASF19
	.byte	0x1
	.byte	0x41
	.ualong	0x2c
	.byte	0x2
	.byte	0x91
	.sleb128 -24
	.byte	0
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x55
	.uleb128 0x6
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x52
	.uleb128 0x1
	.uleb128 0x10
	.uleb128 0x6
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x8
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x27
	.uleb128 0xc
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.uleb128 0x40
	.uleb128 0x6
	.uleb128 0x2117
	.uleb128 0xc
	.uleb128 0x36
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x27
	.uleb128 0xc
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.uleb128 0x40
	.uleb128 0x6
	.uleb128 0x2117
	.uleb128 0xc
	.uleb128 0x36
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x27
	.uleb128 0xc
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x1
	.uleb128 0x40
	.uleb128 0x6
	.uleb128 0x2116
	.uleb128 0xc
	.uleb128 0x36
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_loc,"",@progbits
.Ldebug_loc0:
.LLST0:
	.ualong	.LFB0
	.ualong	.LCFI0
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI0
	.ualong	.LCFI1
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI1
	.ualong	.LCFI2
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI2
	.ualong	.LFE0
	.uaword	0x2
	.byte	0x7e
	.sleb128 8
	.ualong	0
	.ualong	0
.LLST1:
	.ualong	.LFB1
	.ualong	.LCFI3
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI3
	.ualong	.LCFI4
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI4
	.ualong	.LCFI5
	.uaword	0x2
	.byte	0x7f
	.sleb128 12
	.ualong	.LCFI5
	.ualong	.LFE1
	.uaword	0x2
	.byte	0x7e
	.sleb128 12
	.ualong	0
	.ualong	0
.LLST2:
	.ualong	.LFB2
	.ualong	.LCFI6
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI6
	.ualong	.LCFI7
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI7
	.ualong	.LCFI8
	.uaword	0x2
	.byte	0x7f
	.sleb128 12
	.ualong	.LCFI8
	.ualong	.LFE2
	.uaword	0x2
	.byte	0x7e
	.sleb128 12
	.ualong	0
	.ualong	0
.LLST3:
	.ualong	.LFB3
	.ualong	.LCFI9
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI9
	.ualong	.LCFI10
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI10
	.ualong	.LCFI11
	.uaword	0x2
	.byte	0x7f
	.sleb128 16
	.ualong	.LCFI11
	.ualong	.LFE3
	.uaword	0x2
	.byte	0x7e
	.sleb128 16
	.ualong	0
	.ualong	0
.LLST4:
	.ualong	.LFB4
	.ualong	.LCFI12
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI12
	.ualong	.LCFI13
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI13
	.ualong	.LCFI14
	.uaword	0x2
	.byte	0x7f
	.sleb128 16
	.ualong	.LCFI14
	.ualong	.LFE4
	.uaword	0x2
	.byte	0x7e
	.sleb128 16
	.ualong	0
	.ualong	0
.LLST5:
	.ualong	.LFB5
	.ualong	.LCFI15
	.uaword	0x2
	.byte	0x7f
	.sleb128 0
	.ualong	.LCFI15
	.ualong	.LCFI16
	.uaword	0x2
	.byte	0x7f
	.sleb128 4
	.ualong	.LCFI16
	.ualong	.LCFI17
	.uaword	0x2
	.byte	0x7f
	.sleb128 8
	.ualong	.LCFI17
	.ualong	.LCFI18
	.uaword	0x2
	.byte	0x7f
	.sleb128 12
	.ualong	.LCFI18
	.ualong	.LCFI19
	.uaword	0x2
	.byte	0x7f
	.sleb128 36
	.ualong	.LCFI19
	.ualong	.LFE5
	.uaword	0x2
	.byte	0x7e
	.sleb128 36
	.ualong	0
	.ualong	0
	.section	.debug_aranges,"",@progbits
	.ualong	0x44
	.uaword	0x2
	.ualong	.Ldebug_info0
	.byte	0x4
	.byte	0
	.uaword	0
	.uaword	0
	.ualong	.LFB0
	.ualong	.LFE0-.LFB0
	.ualong	.LFB1
	.ualong	.LFE1-.LFB1
	.ualong	.LFB2
	.ualong	.LFE2-.LFB2
	.ualong	.LFB3
	.ualong	.LFE3-.LFB3
	.ualong	.LFB4
	.ualong	.LFE4-.LFB4
	.ualong	.LFB5
	.ualong	.LFE5-.LFB5
	.ualong	0
	.ualong	0
	.section	.debug_ranges,"",@progbits
.Ldebug_ranges0:
	.ualong	.LFB0
	.ualong	.LFE0
	.ualong	.LFB1
	.ualong	.LFE1
	.ualong	.LFB2
	.ualong	.LFE2
	.ualong	.LFB3
	.ualong	.LFE3
	.ualong	.LFB4
	.ualong	.LFE4
	.ualong	.LFB5
	.ualong	.LFE5
	.ualong	0
	.ualong	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF11:
	.string	"BandPass"
.LASF20:
	.string	"GNU C 4.7-GNUSH_v13.01"
.LASF15:
	.string	"smoothingFactor"
.LASF8:
	.string	"input"
.LASF6:
	.string	"long unsigned int"
.LASF9:
	.string	"limit"
.LASF10:
	.string	"HighPass"
.LASF14:
	.string	"BandPassInt"
.LASF17:
	.string	"output"
.LASF12:
	.string	"lowlim"
.LASF5:
	.string	"unsigned char"
.LASF4:
	.string	"char"
.LASF2:
	.string	"long int"
.LASF21:
	.string	"C:\\Dev\\MerpMod\\MerpMod\\Functions.c"
.LASF13:
	.string	"highlim"
.LASF16:
	.string	"previous"
.LASF1:
	.string	"float"
.LASF19:
	.string	"smooth"
.LASF0:
	.string	"short int"
.LASF18:
	.string	"diff"
.LASF3:
	.string	"sizetype"
.LASF7:
	.string	"LowPass"
.LASF22:
	.string	"Smooth"
	.ident	"GCC: (GNU) 4.7-GNUSH_v13.01"
