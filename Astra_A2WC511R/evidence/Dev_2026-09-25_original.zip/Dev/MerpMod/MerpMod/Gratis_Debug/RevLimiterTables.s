	.file	"RevLimiterTables.c"
	.text
	.text
.Ltext0:
	.cfi_sections	.debug_frame
	.global	_DefaultRevLimMode
	.section	RomHole_RevLimTables,"aw",@progbits
	.align 2
	.type	_DefaultRevLimMode, @object
	.size	_DefaultRevLimMode, 1
_DefaultRevLimMode:
	.byte	1
	.global	_DefaultRedLineCut
	.align 2
	.type	_DefaultRedLineCut, @object
	.size	_DefaultRedLineCut, 4
_DefaultRedLineCut:
	.long	1172373504
	.global	_DefaultRedLineHyst
	.align 2
	.type	_DefaultRedLineHyst, @object
	.size	_DefaultRedLineHyst, 4
_DefaultRedLineHyst:
	.long	1112014848
	.global	_DefaultFlatFootShiftHyst
	.align 2
	.type	_DefaultFlatFootShiftHyst, @object
	.size	_DefaultFlatFootShiftHyst, 4
_DefaultFlatFootShiftHyst:
	.long	1112014848
	.global	_DefaultFlatFootShiftStaticDelta
	.align 2
	.type	_DefaultFlatFootShiftStaticDelta, @object
	.size	_DefaultFlatFootShiftStaticDelta, 4
_DefaultFlatFootShiftStaticDelta:
	.long	1165623296
	.global	_DefaultFlatFootShiftSpeedThreshold
	.align 2
	.type	_DefaultFlatFootShiftSpeedThreshold, @object
	.size	_DefaultFlatFootShiftSpeedThreshold, 4
_DefaultFlatFootShiftSpeedThreshold:
	.long	1109393408
	.global	_DefaultFlatFootShiftRpmThreshold
	.align 2
	.type	_DefaultFlatFootShiftRpmThreshold, @object
	.size	_DefaultFlatFootShiftRpmThreshold, 4
_DefaultFlatFootShiftRpmThreshold:
	.long	1163575296
	.global	_DefaultLaunchControlSpeedMax
	.align 2
	.type	_DefaultLaunchControlSpeedMax, @object
	.size	_DefaultLaunchControlSpeedMax, 4
_DefaultLaunchControlSpeedMax:
	.long	1084227584
	.global	_DefaultLaunchControlCut
	.align 2
	.type	_DefaultLaunchControlCut, @object
	.size	_DefaultLaunchControlCut, 4
_DefaultLaunchControlCut:
	.long	1165623296
	.global	_DefaultLaunchControlHyst
	.align 2
	.type	_DefaultLaunchControlHyst, @object
	.size	_DefaultLaunchControlHyst, 4
_DefaultLaunchControlHyst:
	.long	1112014848
	.global	_DefaultFlatFootShiftMode
	.align 2
	.type	_DefaultFlatFootShiftMode, @object
	.size	_DefaultFlatFootShiftMode, 1
_DefaultFlatFootShiftMode:
	.byte	1
	.global	_DefaultFlatFootShiftAutoDelta
	.align 2
	.type	_DefaultFlatFootShiftAutoDelta, @object
	.size	_DefaultFlatFootShiftAutoDelta, 4
_DefaultFlatFootShiftAutoDelta:
	.zero	4
	.global	_GearRatios
	.align 2
	.type	_GearRatios, @object
	.size	_GearRatios, 24
_GearRatios:
	.long	1080603705
	.long	1075314688
	.long	1071736947
	.long	1068255674
	.long	1064866677
	.long	1061259575
	.global	_LCMinimumThrottle
	.align 2
	.type	_LCMinimumThrottle, @object
	.size	_LCMinimumThrottle, 4
_LCMinimumThrottle:
	.long	1114636288
	.global	_FFSMinimumThrottle
	.align 2
	.type	_FFSMinimumThrottle, @object
	.size	_FFSMinimumThrottle, 4
_FFSMinimumThrottle:
	.long	1114636288
	.text
.Letext0:
	.file 1 "C:\\Dev\\MerpMod\\MerpMod\\RevLimiterTables.c"
	.file 2 "C:\\Dev\\MerpMod\\MerpMod\\enums.h"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.ualong	0x191
	.uaword	0x2
	.ualong	.Ldebug_abbrev0
	.byte	0x4
	.uleb128 0x1
	.ualong	.LASF26
	.byte	0x1
	.ualong	.LASF27
	.ualong	.Ldebug_line0
	.uleb128 0x2
	.ualong	.LASF28
	.byte	0x4
	.byte	0x2
	.byte	0x35
	.ualong	0x3e
	.uleb128 0x3
	.ualong	.LASF0
	.sleb128 0
	.uleb128 0x3
	.ualong	.LASF1
	.sleb128 1
	.uleb128 0x3
	.ualong	.LASF2
	.sleb128 2
	.uleb128 0x3
	.ualong	.LASF3
	.sleb128 3
	.byte	0
	.uleb128 0x4
	.byte	0x2
	.byte	0x5
	.ualong	.LASF4
	.uleb128 0x4
	.byte	0x4
	.byte	0x4
	.ualong	.LASF5
	.uleb128 0x5
	.byte	0x4
	.byte	0x5
	.string	"int"
	.uleb128 0x4
	.byte	0x4
	.byte	0x5
	.ualong	.LASF6
	.uleb128 0x4
	.byte	0x4
	.byte	0x7
	.ualong	.LASF7
	.uleb128 0x4
	.byte	0x1
	.byte	0x6
	.ualong	.LASF8
	.uleb128 0x4
	.byte	0x1
	.byte	0x8
	.ualong	.LASF9
	.uleb128 0x4
	.byte	0x4
	.byte	0x7
	.ualong	.LASF10
	.uleb128 0x6
	.ualong	0x45
	.ualong	0x86
	.uleb128 0x7
	.ualong	0x5a
	.byte	0x5
	.byte	0
	.uleb128 0x8
	.ualong	.LASF11
	.byte	0x1
	.byte	0x25
	.ualong	0x76
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_GearRatios
	.uleb128 0x8
	.ualong	.LASF12
	.byte	0x1
	.byte	0x2a
	.ualong	0x45
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_FFSMinimumThrottle
	.uleb128 0x8
	.ualong	.LASF13
	.byte	0x1
	.byte	0x29
	.ualong	0x45
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_LCMinimumThrottle
	.uleb128 0x8
	.ualong	.LASF14
	.byte	0x1
	.byte	0x17
	.ualong	0x68
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_DefaultRevLimMode
	.uleb128 0x8
	.ualong	.LASF15
	.byte	0x1
	.byte	0x23
	.ualong	0x68
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_DefaultFlatFootShiftMode
	.uleb128 0x8
	.ualong	.LASF16
	.byte	0x1
	.byte	0x18
	.ualong	0x45
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_DefaultRedLineCut
	.uleb128 0x8
	.ualong	.LASF17
	.byte	0x1
	.byte	0x19
	.ualong	0x45
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_DefaultRedLineHyst
	.uleb128 0x8
	.ualong	.LASF18
	.byte	0x1
	.byte	0x1e
	.ualong	0x45
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_DefaultLaunchControlSpeedMax
	.uleb128 0x8
	.ualong	.LASF19
	.byte	0x1
	.byte	0x1f
	.ualong	0x45
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_DefaultLaunchControlCut
	.uleb128 0x8
	.ualong	.LASF20
	.byte	0x1
	.byte	0x20
	.ualong	0x45
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_DefaultLaunchControlHyst
	.uleb128 0x8
	.ualong	.LASF21
	.byte	0x1
	.byte	0x24
	.ualong	0x45
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_DefaultFlatFootShiftAutoDelta
	.uleb128 0x8
	.ualong	.LASF22
	.byte	0x1
	.byte	0x1b
	.ualong	0x45
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_DefaultFlatFootShiftStaticDelta
	.uleb128 0x8
	.ualong	.LASF23
	.byte	0x1
	.byte	0x1a
	.ualong	0x45
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_DefaultFlatFootShiftHyst
	.uleb128 0x8
	.ualong	.LASF24
	.byte	0x1
	.byte	0x1c
	.ualong	0x45
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_DefaultFlatFootShiftSpeedThreshold
	.uleb128 0x8
	.ualong	.LASF25
	.byte	0x1
	.byte	0x1d
	.ualong	0x45
	.byte	0x1
	.byte	0x5
	.byte	0x3
	.ualong	_DefaultFlatFootShiftRpmThreshold
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x10
	.uleb128 0x6
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x4
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x28
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x1c
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x8
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0xc
	.uleb128 0x2
	.uleb128 0xa
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.ualong	0x14
	.uaword	0x2
	.ualong	.Ldebug_info0
	.byte	0x4
	.byte	0
	.uaword	0
	.uaword	0
	.ualong	0
	.ualong	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF2:
	.string	"RevLimModeSparkCut"
.LASF14:
	.string	"DefaultRevLimMode"
.LASF13:
	.string	"LCMinimumThrottle"
.LASF17:
	.string	"DefaultRedLineHyst"
.LASF0:
	.string	"RevLimModeUndefined"
.LASF22:
	.string	"DefaultFlatFootShiftStaticDelta"
.LASF24:
	.string	"DefaultFlatFootShiftSpeedThreshold"
.LASF11:
	.string	"GearRatios"
.LASF18:
	.string	"DefaultLaunchControlSpeedMax"
.LASF28:
	.string	"RevLimModeValues"
.LASF9:
	.string	"unsigned char"
.LASF8:
	.string	"char"
.LASF16:
	.string	"DefaultRedLineCut"
.LASF6:
	.string	"long int"
.LASF26:
	.string	"GNU C 4.7-GNUSH_v13.01"
.LASF25:
	.string	"DefaultFlatFootShiftRpmThreshold"
.LASF10:
	.string	"long unsigned int"
.LASF3:
	.string	"RevLimModeComboCut"
.LASF21:
	.string	"DefaultFlatFootShiftAutoDelta"
.LASF19:
	.string	"DefaultLaunchControlCut"
.LASF20:
	.string	"DefaultLaunchControlHyst"
.LASF12:
	.string	"FFSMinimumThrottle"
.LASF27:
	.string	"C:\\Dev\\MerpMod\\MerpMod\\RevLimiterTables.c"
.LASF5:
	.string	"float"
.LASF4:
	.string	"short int"
.LASF23:
	.string	"DefaultFlatFootShiftHyst"
.LASF7:
	.string	"sizetype"
.LASF1:
	.string	"RevLimModeFuelCut"
.LASF15:
	.string	"DefaultFlatFootShiftMode"
	.ident	"GCC: (GNU) 4.7-GNUSH_v13.01"
